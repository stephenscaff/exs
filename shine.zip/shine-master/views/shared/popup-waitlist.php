<?php
/**
 * Signup Popup
 * Features Mailchimp API JS
 *
 * @author    Stephen Scaff
 * @package   modules
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$signup_img['url'] = 'http://localhost/shine/wp-content/uploads/2019/04/qtr-distiller.jpg';

?>

<section id="popup-waitlist" class="popup" aria-hidden="true">
  <button class="popup__close js-close-popup" aria-label="Close">
    <div class="popup__x close-x is-white"></div>
  </button>

  <section class="modal is-signup">
    <div class="modal__col has-bg">
      <figure class="modal__bg" style="background-image: url(<?php echo $signup_img['url']; ?>)"></figure>
    </div>
    <div class="modal__col">
      <div class="modal__content">
        <h3 class="modal__title">Add to Waitlist</h3>
        <div class="waitlist-embed">
        <script id="wlme_inclscript" src="https://www.waitlist.me/load_widget/?wg=9899410081"></script>

        </div>
      </div>
    </div>
  </section>
</section>
