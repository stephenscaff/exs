<?php
/**
 * Views/Shared/Header
 * Main site/app header and nav section.
 *
 * @author    Stephen Scaff
 * @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$company_address   = get_field('company_mail_address', 'option');
$company_phone     = get_field('company_phone', 'option');
$company_fb        = get_field('company_facebook', 'option');
$company_twitter   = get_field('company_twitter', 'option');
$company_instagram = get_field('company_instagram', 'option');
$company_youtube   = get_field('company_youtube', 'option');

?>

<header class="app-header">
  <div class="app-header__wrap">
    <a class="app-header__brand" href="<?php echo get_page_url('home'); ?>">
      <?php echo get_svg('brand-logo'); ?>
    </a>

    <a href="tel:<?php echo format_tel_link($company_phone); ?>" class="app-header__tel"><?php echo $company_phone; ?></a>

    <address class="app-header__address">
      <?php echo format_lines($company_address, 'span'); ?>
    </address>

    <a class="app-header__link-hours">Hours</a>

    <hr class="app-header__sep"/>

    <nav class="app-header__nav">
      <a class="app-header__link" href="<?php echo get_page_url('menu'); ?>">Menu</a>
      <a class="app-header__link" href="<?php echo get_page_url('distillery'); ?>">Distillery</a>
      <a class="app-header__link" href="<?php echo get_page_url('story'); ?>">Story</a>
      <a class="app-header__link" href="<?php echo get_page_url('contact'); ?>">Contact</a>
    </nav>

    <a class="btn is-to-white is-waitlist-btn"
       data-popup="popup-waitlist"
       href="JavaScript:void(0);">
        <span class="btn__text">Waitlist</span>
        <div class="btn__stroke is-outter"></div>
        <div class="btn__stroke is-inner"></div>
      </div>
    </a>

    <a
      class="btn-line is-grey is-newsletter-btn"
      data-popup="popup-signup"
      href="JavaScript:void(0);">
      Newsletter
    </a>

    <footer class="app-header__footer">
      <nav class="app-header__socials">
        <?php if ($company_fb) : ?><a class="app-header__social" href="<?php echo $company_fb; ?>"><i class="icon-facebook-sq"></i></a><?php endif; ?>
        <?php if ($company_twitter) : ?><a class="app-header__social" href="<?php echo $company_twitter; ?>"><i class="icon-twitter"></i></a><?php endif; ?>
        <?php if ($company_instagram) : ?><a class="app-header__social" href="<?php echo $company_instagram; ?>"><i class="icon-instagram"></i></a><?php endif; ?>
        <?php if ($company_youtube) : ?><a class="app-header__social" href="<?php echo $company_youtube; ?>"><i class="icon-youtube"></i></a><?php endif; ?>
      </nav>

      <span class="app-header__copyright">&copy; <?php echo date("Y"); ?> Shine Distillery & Grill</span>
    </footer>
  </div>
</header>

<header class="app-header-sm">
  <div class="grid-xl">
    <div class="app-header-sm__grid">
      <a class="app-header-sm__brand" href="<?php echo get_page_url('home'); ?>">
        <?php echo get_svg('shine-monogram'); ?>
      </a>
      <button class="menu-toggle js-menu-toggle" arial-label="Menu">
        <div class="menu-toggle__bars"></div>
      </button>
    </div>
  </div>
</header>
