<?php
/**
 * Views/Shared/Header
 * Main site/app header and nav section.
 *
 * @author    Stephen Scaff
 * @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$company_address   = get_field('company_mail_address', 'option');
$company_phone     = get_field('company_phone', 'option');
$company_fb        = get_field('company_facebook', 'option');
$company_twitter   = get_field('company_twitter', 'option');
$company_instagram = get_field('company_instagram', 'option');
$company_youtube   = get_field('company_youtube', 'option');

?>
<section class="app-menu-sm">
  <nav class="app-menu-sm__nav">
    <a class="app-menu-sm__link" href="<?php echo get_page_url('menu'); ?>"><span>Menu</span></a>
    <a class="app-menu-sm__link" href="<?php echo get_page_url('distillery'); ?>"><span>Distillery</span></a>
    <a class="app-menu-sm__link" href="<?php echo get_page_url('story'); ?>"><span>Story</span></a>
    <a class="app-menu-sm__link" href="<?php echo get_page_url('contact'); ?>"><span>Contact</span></a>

    <div class="app-menu-sm__link-wrap"><a class="btn is-alpha is-waitlist" href="#"><span>Waitlist</span></a></div>

    <!-- <div class="app-menu-sm__link-wrap"><a class="btn-line is-grey is-newsletter"><span>Newsletter</span></a></div> -->
  </nav>

  <footer class="app-menu-sm__socials">
    <nav class="app-menu-sm__socials">
      <?php if ($company_fb) : ?>
        <a class="app-menu-sm__social" href="<?php echo $company_fb; ?>"><i class="icon-facebook-sq"></i></a>
      <?php endif; ?>
      <?php if ($company_twitter) : ?>
        <a class="app-menu-sm__social" href="<?php echo $company_twitter; ?>"><i class="icon-twitter"></i></a>
      <?php endif; ?>
      <?php if ($company_instagram) : ?>
        <a class="app-menu-sm__social" href="<?php echo $company_instagram; ?>"><i class="icon-instagram"></i></a>
      <?php endif; ?>
      <?php if ($company_youtube) : ?>
        <a class="app-menu-sm__social" href="<?php echo $company_youtube; ?>"><i class="icon-youtube"></i></a>
      <?php endif; ?>
    </nav>
  </footer>

</section>
