<?php
/**
 * Views/Shared/NextRoute
 *
 * Creates a to next page selement
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$next_obj    = get_field('route_selector');
$next        = $next_obj[0];
$next_id     = $next->ID;
$next_title  = get_the_title($next_id);
$next_url    = get_the_permalink($next_id);
$next_img    = get_field('mast_image', $next_id);
$color_theme = get_field('themes', $id);

?>

<section class="next <?php echo $color_theme; ?>">
  <a class="next__link" href="<?php echo $next_url; ?>">
    <figure class="next__figure">
      <div class="next__img" style="background-image: url(<?php echo $next_img['url']; ?>)"></div>
    </figure>
    <header class="next__header">
      <span class="next__pretitle">Up Next</span>
      <h3 class="next__title"><?php echo $next_title; ?></h3>

      <div class="btn is-white">
        <span class="btn__text">Continue</span>
        <div class="btn__stroke is-outter"></div>
        <div class="btn__stroke is-inner"></div>
      </div>
    </header>
  </a>
</section>
