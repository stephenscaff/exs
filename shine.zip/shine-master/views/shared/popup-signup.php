<?php
/**
 * Signup Popup
 * Features Mailchimp API JS
 *
 * @author    Stephen Scaff
 * @package   modules
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$signup_title = get_sub_field('signup_title');
$signup_text  = get_sub_field('signup_text');
$signup_img   = get_sub_field('signup_image');

$signup_img['url'] = 'http://localhost/shine/wp-content/uploads/2019/04/qtr-distiller.jpg';
$signup_title      = 'The Shine Newsletter';
$signup_text       = 'Get some spam-free updates about events and happenings at Shine';

?>

<section id="popup-signup" class="popup" aria-hidden="true">
  <button class="popup__close js-close-popup" aria-label="Close">
    <div class="popup__x close-x is-white"></div>
  </button>

  <section class="modal is-signup">
    <div class="modal__col has-bg">
      <figure class="modal__bg" style="background-image: url(<?php echo $signup_img['url']; ?>)"></figure>
    </div>
    <div class="modal__col">
      <div class="modal__content">
        <h3 class="modal__title"><?php echo $signup_title; ?></h3>
        <p class="modal__subtitle"><?php echo $signup_text; ?></p>

        <form
          action="https://shinedistillerygrill.us20.list-manage.com/subscribe/post?u=1d382e29b9bbfce033c0873cd&amp;id=39ee1fa2b3&c=callback"
          method="post"
          id="mc-signup"
          name="mc-embedded-subscribe-form"
          class="validate"
          validate>

          <div id="js-form-inputs" class="signup__inputs js-form-inputs">
            <div class="input-wrap">
              <input type="email" name="EMAIL" id="mce-EMAIL" value="" placeholder="Email" required>
            </div>
            <div class="input-wrap">
              <input type="text" name="FNAME" id="mce-FNAME" value="" placeholder="First name">
            </div>
            <div class="input-wrap">
              <input type="text" name="LNAME" id="mce-LNAME" value="" placeholder="Last name">
            </div>
            <div style="position: absolute; left: -5000px;" aria-hidden="true">
              <input id="js-validate-robot" type="text" name="b_1d382e29b9bbfce033c0873cd_39ee1fa2b3" tabindex="-1" value="">
            </div>
            <button
              type="submit"
              class="btn is-dark is-block is-submit"
              id="mc-submit"
              value="Subscribe"
              aria-label="Submit"
              >
                <span class="btn__text">Submit</span>
                <div class="btn__stroke is-outter"></div>
                <div class="btn__stroke is-inner"></div>
            </button>
        </form>

        <!-- Signup Message -->
        <div class="signup-message">
          <p id="js-subscribe-response"></p>
        </div>
      </div>
    </div>
  </section>
</section>


<script>
/**
 * MailChimp Signup
 */
(function () {
  if (document.getElementsByTagName('form').length > 0) {
    document.getElementsByTagName('form')[0].addEventListener('submit', function (e) {
      e.preventDefault();

      // Check for spam
      //if(document.getElementById('js-validate-robot').value !== '') { return false }

      // Get url for mailchimp
      var url = this.action.replace('/post?', '/post-json?');

      // Add form data to object
      var data = '';
      var inputs = this.querySelectorAll('#js-form-inputs input');

      for (var i = 0; i < inputs.length; i++) {
        data += '&' + inputs[i].name + '=' + encodeURIComponent(inputs[i].value);
      }

      /**
       * Create/Add post script
       */
      var script = document.createElement('script');

      script.src = url + data;
      document.body.appendChild(script);

      /**
       * Callback Function
       */
      var callback = 'callback';

      window[callback] = function(data) {
        // Remove post script
        delete window[callback];
        document.body.removeChild(script);

        /**
         * Display Message
         */
        document.getElementById('js-subscribe-response').innerHTML = data.msg

        /**
         * On Success
         */
        if (data.result == 'success') {
          setTimeout(function(){
            let popupSignup = document.querySelector('#popup-signup');
            PopUps.close(popupSignup);
          }, 1500);
        }
      };
    });
  }
})();

</script>
