<?php
/**
 * views/modules/content-module
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$title   = get_sub_field('title');
$content = get_sub_field('content');

?>

<section class="content bg-grey-light">
  <div class="grid-sm">

    <?php if ($title) : ?>
      <h1 class="content__title"><?php echo $title; ?></h1>
      <hr class="sep is-full" />
    <?php endif; ?>

    <?php if ($content) : ?>
      <div class="content__excerpt">
        <p><?php echo $content; ?></p>
      </div>
    <?php endif; ?>

  </div>
</section>
