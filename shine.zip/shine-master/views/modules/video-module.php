<?php
/**
 * views/modules/fare-section
 *
 * @author       Karlie Watts
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$youtube_id    = get_sub_field('youtube_id');
$vimeo_id      = get_sub_field('vimeo_id');
$video_caption = get_sub_field('video_caption');

?>

<section class="vid-block bg-grey-light module">
  <div class="grid">
    <div class="max-width-wrap">
      <div class="vid-block-embed flex-vid">
        <iframe
          id="ytplayer"
          type="text/html"

          <?php if ($youtube_id) : ?>
            src="https://www.youtube.com/embed/<?php echo $youtube_id; ?>?modestbranding=1&rel=0&showinfo=0&controls=1&color=white"
          <?php elseif ($vimeo_id) : ?>
            src="https://player.vimeo.com/video/<?php echo $vimeo_id; ?>?color=#C77C4D&title=false&byline=false"
          <?php endif; ?>

          frameborder="0"
          allowfullscreen>
        </iframe>
      </div>
      <p class="vid-block__vid-caption"><?php echo $video_caption; ?></p>
    </div>
  </div>
</section>
