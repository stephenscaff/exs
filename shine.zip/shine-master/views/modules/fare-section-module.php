<?php
/**
 * views/modules/fare-section
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$fare_section    = get_sub_field('fare_section');
$section_title   = get_sub_field('section_title');
$section_details = get_sub_field('section_details');
$fare_items      = get_sub_field('fare_items');
$section_notes  = get_sub_field('section_notes');

?>

<section class="fare-section">
  <header class="fare-section__header">
    <h3 class="fare-section"><?php echo $section_title; ?></h3>
    <?php if ($section_details) : ?>
    <p class="fare-section__details"><?php echo $section_details; ?></p>
    <?php endif; ?>
  </header>

  <hr class="sep is-full" />

  <div class="fare-section__items">
    <?php foreach ($fare_items as $item) :
        $name = $item['name'];
        $description = $item['description'];
        $price = $item['price'];
        $paired_cocktail = $item['paired_cocktail'];
        $half_pad = '';
        if (!$description) $half_pad = 'is-sm';

      ?>
      <div class="fare-item <?php echo $half_pad; ?>">
        <header class="fare-item__header">
          <h5 class="fare-item__name"><?php echo $name; ?></h5>
          <span class="fare-item__price"><span class="currency">$</span><?php echo $price; ?></span>
        </header>
        <?php if ($description) : ?>
          <p class="fare-item__desc"><?php echo $description; ?></p>
        <?php endif; ?>
        <?php if ($paired_cocktail) : ?>
          <span class="fare-item__pairing">
            Paired Cocktail:
            <?php echo $paired_cocktail; ?>
          </span>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <?php if ($section_notes) : ?>
  <footer class="fare-section__footer">
    <?php foreach ($section_notes as $section_note) :
      $notes = $section_note['notes'];
    ?>
    <div class="fare-section__notes">
      <p><?php echo $notes; ?></p>
    </div>
  <?php endforeach; ?>
  </footer>
  <?php endif; ?>
</section>
