<?php
/**
 * views/modules/fulls-module
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$theme       = get_sub_field('themes');
$image       = get_sub_field('image');
$title       = get_sub_field('title');
$content     = get_sub_field('content');
$link        = get_sub_field('button_link');
$url         = get_sub_field('button_url');
$btn_text    = get_sub_field('button_text');
$link_or_url = get_field_fallback($link, $url);
$color_theme = get_sub_field('color_theme');

?>

<section class="full <?php echo $theme; ?>">
  <figure class="full__img" style="background-image: url(<?php echo $image['url']; ?>)"></figure>
  <div class="grid-lg">
    <header class="full__header">
      <h2 class="full__title font-title-sm"><?php echo $title; ?></h2>
      <hr class="sep is-centered is-white">
      <p class="full__text"><?php echo $content; ?></p>

      <?php if ($link_or_url) : ?>
      <a class="btn is-white" href="<?php echo $link_or_url; ?>"><?php echo $btn_text; ?></a>
      <?php endif; ?>
    </header>
  </div>
</section>
