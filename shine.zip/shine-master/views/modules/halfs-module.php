<?php
/**
 * views/modules/halfs-module
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$theme       = get_sub_field('themes');
$svg         = get_sub_field('svgs');
$direction   = get_sub_field('direction');
$image       = get_sub_field('image');
$title       = get_sub_field('title');
$content     = get_sub_field('content');
$link        = get_sub_field('button_link');
$url         = get_sub_field('button_url');
$btn_text    = get_sub_field('button_text');
$link_or_url = get_field_fallback($link, $url);
$classes     = chain_classes([$theme, $direction]);

?>

<section class="halfs <?php echo $classes; ?>">
  <div class="grid-full">
    <div class="halfs__grid">
      <figure class="halfs__figure has-svg">
        <div class="halfs__img" style="background-image: url(<?php echo $image['url']; ?>)"></div>
        <?php echo get_svg($svg); ?>
      </figure>
      <div class="halfs__main">
        <div class="halfs__content">
          <h2 class="halfs__title font-title-sm"><?php echo $title; ?></h2>
          <hr class="sep is-centered">
          <p class="halfs__text"><?php echo $content; ?></p>

          <?php if ($link_or_url) : ?>
            <a class="btn is-dark" href="<?php echo $link_or_url; ?>">
                <span class="btn__text"><?php echo $btn_text; ?></span>
                <div class="btn__stroke is-outter"></div>
                <div class="btn__stroke is-inner"></div>
              </div>
            </a>
          <?php endif; ?>
      </div>
    </div>
  </div>
</section>
