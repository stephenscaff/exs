# Shine Distillery PDX

## A wp build for Shine.

Shine is built atop the Jumpoff - a fairly opinionated starter for custom Wordpress development. It's a platform for beginning web projects that moves away from the interchangeable theme / child theme approach.

Additionally, the Jumpoff aims to reduce over-reliance on 3rd party plugins by baking project features and settings into the theme (via an `inc` directory).

### Features

- Gulp for task running
- A lightweight front-end framework of sorts, with sensible scss/js structuring and a js includes system (see src/assets/js/app.js),
- ES6 Modules via Babel and Browserify, `assets/js/app.js` serving as the entry point.
- Organization by views and components
- A php approach to field management via ACF and Stout Logic's ACF Builder
- Custom drag and drop modules for content authorship
- Custom Admin theme (styles and functionality)
- A small library of useful utilities/helpers

### Dependencies
- [Node](https://nodejs.org/en/download/) : to run `gulp`.
- [NPM](https://www.npmjs.com/get-npm) : also to run `gulp`.
- [Gulp](https://gulpjs.com/) : for compiling, minimizing and linting scss, js, svgs, images, etc.
- [SCSS/SASS](https://sass-lang.com/) : for css authorship.
- [WordPress](https://wordpress.org/) : This is a custom Wordpress build
- [ACF](https://www.advancedcustomfields.com/pro/) : For managing fields, metas, options, etc.
- [StoutLogic ACF Builder](https://github.com/StoutLogic/acf-builder) : A more sane way to register ACF fields within PHP utils

### Run

Install Gulp

```
npm install gulp
```

Install Gulp dependencies

```
npm i -D
````

Install Composer dependencies

```
composer install
```


### Composer

Currently Composer is just installing StoutLogic's ACF Builder.

Make sure to run composer first, or the theme can't locate autoload and you'll see a custom error.


### CSS / JS

As much as possible, css and js is organized by component, named after it's usage / BEM naming convention. JS files are loaded via es6 modules using Browserify and Babel.


### Fields

This build uses ACF for Fields, but actual field authorship is enhanced with [Stout Logic's ACF Builder](https://github.com/StoutLogic/acf-builder).

Stout Logic provides a fluent API for rapidly creating and configuring ACF Fields in PHP, using a really nice builder pattern. It's a more robust solution than `acf-json` in actual practice.

A full cheatsheet on the available fields and their params can be found here:

[Stout Logic's ACF Builder Cheat Sheet](https://gist.github.com/stephenscaff/7eaf497fa01bea5b9b5a939539412b2c)


### Creating Fields

Here's an example of creating fields:

```

/**
 * Fields - SEO
 * Location: Pages, posts, Team post type.
 */
$seo_fields = new StoutLogic\AcfBuilder\FieldsBuilder('seo');

$seo_fields
  ->addText('seo_title')
  ->addTextArea('seo_description',  [
    'rows' =>  '2'
  ])
  ->addImage('seo_image')
  ->setLocation('post_type', '==', 'page')
           ->or('post_type', '==', 'post')
           ->or('post_type', '==', 'team');

add_action('acf/init', function() use ($seo_fields) {
   acf_add_local_field_group($seo_fields->build());
});
```

All Fields are registered in `inc/fields/*`, generally in their own clearly named file. Variables for reuse are housed in `inc/fields/vars.php` and modules are stored in `inc/fields/modules/*`


### Setting Field Locations
`
You can set the locations of field groups with the `->setLocation()` and `->or()` methods.

```
// Set to a page template
->setLocation('page_template', '==', 'templates/home.php')

// Set to a post type
->setLocation('post_type', '==', 'work');

// Set to a page (uses get_id_by_name() helper)
->setLocation('page', '==', get_id_by_name('about'));

// Options page or Post Type Index page
->setLocation('options_page', '==', 'work-index');

// Chaining Locations
->setLocation('page', '==', get_id_by_name('home'))
         ->or('page', '==', get_id_by_name('about'))
         ->or('page_template', '==', 'templates/single-column.php')
         ->or('options_page', '==', 'careers-index')
         ->or('post_type', '==', 'work');

```

### Modules

Jumpoff uses ACF's Flexible content fields to create a drag-and-drop module system.

A custom class (`inc/Acf/AcfModules.php`) further enhances flexible content fields by mapping them by name to files within the `views/modules` directory.

Calling the Modules in a template

```
while (has_sub_field('modules')) :
  ACF_Modules::render(get_row_layout());
endwhile;
```


### INC

Site functionality is generally added in the `inc` folder, as oppose to plugins and whatnot.
Take a run through this directory to see what options and helpers available.


### Debugging

The jumpoff has 2 debugger utilities located in `inc/Utils/Debuggers`

```
# Simple debugger with formatted output.
jumpoff_dump($foo)


# JS Console Debugger
jumpoff_dump_js($data)

# JSON Formater
jumpoff_format_json($data)

```
