import "@babel/polyfill";
import './components/Sniffers'
import './components/HighwayTransitions'
import MenuSmall from './components/MenuSmall'
import HashTabs from './components/HashTabs'
import InView from './components/InView'
import PopUps from './components/PopUps'
import * as Map from './components/Map'


MenuSmall.init()
HashTabs.init()
InView.init()
PopUps.init()

if (document.querySelector('.js-location-map')) {
  Map.LocationMap('.js-location-map');
}
