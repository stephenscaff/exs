export const stylers = {

  /**
   * Map Styler JSON
   */
  styles: [
    {
        "featureType": "all",
        "elementType": "labels.text.fill",
        "stylers": [
            {
                "saturation": 36
            },
            {
                "color": "#000000"
            },
            {
                "lightness": 40
            }
        ]
    },
    {
        "featureType": "all",
        "elementType": "labels.text.stroke",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "color": "#000000"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "all",
        "elementType": "labels.icon",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 17
            },
            {
                "weight": 1.2
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "labels",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative.country",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "simplified"
            }
        ]
    },
    {
        "featureType": "administrative.country",
        "elementType": "geometry",
        "stylers": [
            {
                "visibility": "simplified"
            }
        ]
    },
    {
        "featureType": "administrative.country",
        "elementType": "labels.text",
        "stylers": [
            {
                "visibility": "simplified"
            }
        ]
    },
    {
        "featureType": "administrative.province",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative.locality",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "simplified"
            },
            {
                "saturation": "-100"
            },
            {
                "lightness": "30"
            }
        ]
    },
    {
        "featureType": "administrative.neighborhood",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative.land_parcel",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "simplified"
            },
            {
                "gamma": "0.00"
            },
            {
                "lightness": "74"
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "landscape.man_made",
        "elementType": "all",
        "stylers": [
            {
                "lightness": "3"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "featureType": "road",
        "elementType": "geometry",
        "stylers": [
            {
                "visibility": "simplified"
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 17
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 29
            },
            {
                "weight": 0.2
            }
        ]
    },
    {
        "featureType": "road.arterial",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 18
            }
        ]
    },
    {
        "featureType": "road.local",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "transit",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 19
            }
        ]
    },
    {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#000000"
            },
            {
                "lightness": 17
            }
        ]
    }
],

     /**
      * Map Icon/Pin SVG
      * SVG is base64 encoded.
      */
     icons: {
       gold: 'data:image/svg+xml;base64,PHN2ZyBjbGFzcz0iZ3BzLW1hcmtlciIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB2aWV3Qm94PSIwIDAgMzIgNDAiPiAgPHBhdGggZmlsbD0iI0M3N0M0RCIgZD0iTTE4LjcgMTcuOWMtLjQtLjYtMS4zLS45LTQtMS40LTEuMi0uMi0yLjYtLjgtMy4xLTEuMi0uMi0uMi0uMy0uMS0uMS4xLjUuNyAxLjcgMS4zIDMuMSAxLjUgMi42LjUgMy42LjcgNCAxLjEuMy4zLjMuMy4xLS4xek0xMy43IDE0LjNjLjIuMS40LjEuMiAwLS40LS4yLS44LS43LS44LTEuMiAwLTEgLjctMS42IDIuNS0xLjYgMS40IDAgMi45LjUgMy4zLjcuNC4xLjQuMSAwLS4yLS40LS4zLTEuOC0uOS0zLjMtLjktMi4yIDAtMi45LjgtMi45IDIuMS0uMS41LjQgMSAxIDEuMXoiLz4gIDxwYXRoIGZpbGw9IiNDNzdDNEQiIGQ9Ik0yMCAxNi4xYy0uNC0uMi0uNS0uMi0uMS4yLjUuNCAxLjEgMSAxLjEgMi42IDAgMi0xLjYgMy44LTUgMy44LTIgMC0zLjYtLjYtNC42LTEuNC0uNC0uMy0uNC0uMi0uMS4xLjkuOSAyLjYgMS43IDQuNyAxLjcgMy43IDAgNS40LTIgNS40LTQuMiAwLTEuNy0uNy0yLjQtMS40LTIuOHpNMjAuNyAxM2wtLjQtMi43aC0uNGwuMyAyLjR6Ii8+ICA8cGF0aCBmaWxsPSIjQzc3QzREIiBkPSJNMTYgMy41Yy02LjcgMC0xMiA1LjQtMTIgMTIgMCA2LjcgMTIgMjEgMTIgMjFzMTItMTQuMyAxMi0yMWMwLTYuNi01LjMtMTItMTItMTJ6bTAgMjAuMmMtNC4xIDAtNi0yLjEtNi00LjEgMC0xLjcgMS40LTIuMSAxLjQtMi4xLjMgMS42IDIuMyAyLjkgNS4xIDIuOSAxLjQgMCAyLS40IDItMS4xIDAtMS4xLTEuMy0xLjMtNC4xLTEuOC0zLjEtLjUtNC4zLTItNC4zLTQuMSAwLS44LjItMS42LjctMi4yLjItLjIuMy0uNS4zLS44VjEwbC4xLTFjMC0uMS4xLS4xLjIgMCAuMi4zLjUuNy45LjcuMyAwIC42LS4xIDEtLjIuNi0uMiAxLjQtLjMgMi4yLS4zIDIuMyAwIDMuNi42IDQuMy42LjQgMCAuNy0uNC45LS43IDAtLjEuMi0uMS4yIDBsLjEgMS4xLjQgMy44LS4yLjFjLTEuMy0xLjItMy45LTItNS42LTItMS41IDAtMS44LjUtMS44IDEuMSAwIC43IDEgMSAzLjggMS41IDMuNC42IDQuNiAyLjEgNC42IDQuMy0uMiAyLjUtMiA0LjctNi4yIDQuN3oiLz48L3N2Zz4='
  }
};
