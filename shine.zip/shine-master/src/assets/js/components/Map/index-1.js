import GoogleMapsApi from './GoogleMapsApi';
import { stylers }   from './stylers';
import markerTmpl from './marker.tmpl';

/**
 * Init Property Map
 * Main map rendering function that uses our GMaps API class
 */
export function LocationMapInit() {

  const gmapApi = new GoogleMapsApi();
  const mapEl   = document.querySelector('.js-location-map');
  const data    = locationData; // global var from page

  gmapApi.load().then(() => {
    renderMap(mapEl, data)
 })
}

/**
 * Render Map
 * @param {map obj} mapEl - Google Map
 * @param {obj} data - map data
 */
export function renderMap(mapEl, data) {

  let lat = parseFloat(data.lat)
  let lng = parseFloat(data.lng)

  const options = {
    mapTypeId: google.maps.MapTypeId.ROADMAP,
    styles:    stylers.styles,
    center:    { lat: lat, lng: lng },
    zoom:      14
  }

  /**
   * Google map instance
   * @type {Map}
   */
  const map = new google.maps.Map(mapEl, options)

  const icon = {
    url:        stylers.icons.gold,
    scaledSize: new google.maps.Size(80, 80)
  }

  const tmpl = markerTmpl(data)

  const marker = new google.maps.Marker({
    position:  new google.maps.LatLng(lat, lng),
    map:       map,
    icon:      icon,
    title:     'Shine Distillery & Grill',
    animation: google.maps.Animation.DROP,
    content:   tmpl
  })

  const infowindow = new google.maps.InfoWindow()

  handleMarkerClick(map, marker, infowindow)
}

/**
 * Handle Marker Click
 *
 * @param {map obj} mapEl
 * @param {marker} marker
 * @param {infowindow} infoWindow
 */
export function handleMarkerClick(map, marker, infowindow) {

  google.maps.event.addListener(marker, 'click', function() {
    infowindow.setContent(marker.content);
    infowindow.open(map, marker);
  });

  google.maps.event.addListener(map, 'click', function(event) {
    if (infowindow) {
      infowindow.close(map, infowindow);
    }
  });
}
