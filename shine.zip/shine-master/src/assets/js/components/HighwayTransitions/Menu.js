
/**
 * Handle Menu Active Class
 */
export default function Menu(location) {
  const links = document.querySelectorAll('.app-header__nav a')

  for (let i = 0; i < links.length; i++) {
    const link = links[i]

    link.classList.remove('is-active')

    if (link.href === location.href) {
      link.classList.add('is-active')
    }
  }
}
