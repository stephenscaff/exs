import Highway from '@dogstudio/highway';
import Fade from './Fade.js';
import Seo from './Seo.js'
import Menu from './Menu.js'
import Inits from './Inits.js'

const H = new Highway.Core({
  transitions: {
    default: Fade
  }
});

/**
 * NAVIGATE_IN event
 * This event is sent everytime a `data-router-view` is added to the DOM Tree
 */
H.on('NAVIGATE_IN', ({ to, location }) => {

  Seo(to, location)
  Menu(location)
  document.body.classList = to.page.body.classList
});

/**
 * Navigate End Inits
 */
H.on('NAVIGATE_END', ({ to, from, trigger, location }) => {
  Inits()
})
