import Utils from '../components/Utils.js'
/**
 * PopUps
 * @author stephen scaff
 * @todo   Vimeo player was baked in. But, have been using plyr.js, so should remove Vimeo stuff.
 */
 const PopUps = (() => {

  let html = document.querySelector('html'),
      popUps = document.querySelectorAll('[data-popup]'),
      closeLinks = document.querySelectorAll('.js-close-popup'),
      popUpVid = document.querySelectorAll('.js-popup-vid');

  let isOpen = false,
      isVimeo = false,
      isVideo = false,
      vid = '';

    if (popUpVid.length) {
      var popUpPlayer = new Plyr('.js-popup-vid', {});
      isVideo = true;
    }

  return{

    /**
     * Init
     */
    init(){
      html = document.querySelector('html'),
      popUps = document.querySelectorAll('[data-popup]'),
      closeLinks = document.querySelectorAll('.js-close-popup'),
      popUpVid = document.querySelectorAll('.js-popup-vid');
      this.bindEvents();
    },

    /**
     * Bind Events
     */
    bindEvents() {
      Utils.forEach ( popUps, function (index, popUp) {
        PopUps.checkVideos(popUp);

        // Main Click EVent
        popUp.addEventListener('click', function(e) {
          e.preventDefault();
          console.log('clicked popup')
          let targetPopup = popUp.dataset.popup;
          let targetPopupId = document.querySelector('#' + targetPopup);

          PopUps.open(targetPopupId);

          if (isVimeo) PopUps.playVimeoVideo(popUp, targetPopupId, vidWrap);

          if (isOpen = false) {
            return;
          } else {
            Utils.forEach ( closeLinks, function (index, closeLink) {
              closeLink.addEventListener('click', function(e) {
                e.preventDefault();
                PopUps.close(targetPopupId);
                if (isVideo) PopUps.stopVideo(vid);
              });
            });
            window.onkeydown = function(e) {
              if (e.keyCode === 27 && isOpen) {
                PopUps.close(targetPopupId);
                if (isVimeo) PopUps.stopVimeoVideo(targetPopupId, vidWrap);
                if (isVideo) PopUps.stopVideo(vid);
              }
            }
          }
        });
      });
    },

    /**
     * Is Video/Vimeo CHeck
     */
    checkVideos(popUp) {
      if (popUp.hasAttribute('data-vimeo-id') ) {
        isVimeo = true;
      }
      // if (popUp.classList.contains('has-video')) {
      //   isVideo = true;
      // }
    },

    /**
     * Open Modal
     */
    open(el){
      html.classList.remove('popup-is-closed');
      html.classList.add('popup-is-opening');
      el.classList.remove('is-closed');
      el.classList.add('is-open');

      if (isVideo) PopUps.playVideo();

      setTimeout(function(){
        html.classList.remove('popup-is-opening');
        html.classList.add('popup-is-open');
        isOpen = true;
      }, 200);
    },

    /**
     * Close Modal
     */
    close(el){
      html.classList.add('popup-is-closing');
      el.classList.add('is-closing');

      if (isVideo) PopUps.stopVideo();

      setTimeout(function(){
        html.classList.remove('popup-is-open');
        el.classList.remove('is-open');
        html.classList.remove('popup-is-closing');
        html.classList.add('popup-is-closed');
        el.classList.remove('is-closing');
        el.classList.add('is-closed');

        isOpen = false;
      }, 1000);
    },

    /**
     * Play Video
     * Vid is Plyr object
     */
     playVideo() {
       popUpPlayer.play();
     },

     /**
      * Stop Vid
      * Vid is Plyr object
      */
     stopVideo() {
       popUpPlayer.stop();
     },

    /**
     * Play Vimeo Video
     * Launched Vimeo vid in wrapper via api call
     */
    playVimeoVideo(popUp, targetPopupId, vidWrap) {

      var vimeoID = popUp.dataset.vimeoId,
          vimeoColor = popUp.dataset.vimeoColor
          vimeoPlayer = 'https://player.vimeo.com/video/',
          vimeoApi =    'http://www.vimeo.com/api/oembed.json?url=',
          vimeoPlayerId = vimeoPlayer + vimeoID,
          vimeoRequest = vimeoApi + encodeURIComponent(vimeoPlayerId) + '&color=' + vimeoColor + '&autoplay=1&callback=?';

      Util.loadJSONP(vimeoRequest, function(data) {
        console.log(data);
        vidWrap.innerHTML = unescape(data.html);
      });
    },


    /**
     * Stop Vid
     */
    stopVimeoVideo(targetPopupId, vidWrap) {
      while(vidWrap.firstChild) {
        vidWrap.removeChild(vidWrap.firstChild);
      }
    },
  };
 })();


window.PopUps = PopUps;
export default PopUps;
