<?php
/**
 * Single
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

include(locate_template( 'views/post/archive.php' ) );
