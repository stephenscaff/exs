<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


require_once('AdminSetup.php');
require_once('AdminEditors.php');
require_once('AdminDash/CustomDash.php');
require_once('FeaturedImageCol.php');
require_once('PostDuplicator.php');
require_once('PostOrdering/PostOrdering.php');
