<?php

/**
 *  Admin Dash View
 *
 *
 *  @version    1.0
 *  @see        admin-dash.php
 *  @see        admin/admin-theme/assets (for styles)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

# Wp admin bootstrap
require_once( ABSPATH . 'wp-load.php' );
require_once( ABSPATH . 'wp-admin/admin.php' );
require_once( ABSPATH . 'wp-admin/admin-header.php' );

?>

<section class="dash">

  <header class="dash-header">
    <h1 class="dash-header__title">Welcome to Your Site</h1>
    <p class="dash-header__text">From here you can create and manage the contetn and font-end experience of your site.</p>
    <p class="dash-header__text">  <a class="" href="<?php echo site_url( '' ); ?>" target="_blank">Launch Homepage</a></p>
  </header>

  <section class="dash-cards">

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'admin.php?page=hours' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-time-o"></i>

          <h3 class="dash-card__title">Hours</h3>

          <p class="dash-card__text">Manage Open Hours</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'admin.php?page=alerts' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-alert-bell-add"></i>

          <h3 class="dash-card__title">Alert</h3>

          <p class="dash-card__text">Post an Alert on the Homepage</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'post.php?post=43&action=edit' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-pizza"></i>

          <h3 class="dash-card__title">Menu</h3>

          <p class="dash-card__text">Create and manage Success Stories</p>

        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'post.php?post=4&action=edit' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-pages"></i>

          <h3 class="dash-card__title">Homepage</h3>

          <p class="dash-card__text">Manage Homepage Content.</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'post.php?post=12&action=edit' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-pages"></i>

          <h3 class="dash-card__title">Distillery</h3>

          <p class="dash-card__text">Manage the Distillery Page Content.</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'post.php?post=78&action=edit' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-pages"></i>

          <h3 class="dash-card__title">Contact</h3>

          <p class="dash-card__text">Manage the Contact Page Content.</p>
        </div>
      </a>
    </article>




  </section>
</section>

<?php //include( ABSPATH . 'wp-admin/admin-footer.php' );
