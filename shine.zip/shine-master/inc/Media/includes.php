<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once('ImageSettings.php');
require_once('MaxUploadSize.php');
require_once('featuredImage.php');
