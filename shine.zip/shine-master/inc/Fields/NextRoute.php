<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Next Route
 * Selector to show next route at bottom of a page.
 */
$next_route = new StoutLogic\AcfBuilder\FieldsBuilder(
  'next_route', ['menu_order' => '99']
);

$next_route
  ->addRelationship('route_selector',
    [
      'post_type'	    => array('page'),
      'filters'       => array('search', '', ''),
      'max'           => 1,
    ]
  )
  ->setLocation('post_type', '==', 'page');

add_action('acf/init', function() use ($next_route) {
   acf_add_local_field_group($next_route->build());
});
