<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Hours
 */
$hours = new StoutLogic\AcfBuilder\FieldsBuilder('hours');

$hours
  ->addRepeater('hour_items', [
    'button_label' => 'Add item',
    'layout' => 'block',
  ])
    ->addText('day', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('time', [
      'wrapper' =>  ['width' => '50%']
    ])
  ->endRepeater()
  ->setLocation('options_page', '==', 'hours');

add_action('acf/init', function() use ($hours) {
   acf_add_local_field_group($hours->build());
});
