<?php
/**
 * Modules
 */
if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Modules (primary)
 */
$modules= new FieldsBuilder('modules', [
  'key'        => 'group_modules',
  'menu_order' => '2',
]);

$modules
  ->addFlexibleContent('modules',
    ['button_label'=> 'Add Module']
  )
  ->addLayout($content_module,
    ['name'=> 'content_module']
  )
  ->addLayout($gallery_module,
    ['name'=> 'gallery_module']
  )
  ->addLayout($halfs_module,
    ['name'=> 'halfs_module']
  )
  ->addLayout($fulls_module,
    ['name'=> 'fulls_module']
  )
  ->addLayout($team_module,
    ['name'=> 'team_module']
  )
  ->addLayout($video_module,
    ['name'=> 'video_module']
  )
  ->setLocation('page_template', '==', 'templates/modules.php')
           ->or('page_template', '==', 'templates/home.php');

  add_action('acf/init', function() use ($modules) {
     acf_add_local_field_group($modules->build());
  });


/**
 * Fare / Menu Modules
 */
  $fare_modules= new FieldsBuilder('fare_modules', [
    'key'        => 'group_fare_modules',
    'menu_order' => '1',
  ]);

  $fare_modules
    ->addFlexibleContent('modules',
      ['button_label'=> 'Add Module']
    )
    ->addLayout($fare_section_module,
      ['name'=> 'fare_section_module']
    )
    ->setLocation('post_type', '==', 'fare');

    add_action('acf/init', function() use ($fare_modules) {
      acf_add_local_field_group($fare_modules->build());
    });
