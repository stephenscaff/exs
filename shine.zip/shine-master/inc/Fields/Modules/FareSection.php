<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Menu Section Module
 * @see views/modules/halfs-module.php
 * @see scss/components/_halfs.scss
 */
$fare_section_module = new FieldsBuilder('fare_section');
$fare_section_module
  ->addMessage('', 'The Menu Section Module creates a new menu section to add menu items')
  ->addText('section_title')
  ->addTextArea('section_details',
    ['rows' =>  '3']
  )
  ->addRepeater('fare_items',
    [
     'label'        => 'Menu Items',
     'button_label' => 'Add Item',
     'layout'       => 'block',
     'min'          => 1,
    ]
  )
  ->addText('name',
    ['wrapper' => ['width' => '80%']]
  )
  ->addText('price',
    ['wrapper' => ['width' => '20%']]
  )
  ->addTextArea('description',
    ['rows' =>  '2']
  )
  ->addText('paired_cocktail')
  ->endRepeater()
  ->addRepeater('section_notes',
    [
     'label'        => 'Section Footer Notes',
     'button_label' => 'Add Notes',
     'layout'       => 'block',
    ]
  )
    ->addTextArea('notes',
      [
        'label'     => 'Notes',
        'rows'      =>  '4',
        'new_lines' => 'br'
      ]
    )
  ->endRepeater();
