<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Halfs Module
 * @see views/modules/halfs-module.php
 * @see scss/components/_halfs.scss
 */
$team_module = new FieldsBuilder('team_module');
$team_module
  ->addMessage('', 'The Team Module calls the team members created from the Team Content Type.');
