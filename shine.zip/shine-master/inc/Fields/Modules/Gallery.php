<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Gallery Module
 * @see views/modules/gallery-module.php
 * @see scss/components/gallery.scss
 */
$gallery_module = new FieldsBuilder('gallery_module');
$gallery_module
  ->addMessage('', 'The Gallery Module creates a gallery of images. You can select the size of each image. <br/>Image Combos inlcude 100%,  50/25/25, or 25/25/50. ')
  ->addRepeater('images', [
    'min' => 1,
    'button_label' => 'Add Image',
    'layout' => 'block',
  ])
    ->addImage('image', [
      'wrapper'    =>  ['width' => '25%'],
    ])
    ->addSelect('image_width', [
      'wrapper'    =>  ['width' => '75%'],
    ])
      ->addChoice('gal__item-100', '100%')
      ->addChoice('gal__item-50', '50%')
      ->addChoice('gal__item-25', '25%')
      ->addSelect('themes',
        [
          'return_format'	=> 'value',
          'allow_null'    =>  '1'
        ]
      )
      ->addChoice('alpha-bg-white-svg', 'Orange Background, White Badge')
      ->addChoice('alpha-bg-dark-svg', 'Orange Background, Dark Badge')
      ->addChoice('dark-bg-white-svg', 'Dark Background, White Badge')
      ->addChoice('dark-bg-alpha-svg', 'Dark Background, Orange Badge')

    ->addFields($svg_selector)
  ->endRepeater();
