<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Map Module
 * @see views/modules/map-module.php
 * @see scss/components/map.scss
 * @see js/components/GoogleMap
 */
$map_module = new FieldsBuilder('map_module');
$map_module
  ->addMessage('', 'The Map Module adds a custom map to the page ')
  ->addGoogleMap('gmap');
