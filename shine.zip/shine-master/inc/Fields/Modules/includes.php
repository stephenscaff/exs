<?php

if ( ! defined( 'ABSPATH' ) ) exit;

require_once('Content.php');
require_once('Halfs.php');
require_once('Fulls.php');
require_once('Gallery.php');
require_once('FareSection.php');
require_once('Video.php');
require_once('Team.php');
