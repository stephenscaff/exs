<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Buttons
 */
$button = new FieldsBuilder('button');
$button
  ->addPageLink('button_link',
    [
      'allow_null' => 'true',
      'wrapper'    => ['width' => '33.333%'],
      'label'      => 'Button Page Link (internal)',
    ]
  )
  ->addText('button_url',
    [
      'wrapper'    => ['width' => '33.333%'],
      'label'      => 'Button URL (external)'
    ]
  )
  ->addText('button_text',
    [
      'wrapper'    => ['width' => '33.333%'],
    ]
  );


/**
 * Headings
 */
$heading = new FieldsBuilder('heading');
$heading
  ->addText('heading_title',
    ['label' => 'Section Title']
  );


/**
 * SVG Selector
 */
$svg_selector = new FieldsBuilder('svg_selector');
$svg_selector
  ->addSelect('svgs',
    [
    'label' => 'Badge',
    'return_format'	=> 'value',
    'allow_null'    =>  '1'
    ]
  )
  ->addChoice('good-eats', 'Good Eats')
  ->addChoice('port-land', 'Port Land')
  ->addChoice('product-of-pdx', 'Product of Portland')
  ->addChoice('brand-logo', 'Shine Logo')
  ->addChoice('shine-monogram', 'Shine Monogram')
  ->addChoice('small-batch-distilled', 'Small Batch Distilled');


/**
 * Color Themes
 */
$color_themes = new FieldsBuilder('color_themes');
$color_themes
  ->addSelect('themes',
    [
      'return_format'	=> 'value',
      'allow_null'    =>  '1'
    ]
  )
  ->addChoice('has-filter-alpha', 'Orange Image, Orange Background')
  ->addChoice('has-filter-alpha-img', 'Orange Image')
  ->addChoice('bg-alpha', 'Orange Background')
  ->addChoice('has-filter-grey', 'Grey Image, Grey Background')
  ->addChoice('has-overlay-dark', 'Dark Image, White Content');
