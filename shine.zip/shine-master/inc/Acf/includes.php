<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

require_once('AcfModules.php');
require_once('AcfIndexPages.php');
require_once('AcfOptionsPages.php');
require_once('AcfSearch.php');
require_once('AcfExtras.php');
