<?php
/**
 * Template Name: Contact
 *
 * @author      Karlie Watts
 * @package     jumpoff
 * @subpackage  template
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$address    = get_field('company_mail_address', 'options');
$phone      = get_field('company_phone', 'options');
$email      = get_field('company_email', 'options');
$hour_items = get_field('hour_items', 'options');
$gmap       = get_field('gmap', 'options');

?>


<main class="app-main" data-router-wrapper>
  <div data-router-view="<?php echo $hash; ?>">

    <section class="contact bg-grey-light">
      <div class="grid">
        <div class="contact__header-container grid-xs">
          <h1 class="contact__title">Our Hours & Location</h1>
          <hr class="sep is-full" />
          <p class="contact__info"><?php echo $address; ?></p>
          <p class="contact__info"><?php echo $phone; ?> / <?php echo $email; ?></p>
        </div>
        <div class="contact__hours-container">

        <?php foreach ($hour_items as $hour_item) :
          $day  = $hour_item['day'];
          $time = $hour_item['time'];
        ?>

          <div class="contact__hours-item">
            <span class="contact__hours-day"><?php echo $day; ?></span>
            <p class="contact__hours-time"><?php echo $time; ?></p>
          </div>
      <?php endforeach; ?>
      </div>
    </section>

    <section class="location-map">
      <div class="location-map__wrap">
        <div
          class="location-map__map js-location-map"
          data-lat="<?php echo $gmap['lat']; ?>"
          data-lng="<?php echo $gmap['lng']; ?>"
          data-address="<?php echo $gmap['address']; ?>"
          data-title="Shine Distillery & Grill"
          data-zoom="14">
        </div>
      </div>
    </section>

    <?php get_template_part( 'views/shared/next-route' ); ?>

  </div>
</main>

<?php get_footer(); ?>
