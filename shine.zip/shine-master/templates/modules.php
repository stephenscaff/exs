<?php
/**
 * Template Name: Modules
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  template
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$title  = get_the_title();
$hash   = make_hash($title);

?>
<main class="app-main" data-router-wrapper>
  <div data-router-view="<?php echo $hash; ?>">
    <?php get_template_part( 'views/shared/mast' ); ?>
    <?php get_template_part( 'views/shared/modules' ); ?>
    <?php get_template_part( 'views/shared/next-route' ); ?>
  </div>
</main>

<?php get_footer(); ?>
