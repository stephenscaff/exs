<?php
/**
 * Template Name: Fare
 * Template for menu / fare
 *
 * @author  Stephen Scaff
 * @package jumpoff/shine
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$title = get_the_title();
$hash  = make_hash($title);

?>

<main class="app-main" data-router-wrapper>
  <div data-router-view="<?php echo $hash; ?>">

    <?php include(locate_template('views/shared/mast.php')); ?>

    <section class="fare-tabs bg-grey-light">
      <div class="grid">
        <nav class="fare-tabs__nav">
          <ol class="hashtabs-nav" data-hashtabs-id="menus">
          <?php
          $args = array(
            'post_type' => 'fare'
          );
          $menus = get_posts($args);
          foreach ( $menus as $post ) : setup_postdata( $post );
            $title = get_the_title($menu);
          ?>
          <li class="nav-tab"
              data-hashtabs-pair="<?php echo make_hash($title); ?>">
            <a class="fare-tabs__link btn is-dark" href="<?php echo make_hash($title); ?>">
              <span class="btn__text"><?php echo $title; ?></span>
              <span class="btn__stroke is-outter"></span>
              <span class="btn__stroke is-inner"></span>
            </a>
          </li>
          <?php endforeach; wp_reset_postdata(); ?>
        </ol>
      </nav>
    </div>

    <section class="fare-tabs__main bg-grey-light">
      <div class="grid">
        <ol class="hashtabs-data" data-hashtabs-id="menus">
          <?php
          foreach ( $menus as $post ) : setup_postdata( $post );
            $title = get_the_title($post);
          ?>
            <li class="menu-tabs__item"
                data-hashtabs-pair="<?php echo make_hash($title); ?>">
                <?php
                while (has_sub_field('modules', $post)) :
                  ACF_Modules::render(get_row_layout());
                endwhile; ?>
            </li>
          <?php endforeach; wp_reset_postdata(); ?>
          </ol>
        </div>
      </section>
    </section>
    <?php get_template_part( 'views/shared/next-route' ); ?>
  </div>
</main>

<?php get_footer(); ?>
