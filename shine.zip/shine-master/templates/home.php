<?php
/**
 * Template Name: Home
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>

<main class="app-main" data-router-wrapper>
  <div data-router-view="home">
  <?php get_template_part( 'views/shared/mast' ); ?>
  <?php get_template_part( 'views/shared/modules' ); ?>
  <?php get_template_part( 'views/shared/next-route' ); ?>
  </div>
</main>

<?php get_footer(); ?>
