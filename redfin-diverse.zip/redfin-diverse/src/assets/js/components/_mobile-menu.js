/**
 * Mobile Nav
 */
var MobileNav = (function() {

  var settings = {
    body: $('body'),
    menuToggle: $('.js-menu-toggle'),
    activeClass: 'menu-is-open',
  };

  return {

    /**
     * Init Tags
     */
    init: function () {
      this.bindEvents();
    },

    /**
     * Bind Our Events
     */
    bindEvents: function(){

      // Main Menu Toggle
      settings.menuToggle.click(function(e) {
          e.preventDefault();
          MobileNav.toggleMenu();
      });
    },

    /**
     * Toggle Menu
     */
    toggleMenu: function(){
      settings.body.toggleClass(settings.activeClass);
    },

    /**
     * Close Menu Util
     */
    closeMenu: function(){
      settings.body.removeClass(settings.activeClass);
    },
  };
})();

MobileNav.init();
