/**
 * We Scrollin'
 * A scroll to target deal via data attributes, that uses the
 * post titles to auto set the data atts and anchors.
 * Includes pushState to deep link to posts via hash
 *
 */

var WeScrollin = (function() {

  //var feedNav = $('.js-nav > a');
  //var feed = $('.app-main > .feed');

  var settings = {
    navItem:    $('.js-nav a'),
    section:       $('.js-section'),
    activeClass:    'is-active',
    scrollOffset:   30,
    scrollSpeed:    100,
    scrollThrottle: 20,
  };

  return {

    /**
     * Init Tags
     */
    init: function () {
      this.bindEvents();
    },

    /**
     * Bind Our Events
     */
    bindEvents: function () {
      WeScrollin.setup();
      WeScrollin.handleScroll();
      WeScrollin.handleClick();
    },

    /**
     * Set up on page load
     */
    setup: function () {
      console.log(settings.feedNavItem);
      $('.js-nav a').first().addClass('is-active');
    },

    /**
     * Handle Scroll
     * Loops over Posts to Build hash and IDs and then set them
     * @see _utils.js for throttle and inview helper
     */
    handleScroll: function() {
      settings.section.each(function(idx, el){

        //var hash = document.getElementById($(this)).id;
        var hash = $(this).attr('id');
            //hash = WeScrollin.titleToHash(title);

        // Auto build our anchor ids
        //$(this).attr('id', hash);

        // Auto set data-scroll values
        //WeScrollin.buildNav(idx, hash);

        window.addEventListener('scroll', Util.throttle(function() {
          if (Util.isInView(el, 100)) {
            //WeScrollin.updateHash(hash)
            settings.navItem.removeClass(settings.activeClass);
            settings.navItem.eq(idx).addClass(settings.activeClass);
          }

          if (Util.isInView(el, 100)) {
            $(el).addClass('is-active');
          }
        }, settings.scrollThrottle), false);
      });
    },

    /**
     * Title To Hash
     * Creates a clean hash from provided title
     * @return {string} - our cleaned hash
     */
     titleToHash: function(title) {
       return title.toLowerCase().replace(/ /g,'-').replace(/[^\w-]+/g,'');
     },

    /**
     * Build Nav
     * Automatically sets the data-scroll values from our
     * post titles. Might want to go further and automatically
     * create the title's as well...
     *
     * @param {integer} index
     * @param {string} hash value for [data-scroll]
     */
    buildNav: function(idx, hash){
      return settings.feedNavItem.eq(idx).attr('data-scroll', hash);
    },

    /**
     * Update Hash
     * Sends hash to url, with pushstate if available
     *
     * @param {string} hash value to send to url
     */
    updateHash: function(hash){
      if ( history.pushState ) {
        history.pushState(null, null, '#'+hash);
      }
      else {
        location.hash = '#'+hash;
      }
    },

    /**
     * Handle Click
     * Performs the scroll animation.
     */
    handleClick: function() {

      settings.navItem.click(function(e) {
        e.preventDefault();
        var target = $('#' + $(this).data('scroll'));

        $('html, body').stop().animate({
            'scrollTop': target.offset().top - settings.scrollOffset,
          }, {
            duration: settings.scrollSeed,
            easing: 'swing',
            complete: WeScrollin.closeMobileMenu(),
        });
      });
    },

    /**
     * Close Mobile Menu
     *
     * Calls the closeMenu method of our Mobile Menu
     * with a visibility check (to ensure we're on mobile)
     * and the ability to 'hide' the scroll animation.
     *
     * @see _mobile-menu.js
     */
    closeMobileMenu: function() {
      if ( $('.menu-toggle').is(':visible') ) {
        setTimeout(function() {
          MobileNav.closeMenu();
        }, 500);
      }
    },
  };
})();

WeScrollin.init();
