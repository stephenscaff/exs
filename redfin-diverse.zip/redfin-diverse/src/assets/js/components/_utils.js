/**
 * Global Utilities
 */

var Util = (function() {

  return {

/**
 * Is In View?
 * A super simple in viewport check
 * Would probs want to build this out a bit more
 *
 * @param  {el} Element to test
 * @return {boolean}
 */
isInView: function(el, offset) {
  // 'sup jquery
  if (typeof jQuery === "function" && el instanceof jQuery) {
    el = el[0];
  }
  var winY = window.innerHeight || document.documentElement.clientHeight,
      bounds = el.getBoundingClientRect(),
      isTopVisible = (bounds.top >= 0) && (bounds.top <= winY - offset);

  if (isTopVisible) {
    return true;
  }
},

isAtTop: function(el) {
  var distance = $(el).offset().top,
  $window = $(window);

  if ($window.scrollTop() >= distance/1.5) {
    return true;
  }
},


    /**
     * ForEach Utility
     * Ensure we can loop over a object or nodelist
     * @see https://toddmotto.com/ditch-the-array-foreach-call-nodelist-hack/
     */
    forEach: function (array, callback, scope) {
      for (var i = 0; i < array.length; i++) {
        callback.call(scope, i, array[i]);
      }
    },


    /**
     * Throttle Util
     * Stoopid simple throttle util to control scroll events and so on.
     *
     * @param  {Function}  Function call to throttle.
     * @param  {int}       milliseconds to throttle  method
     * @return {Function}  Returns a throttled function
     */
    throttle: function(callback, ms) {
      var wait = false;
      return function () {
          if (!wait) {
              callback.call();
              wait = true;
              setTimeout(function () {
                  wait = false;
              }, ms);
          }
      };
    },
  };
 })();
