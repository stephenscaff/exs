/**
 * Hitting WP RSS feed to pull in posts
 * @see https://github.com/sdepold/jquery-rss
 */
jQuery(function($) {

  var url = "https://www.redfin.com/blog/tag/board-diversity/feed";
  $("#js-posts").rss(url,
  {
    tokens: {
      img: function(entry, tokens){ return "dynamic-stuff: " + entry },
    },
    layoutTemplate: '{entries}',
    entryTemplate:'<article class="post"><a class="post__link" href="{url}"><figure class="post__figure">{teaserImageUrl}</figure><div class="post__content"><div class="post__metas"><span class="post__tax">Technology</span><span class="pipe"></article><time class="post__date">{date}</time></div><h3 class="post__title">{title}</h3><p class="post__text">{shortBodyPlain}</p><span class="post__btn btn-alpha">Read More</span></div></a></article>'
  })
})
