/*jshint -W030*/
/*globals feature: false */

/**
 * Global Site inits
 */
var site = {

  /**
   * Js is supported
   */
  isJsReady: function() {
    $('html').removeClass('no-js');
  },

  /**
   * Add Active Class to Mast
   */
  manualActive: function(el, time) {
    setTimeout(function() {
      el.addClass('is-active');
    }, time);
  }
}

site.isJsReady();

$(function(){
  $mast = $('.mast');
  $intro = $('.intro');
  site.manualActive($mast, 700);
  site.manualActive($intro, 1100);
});



// $(function() {
//
//   (function($) {
//     var body = $('body');
//     var title = $(".post__title");
//
//     function grabXml() {
//       $.ajax({
//         type: "GET",
//         url: "https://www.redfin.com/blog/tag/board-diversity/feed",
//         dataType: "xml",
//         success: parseXml
//       });
//     }
//
//     function parseXml(xml) {
//       $(xml).find("item").each(function() {
//         //var img = $(this).find("img");
//         var postTitle = $(this).find("post__title").text();
//         title.append(postTitle);
//       });
//     }
//     grabXml();
//     var xml = grabXml();
//     console.log(xml);
//
//   })(jQuery);
// });

//
//
// rssurl = 'https://www.redfin.com/blog/tag/board-diversity/feed';
// $.get(rssurl, function(data) {
//     var $xml = $(data);
//     $xml.find("item").each(function() {
//         var $this = $(this),
//             item = {
//                 title: $this.find("title").text(),
//                 link: $this.find("link").text(),
//                 description: $this.find("description").text(),
//                 pubDate: $this.find("pubDate").text(),
//                 author: $this.find("author").text()
//         }
//         //Do something with item here...
//         console.log(item.title);
//     });
// });



//
// function parseRSS(url, callback) {
//   $.ajax({
//     url: document.location.protocol + '//ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=10&callback=?&q=' + encodeURIComponent(url),
//     dataType: 'json',
//     success: function(data) {
//       callback(data.responseData.feed);
//     }
//   });
// }
//
// parseRSS('https://www.redfin.com/blog/tag/board-diversity/feed', foo);
//
// var rss = parseRSS();
