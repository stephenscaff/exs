# Redfin Diversity From The Start

## Run

From directory, run `npm install gulp`, then run `gulp`

## Project
The `src` folder builds out to the `dist` folder. So, perform editing in `src`
The project also includes a lightweight server running on port 8111 (if need be, modify that in `gulp.js` via `const PORT`).

[Open Local Host](http://localhost:8111/)


## Or, Just View It

`dist` has been left in the project, so you can also just view the site by dragging `dist/index.html` into Chrome. If you need an unminified version, you can edit the values of js and css in `gulp.js`

## Dependencies

Jquery 3.2.0 (sorry)


## HBS?

Handlebars is added as a gulp dependency for partials (head, headers, footer, etc). It's just used at compile, not on the front end.


## Feed form Redfin Real-Time

Ideally, we'd like to pull in the research posts form the site automatically.
The best way to do this would be via a json endpoint using the wp api.

However, it appears that the WP API is not enabled as hitting all endpoints just redirects you to home.

Another possible way would be to parse the RSS Feed for a specific cat. But, featured images are not being pulled into the feed, so we'd have to make that happen, and without direct access to the production  build, that could take a while.

So, currently, we're just adding posts manually.
