<?php
/**
 * Archive for resources post type
 *
 * @author    Stephen Scaff
 * @package   archive
 * @version   2.0.0
 * @see       inc/post-types/post-type-resources
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- MAIN --> 
<main role="main" class="">

<?php
// If not on pagination page
if ( !is_paged() ) : 

$args = array(
  'post_type' => 'resources',
  'posts_per_page'   => 1,
  //'post-functions'   => 'featured',
  'tax_query'       => array(
    array(
      'taxonomy'    => 'post-functions',
      'field'       => 'slug',
      'terms'       => array( 'featured' ),
      'operator'    => 'IN',
    ),
  ));
  $featured = get_posts( $args );
  if ($featured) : 
    foreach ( $featured as $post ) : setup_postdata( $post );
      get_template_part( 'partials/partial', 'post-mast' ); 
    endforeach; 
  endif;
  wp_reset_postdata();
  endif;
?>

<!-- Filter Bat -->
<?php get_template_part( 'partials/partial', 'filter-bar' ); ?>

<!-- Posts -->
<?php get_template_part( 'partials/partial', 'posts' ); ?>

<!-- Load More -->
<?php get_template_part( 'partials/partial', 'load-more' );?>

</main>

<!-- Footer  --> 
<?php get_footer(); ?>