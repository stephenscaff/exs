<?php
/**
 * Template Name: Signup
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

?>

<!-- Main -->
<main role="main">

<section class="signup signup-section signup--dark">
    <div class="signup__content">
      
      <div class="grid">
          
        <header class="signup__header">
          <h2 class="signup__title color-alpha">Join The Mailing List</h2>
        </header>  

            
        <?php echo do_shortcode('[contact-form-7 id="1361" title="Newsletter Signup"]'); ?>  
      </div>
    </div>
  </section>

</main>

<!-- FOOTER -->    
<?php get_footer(); ?>