<?php
/**
 * Template Name: Listing Single
 *
 * Single Listing page
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   1
 * @see       scss/components/_listing-filters
 * @see       scss/components/_listing-pagination
 * @see       scss/components/_listing-search
 * @see       scss/components/_listing-tags
 * @see       scss/components/_listing-stats
 * @see       js/components/_listing-search.js"
 * @see       js/components/_listing-filter-tags.js"
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

?>

<!-- Google Maps -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBRCmS0UsD8zSfKb8i7dyiR7FNA2f6opV0"></script>

<!-- Main -->
<main role="main">

<section class="mast mast--listing">
  <figure class="mast__bg js-parallax" style="background-image:url(/capital-pacific/wp-content/uploads/2017/03/cs-mast-4.jpg)"></figure>
  <div class="grid-med">
    <header class="mast__header">
      <h1 class="mast__title"><?php the_title(); ?></h1>
    </header>
    <div class="mast__content">
      <span class="mast__address">10101 Woodfield Lane, St. Louis, Mo</span>
    </div>  
  </div>
</section>

<!-- Heading -->
<section class="heading heading--intro pad-med">
  <div class="grid-med">
    <div class="heading__grid">
      
    <!-- Heading Header -->
      <header class="heading__header heading__team">
        <h4 class="heading__title">Contacts for this property:</h4>
        
        <!-- related team -->
        <section class="related-team">
          
          <!-- Related Team : Item -->
          <div class="related-team__item mb-2">
            <h5 class="related-team__title">Zeb Ripple</h5>
            <span class="related-team__contact">(415) 274-2702</span>
            <span class="related-team__contact">Zrippple@capitalpacific.com</span>

            <a class="related-team__link" href="<?php the_permalink(); ?>">View Profile</a>
          </div>

          <!-- Related Team : Item -->
          <div class="related-team__item mb-2">
            <h5 class="related-team__title">Zeb Ripple</h5>
            <span class="related-team__contact">(415) 274-2702</span>
            <span class="related-team__contact">Zrippple@capitalpacific.com</span>

            <a class="related-team__link" href="<?php the_permalink(); ?>">View Profile</a>
          </div>

        </section>
      </header>

      <!-- Heading: Content -->
      <div class="heading__content has-lead">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus elit diam, accumsan in massa in, consequat porttitor nulla.</p> 

        <p>Enean id felis congue, porttitor neque a. Lorem ipsum dolor sit amet, consectetur adiping elit. Phasellus elit diam, accumsan in massa in, consequa. Sit amet, contetur adipiscing elit. Phasellus elit diam, accumsan in massa in, consequat porttitor nulla. Aen id felis, porttitor neque a.</p>

         <p>Congue, porttitor neque a. Lorem ipsum dolor sit amet, consectetur adiping elit. Phasellus elit diam, accumsan in massa in, consequa. Sit amet, contetur adipiscing elit. Phasellus elit diam, accumsan in massa in, consequat porttitor nulla. Aen elit diam, accumsan in massa.</p>

         <p>Porttitor neque a. Lorem ipsum dolor sit amet, consectetur adiping elit. Phasellus elit diam, accumsan in massa in, consequa. Sit amet, contetur adipiscing elit. Phasellus elit diam, accumsan in massa in porttitor neque a. Lorem ipsum dolor sit amet, consectetur adiping elit. Phasellus elit diam, accumsan in massa in, consequa. Sit amet, contetur adipiscing elit. Phasellus elit diam, accumsan in massa in.</p>




<a class="btn-vert is-m-bar" href="#">
  <span>
    <span class="btn-vert__icon"><i class="icon-download"></i></span>
    <span class="btn-vert__text">Download Marketing Package</span>
  </span>
</a>

      </div>
    </div>
  </div>
</section>


<section class="stats">
  <div class="grid-lg">
    <div class="stats__grid">

      <!-- Stats Item -->
      <div class="stats__item">
        <span class="stats__pretitle">Price</span>
        <span class="stats__numb">$11,480,000</span>
      </div>

      <!-- Stats Item -->
      <div class="stats__item">
        <span class="stats__pretitle">Land Area</span>
        <span class="stats__numb">25,000 SF</span>
      </div>

      <!-- Stats Item -->
      <div class="stats__item">
        <span class="stats__pretitle">Total Rentable Area</span>
        <span class="stats__numb">$82,742 SF</span>
      </div>

      <!-- Stats Item -->
      <div class="stats__item">
        <span class="stats__pretitle">Year Built</span>
        <span class="stats__numb">2016</span>
      </div>

      <!-- Stats Item -->
      <div class="stats__item">
        <span class="stats__pretitle">Cap Rate</span>
        <span class="stats__numb">7.00%</span>
      </div>

      <!-- Stats Item -->
      <div class="stats__item">
        <span class="stats__pretitle">Current Rent</span>
        <span class="stats__numb">$135,000 IN</span>
      </div>

      <!-- Stats Item -->
      <div class="stats__item">
        <span class="stats__pretitle">Price Per SQ Ft</span>
        <span class="stats__numb">$139</span>
      </div>

      <!-- Stats Item -->
      <div class="stats__item">
        <span class="stats__pretitle">Tenants</span>
        <span class="stats__tenants">BURLINGTON COAT FACTORY, RUE 21, ROSS, FIVE BELOW, SHOE CARNIVAL, T.J. MAXX</span>
      </div>
    </div>
  </div>
</section>

<!-- Vid Block -->
<section class="vid-block pad">
  <div class="grid-lg">

  <!-- Vid Block : Link - launched full viewport vid based on data atts -->
    <a class="vid-block__link" href="#" data-popup="video-72949159" data-vimeo-id="72949159" data-vimeo-color="fb4f42">

      <!-- Vid Block : Bg -->
      <figure class="vid-block__bg" style="background-image:url(http://127.0.0.1/capital-pacific/wp-content/uploads/2017/03/cs-vid-bg.jpg)"></figure>
      
      <!-- Vid Block: Header -->        
      <header class="vid-block__header">

        <!-- Vid Block: Play Button -->
        <button type="button" name="button" class="play-button vimeo-id">
          <span class="play-button__circle"></span>
          <svg x="0px" y="0px" viewBox="0 0 15 25" style="enable-background:new 0 0 15 25;" xml:space="preserve" class="play-button__triangle">
             <polygon class="st0" points="1.5,1.5 13.8,12.5 1.5,23.5 "></polygon>
          </svg>
          <svg x="0px" y="0px" viewBox="0 0 61 61" style="enable-background:new 0 0 61 61;" xml:space="preserve" class="play-button__circle-inner">
             <circle class="st0" cx="30.5" cy="30.5" r="28.5"></circle>
          </svg>
        </button>
        <!-- Vid Block: Title -->
        <h3 class="vid-block__title">Watch the Video Testimonial</h3>

        <!-- Vid Block: Btn -->
        <span class="vid-block__btn btn-line btn--white">Watch The Video</span>

      </header>
    </a>
  </div>
</section>

<!-- Full Viewport Video Interaction -->
<section id="video-72949159" class="popup" aria-hidden="true">  
  <button class="popup__close js-close-popup" aria-label="Close">
    <div class="popup__x"></div>
  </button> 
  <div class="flex-vid vimeo popup__vid"></div>
</section>

<!-- Heading -->
<section class="heading  pad-med heading--left">
  <div class="grid-med">
    <div class="heading__grid">
      
    <!-- Heading: Header -->
      <header class="heading__header">
        <h4 class="heading__title">Investment highlights</h4>
      </header>
      <!-- Heading : Content -->
      <div class="heading__content">
        
        <h4 class="heading__subtitle">Those who came before us</h4>        

        <p>Those who came before us made certain that this country rode the first waves of the industrial revolutions, the first waves of modern invention, and the first wave of nuclear power, and this generation does not intend to founder in the backwash of the coming age of space. We mean to be a part of it–we mean to lead it. For the eyes of the world now look into space, to the moon and to the planets beyond, and we have vowed that we shall not see it governed by a hostile flag of conquest, but by a banner of freedom and peace. We have vowed that we shall not see space filled with weapons of mass destruction, but with instruments of knowledge and understanding.</p>

        <h4 class="heading__subtitle">Head is another title</h4>  

        <p>Yet the vows of this Nation can only be fulfilled if we in this Nation are first, and, therefore, we intend to be first. In short, our leadership in science and in industry, our hopes for peace and security, our obligations to ourselves as well as others, all require us to make this effort, to solve these mysteries, to solve them for the good of all men, and to become the world’s leading space-faring nation.</p>
      </div>
    </div>
  </div>
</section>

<!-- Gallery With Pad, 3 images -->
<section class="gal has-pad">
  <div class="gal-full">
    <div class="gal__grid">
      <!-- Gal Item -->
      <figure class="gal__item gal-full">
        <img class="gal__img" src="/capital-pacific/wp-content/uploads/2017/03/cp-cs-food-3.jpg">
      </figure>

      <!-- Gal Item -->
      <figure class="gal__item gal-half">
        <img class="gal__img" src="/capital-pacific/wp-content/uploads/2017/03/cs-mast-2.jpg">
      </figure>

      <!-- Gal Item -->
      <figure class="gal__item gal-half">
        <img class="gal__img" src="/capital-pacific/wp-content/uploads/2017/03/cp-cs-mast-bg-food.jpg">
      </figure>
    </div>
  </div>
</section>

<!-- Heading -->
<section class="heading  pad-med heading--left">
  <div class="grid-med">
    <div class="heading__grid">
      
    <!-- Heading: Header -->
      <header class="heading__header">
        <h4 class="heading__title">Investment highlights</h4>
      </header>
      <!-- Heading : Content -->
      <div class="heading__content">
        
        <h4 class="heading__subtitle">Those who came before us</h4>        

        <p>Those who came before us made certain that this country rode the first waves of the industrial revolutions, the first waves of modern invention, and the first wave of nuclear power, and this generation does not intend to founder in the backwash of the coming age of space. We mean to be a part of it–we mean to lead it. For the eyes of the world now look into space, to the moon and to the planets beyond, and we have vowed that we shall not see it governed by a hostile flag of conquest, but by a banner of freedom and peace. We have vowed that we shall not see space filled with weapons of mass destruction, but with instruments of knowledge and understanding.</p>

        <h4 class="heading__subtitle">Head is another title</h4>  

        <p>Yet the vows of this Nation can only be fulfilled if we in this Nation are first, and, therefore, we intend to be first. In short, our leadership in science and in industry, our hopes for peace and security, our obligations to ourselves as well as others, all require us to make this effort, to solve these mysteries, to solve them for the good of all men, and to become the world’s leading space-faring nation.</p>
      </div>
    </div>
  </div>
</section>

<!-- Gallery Example: Single, no Pad -->
<section class="gal ">
  <div class="gal-full">
    <div class="gal__grid no-pad">
      <figure class="gal__item Array">
        <img class="gal__img" src="/capital-pacific/wp-content/uploads/2017/03/cp-cs-food-4.jpg">
      </figure>
    </div>
  </div>
</section>

<!-- Locations -->
<section class="location-map">
  <div id="js-map" class="location-map__map js-location-map">
    <span class="address">7036 Clayton Ave, St. Louis, MO 63117, United States</span>
  </div>
</section>

<!-- Next -->
<article class="banner banner--next">
  <a class="banner__link" href="/capital-pacific/blog/2017/03/first-half-2016-retail-investment-insights/">
    <figure class="banner__bg " style="background-image:url(/capital-pacific/wp-content/uploads/2017/03/cs-mast-post-1.jpg)"></figure>
    <div class="grid">
      <header class="banner__header">
        <span class="banner__pretitle">Read Next</span>
        <h1 class="banner__title">First half 2016 retail investment insights</h1>
        <span class="btn-line btn--white">Read Story</span>
      </header>
    </div>
  </a>
</article>


</main>





<!-- Footer-->	
<?php get_footer(); ?>