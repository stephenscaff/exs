<?php
/**
 * Template Name: Approach
 *
 * Template for the Approach page, that calls module specific to the page.
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$mast_title = get_field('mast_title');

?>

<!-- Main -->
<main role="main">
  
<!-- Mast -->
<section class="mast mast--approach">
  <figure class="mast__bg js-parallax" style="background-image:url(<?php echo jumpoff_ft_img('full'); ?>)"></figure>
  <div class="grid-med">
    <header class="mast__header">
      <h1 class="mast__title"><?php echo $mast_title ?></h1>
    </header>
  </div>
</section>

<?php 
// Call Modules
while (has_sub_field('modules')) :
  ACF_Modules::render(get_row_layout()); 
endwhile; 
?>

</main>

<!-- Footer-->	
<?php get_footer(); ?>