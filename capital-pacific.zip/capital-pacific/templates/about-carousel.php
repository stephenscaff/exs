<?php
/**
 * Template Name: About
 *
 * About page tempalte, featuring the Slidee pattern and related fields.
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 * @see       components/_slidee.scss
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$about_mast = 'about_mast';

?>

<!-- Main --> 
<main role="main">

  <!-- Mast --> 
  <section class="slidee-mast">
    <div class="slidee-mast__images js-slidee">

    <?php while( have_rows($about_mast) ): the_row(); 
    $title = get_sub_field('title');
    $image = get_sub_field('image');  
    ?>

      <article class="slidee-mast__item" data-slidee-title="<?php echo $title; ?>">
        <figure class="slidee-mast__img" style="background-image:url(<?php echo $image['url']; ?>)"></figure>
        <header class="slidee-mast__header">
          <h2 class="slidee-mast__title"><?php echo $title; ?></h2>
        </header>
      </article>

    <?php endwhile; ?>
    </div>
  </section>

<!-- Slidee Info -->
<section class="slidee-info">
  <div class="slidee-info__wrap">

    <!-- Story -->
    <article class="slidee-info__item">

    <?php 
    // Modules
    while (has_sub_field('about_modules_1')) :
      ACF_Modules::render(get_row_layout()); 
    endwhile; 
    ?>

    </article>

    <!-- Story -->
    <article class="slidee-info__item">

    <?php 
    // Modules
    while (has_sub_field('about_modules_2')) :
      ACF_Modules::render(get_row_layout()); 
    endwhile; 
    ?>

    </article>

    <!-- Philantropy -->
    <article class="slidee-info__item">
      <?php 
      // Modules
      while (has_sub_field('about_modules_3')) :
        ACF_Modules::render(get_row_layout()); 
      endwhile; 
      ?>
    </article>
  </div>
</section>

</main>

<!-- FOOTER --> 
<?php get_footer(); ?>