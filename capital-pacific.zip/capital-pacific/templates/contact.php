<?php
/**
 * Template Name: Contact
 * The contact page template and related fields
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$mast_title = get_field('mast_title');
$mast_text = get_field('mast_text');

$company_twitter = get_field('company_twitter', 'option');
$company_facebook = get_field('company_facebook', 'option');
$company_linkedin = get_field('company_linkedin', 'option');


$sfo_address = get_field('company_address_sfo', 'option');
$sfo_phone = get_field('company_phone_sfo', 'option');
$sfo_fax = get_field('company_fax_sfo', 'option');
$sfo_email = get_field('company_email_sfo', 'option');

$sea_address = get_field('company_address_sea', 'option');
$sea_phone = get_field('company_phone_sea', 'option');
$sea_fax = get_field('company_fax_sea', 'option');
$sea_email = get_field('company_email_sea', 'option');

$pdx_address = get_field('company_address_pdx', 'option');
$pdx_phone = get_field('company_phone_pdx', 'option');
$pdx_fax = get_field('company_fax_pdx', 'option');
$pdx_email = get_field('company_email_pdx', 'option');


$contact_cta_title = get_field('contact_cta_title');
$contact_cta_text = get_field('contact_cta_text');
$contact_cta_link = get_field('contact_cta_link');
$contact_cta_link_text = get_field('contact_cta_link_text');
$contact_cta_img = get_field('contact_cta_img');

$careers_cta_title = get_field('careers_cta_title');
$careers_cta_link = get_field('careers_cta_link');
$careers_cta_link_text = get_field('careers_cta_link_text');

?>

<!-- Main -->
<main role="main">

<!-- MAST -->
<section class="mast mast--contact">
  <div class="grid-med">
    <header class="mast__header">
      <h1 class="mast__title"><?php echo $mast_title; ?></h1>
    </header>
    <div class="mast__contacts">
      <div class="mast__col">
        <p class="mast__text"><?php echo $mast_text; ?></p>
      </div>
      <div class="mast__col">
        <a class="mast__link" href="<?php echo $company_twitter; ?>" target="_blank"><i class="icon-twitter"></i> <span>What We're Reading</span></a>
        <a class="mast__link" href="<?php echo $company_facebook; ?>" target="_blank"><i class="icon-facebook"></i> <span>Behind the Scenes</span></a>
        <a class="mast__link" href="<?php echo $company_linkedin; ?>" target="_blank"><i class="icon-linkedin"></i> <span>All Business</span></a>
      </div>  
    </div>
  </div>
</section>

<!-- Contacts -->
<section class="contacts">
  <div class="grid-med">
    <div class="contacts__grid">
      <div class="contacts__item">
        <h3 class="contacts__title color-sfo">SFO.</h3>
        <address class="contacts__address">
        <?php echo jumpoff_line_wrap($sfo_address, 'span'); ?>
        </address>

        <span class="contacts__tel">PH: <a href="tel:<?php echo $sfo_phone; ?>"><?php echo $sfo_phone; ?></a></span>
        <span class="contacts__tel">FAX: <a href="tel:<?php echo $sfo_fax; ?>"><?php echo $sfo_fax; ?></a></span>

        <a class="contacts__email" href="mailto:<?php echo $sfo_email; ?>"><?php echo $sfo_email; ?></a>
      </div>

      <div class="contacts__item">
        <h3 class="contacts__title color-pdx">PDX.</h3>
        <address class="contacts__address">
        <?php echo jumpoff_line_wrap($pdx_address, 'span'); ?>
        </address>

        <span class="contacts__tel">PH: <a href="tel:<?php echo $pdx_phone; ?>"><?php echo $pdx_phone; ?></a></span>
        <span class="contacts__tel">FAX: <a href="tel:<?php echo $pdx_fax; ?>"><?php echo $pdx_fax; ?></a></span>

        <a class="contacts__email" href="mailto:<?php echo $pdx_email; ?>"><?php echo $pdx_email; ?></a>
      </div>

       <div class="contacts__item">
        <h3 class="contacts__title color-sea">SEA.</h3>
        <address class="contacts__address">
        <?php echo jumpoff_line_wrap($sea_address, 'span'); ?>
        </address>

        <span class="contacts__tel">PH: <a href="tel:<?php echo $sea_phone; ?>"><?php echo $sea_phone; ?></a></span>
        <span class="contacts__tel">FAX: <a href="tel:<?php echo $sea_fax; ?>"><?php echo $sea_fax; ?></a></span>

        <a class="contacts__email" href="mailto:<?php echo $sea_email; ?>"><?php echo $sea_email; ?></a>
      </div>
    </div>
  </div>
  </section>

<!-- Banner CTA -->
<section class="banner banner--center">
  <a class="banner__link" href="<?php echo $contact_cta_link; ?>">
    <figure class="banner__bg " style="background-image:url(<?php echo $contact_cta_img['url']; ?>)"></figure>
    <div class="grid">
      <header class="banner__header">
        <h1 class="banner__title"><?php echo $contact_cta_title; ?></h1>
        <p class="banner__text"><?php echo $contact_cta_text; ?></p>
        <span class="btn-line btn--white"><?php echo $contact_cta_link_text; ?></span>
      </header>
    </div>
  </a>
</section>

<!-- CTA Div Link -->
<section class="div-link">
  <div class="grid-xl">
    <a class="div-link__link" href="<?php echo $careers_cta_link; ?>">
        <header class="div-link__header">
          <span class="div-link__pretitle">Career Opportunities</span>
          <h2 class="div-link__title"><?php echo $careers_cta_title; ?></h2>
          <span class="btn-line btn--white"><?php echo $careers_cta_link_text; ?></span>
        </header>
    </a>
  </div>
</section>

</main>




<!-- Footer-->	
<?php get_footer(); ?>