<?php
/**
 * Template Name: Home
 * Includes the custom Velo Slider jaun
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- Main -->
<main role="main">

<!-- Slider Loop -->
<?php get_template_part( 'partials/partial', 'home-slider' );?> 

</main>

<!-- Footer-->	
<?php get_footer(); ?>