<?php
/**
 * Template Name: Listings
 * The Listing page index / archive
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$mast_title = get_field('mast_title');

?>

<!-- Main -->
<main role="main">
  
<!-- MAST -->
<section class="mast mast--listings">
  <figure class="mast__bg js-parallax" style="background-image:url(../wp-content/uploads/2017/03/cs-mast-1.jpg)"></figure>
  <div class="grid-med">
    <header class="mast__header">
      <span class="mast__pretitle">What Can We Help You Find?</span>
      <h1 class="mast__title">Have a look at our current listings.</h1>
    </header>
  </div>
</section>


<?php get_template_part( 'partials/partial', 'listings-filters' ); ?>


<section id="listings" class="listings">

  <div class="grid-med">

  <!-- Listing Item -->
    <article class="listing">

      <!-- Listing Link -->
      <a class="listing__link" href="/capital-pacific/listing-single/">

        <!-- Listing Headers -->
        <header class="listing__header">
          <div class="listing__titles">
            <span class="listing__pretitle">St. Louis, Mo</span>
            <h3 class="listing__title">Arby's</h3>
          </div>

          <div class="listing__metas">
            <span class="listing__meta"><strong>Price</strong> $33,900,000</span>
            <span class="listing__meta"><strong>Cap Rate</strong> %6.90%</span>
          </div>
        </header>

        <!-- Figure / Image -->
        <figure class="listing__figure has-preloader">
            <div class="listing__img js-lazy" style="background-image:url()" data-src="https://source.unsplash.com/UmkYTjF7khA/1600x1400"></div>
            <span class="preloader preloader--white"></span>
            <i class="listing__icon icon-eye"></i>
            <span class="is-pending__overlay"><span>Pending</span></span>
        </figure>

        <!-- Footer -->
        <footer class="listing__footer">
          <div class="listing__details">
            <span class="listing__detail"><strong>Type</strong>  Retail-Power Center</span>
            <span class="listing__detail"><strong>Total Rentable Area</strong>  139,831 SF</span>
            <span class="listing__detail"><strong>Lead Broker</strong>  Kevin Adatto</span>
            <span class="listing__detail"><strong>P</strong> <span data-simlink="tel:+15036757726">503.675.7726</span></span>
            <span class="listing__detail"><strong>E</strong> <span data-simlink="mailto:kadatto@capitalpacific.com">kadatto@capitalpacific.com</span></span>
          </div>

          <span class="listing__btn"><span class="btn-line">View Full Listing</span></span>
        </footer>
      </a>
    </article>


    <!-- Listing Item -->
    <article class="listing is-pending">
      
      <!-- Listing Link -->
      <a class="listing__link" href="/capital-pacific/listing-single">

        <!-- Listing Headers -->
        <header class="listing__header">
          <div class="listing__titles">
            <span class="listing__pretitle">St. Louis, Mo</span>
            <h3 class="listing__title">Trader Joes</h3>
          </div>
          <div class="listing__metas">
            <span class="listing__meta"><strong>Price</strong> $33,900,000</span>
            <span class="listing__meta"><strong>Cap Rate</strong> %6.90%</span>
          </div>
        </header>

        <!-- Figure / Image -->
        <figure class="listing__figure has-preloader">
          <div class="listing__img js-lazy" style="background-image:url()" data-src="https://source.unsplash.com/HzEb3ZRtV88/1600x1400"></div>
          <span class="preloader preloader--white"></span>
          <i class="listing__icon icon-eye"></i>
          <span class="is-pending__overlay"><span>Pending</span></span>
        </figure>

        <!-- Footer -->
        <footer class="listing__footer">
          <div class="listing__details">
            <span class="listing__detail"><strong>Type</strong>  Retail-Power Center</span>
            <span class="listing__detail"><strong>Total Rentable Area</strong>  139,831 SF</span>
            <span class="listing__detail"><strong>Lead Broker</strong>  Kevin Adatto</span>
            <span class="listing__detail"><strong>P</strong> <span data-simlink="tel:+15036757726">503.675.7726</span></span>
            <span class="listing__detail"><strong>E</strong> <span data-simlink="mailto:kadatto@capitalpacific.com">kadatto@capitalpacific.com</span></span>
          </div>

          <span class="listing__btn"><span class="btn-line">View Full Listing</span></span>
        </footer>
      </a>
    </article>



    <!-- Listing Item -->
    <article class="listing">

      <!-- Listing Link -->
      <a class="listing__link" href="/capital-pacific/listing-single/">

        <!-- Listing Headers -->
        <header class="listing__header">
          <div class="listing__titles">
            <span class="listing__pretitle">St. Louis, Mo</span>
            <h3 class="listing__title">North District shopping center</h3>
          </div>

          <div class="listing__metas">
            <span class="listing__meta"><strong>Price</strong> $33,900,000</span>
            <span class="listing__meta"><strong>Cap Rate</strong> %6.90%</span>
          </div>
        </header>

        <!-- Figure / Image -->
        <figure class="listing__figure has-preloader">
            <div class="listing__img js-lazy" style="background-image:url()" data-src="https://source.unsplash.com/-udZnjsCzsE/1600x1400"></div>
            <span class="preloader preloader--white"></span>
            <i class="listing__icon icon-eye"></i>
            <span class="is-pending__overlay"><span>Pending</span></span>
        </figure>

        <!-- Footer -->
        <footer class="listing__footer">
          <div class="listing__details">
            <span class="listing__detail"><strong>Type</strong>  Retail-Power Center</span>
            <span class="listing__detail"><strong>Total Rentable Area</strong>  139,831 SF</span>
            <span class="listing__detail"><strong>Lead Broker</strong>  Kevin Adatto</span>
            <span class="listing__detail"><strong>P</strong> <span data-simlink="tel:+15036757726">503.675.7726</span></span>
            <span class="listing__detail"><strong>E</strong> <span data-simlink="mailto:kadatto@capitalpacific.com">kadatto@capitalpacific.com</span></span>
          </div>

          <span class="listing__btn"><span class="btn-line">View Full Listing</span></span>
        </footer>
      </a>
    </article>
  </div>
</section>

<section class="listing-pagination">
  <div class="grid-xl">
    <div class="listing-pagination__grid">
      <div class="listing-pagination__totals">
        <span class="totals-numbers">1 - 6</span>
        <span class="totals-numbers">241 Listings</span>
      </div>

      <nav class="listing-pagination__pages">
        <ul>
          <li><a class="is-active" href="#">1</a></li>
          <li><a href="#">2</a></li>
          <li><a href="#">3</a></li>
          <li><a href="#">4</a></li>
          <li><a href="#"><i class="icon-right-chev"></i></a></li>
        </ul>
      </nav>
    </div>
  </div>
</section>
</main>

<!-- Footer-->	
<?php get_footer(); ?>