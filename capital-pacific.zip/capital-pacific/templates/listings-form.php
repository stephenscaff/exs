<?php
/**
 * Template Name: Listing Form
 *
 * Viewport Steps form for loading listings on the listings page
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   1
 * @see       scss/components/_listing-form
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

?>
<style type="text/css">
/* Hide header and footer */
  .site-header, .site-footer{
    display: none;
  }
</style>

<!-- Main -->
<main role="main">

<form class="listing-form">
  <section id="step-1" class="listing-form__step listings-form__step--1">
    <header class="listing-form__help">
      <i class="listing-form__help-icon icon-help-o-alt"></i>
      <span class="listing-form__help-text">This is the hint and it contains some helpful info to provide additional info</span>
    </header>
    <div class="listing-form__content">
      <p class="listing-form__heading">At Capital Pacific, we tailor our process to our clients and their needs. To help us serve you better, please answer a few questions regarding your property search.</p>
      <div class="listing-form__numbs">
      <span class="listing-form__numb is-active">01</span>
      <span class="listing-form__numb">02</span>
      <span class="listing-form__numb">03</span>
    </div>
      <label class="listing-form__label">Where would you like to search?</label>
      <div class="listing-form__select-control">
      <select class="listing-form__select js-select">
        <option selected="" disabled="">Select a Region</option>
        <option value="East Coast">East Coast</option>
        <option value="Midwest">Midwest</option>
        <option value="Northwest">Northwest</option>
        <option value="West Coast">West Coast</option>
      </select>
    </div>
    </div>
  </section>

  <section id="step-2" class="listing-form__step listings-form__step--2">
    <header class="listing-form__help">
      <i class="listing-form__help-icon icon-help-o-alt"></i>
      <span class="listing-form__help-text">This is the hint and it contains some helpful info to provide additional info</span>
    </header>
    <div class="listing-form__content">
      <div class="listing-form__content">
      <div class="listing-form__numbs">
        <span class="listing-form__numb">01</span>
        <span class="listing-form__numb is-active">02</span>
        <span class="listing-form__numb">03</span>
      </div>
      <label class="listing-form__label">What's your property type?</label>
      <div class="listing-form__select-control">
      <select class="listing-form__select js-select">
        <option selected="" disabled="">Select a Type</option>
        <option value="East Coast">Commercial</option>
        <option value="Midwest">Mixed Use</option>
        <option value="Northwest">Residential</option>
      </select>
      </div>
    </div>
  </div>
  </section>

  <section id="step-3" class="listing-form__step listings-form__step--3">
    <header class="listing-form__help">
      <i class="listing-form__help-icon icon-help-o-alt"></i>
      <span class="listing-form__help-text">This is the hint and it contains some helpful info to provide additional info</span>
    </header>
    <div class="listing-form__content">
      <div class="listing-form__numbs">
        <span class="listing-form__numb">01</span>
        <span class="listing-form__numb">02</span>
        <span class="listing-form__numb is-active">03</span>
      </div>
      <label class="listing-form__label">What's your price range?</label>
      <div class="listing-form__select-control">
      <select class="listing-form__select js-select js-select-fakie">
        <option selected="" disabled="">Select a price range</option>
        <option value="/listings">East Coast</option>
        <option value="/listings">Midwest</option>
        <option value="/listings">Northwest</option>
        <option value="/listings">West Coast</option>
      </select>
      </div>
    </div>
  </section>
</form>
</main>

<!-- Footer-->	
<?php get_footer(); ?>

<script type="text/javascript">
/**
 * Fake Code to demo interaction
 * Obviously this will be removed.
 */

(function($) {

var body = $('body');

function redirectPage() {
  window.location = '/capital-pacific/listings/';
}

$('.js-select-fakie').on('change', function() {
  body.fadeOut(500, redirectPage);
  return false;
});

})(jQuery);


/**
 *  Scroll To Next Section on Select Change
 * 
 *  Since this will probably change, leaving it here for now.
 *
 *  @todo  Build this out once specs are clear and move into a 
 *         js module or whateves.
 *  @see   js/vendor/_dropkick.js  (select styling)
 *  @see   scss/components/_listing-form.scss
 *  
 */

$('.js-select').on('change', function() {
    var nextStep = $(this).closest('.listing-form__step').next();
    
    if (nextStep.length !== 0) {
      $('html, body').animate({
          scrollTop: nextStep.offset().top
      }, 500);
    }
});
</script>