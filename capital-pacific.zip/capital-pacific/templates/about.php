<?php
/**
 * Template Name: About
 *
 * About page tempalte, featuring the a different (from v1) scroll interaction.
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$about_mast = 'about_mast';

?>

<!-- Main --> 
<main role="main">


  <!-- Mast --> 
  <section class="about-mast">
    <div class="about-mast_images">

    <?php 
    $counter = 1;
    while( have_rows($about_mast) ): the_row(); 

    $title = get_sub_field('title');
    $image = get_sub_field('image');  
    ?>

      <article class="about-mast__item js-mast-item" data-slidee-title="<?php echo $title; ?>">
        <header class="about-mast__header js-mast-header">
          <figure class="about-mast__img" style="background-image:url(<?php echo $image['url']; ?>)"></figure>
          <h2 class="about-mast__title"><?php echo $title; ?></h2>
        </header>

        <section class="about-mast__content js-inview">
          <?php 
          // Modules

          $modules = 'about_modules';
          $modules_count = $modules.'_' .$counter;
     
          while (has_sub_field($modules_count)) :
            ACF_Modules::render(get_row_layout()); 
          endwhile; 
          ?>
        </section>
      </article>

    <?php 
$counter++;
    endwhile; ?>
    </div>
  </section>

</main>

<!-- FOOTER --> 
<?php get_footer(); ?>