<?php
/**
 * Template Name: Mast & Modules
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

?>

<!-- Main -->
<main role="main">

<!-- Mast -->
<?php get_template_part( 'partials/partial', 'mast' ); ?>

<?php get_template_part( 'partials/partial', 'modules' ); ?>

</main>

<!-- FOOTER -->    
<?php get_footer(); ?>