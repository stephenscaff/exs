<?php
/**
 * Default Page Template
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- Main --> 
<main role="main">

<?php get_template_part( 'partials/partial', 'mast' ); ?>

<!-- Content -->
<section class="content pad">
  <div class="grid-sm">
    <?php 
    while (have_posts()) : the_post();
    the_content();
   endwhile; 
   ?> 
  </div>
</section>

</main>

<!-- Footer --> 
<?php get_footer(); ?>