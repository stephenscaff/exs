<?php
/**
 * General post archive
 *
 * @author    Stephen Scaff
 * @package   archive
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- MAIN --> 
<main role="main" class="has-offset">

<!-- Page Title -->
<section class="page-title">
  <div class="grid">
    <header class="page-title__header">
    <?php if (is_post_type_archive()) : ?>
      <h1 class="page-title__title"><?php post_type_archive_title(); ?></h1>
    <?php elseif (is_category()) : ?>
      <h2 class="page-title__title"><?php single_cat_title( '', true ); ?></h2>
    <?php endif; ?>
    </header>
  </div>
</section>


<!-- Posts-->
<section class="feeds">
    <div id="js-posts" class="feeds__grid js-posts">
  <?php
    if ( have_posts() ): while ( have_posts() ) : the_post();
      get_template_part( 'partials/content/content', 'post' );
    endwhile; else: 
      get_template_part( 'partials/content/content', 'none' );
    endif;
    ?>
  </div>
</section>

<!-- Load More -->
<?php get_template_part( 'partials/partial', 'load-more' );?>

</main>

<!-- Footer  --> 
<?php get_footer(); ?>