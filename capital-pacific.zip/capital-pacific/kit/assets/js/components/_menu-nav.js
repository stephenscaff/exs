
/** 
 * Menu Interaction
 * Toggles the site's main offcanvas nav (same for mobile and desktop)
 * @see: scss/components/layouts/_site-menu.scss
 * @see: js/components/_site-menu.js
 */
  var MenuNav = (function(){

    /**
     * Settings Object
     */
    var settings = {
      body: $('body'),
      menuToggle: $('.js-menu-toggle'),
      siteMenu: $('.site-menu'),
      siteMenuLink: $('.js-site-menu-link'),
      siteMenuBg: $('.js-site-menu-bg'),
      siteMenuActive: 'menu--is-open',
      siteMenu_isClosing: 'menu--is-closing',
      siteMenu_isOpening: 'menu--is-opening',
      main: $('main'),
      self: this,
    };

 return {
 
    /**
     * Init
     */
      init: function() {
        this.bindEvents();
      },

    /**
     * Bind EVents
     */
    bindEvents: function(){

      // Main Click event
      settings.menuToggle.click(function(e) {
        e.preventDefault();
        MenuNav.toggleMenu();
        settings.menuToggle.focus()
      });
      
      // Key commands
      $(document).keyup(function(e) {
        if (settings.body.hasClass(settings.siteMenuActive) && e.which === 27) {
          MenuNav.toggleMenu();
        }
        if ($('input, textarea').is(':focus')) {
          return;
        }
        if (e.which === 77) {
          MenuNav.toggleMenu();
        }
      });

      // Hover Images
      settings.siteMenuLink.hover(function() {
        settings.self = this;
        MenuNav.hoverBGs();
      })
    },

    /** 
     * Toggle Menu
     */
    toggleMenu: function(){
      if (settings.body.hasClass(settings.siteMenuActive)){
        settings.body.addClass(settings.siteMenu_isClosing);
        settings.body.toggleClass(settings.siteMenuActive);
        settings.siteMenu.attr('aria-hidden', 'true');
            settings.main.attr('aria-hidden', 'false');
          setTimeout(function(){
            settings.body.removeClass(settings.siteMenu_isClosing);
        }, 12000);
      } else {
        settings.body.addClass(settings.siteMenu_isOpening);
        setTimeout(function(){
          settings.body.toggleClass(settings.siteMenuActive).removeClass(settings.siteMenu_isOpening);
          settings.siteMenu.attr('aria-hidden', 'false');
          settings.main.attr('aria-hidden', 'true');
        }, 100);
      }
    },
    hoverBGs: function(){
      var index = settings.siteMenuLink.index(settings.self) + 1;
      $('.js-site-menu-bg:nth-child(' + index + ')').toggleClass('is-active');
    },
    };
  })();
 MenuNav.init();




