// /** 
//  * Scrolling Nav
//  * Function for nav interactions on scroll.
//  */
// (function($) {

//   var ScrollingNav = (function() {
    
//     var $body = $('body'),
//         scrollDistance = '70',
//         scrollThrottle = '150',
//         scrollingClass = 'scrolling-down';
      
//     return{
      
//       init: function() {  
//         this.onScrollDown();
//       },

//       /** 
//        * Scrolling Down
//        * Throttles scrolling via setInterval
//        */
//       onScrollDown: function(){
        
//         var scrolledDown;

//         $(window).scroll(function(){
//           scrolledDown = true;
//         });

//         // Throttle scroll
//         setInterval(function() {
//           if (scrolledDown) {
//             ScrollingNav.hasScrolled();
//             scrolledDown = false;
//           }
//         }, scrollThrottle);
//       },   

//       /**
//        * Has Scrolled
//        * Adds and removes scrolling class to body
//        */
//       hasScrolled: function() {
//         var scrolling = $(window).scrollTop();
//         (scrolling >= scrollDistance) ? $body.addClass(scrollingClass) : $body.removeClass(scrollingClass);
//       },
//     };
//   })();
// ScrollingNav.init();
// })(jQuery);






var ScrollNav = (function() {

  var settings = {
    body: document.querySelector('body'),
    //site_header: document.querySelector('.site-header'),
    scroll_threshold: 50,
    scroll_throttle: 150,
  };

  return{

    init: function(){
      this.bind()
    },

    bind: function(){
      this.toggleHeaderState();
    },
    
    throttle: function(fn, ms) { 
      var time, last = 0;
      return function() {
        var a = arguments, t = this, now = +(new Date), exe = function() { last = now; fn.apply(t, a); };
        clearTimeout(time);
        (now >= last + ms) ? exe() : time = setTimeout(exe, ms);
      }
    },

    toggleHeaderState: function(el){
      var winY = window.innerHeight || document.documentElement.clientHeight;

      window.addEventListener('scroll', this.throttle(function() {
        
        var scroll_distance = window.scrollY;
        console.log('scrolling');
        if (scroll_distance >= 10) {
          settings.body.classList.add('scrolling-down');
        } else {
          settings.body.classList.remove('scrolling-down');
        }
      }, settings.scroll_throttle), false);
    },
  };
})();
ScrollNav.init();

