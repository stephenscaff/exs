/** 
 * Search Drawer Toggle
 * Toggles the search drawer interaction on listings page.
 *
 *  @see scss/components/_listings-search.scss
 */
(function($) {
  var s,
  searchDrawer = {
    settings: {
      body: $('body'),
      searchToggle: $(".js-listing-search-toggle"),
      searchDrawer: $(".listing-search-drawer"),
      searchInput: $(".listing-search-drawer__input"),
    },

    /** 
     * Init 
     */
    init: function() {
      s = this.settings;
      this.bindEvents();
    },

    /**
     * Bind
     */
    bindEvents: function(){
      s.searchToggle.click(function(e) {
        e.preventDefault();
        console.log('clicked');
        searchDrawer.toggleSearch();
        searchDrawer.focusSearch();
      });
      $(document).keyup(function(e) {
        if ($("body").hasClass("is-open") && e.which === 27) {
          searchDrawer.toggleSearch();
        }
      });
    },

    /**
     * On Focus
     */
    focusSearch: function(){
      setTimeout(function(){
        s.searchInput.focus();
      }, 400);
    },

    /**
     * Toggle Search 
     */
    toggleSearch: function(){
      console.log('clicked');
      s.searchDrawer.toggleClass("is-open is-hidden");
    },

    /**
     * Close Search 
     */
    closeSearch: function(){
      $(".is-open").removeClass("is-open");
    },

  };
  searchDrawer.init();
})(jQuery);

