/** 
 * FlterTags
 * Creates filter tags from selected select options.
 * Outputs tags to div within listings filters/filter-bar.
 *
 *  @see scss/components/_listings-
 */
var FilterTags = (function() {
    
  var filterSelect = $('.js-select-tags'),
      tagsOutput = $('.js-listing-tags-output');

  return {
   
    /**
     * Init Tags
     */
    init: function() {
      this.bind();
    },

    /**
     * Bind UI events
     */
    bind: function(){

      // Select to Tags
      filterSelect.change(function(){
        console.log('changed');
        var option = $(this).find('option:selected');
        html = option.html();
        var tag = $('<div />', {'class' : 'filter-tag'}).append($('<span class="filter-tag__text">' + html + '</span><span class="icon-x js-close-tag"></span>'));
        tag.data('field', $(this).data('field'));
        tag.data('id', option.val());
        tagsOutput.append(tag);
      });

      // Remove Tags
      FilterTags.removeTag();

    },

    /** 
     * Remove tags
     */
    removeTag: function(){
      $(document).on('click', '.js-close-tag', function() {
        $(this).parent().remove();
       });
    },
  };
})();
FilterTags.init();