/*jshint -W030*/
/** 
 * Simulated Links
 * Enables nested category archive links to still be clickable
 * @author Stephen Scaff
 *
 */
(function($) {
  var simLinks = { 

    init: function() {
      $("[data-sim-link]").on("click", function(e) {
        var $this, $simLink;
        $this = $(this), 
        $simLink = $this.data("sim-link"), 
        $simLink && (e.preventDefault(),
          e.stopPropagation(), 
          window.open && e.metaKey ?
          window.open($simLink, "_blank") : 
          window.location.assign($simLink)
        );
      });
    },
  };
  simLinks.init();
})(jQuery);