/**
 * Email Cloaker
 * Cloaks Emails written out to prevent them spammy botheads
 */

var EmailCloaker = (function() {
  var $emailToCloak = $(".js-email-cloak");
  return{
     
    /**
     * Init
     */
    init: function(){
      this.replacers();
    },
    
    /**
     * Replacers
     * Replaces ats and dots and builds an actual email address
     */
    replacers: function(){
      
      $emailToCloak.each(function(){
        var ats, dots, address, i, foundDots;
        ats = [ ' at ', ' (at) ', ' [at] ' ];
        dots = [ ' dot ', ' (dot) ', ' [dot] ' ];
        
        address = $(this).html();
        
        // Replace Ats
        for ( i = 0; i < ats.length; i++ ) {
            address = address.replace(ats[i], '@');
        }
        
        // replace Dots
        for ( i = 0; i < dots.length; i++ ) {
            address = address.replace(dots[i], '.');
            
            moreDots = [];
            moreDots = address.split(dots[i]);
            // Got more dots?
            for ( var j = 1; j < moreDots.length; j++ ) {
              address = address.replace(dots[i], '.');
            }
        }
        $(this).html('' + address + '');
      });
    },
  }
 })();
EmailCloaker.init();