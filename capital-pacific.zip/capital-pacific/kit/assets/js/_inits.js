/*jshint -W030*/
/*globals feature: false */

/**
 * Global Site inits
 */
var site = {
  
  /**
   * Featured Init
   */
  featureJS: function(){
    //no-js 
    $("html").removeClass("no-js");
    //no-svg 
    if (!feature.svg) {
      $("html").addClass("no-svg");
    }
    //no-flexbox 
    if (!feature.cssFlexbox) {
      $("html").addClass("no-flexbox");
    }
  },

  /**
   *  Parallax
   *  @see js/components/_plax.js
   */
  plax: function(){
    $('.js-parallax').parallax(6, 'false');
  },

  /**
   * Laxy Load
   * @see js/vendor/_unveil.js
   */
  lazy: function(){
    $(".js-lazy").unveil(90);
  },

  /**
   * Caption slider
   */
  captionSlider: function(){

    // Vars
    var slider = $('.js-caption-slider'),
        displayItems = $('.js-caption-slider-items'),
        displayCurrent = $('.js-caption-slider-current');

    /**
     * Init Owl Slider
     */
    slider.owlCarousel({
      items: 1,
      nav : true, // Show next and prev buttons
      dots:false,
      navpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
      loop: true,
      animateOut: "fade-out",
      animateIn: "fade-in",
      navigationText : false,
      fallbackEasing: "easeInOutCubic",
      responsiveRefreshRate: 0,
      navText: ["<i class='icon-left-chev-o'></i>","<i class='icon-right-chev-o'></i>"],
      navContainer: '#caption-slider__nav',
    });

    // Get total number of slides
    var sliderItems = $('.owl-item:not(.cloned)').length;
   
    /**
     * Display Slides total on load
     */
    displayItems.html(sliderItems);

    /** 
     * On Slide, count and display current/index
     */
    slider.on('changed.owl.carousel', function(event) {
      // Get index
      var sliderCurrent = event.item.index + 1;
      // Show Current
      displayCurrent.html(sliderCurrent);
    });
  },


  /** 
   * Slidee
   * Functionality for the Slidee/Carousel thing
   * featured on the about page.
   * @see tempaltes/about
   * @see scss/components/_slidee.scss
   */ 
  slidee: function(){
    
    // Our carousel object
    var carousel = $('.js-slidee');


    // var prev_title = $('.owl-stage').find(".owl-item.active").eq(-1).find('.slidee-mast__item').data('slidee-title');
    // var next_title = $('.owl-stage').find(".owl-item.active").eq(+1).find('.slidee-mast__item').data('slidee-title');
 
    // init Owl
    carousel.owlCarousel({
      items: 1,
      nav : true, // Show next and prev buttons
      dots:false,
      navpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
      loop: true,
      navText: ['<i class="icon-left-arrow"></i><span class="owl-nav__text">Our Community</span>','<span class="owl-nav__text">Our Culture</span><i class="icon-right-arrow"></i>'],
    });

    // On Owl Prev
    carousel.on('prev.owl.carousel', function(event) {
      prevFlag = true
    });

    /** 
     * Owl on change event for the Slidee pattern, featured on ABout page.
     * Uses the slider to display indexed content to the right.
     * Owl has documented bug with it's custom event and indexing.
     * This nomralizes that.
     */
    carousel.on('changed.owl.carousel initialize.owl.carousel', function(event) {
      // Set a previous flag
      prevFlag = '';

      var owlItems  = event.item.count,   // Total number of items (correct/consistent)
          item      = event.item.index,   // Owl reported position (wrong/inconsistent)
          calcItem  = Math.floor(item - (owlItems / 2) + 1); // slightly more logical position of the current item (if not from previous click)

          
          var prev_title = $(event.target).find(".owl-item").eq(item-1).find('.slidee-mast__item').data('slidee-title');
          var next_title = $(event.target).find(".owl-item").eq(item+1).find('.slidee-mast__item').data('slidee-title');
          console.log(prev_title, next_title);

          $('.owl-prev .owl-nav__text').html(prev_title);
          $('.owl-next .owl-nav__text').html(next_title);
      // if from previous click
      if(prevFlag) {
        if (calcItem === 0) {  // reports 0 instead of last value
          calcItem = owlItems; // solve that problem
        }
      }

      // handle values that fall outside of logical min/max bounds
      if(prevFlag === false && calcItem === 0 || calcItem > owlItems) {
        calcItem = 1;
      }

      // update counter
      console.log(calcItem + '/' + owlItems);
      
      // reset previous flag
      prevFlag = false
      $('html, body').animate({scrollTop:0}, '400', 'easeOutExpo'); 
      $('.slidee-info__wrap article').hide().removeClass('is-active');
      $('.slidee-info article:nth-child(' + calcItem + ')').show().addClass('is-active');

      //currentSlide = $('.active');


    });
  },

  /**
   * Styled Selects
   * Uses dropkick.js
   *
   * @see   js/vendor/_dropkick.js
   * @see   templates/listings.php
   */
  styledSelects : function(){
    $(".js-select").dropkick();
  },
};


/**
 * Doc ready them inits
 */
$(function(){
  // Feature JS
  site.featureJS();
  // Plax
  if($('.js-parallax').length){
    site.plax();
  }
  // Lazy Loader
  if($('.js-lazy').length){
    site.lazy();
  }
  // Plax
  if($('.js-caption-slider').length){
    site.captionSlider();
  }
  // SLidee
  if($('.js-slidee').length){
    site.slidee();
  }
  // Styled Selects vis dropkick.js
  if($('.js-select').length){
    site.styledSelects();
  }
});






// function isInViewport(element) {
//   var rect = element.getBoundingClientRect();
//   var html = document.documentElement;
//   return (
//     rect.top >= 0 &&
//     rect.left >= 0 &&
//     rect.bottom <= (window.innerHeight || html.clientHeight) &&
//     rect.right <= (window.innerWidth || html.clientWidth)
//   );
// }

// var _requestAnimationFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame;

// function scrollTrigger(element) {
//   document.addEventListener("scroll", function() {
//     var elementBounds = element.getBoundingClientRect();

//     if ((elementBounds.top >= 0) && elementBounds.bottom <= window.innerHeight + 190) {
//       element.classList.add('is-inview');
//     }
//     else {
//       element.classList.remove('is-inview');
//     }
//   });
// }
// document.addEventListener('DOMContentLoaded', function() {
  
//   var viewer = document.querySelectorAll('.js-inview');

//   viewer.forEach(function(element) {
//     scrollTrigger(element);
//     console.log('hieeeeee!');
//   });
// });

