/* Most scripts are wrapped in an Immediately-Invoked Function Expression (IIFE) to
 * prevent variables from leaking onto the global scope. For more information
 * on IIFE visit the link below.
 * @see http://en.wikipedia.org/wiki/Immediately-invoked_function_expression
 /

/** Vendor **/
// @codekit-append "vendor/_feature.js"
// @codekit-append "vendor/_unveil.js"
// @codekit-append "vendor/_owl.js"
// @codekit-append "vendor/_wow.js"
// @codekit-append "vendor/_velocity.js"
// @codekit-append "vendor/_dropkick.js"
// @codekit-append "vendor/_vides.js"

/** Components **/
// @codekit-append "components/_easings.js"
// @codekit-append "components/_page-transitions.js"
// @codekit-append "components/_about-mast.js"
// @codekit-append "components/_mast-parallax.js"
// @codekit-append "components/_home-slider.js"
// @codekit-append "components/_scrolling-nav.js"
// @codekit-append "components/_menu-nav.js"
// @codekit-append "components/_popups.js"
// @codekit-append "components/_gmaps.js"
// @codekit-append "components/_dropdown.js"
// @codekit-append "components/_sim-links.js"
// @codekit-append "components/_popups.js"
// @codekit-append "components/_listing-search.js"
// @codekit-append "components/_listing-filter-tags.js"
// @codekit-append "components/_velo-effects.js"
// @codekit-append "components/_velo-slider.js"

/** Inits **/
// @codekit-append "_inits.js"






