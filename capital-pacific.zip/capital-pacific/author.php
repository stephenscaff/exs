
<?php
/**
 * Author archive
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- Main --> 
<main role="main" class="page-author">

<section class="page-title page-title--lg">
  <div class="grid">
  <div class="page-title__content">
      <span class="page-title__pretitle">Posts By:</span>
      <h1 class="page-title__title"><?php the_author_meta('display_name'); ?></h1>
      <?php if (get_the_author_meta('description')) : ?>
      <p><?php the_author_meta('description'); ?></p>
    <?php endif; ?>
  </div>
  </div>
</section>

<section class="feeds">
  <div id="js-posts" class="feeds__grid">
<?php
$count = 0;
$args = array(
  'post_type'        => 'post',
  'posts_per_page'   => 6,
  //'offset'           => 1,
  'paged'            => $paged,
);

$wp_query = new WP_Query($args);
if (have_posts()) :  while ( $wp_query->have_posts() ) : $wp_query->the_post();
  $count++;
  $third = ($count % 3 == 0) ? 'feed--full' : '';
  include(locate_template('partials/content/content-post.php'));
endwhile; endif;
wp_reset_postdata();
?>
  </div>
</section>

<!-- Load More -->
<?php get_template_part( 'partials/partial', 'load-more' );?>

</main>

<!-- Footer  --> 
<?php get_footer(); ?>