<?php
/**
 * Template for Team Taxonomy, 'team_cat'
 *
 * @author    Stephen Scaff
 * @package   team/team-filters
 * @version   1
 * @see       inc/post-types/post-type-team.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$team_term = get_term_by( 'slug', $term, 'team_cat');
$term_name = $team_term->name;
$term_slug = $team_term->slug;
$term_desc = $team_term->description;


?>

<!-- MAIN --> 
<main role="main" class="">

<!-- Page Title -->
<section class="page-title">
  <div class="grid">
    <header class="page-title__header">
      <h1 class="page-title__title">Our team</h1>
    </header>
  </div>
</section>

<!-- Filters -->
<section class="tags">
  <div class="grid">
    <div class="tags__grid has-h-border h-border--2m">
    <header class="tags__header">
      <h3 class="tags__title">Filter by:</h3>
    </header>

    <div class="tags__content">
      <ul class="tags__list">
        <?php echo jumpoff_filter_items('team_cat'); ?>
      </ul>
    </div>
  </div>
  </div>
</section>

<!-- Teams Grid -->
<section class="teams">
  <div class="grid-full">
    <div class="teams__grid">
      
      <article class="team team-tax">
        <div class="team-tax__content">
          <h3 class="team-tax__title"><?php echo $term_name;?></h3>
          <p class="team-tax__text"><?php echo $term_desc; ?></p>
        </div>
      </article>

<?php 
$args = array(
  'post_type'        => 'team',
  'posts_per_page'   => -1,
  'paged'            => $paged,
  'tax_query'       => array(
    array(
      'taxonomy'    => 'team_cat',
      'field'       => 'slug',
      'terms'       => array( $term_slug ),
      'operator'    => 'IN',
    ),
  )
);

$wp_query = new WP_Query($args);
if (have_posts()) :  while ( $wp_query->have_posts() ) : $wp_query->the_post();
  get_template_part( 'partials/content/content', 'team' );
endwhile; endif;
?>
    </div>
  </div>
</section>

</main>

<!-- Footer  --> 
<?php get_footer(); ?>