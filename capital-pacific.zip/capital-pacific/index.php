<?php
/**
 * Template for iconv(in_charset, out_charset, str)                                                                                                                       n
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

// If not on pagination page

$args = array(
  'posts_per_page'  => 1,
);
$first = get_posts( $args );
if ( !is_paged() ) : 
  if ($first) : 
    foreach ( $first as $post ) : setup_postdata( $post );
      get_template_part( 'partials/partial', 'post-mast' ); 
    endforeach; 
  endif;
  wp_reset_postdata();
endif;

?>

<main role="main">

<!-- Filter Bar -->
<?php get_template_part( 'partials/partial', 'filter-bar' ); ?>


<section class="feeds">
  <div id="js-posts" class="feeds__grid">

<?php 
/**
 * Get Posts past first.
 */
$first_id = $first[0]->ID;
$ppp = intval(get_option('posts_per_page')); 

add_filter('post_limits', 'jumpoff_limit_posts');

$args = array(
  'post_type'        => 'post',
  'posts_per_page'   => 6,
  //'offset'           => 1,
  'paged'            => $paged,
  'post__not_in' => array($first_id)
);

$count = 0;
$wp_query = new WP_Query($args);
if (have_posts()) :  while ( $wp_query->have_posts() ) : $wp_query->the_post();
  $count++;
  $third = ($count % 3 == 0) ? 'feed--full' : '';
  include(locate_template('partials/content/content-post.php'));
endwhile; endif;
wp_reset_postdata();

remove_filter('post_limits', 'jumpoff_limit_posts');

?>

  </div>
</section>

<!-- Load More -->
<?php get_template_part( 'partials/partial', 'load-more' );?>

<!-- Conferences -->
<?php get_template_part( 'partials/partial', 'conferences' );?>

<!-- Events -->
<?php get_template_part( 'partials/partial', 'events' );?>

</main>

<!-- Footer --> 
<?php get_footer(); ?>