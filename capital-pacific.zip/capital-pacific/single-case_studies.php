<?php
/**
* The default template for single case studies
*
* @author    Stephen Scaff
* @package   jumpoff/single
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

// vars
$subtitle = get_field('subtitle');
$cs_price = get_field('cs_price');
$cs_cap_rate = get_field('cs_cap_rate');
$cs_intro = get_field('cs_intro');
$cs_team = get_field('cs_team');
$cs_map = get_field('cs_location_map');

//$vcard = new TeamVcard;
//$vcard_link = $vcard->link();

$office = jumpoff_post_term('office_location', 'slug');

?>
<!-- Google Maps -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA-27eNYal8SDSigP09PuN5eTJ8QSq86fo"></script>

<!-- MAIN -->
<main role="main">

<?php while (have_posts()) : the_post(); ?>

<article>

<!-- MAST -->
<section class="mast mast--casestudies">
  <figure class="mast__bg js-parallax" style="background-image:url(<?php echo jumpoff_ft_img('full'); ?>)"></figure>
  <div class="grid-med">
    <header class="mast__header">
      <h1 class="mast__title"><?php the_title(); ?></h1>
    </header>
    <div class="mast__cols">
      <div class="mast__col">
        <span class="mast__position"><?php echo $subtitle; ?></span>
      </div>
      <div class="mast__col mast__metas">
        <span class="mast__meta">Price <?php echo $cs_price; ?></span>
      </div>  
    </div>
  </div>
</section>

<section class="post-content has-lead pad-med">
  <div class="grid-sm">
    <?php echo $cs_intro; ?>
  </div>
</section>

<?php 
// Modules
while (has_sub_field('modules')) :
  ACF_Modules::render(get_row_layout()); 
endwhile; 
?>

<section class="related-team pad">
  <div class="grid-sm">
    <header class="team-cards__header heading">
      <h3 class="heading__title">For more insights</h3>
    </header>

    <div class="related-team__grid">
      <?php
        if ($cs_team) : 
          foreach ( $cs_team as $post ) : setup_postdata( $post ); 
            $team_phone = get_field('team_phone');
            $team_email = get_field('team_email');
          ?>
    
          <div class="related-team__item mb-2">
            <h5 class="related-team__title"><?php the_title(); ?></h5>
            <span class="related-team__contact"><?php echo $team_phone; ?></span>
            <span class="related-team__contact"><?php echo $team_email; ?></span>

            <a class="related-team__link" href="<?php the_permalink(); ?>">View Profile</a>
          </div>
        <?php
        endforeach;
        wp_reset_postdata();
        ?>
      <?php endif; ?>
    </div>
    </div>
</section>

<!-- Location Map -->
<section class="location-map">
  <div id="js-map" class="location-map__map js-location-map">
    <span class="address"><?php echo $cs_map['address']; ?></span>
  </div>
</section>

</article>

<?php endwhile; ?>

<?php get_template_part( 'partials/partial', 'next' ); ?>

</main>

<!-- FOOTER -->    
<?php get_footer(); ?>