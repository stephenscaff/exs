<?php
/**
 * Archive for Team post type
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 * @see       inc/post-types/post-type-team
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

/**
 *  Team Term Module
 *  Outputs our team pattern by tax term, which consists of 
 *  term name, desc, and then associated posts.
 *  This prevents us from writting the same code over and over,
 *  and makes it easy to add or remove terms in the future.
 *
 *  The loop uses another funciton jumpoff_cpt_tax, which is a get posts
 *  jaun, by CPT and Tax.
 *
 *  @see inc/helpers/loops.scss (for the cpt tax loop function)
 *  @see partials/partial-team (for the team markup)
 */
function team_term_module($term){
  global $post;
  
  // Vars, passed to partial-productss-heading
  $team_term = get_term_by( 'slug', $term, 'team_cat');
  
  if ($team_term) {
    $name = $team_term->name;
    $slug = $team_term->slug;
    $desc = $team_term->description;
    
    // Get our team partial, which also includes loop
    include(locate_template('partials/partial-team.php'));
  }
}

/**
 *  Team Term Modules
 *  Loops through our team terms to build out the team 
 *  archive grid and term title/desc blocks
 */
function team_term_modules(){
  global $post;
  
  $terms = get_terms( 'team_cat' ); 
  
  foreach ( $terms as $term ) {
    $team_term = get_term_by( 'slug', $term->slug, 'team_cat');

    if ($team_term) {
      $name = $team_term->name;
      $slug = $team_term->slug;
      $desc = $team_term->description;
      // Get our team partial, which also includes loop
      include(locate_template('partials/partial-team.php'));
    }
  }
}

?>

<!-- MAIN --> 
<main role="main" class="has-offset">

<!-- Page Title -->
<section class="page-title">
  <div class="grid">
    <header class="page-title__header">
      <h1 class="page-title__title">Our team</h1>
    </header>
  </div>
</section>


<!-- Filters -->
<section class="tags">
  <div class="grid">
    <div class="tags__grid">
    <header class="tags__header">
      <h3 class="tags__title">Filter by:</h3>
    </header>

    <div class="tags__content">
      <ul class="tags__list">
        <?php echo jumpoff_filter_items('team_cat'); ?>
      </ul>
    </div>
  </div>
  </div>
</section>


<section class="teams">
  <div class="grid-full">
    <div class="teams__grid">
     
<?php 
/**
 * Call our Team Term Module
 */
echo team_term_modules();
// Replaced single calls with a loop.
// echo team_term_module('brokers'); 
// echo team_term_module('research-and-analytics'); 
// echo team_term_module('transactions'); 
// echo team_term_module('marketing'); 
// echo team_term_module('behind-the-scenes'); 

?>
    </div>
  </div>
</section>

<?php get_template_part( 'partials/partial-contact-cta' ); ?>

</main>

<!-- Footer  --> 
<?php get_footer(); ?>