<?php
/**
* The default template for single Team post type
*
* @author    Urban Influence
* @package   jumpoff/single
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

// vars
$team_mast_img = get_field('team_mast_image');
$team_position = get_field('team_position');
$team_bio = get_field('team_bio');
$team_quote = get_field('team_quote');
$team_quote_img = get_field('team_quote_image');
$team_qna = 'team_qna';
$team_phone = get_field('team_phone');
$team_email = get_field('team_email');
$team_twitter = get_field('team_twitter');
$team_facebook = get_field('team_fb');
$team_linkedin = get_field('team_linkedin');
$office = jumpoff_post_term('office_location', 'slug');

?>

<!-- MAIN -->
<main role="main">

<?php while (have_posts()) : the_post(); ?>

<article>

<!-- MAST -->
<section class="mast mast--team">
  <figure class="mast__bg " style="background-image:url(<?php echo $team_mast_img['url'] ?>)"></figure>
  <div class="grid-med mast__end">
    <header class="mast__header">
      <h1 class="mast__title"><?php the_title(); ?></h1>
    </header>
    <div class="mast__contacts">
      <div class="mast__col">
        <span class="mast__position mast__subtitle"><?php echo $team_position; ?></span>
      </div>
      <div class="mast__col">
        <span class="mast__phone"><?php echo $team_phone; ?></span>
        <span class="mast__email"><?php echo $team_email; ?></span>
      </div>
      <div class="mast__col">
        <?php if ($team_twitter) : ?><a class="mast__link" href="<?php echo $team_twitter; ?>" target="_blank"><i class="icon-twitter"></i></a><?php endif; ?>
        <?php if ($team_facebook) : ?><a class="mast__link" href="<?php echo $team_facebook; ?>" target="_blank"><i class="icon-facebook"></i></a><?php endif; ?>
        <?php if ($team_linkedin) : ?><a class="mast__link" href="<?php echo $team_linkedin; ?>" target="_blank"><i class="icon-linkedin"></i></a><?php endif; ?>
      </div>  
    </div>
  </div>
</section>

<!-- Content : Bio -->
<section class="team-bio content has-lead  pad">
  <div class="grid-sm">
    <?php echo $team_bio; ?>
  </div>
</section>

<?php if ($team_quote) : ?>
<!-- Banner Quote -->
<section class="banner banner--quote">
  <div class="banner__wrap">
  <?php if ($team_quote_img) : ?>
    <figure class="banner__bg " style="background-image:url(<?php echo $team_quote_img['url'] ?>)"></figure>
  <?php endif ; ?>
  <div class="grid">
    <div class="banner__content">
      <blockquote class="quote">
        <?php echo $team_quote; ?>
      </blockquote>
    </div>
  </div>
  </div>
</section>
<?php endif; ?>

<!-- Content -->
<section class="content content-qa pad">
  <div class="grid-sm">
    <?php while( have_rows($team_qna) ): the_row(); 
    $question  = get_sub_field('question');
    $answer = get_sub_field('answer');
    ?>  
    <p class="content-qa__q"><?php echo $question; ?></p>
    <p class="content-qa__a"><?php echo $answer; ?></p>
    <?php endwhile; ?>
  </div>
</section>

</article>

<?php endwhile;
// Related Team Field
$cs_team = get_field('related_team'); 

if ($cs_team) : 

?>
<section class="teams-more">
  <div class="grid-full">
    <div class="teams-more__grid">

      <article class="team team-tax team-tax--bottom">
        <div class="team-tax__content">
          <h3 class="team-tax__title">Meet More of Our Team Members</h3>
        </div>
      </article>
    <?php
    foreach ( $cs_team as $post ) : setup_postdata( $post ); 
      $team_phone = get_field('team_phone');
      $team_email = get_field('team_email');
      get_template_part( 'partials/content/content', 'team' );
    endforeach;
    wp_reset_postdata();
  ?>
      </div>
  </div>
</section>

<?php else : ?>

<section class="teams-more">
  <div class="grid-full">
    <div class="teams-more__grid">
      <article class="team team-tax team-tax--bottom">
        <div class="team-tax__content">
          <h3 class="team-tax__title">Meet More of Our Team Members</h3>
        </div>
      </article>
      <?php $args = array(
        'posts_per_page'   => 3,
        'post_type'        => 'team',
        'orderby'          => 'rand',
        'post__not_in' => array($post->ID),
        );

        $posts = get_posts( $args );
        foreach ( $posts as $post ) : setup_postdata( $post );
          get_template_part( 'partials/content/content', 'team' );
        endforeach;
        wp_reset_postdata(); ?>
    </div>
  </div>
</section>

<?php endif; ?>
</main>

<!-- FOOTER -->    
<?php get_footer(); ?>
