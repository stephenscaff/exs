<?php
/**
* The default template for single Region post type
*
* @author    Stephen Scaff
* @package   single-regions
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

// vars
$mast_title = get_field('mast_title');
$mast_text = get_field('mast_text');
$mast_bg_color = get_field('mast_bg_color');

// Approach ID
$approach_page_id = get_page_by_title( 'Approach' ); 

//$vcard = new TeamVcard;
//$vcard_link = $vcard->link();

$office = jumpoff_post_term('office_location', 'slug');

?>
<!-- Google Maps -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA-27eNYal8SDSigP09PuN5eTJ8QSq86fo"></script>
<!-- MAIN -->
<main role="main">

<?php while (have_posts()) : the_post(); ?>

<article>

<!-- MAST -->
<section class="mast mast--region <?php echo $mast_bg_color; ?>">
  <!-- <figure class="mast__bg js-parallax" style="background-image:url(<?php echo jumpoff_ft_img('full'); ?>)"></figure> -->
  <div class="grid-med">
    <header class="mast__header">
      <h1 class="mast__title"><?php echo $mast_title; ?></h1>
    </header>
    <div class="mast__content">
    <span class="mast__subtitle"><?php echo $mast_text; ?></span>
    </div>  
  </div>
</section>

<?php 
// Modules
while (has_sub_field('modules')) :
  ACF_Modules::render(get_row_layout()); 
endwhile; 
?>

<!-- Banner -->
<section class="banner banner--center">
  <a class="banner__link" href="<?php echo jumpoff_page_url('approach'); ?>">
    <figure class="banner__bg " style="background-image:url(<?php echo jumpoff_ft_img('full', $approach_page_id); ?>)"></figure>
    <div class="grid">
      <div class="banner__content">
        <span class="banner__pretitle">Learn More</span>
        <h3 class="banner__title">It's more than just our regional approach that makes us different.</h3>
        <span class="banner__btn btn-line">Our Approach</span>
      </div>
    </div>
  </a>
</section>

<?php  get_template_part( 'partials/partial-contact-cta' ); ?>

</article>
<?php endwhile; ?>
</main>

<!-- FOOTER -->    
<?php get_footer(); ?>