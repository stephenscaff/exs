<?php
/**                                                                                                               
 * Case Studies archive/index view
 *
 * @author    Stephen Scaff
 * @package   archive
 * @version   1.0.0
  * @see      inc/post-types/post-type-case_studies
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$mast_title = get_field('mast_title', 'cpt_case_studies');
$mast_text = get_field('mast_text', 'cpt_case_studies');

?>

<!-- Main --> 
<main role="main">

<!-- Mast -->
<section class="mast mast--case-studies bg-darkgrey">
  <div class="grid-med">
    <header class="mast__header">
      <h1 class="mast__title"><?php echo $mast_title; ?></h1>
    </header>
    <div class="mast__content">
      <p class="mast__text"><?php echo $mast_text; ?></p>
    </div>
  </div>
</section>

<!-- Work -->
<section class="works">
  <div class="works__grid">

<?php 
// Get posts per page set in admin
$ppp = intval(get_option('posts_per_page')); 

// Start Post Limits filter to deal with featured post offset
add_filter('post_limits', 'jumpoff_limit_posts');

$args = array(
  'post_type'        => 'case_studies',
  'posts_per_page'   => $ppp,
  'paged'            => $paged,
  'order'            => 'DESC',
);

$count = 0;
$wp_query = new WP_Query($args);

if (have_posts()) :  while ( $wp_query->have_posts() ) : $wp_query->the_post();
  $count++;
  $third = ($count % 3 == 0) ? 'work--full' : '';
  include(locate_template('partials/content/content-case-studies.php'));
endwhile; endif;
wp_reset_postdata();

// Stop/remove post limits filter
remove_filter('post_limits', 'jumpoff_limit_posts');
?>

  </div>
</section>

<!-- Load More -->
<?php get_template_part( 'partials/partial', 'load-more' );?>

</main>

<!-- Footer  --> 
<?php get_footer(); ?>