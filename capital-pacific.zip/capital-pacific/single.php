<?php
/**
* The default template for single blog posts.
*
* @author    Stephen Scaff
* @package   jumpoff
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$conference_date = get_field('conference_date');
$conference_link = get_field('conference_link');

?>

<!-- MAIN-->
<main role="main">

<?php while (have_posts()) : the_post(); ?>

<article>

<!-- Post Mast -->
<?php get_template_part( 'partials/partial', 'post-mast' );?>

<!-- MAST -->
<section class="post-metas">
  <div class="grid-med">

    <?php if (is_singular('post')) : ?>
    <time class="post-metas__date"><?php the_time('F j, Y'); ?></time>

    <ul class="post-metas__cats">
      <li class=""><span class="post-metas__label">Tags</span></li>
      <?php echo jumpoff_categories_list(); ?>
    </ul>
  <?php elseif (is_singular('conferences')) : ?>
    <time class="post-metas__date"><?php echo $conference_date; ?></time>
    <a class="post-metas__link btn-arrow" href="<?php echo $conference_link; ?>">Conference Info</a>
  <?php endif; ?>
  </div>
</section>

<!--Post Content -->
<section class="post-content content has-lead">
  <div class="grid-sm">
      <?php the_content(); ?>
  </div>
</section>

<!-- Footer -->
<?php get_template_part( 'partials/partial', 'post-footer' );?>

</article>

<?php endwhile; ?>

<!-- Next -->
<?php get_template_part( 'partials/partial', 'next' );?>

</main>

<!-- Footer-->    
<?php get_footer(); ?>