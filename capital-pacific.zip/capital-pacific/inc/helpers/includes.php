<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

require_once('conditionals.php');
require_once('dynamic-classes.php');
require_once('formating.php');