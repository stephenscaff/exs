<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/** 
 *  jumpoff_body_class
 *  Cleans up body classes, then adds custom, based on page or cpt names
 *  @return: $classes (string)
 */
function jumpoff_body_class($classes) {
  global $post, $page;

  if (is_single() || is_page() && !is_front_page()) {
    $classes[] = 'page-' . basename(get_permalink());
  }
  if (is_home() || is_singular('post') || is_post_type_archive( 'post' )) {
    $classes[] = 'page-news';
  }
  //Example for CPTs
  if (is_singular('case_studies') || is_post_type_archive( 'case_studies' )) {
    $classes[] = 'page-case_studies';
  }

  //Example for CPTs
  if (is_post_type_archive( 'team' )) {
    $classes[] = 'page-team';
  }

  if (is_singular('team')){
    $classes[] = 'page-team-single';
  }

  // Remove Classes
  $home_id_class = 'page-id-' . get_option('page_on_front');
  $page_id_class = 'page-id-' . get_the_ID();
  $post_id_class = 'postid-' . get_the_ID();
  $page_template_page = 'page-template-page-' . basename(get_permalink());
  $page_template_name_class = 'page-template-page-' . basename(get_permalink());
  $page_template_name_php = 'page-template-page-' . basename(get_permalink()) . '-php';
  $page_templates_name_php = 'page-template-templates' . basename(get_permalink()) . '-php';

  // Remove Classes Array
  $remove_classes = array(
    'page-template-default', 
    'page-template', 
    'single-format-standard',
    'page-template-templates',

    $home_id_class,
    $page_id_class,
    $post_id_class,
    $page_template_page,
    $page_template_name_class,
    $page_template_name_php,
    $page_templates_name_php
  );

  // Add specific classes
  $classes[] = 'is-loading';
  $classes = array_diff($classes, $remove_classes);
  return $classes;
}

add_filter('body_class', 'jumpoff_body_class');



/** 
 *  jumpoff_ids()
 *  Retrieves IDs to use in calling fields.
 *  @return: $id (the id of the post)
 *  @example: $postidd = jumpoff_ids();
 */
function jumpoff_ids() {
  global $post;
  $page_for_posts = get_option( 'page_for_posts' );
  $id="";
  
  if( !is_object( $post ) ) 
     return;
  
  if (is_post_type_archive()){
    //$post_type = get_queried_object();
    $post_type = get_post_type( $post->ID );
    $cpt = $post_type; 
    $id = "cpt_$cpt";
  } elseif (is_home()){
    $id = 'options'; 
  } elseif (is_front_page()) {
    $id = get_option('page_on_front');
  } else{
    $id = $post->ID;
  }
  return $id;
}


/** 
*  jumpoff_mod_class
*  For creating BEM style modifiers
*  @return: $class (string)
*/
function jumpoff_mod_class() {
  $page_for_posts = get_option( 'page_for_posts' );
  $class='';
  if (is_home()){
    $class ='blog';
  } elseif (is_front_page()) {  
    $class ='home';
  } elseif (is_post_type('name')){
    $class = 'name';
  } elseif (is_archive()){
    $class = 'archive';
  } else {
    $class = basename(get_permalink());
  }
  return $class;
}
