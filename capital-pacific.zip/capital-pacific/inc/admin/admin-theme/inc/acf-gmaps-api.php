<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * ACF Google Maps API Key
 * Provide API key to acf / admin for storefinder post type
 */

function jumpoff_acf_init() {
  acf_update_setting('google_api_key', 'AIzaSyA-27eNYal8SDSigP09PuN5eTJ8QSq86fo');
}

add_action('acf/init', 'jumpoff_acf_init');
