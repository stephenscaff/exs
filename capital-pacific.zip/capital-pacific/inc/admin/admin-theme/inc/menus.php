<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Admin Menus
 * Cleans up menu items, removing and reordering.
 */
class AdminMenus{
  
  /**
   * Constructor
   */
  function __construct(){
    // Uncomment to remove dangerous items for all but specified admin
    //add_action( 'admin_menu', array( $this, 'remove_items') );  
    add_filter('menu_order', array( $this, 'order_items') );  
    add_filter('custom_menu_order', array( $this, 'order_items') );  
  }

  /**
   * Remove Items
   * Remove menu items if not super user (me)
   */
  function remove_items(){
    $current_user = wp_get_current_user();
    var_dump($current_user->user_nicename);
    // Get Super User - specify admin nicename
    $super_user = array('admin');
    if ( $current_user->user_nicename !== "admin" ) {
      remove_menu_page( 'edit-comments.php' );
      remove_menu_page( 'themes.php' );
      remove_menu_page( 'plugins.php' ); 
      remove_menu_page( 'tools.php' ); 
      remove_menu_page( 'edit.php?post_type=acf-field-group' ); 
    }
  }

  /**
   * Order Remaining Menu Items
   */
  function order_items($menu_order){
    if (!$menu_order) return true;

    return array(
      'index.php',
      'company-contacts',
      'upload.php',                 
      'edit.php?post_type=page',              
      'edit.php',     
      'admin.php?page=site-menu',
      'edit.php?post_type=home_slides',   
      'edit.php?post_type=case_studies',
      'edit.php?post_type=team',
      'edit.php?post_type=regions', 
      'edit.php?post_type=conferences', 
      'edit.php?post_type=events',                         
      'users.php',                              
      'separator2',                         
      'plugins.php',                       
      'tools.php',                          
      'options-general.php',                 
      'themes.php',                         
    );
  }
}

new AdminMenus;