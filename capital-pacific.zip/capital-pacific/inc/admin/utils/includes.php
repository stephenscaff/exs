<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once('post-duplicator.php');
require_once('class-wp-max-image-size.php');
