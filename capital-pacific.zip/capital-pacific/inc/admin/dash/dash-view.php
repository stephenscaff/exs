<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Clients
 *
 *  Slug : press-releases
 *  Supports : title','thumbnail', 'editor', 'excerpt'
 *
 *  @version    1.0
 *  @see        single-press-releases
 *  @see        archive-press-releases
 */

/** WordPress Administration Bootstrap */
require_once( ABSPATH . 'wp-load.php' );
require_once( ABSPATH . 'wp-admin/admin.php' );
require_once( ABSPATH . 'wp-admin/admin-header.php' );

?>

<section class="dash">

  <header class="dash-header">
    <h1 class="dash-header__title">Welcome to the Capital Pacific's CMS</h1>
    <p class="dash-header__text">From here you can create and manage the font-end experience.</p>
  </header>
  
  <section class="dash-cards">

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=home_slides' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-home"></i>

          <h3 class="dash-card__title">Home Slides</h3>

          <p class="dash-card__text">Edit the Home page slider. </p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=page' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-file-empty"></i>

          <h3 class="dash-card__title">Pages</h3>

          <p class="dash-card__text">Add new pages, or manage editing</p>
        </div>
      </a>
    </article>


    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-pencil"></i>

          <h3 class="dash-card__title">Posts / News</h3>

          <p class="dash-card__text">Manage, edit and add Blog Posts. </p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url('edit.php?post_type=case_studies'); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-book"></i>

          <h3 class="dash-card__title">Manage Successes</h3>

          <p class="dash-card__text">Create and manage Case Studies.</p>
        </div>
      </a>
    </article>


    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=team' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-eye"></i>

          <h3 class="dash-card__title">Team Members</h3>

          <p class="dash-card__text">Add, Edit and Manage Team Members</p>
        </div>
      </a>
    </article>


    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=regions' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-earth"></i>

          <h3 class="dash-card__title">Regions</h3>

          <p class="dash-card__text">Manage or edit your Regional Pages</p>
        </div>
      </a>
    </article>
    

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=conferences' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-map-marker"></i>

          <h3 class="dash-card__title">Conferences</h3>

          <p class="dash-card__text">Manage, edit and add new conference posts. </p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=conferences' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-map-marker"></i>

          <h3 class="dash-card__title">Events</h3>

          <p class="dash-card__text">Manage, edit and add new conference posts. </p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'admin.php?page=site-menu' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-link"></i>

          <h3 class="dash-card__title">Site Menu</h3>

          <p class="dash-card__text">Edit Links and Images in the site menu</p>
        </div>
      </a>
    </article>
    
    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'admin.php?page=company-contacts' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-phone-handset"></i>

          <h3 class="dash-card__title">Company Contacts</h3>

          <p class="dash-card__text">Edit global company phone numbers, socials, etc. </p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'users.php' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-lock"></i>

          <h3 class="dash-card__title">CMS Users</h3>

          <p class="dash-card__text">Add Users and their access levels </p>
        </div>
      </a>
    </article>
  </section>
</section>
<?php //include( ABSPATH . 'wp-admin/admin-footer.php' );