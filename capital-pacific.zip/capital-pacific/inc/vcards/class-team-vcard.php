<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 * Class : TeamVcard
 *
 * Class to build and save vCards for Moran's Team Members.
 * Uses the Team Post Type and it's associated fields.
 *
 * @author   Stephen Scaff
 * @package  Moran
 * @see      singe-team.php
 */
class TeamVcard{

  /**
   * Our Upload directory
   */
  private $upload_dir = '';

  /**
   * Constructor
   */
  function __construct() {
    // Upload Directory using wp_upload_dir()
    // @see https://developer.wordpress.org/reference/functions/wp_upload_dir/
    $this->upload_dir = wp_upload_dir();

    // Build on save post
    add_action( 'save_post_team', array( $this, 'create_file' )); 

  }

  /**
   * Get Words in Name
   * Since our names come from the_title instead of
   * first and last name fields, we need a method to extract them.
   */
  public function get_name($name){

    // Get the title
    $title = get_the_title();

    // Get word Count
    $words=str_word_count($title, 1);

    // If we have a 3 word name
    if (count($words) == 3){
      $first_name = $words[0] . " " . $words[1];
      $last_name = $words[2];
    } else {
      $first_name = $words[0];
      $last_name = $words[1];
    }

    // If First Name arg
    if ($name == 'first'){
      $name = $first_name;
    }
    // If last name 
    elseif ($name == 'last'){
      $name = $last_name;
    }
    return $name;
  }

  /**
   * Get Image
   * To add an image to our vcard, let's base64 out image field.
   * First, try with curl, then file_get_content
   * 
   * @return $base64_photo
   */
  public function get_img($img){
    // Use cUrl if we can
    if (function_exists('curl_init')) { 
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_HEADER, 0);
      curl_setopt($ch, CURLOPT_URL, $img);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      $base64_photo = base64_encode(curl_exec($ch));
      curl_close($ch);
    } else { 
      // try using file_get_content  
      $base64_photo = base64_encode(file_get_contents($img, true));
    }
    
    return $base64_photo;
  }

   /**
   * Link
   * So, had issues with getting directory with the method get_dir.
   * This seems to work. We jsuted neededa way to get the file on 
   * the front end, from the single-team template.
   * Our dir: /wp-content/uploads/vcards
   * 
   * $vcard = new TeamVcard;
   * $vcard_link = $vcard->link();
   *
   * @return (string) $vcf_dir
   */
  public function link(){
    global $post;
    $post_slug = $post->post_name;
    $upload_dir = wp_upload_dir();
    $file_url = $upload_dir['baseurl'] . '/vcards/' . $post_slug . '.vcf';

    return $file_url;
  }


  /**
   * Get Directory
   * Get's the directory of the team memeber's vcard file
   *
   * @return (string) $vcf_dir
   */
  public function get_dir(){
    global $post;
    $post_slug = $post->post_name;
    $vcf_dir = $this->upload_dir['basedir'] . '/vcards/' . $post_slug . '.vcf';

    return $vcf_dir;
  }


  /**
   * Create File
   * First set vcard content with our fields
   * Then if dir is writable, create our vcf file.
   */
  public function create_file() {
    
    global $post;
    
    $id = $post->ID;
    $full_name = get_the_title();
    $title = get_post_meta($id, 'team_title', true);
    $phone = get_post_meta($id,'team_phone', true);
    $email = get_post_meta($id, 'team_email', true);
    $img_id = get_post_meta($id, 'team_image_small', true);
    $img =  wp_get_attachment_url($img_id);

// Our vcard content
$vcard_contents = 'BEGIN:VCARD
VERSION:3.0
N:' . $this->get_name('last') . ';' . $this->get_name('first') .'
FN:' . $full_name . '
PHOTO;ENCODING=b;TYPE=JPEG:' . $this->get_img($img) . '
ORG:Moran & Company;
TITLE:'.$title.'
TEL;TYPE=WORK,VOICE:'.$phone.'
TEL;TYPE=CELL,VOICE:'.$phone_2.'
EMAIL;TYPE=PREF,INTERNET:'.$email.'
item1.X-ABADR:us
item2.X-ABADR:us
item3.URL;type=pref:http\://moranandco/com/
END:VCARD';
    
    $file_link = $this->get_dir();

    // If writable, create our vcf file
    if (is_writable($this->upload_dir['basedir'] . '/')) {
      
      $vcf_file = fopen($file_link, "w");
      fwrite($vcf_file, $vcard_contents);
      fclose($vcf_file);

    } else {
      // Some Error Info
      echo "ERROR: Please ensure the vcard directory is writable
      <pre>" . print_r($upload_dir['basedir'],true) . "</pre>
      <pre>" . print_r(pathinfo(__FILE__)) . "</pre>";
    }
  }
}
# Init
new TeamVcard();
