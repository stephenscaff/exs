<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once('permalinks.php');
require_once('support.php');
require_once('image-settings.php');
require_once('cf7.php');
