<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  CF7 Skip Mailer
 *  be the same and actually work.
 */
add_filter('wpcf7_skip_mail','cf7_skip_mailer');

function cf7_skip_mailer($f){
  $submission = WPCF7_Submission::get_instance();
  return true;
 }
