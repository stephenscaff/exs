<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

require_once('nav.php');
require_once('paths.php');
//require_once('rewrites.php');