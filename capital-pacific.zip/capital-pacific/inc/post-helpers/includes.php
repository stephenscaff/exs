<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

require_once('images.php');
require_once('loops.php');
require_once('pagination.php');
require_once('post-templates.php');
require_once('taxonomies.php');
require_once('cpt-nav.php');
require_once('query-filters.php');