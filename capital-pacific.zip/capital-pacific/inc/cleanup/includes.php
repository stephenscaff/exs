<?php

if ( ! defined( 'ABSPATH' ) ) exit; 

require_once('cleanup.php');