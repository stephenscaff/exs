<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

require_once('class-acf-modules.php');
require_once('index-fields.php');