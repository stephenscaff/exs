<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Case Studies
 *
 *  Slug :      Case Studies
 *  Supports : 'title','thumbnail', 'excerpt', 'editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 *  @see        single-Case Studies.php
 *  @see        archive-Case Studies.php
 */

add_action('init', 'create_case_studies_post_type');

function create_case_studies_post_type() {
  
  register_post_type( 'case_studies', 

  array(
    'labels'              => array(
    'name'                => __( 'Case Studies' ),
    'singular_name'       => __( 'Case Studies' ),
    'add_new'             => __( 'Add Case Studies' ),
    'add_new_item'        => __( 'Add Case Studies' ),
    'edit'                => __( 'Edit Case Studies' ),
    'edit_item'           => __( 'Edit Case Studies' ),
    'new_item'            => __( 'New Case Studies' ),
    'view'                => __( 'View This Case Studies' ),
    'view_item'           => __( 'View This Case Studies ' ),
    'search_items'        => __( 'Search Case Studies' ),
    'not_found'           => __( 'Sorry Buddy. That Event cannot be found' ),
    'not_found_in_trash'  => __( 'That Event is not in the Trash' ),
  ),

  'description'           => __( 'Capital Pacific Case Studies.' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_dashicon'         => 'dashicons-book-alt',
  'menu_icon'             => 'dashicons-book-alt',
  'query_var'             => true,  
  'supports'              => array( 'title','thumbnail', 'excerpt' ),
  'capability_type'       => 'post',
  'can_export'            => true,
  'has_archive'           => true,
  'rewrite'               => array('slug' => 'case-studies', 'with_front' => false),
  ));
}


/**
 *  Taxonomy: Event Cat
 *
 *  Creates 'Case Studies Category' custom taxonomy
 *
 *  Slug : Event-category
 *  hierarchical : true
 *
 *  @version    1.0
 */
//add_action( 'init', 'Case Studies_cat');

function case_studies_cat() {
  
  register_taxonomy(
  'case_studies_cat', 

  // Apply our taxonomy to the following post types
  array( 'Case Studies'), 
  array(  
    'labels'             => array(
    'name'               => _x('Event Categories', 'taxonomy general name'),
    'singular_name'      => _x('Event Category', 'taxonomy singular name'),
    'search_items'       => __('Search Event Categories '),
    'all_items'          => __('All Event Categories'),
    'edit_item'          => __('Edit Event Category'),
    'update_item'        => __('Update Event Category'),
    'add_new_item'       => __('Add New Event Category'),
    'new_item_name'      => __('New Event Category'),
    'menu_name'          => __('Event Categories'),
  ),
  'hierarchical'         => true,  
  'show_ui'              => true,
  'show_admin_column'    => true,
  'show_in_quick_edit'   => true,
  'rewrite'              => array(
    'slug'               => 'Event-category',
    'with_front'         => false, 
    ),
  ));
}