<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 *  Post Type: Team
 *
 *  Slug :      team
 *  Supports : 'title','thumbnail', 'editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 *  @see        single-team.php
 *  @see       
 */

add_action('init', 'create_team_post_type');

function create_team_post_type() {
  
  register_post_type( 'team', 

  array(
    'labels'              => array(
    'name'                => __( 'Team' ),
    'singular_name'       => __( 'Team' ),
    'add_new'             => __( 'Add Team Member' ),
    'add_new_item'        => __( 'Add Team Member' ),
    'edit'                => __( 'Edit Team Member' ),
    'edit_item'           => __( 'Edit Team Member' ),
    'new_item'            => __( 'New Team Member' ),
    'view'                => __( 'View This Team Member' ),
    'view_item'           => __( 'View This Team Member ' ),
    'search_items'        => __( 'Search Team Members' ),
    'not_found'           => __( 'Sorry Buddy. That Team Member cannot be found' ),
    'not_found_in_trash'  => __( 'That Team Member is not in the Trash' ),
  ),

  'description'           => __( 'The Capital Pacific Team.' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_position'         => 6,
  'menu_dashicon'         => 'dashicons-groups',
  'menu_icon'             => 'dashicons-groups',
  'query_var'             => true,  
  'supports'              => array( 'title','thumbnail'),
  'capability_type'       => 'post',
  'can_export'            => true,
  'has_archive'           => true,
  'rewrite'               => array('slug' => 'team', 'with_front' => false),
  ));
}



/**
 *  Taxonomy: Team Cat
 *
 *  Creates 'Team Cat' custom taxonomy
 *
 *  Slug : team-cat
 *  hierarchical : true
 *  Borkers and associates, analysistes,transactions,  marketing,  behind
 *  
 *  @version    1.0
 */
add_action( 'init', 'team_cat');

function team_cat() {
  
  register_taxonomy(
  'team_cat', 

  // Apply our taxonomy to the following post types
  array( 'team'), 
  array(  
    'labels'             => array(
    'name'               => _x('Team Categories', 'taxonomy general name'),
    'singular_name'      => _x('Team Category', 'taxonomy singular name'),
    'search_items'       => __('Search Team Categories '),
    'all_items'          => __('All Team Categories'),
    'edit_item'          => __('Edit Team Category'),
    'update_item'        => __('Update Team Category'),
    'add_new_item'       => __('Add New Team Category'),
    'new_item_name'      => __('New Team Category'),
    'menu_name'          => __('Team Categories'),
  ),
  'hierarchical'         => true,  
  'show_ui'              => true,
  'show_admin_column'    => true,
  'show_in_quick_edit'   => true,
  'rewrite'              => array(
    'slug'               => 'team-filters',
    'with_front'         => false, 
    ),
  ));
}

