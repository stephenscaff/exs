<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Events
 *
 *  Slug :      Events
 *  Supports : 'title','thumbnail', 'excerpt', 'editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 *  @see        single-Events.php
 *  @see        archive-Events.php
 */

add_action('init', 'create_events_post_type');

function create_events_post_type() {
  
  register_post_type( 'events', 

  array(
    'labels'              => array(
    'name'                => __( 'Events' ),
    'singular_name'       => __( 'Event' ),
    'add_new'             => __( 'Add Event' ),
    'add_new_item'        => __( 'Add Event' ),
    'edit'                => __( 'Edit Event' ),
    'edit_item'           => __( 'Edit Event' ),
    'new_item'            => __( 'New Event' ),
    'view'                => __( 'View This Event' ),
    'view_item'           => __( 'View This Event ' ),
    'search_items'        => __( 'Search Events' ),
    'not_found'           => __( 'Sorry Buddy. That Event cannot be found' ),
    'not_found_in_trash'  => __( 'That Event is not in the Trash' ),
  ),

  'description'           => __( 'Capital Pacific Events.' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_dashicon'         => 'dashicons-pressthis',
  'menu_icon'             => 'dashicons-pressthis',
  'query_var'             => true,  
  'supports'              => array( 'title','thumbnail', 'editor', 'excerpt', 'author' ),
  'capability_type'       => 'post',
  'can_export'            => true,
  'has_archive'           => true,
  'rewrite'               => array('slug' => 'events', 'with_front' => false),
  ));
}


/**
 *  Taxonomy: Event Cat
 *
 *  Creates 'Events Category' custom taxonomy
 *
 *  Slug : Event-category
 *  hierarchical : true
 *
 *  @version    1.0
 */
//add_action( 'init', 'Events_cat');

function events_cat() {
  
  register_taxonomy(
  'events_cat', 

  // Apply our taxonomy to the following post types
  array( 'Events'), 
  array(  
    'labels'             => array(
    'name'               => _x('Event Categories', 'taxonomy general name'),
    'singular_name'      => _x('Event Category', 'taxonomy singular name'),
    'search_items'       => __('Search Event Categories '),
    'all_items'          => __('All Event Categories'),
    'edit_item'          => __('Edit Event Category'),
    'update_item'        => __('Update Event Category'),
    'add_new_item'       => __('Add New Event Category'),
    'new_item_name'      => __('New Event Category'),
    'menu_name'          => __('Event Categories'),
  ),
  'hierarchical'         => true,  
  'show_ui'              => true,
  'show_admin_column'    => true,
  'show_in_quick_edit'   => true,
  'rewrite'              => array(
    'slug'               => 'event-category',
    'with_front'         => false, 
    ),
  ));
}