<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 *  Taxonomy: Office Location
 *
 *  Creates 'Office Location' custom taxonomy
 *  SF = blue, PDX = gold, SEA = grey
 *
 *  Slug : na
 *  hierarchical : false
 *  @author     Stephen Scaff
 *  @version    1.0
 */
add_action( 'init', 'office_location_tax');

function office_location_tax() {
  
  register_taxonomy(
  'office_location', 

  // Apply our taxonomy to the following post types
  array( 'team'), 
  array(  
    'labels'             => array(
    'name'               => _x('Office Locations', 'taxonomy general name'),
    'singular_name'      => _x('Office Locations', 'taxonomy singular name'),
    'search_items'       => __('Search Office Locations '),
    'all_items'          => __('All Office Locations'),
    'edit_item'          => __('Edit Office Location'),
    'update_item'        => __('Update Office Location'),
    'add_new_item'       => __('Add New Office Location'),
    'new_item_name'      => __('New Office Location'),
    'menu_name'          => __('Office Location'),
  ),
  'hierarchical'         => true,  
  'show_ui'              => true,
  'show_admin_column'    => true,
  'show_in_quick_edit'   => true,
  // 'rewrite'              => array(
  //   'slug'               => 'regions',
  //   'with_front'         => false, 
  //   ),
  ));
}