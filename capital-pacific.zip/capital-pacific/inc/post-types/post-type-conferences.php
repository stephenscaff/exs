<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 *  Post Type: Team
 *
 *  Slug :      team
 *  Supports : 'title','thumbnail', 'editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 *  @see        single-team.php
 *  @see       
 */

add_action('init', 'create_conferences_post_type');

function create_conferences_post_type() {
  
  register_post_type( 'conferences', 

  array(
    'labels'              => array(
    'name'                => __( 'Conferences' ),
    'singular_name'       => __( 'Conferences' ),
    'add_new'             => __( 'Add Conferences ' ),
    'add_new_item'        => __( 'Add Conferences ' ),
    'edit'                => __( 'Edit Conferences ' ),
    'edit_item'           => __( 'Edit Conferences ' ),
    'new_item'            => __( 'New Conferences' ),
    'view'                => __( 'View This Conference ' ),
    'view_item'           => __( 'View This Conference ' ),
    'search_items'        => __( 'Search Conferences' ),
    'not_found'           => __( 'Sorry Buddy. That Conference cannot be found' ),
    'not_found_in_trash'  => __( 'That Conference is not in the Trash' ),
  ),

  'description'           => __( 'Capital Pacific Conferences.' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_position'         => 6,
  'menu_dashicon'         => 'dashicons-groups',
  'menu_icon'             => 'dashicons-groups',
  'query_var'             => true,  
  'supports'              => array( 'title','thumbnail', 'editor'),
  'capability_type'       => 'post',
  'can_export'            => true,
  'has_archive'           => true,
  'rewrite'               => array('slug' => 'conferences', 'with_front' => false),
  ));
}

