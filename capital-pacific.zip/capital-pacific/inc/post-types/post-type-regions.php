<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Events
 *
 *  Slug :      Events
 *  Supports : 'title','thumbnail', 'excerpt', 'editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 *  @see        single-Events.php
 *  @see        archive-Events.php
 */

add_action('init', 'create_regions_post_type');

function create_regions_post_type() {
  
  register_post_type( 'regions', 

  array(
    'labels'              => array(
    'name'                => __( 'Regions' ),
    'singular_name'       => __( 'Region' ),
    'add_new'             => __( 'Add Region' ),
    'add_new_item'        => __( 'Add Region' ),
    'edit'                => __( 'Edit Region' ),
    'edit_item'           => __( 'Edit Region' ),
    'new_item'            => __( 'New Region' ),
    'view'                => __( 'View This Region' ),
    'view_item'           => __( 'View This Region ' ),
    'search_items'        => __( 'Search Regions' ),
    'not_found'           => __( 'Sorry Buddy. That Region cannot be found' ),
    'not_found_in_trash'  => __( 'That Region is not in the Trash' ),
  ),

  'description'           => __( 'Region.' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_dashicon'         => 'dashicons-admin-site',
  'menu_icon'             => 'dashicons-admin-site',
  'query_var'             => true,  
  'supports'              => array( 'title' ),
  'capability_type'       => 'post',
  'can_export'            => true,
  'has_archive'           => true,
  'rewrite'               => array('slug' => 'regions', 'with_front' => false),
  ));
}
