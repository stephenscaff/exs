<?php
/**
 * Flush Rewrites
 */
add_action( 'after_switch_theme', 'jumpoff_flush_rewrite_rules' );

// Flush your rewrite rules
function jumpoff_flush_rewrite_rules() {
  flush_rewrite_rules();
}

require_once('tax-post-functions.php');
require_once('tax-office-location.php');
require_once('post-type-case-studies.php');
require_once('post-type-conferences.php');
require_once('post-type-events.php');
require_once('post-type-regions.php');
require_once('post-type-team.php');
require_once('post-type-home-slides.php');