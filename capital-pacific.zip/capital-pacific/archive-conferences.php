<?php
/**
 * Archive template for the Conferences post type
 * @author    Stephen Scaff
 * @package   archive
 * @version   2.0.0
 * @see       inc/post-types/post-type-conferences
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- MAIN --> 
<main role="main" class="has-offset">

<!-- Page Title -->
<section class="page-title">
  <div class="grid">
    <header class="page-title__header">
    <?php if (is_post_type_archive()) : ?>
      <h1 class="page-title__title"><?php post_type_archive_title(); ?></h1>
    <?php endif; ?>
    </header>
  </div>
</section>


<!-- Posts-->
<section class="conferences conferences--offset">
  <div class="grid">
    <div class="conferences__grid">
  <?php
    if ( have_posts() ): while ( have_posts() ) : the_post();
      get_template_part( 'partials/content/content', 'conferences' );
    endwhile; else: 
      get_template_part( 'partials/content/content', 'none' );
    endif;
    ?>
  </div></div>
</section>

<!-- Load More -->
<?php get_template_part( 'partials/partial', 'load-more' );?>

</main>

<!-- Footer  --> 
<?php get_footer(); ?>