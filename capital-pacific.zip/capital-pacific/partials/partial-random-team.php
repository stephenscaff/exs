<?php
/**
 * Region Map
 * And svg US map, that highlights CP's region, with links to Region Pages (via region post type)
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<section class="teams-more">
  <div class="grid-full">
    <div class="teams-more__grid">
      <article class="team team-tax">
        <div class="team-tax__content">
          <h3 class="team-tax__title">Brokers & associates</h3>
          <p class="team-tax__text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eros dui, suscipit a congue tempor, venenatis at est. Ut sit amet scelerisque turpis. Etiam commodo volutpat eros nec fringilla. Fusce vitae aliquam enim.</p>
        </div>
      </article>
      <?php $args = array(
        'posts_per_page'   => 3,
        'post_type'        => 'team',
        'orderby'          => 'rand',
        'post__not_in' => array($post->ID),
        );

        $posts = get_posts( $args );
        foreach ( $posts as $post ) : setup_postdata( $post );
          get_template_part( 'partials/content/content', 'team' );
        endforeach;
        wp_reset_postdata(); ?>
    </div>
  </div>
</section>