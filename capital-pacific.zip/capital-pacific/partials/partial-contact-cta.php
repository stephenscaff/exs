<?php
/**
 *  Partial : Contact CTA
 *
 *  Adds a Div Link for the contact cta fields, with conditional for 
 *  a page link or mailto;
 *
 * @author    Stephen Scaff
 * @package   partials
 * @see       scss/components/_div-links.scss
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// I don't know man...
if (is_post_type_archive('team')) :
$id = jumpoff_ids();
endif;

// Vars
$c_cta_pretitle = get_field('c_cta_pretitle', $id);
$c_cta_title = get_field('c_cta_title', $id);
$c_cta_email = get_field('c_cta_email', $id);
$c_cta_link = get_field('c_cta_link', $id);
$c_cta_link_text = get_field('c_cta_link_text', $id);
$c_cta_bg_color = get_field('c_cta_bg_color', $id);
?>

<!-- Contact CTA -->
<section class="div-link">
  <div class="grid-xl">
    <?php if ($c_cta_email) : ?>
    <a class="div-link__link <?php echo $c_cta_bg_color; ?>" href="mailto:<?php echo $c_cta_email; ?>" target="_blank">
    <?php else : ?>
    <a class="div-link__link <?php echo $c_cta_bg_color; ?>" href="<?php echo $c_cta_link; ?>">
    <?php endif; ?>
      <header class="div-link__header">
        <span class="div-link__pretitle"><?php echo $c_cta_pretitle; ?></span>
        <h1 class="div-link__title"><?php echo $c_cta_title; ?></h1>
        <span class="div-link__btn btn-line btn--white"><?php echo $c_cta_link_text; ?></span>
      </header>
    </a>
  </div>
</section>