<?php
/**
 * Partial: Conferences
 *
 * Gets conferences post type with link to archive
 *  
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<!-- Conferences -->
<section class="conferences conferences--offset">
  <div class="grid">
    <div class="conferences__grid">
    <?php 
    $args = array(
      'posts_per_page'   => 9,
      'post_type'        => 'conferences',
    );

    $posts = get_posts( $args );

    foreach ( $posts as $post ) : setup_postdata( $post );
      get_template_part( 'partials/content/content', 'conferences' );
    endforeach;
    wp_reset_postdata();
    ?>
    </div>
  </div>
</section>

<!-- View All -->
<section class="view-all">
  <div class="grid">
    <a class="btn-draw btn--alpha" href="<?php echo get_post_type_archive_link( 'conferences' ); ?>"><span class="btn-draw__text"><span>View All Conferences</span></span></a>
  </div>
</section>

