<?php
/**
 * Partial: Header
 * The main header region partial
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version    1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


$site_menu = 'site_menu';

?>

<body id="top" <?php body_class(); ?>>

<!-- SITE HEADER -->
<header class="site-header">
  <div class="site-header__grid">
    <!-- Logo -->
    <a href="/" class="site-header__logo">
      <svg class="logo-svg" xmlns="http://www.w3.org/2000/svg" width="285.632" height="51.629" viewBox="0 0 285.632 51.629">
        <path fill="#F05346" d="M26.075.478C12.227.478 1 11.705 1 25.553s11.227 25.075 25.075 25.075c13.849 0 25.075-11.227 25.075-25.075S39.924.478 26.075.478zm5.08 36.566v-4.008c3.361-1.618 4.765-4.798 4.765-8.287 0-4.551-2.791-8.462-7.751-9.251V41.51c-.695.094-1.4.159-2.121.159-.533 0-1.059-.028-1.578-.08v-4.088c-6.951-.844-12.647-6.485-12.647-12.981 0-5.408 4.094-10.395 9.602-12.274v4.026c-3.342 1.627-5.005 4.779-5.005 8.248 0 4.552 3.09 8.462 8.05 9.251V11.654h1.85c7.828 0 14.196 5.875 14.196 13.096.001 5.424-3.835 10.431-9.361 12.294z"/>
        <g fill="#F05346">
          <path d="M75.486 19.589c1.223 0 2.201.301 2.935.79v2.935c-.827-.64-1.731-.941-2.69-.941-1.92 0-3.142 1.185-3.142 3.18 0 1.976 1.222 3.16 3.142 3.16.959 0 1.863-.281 2.69-.921v2.934c-.734.489-1.712.79-2.935.79-3.518 0-5.926-2.37-5.926-5.963-.001-3.593 2.408-5.964 5.926-5.964zM92.187 19.777l4.402 11.552h-3.067l-.828-2.238H88.5l-.809 2.238H84.7l4.402-11.552h3.085zm-2.766 6.83h2.371l-1.185-3.255-1.186 3.255zM106.086 27.736v3.593h-2.991V19.777h5.061c2.503 0 4.196 1.411 4.196 3.989 0 2.559-1.694 3.97-4.196 3.97h-2.07zm1.75-5.419h-1.75v2.898h1.75c1.092 0 1.581-.583 1.581-1.449 0-.884-.49-1.449-1.581-1.449zM122.328 31.329h-3.029V19.777h3.029v11.552zM129.217 19.777h10.161v2.597h-3.575v8.955h-3.029v-8.955h-3.556v-2.597zM151.455 19.777l4.402 11.552h-3.067l-.828-2.238h-4.195l-.809 2.238h-2.991l4.402-11.552h3.086zm-2.766 6.83h2.371l-1.185-3.255-1.186 3.255zM162.179 19.777h3.029v8.937h5.173v2.615h-8.203V19.777z"/>
          <g>
            <path d="M190.11 27.736v3.593h-2.991V19.777h5.061c2.503 0 4.196 1.411 4.196 3.989 0 2.559-1.694 3.97-4.196 3.97h-2.07zm1.75-5.419h-1.75v2.898h1.75c1.092 0 1.581-.583 1.581-1.449 0-.884-.49-1.449-1.581-1.449zM208.843 19.777l4.402 11.552h-3.067l-.827-2.238h-4.196l-.809 2.238h-2.991l4.402-11.552h3.086zm-2.766 6.83h2.371l-1.185-3.255-1.186 3.255zM224.403 19.589c1.223 0 2.201.301 2.935.79v2.935c-.827-.64-1.731-.941-2.69-.941-1.92 0-3.142 1.185-3.142 3.18 0 1.976 1.222 3.16 3.142 3.16.959 0 1.863-.281 2.69-.921v2.934c-.734.489-1.712.79-2.935.79-3.518 0-5.926-2.37-5.926-5.963s2.408-5.964 5.926-5.964zM237.559 31.329h-3.029V19.777h3.029v11.552zM244.937 31.329V19.777h8.128v2.615h-5.137v2.296h4.723v2.559h-4.723v4.082h-2.991zM263.155 31.329h-3.029V19.777h3.029v11.552zM275.521 19.589c1.223 0 2.201.301 2.935.79v2.935c-.827-.64-1.731-.941-2.69-.941-1.92 0-3.142 1.185-3.142 3.18 0 1.976 1.222 3.16 3.142 3.16.959 0 1.862-.281 2.69-.921v2.934c-.734.489-1.712.79-2.935.79-3.518 0-5.926-2.37-5.926-5.963-.001-3.593 2.408-5.964 5.926-5.964z"/>
          </g>
        </g>
      </svg>
    </a>

    <!-- Main Nav-->
    <nav class="site-header__nav" role="navigation">
      
      <a href="http://cp.capitalpacific.com/FindProperties">View Property Offerings</a>

      <a class="menu-link js-menu-toggle">
        <div class="menu-link__bars"><span></span></div>
        <div class="menu-link__text">Menu</div>
      </a> 
    </nav>
  </div>
</header>

<!-- Site Menu -->
<section class="site-menu" aria-hidden="true">
  <section class="site-menu__bgs">
    <?php 
      while( have_rows($site_menu, 'option') ): the_row(); 
      $img = get_sub_field('image');
    ?>
      <figure class="site-menu__bg js-site-menu-bg" style="background-image: url(<?php echo $img['url']; ?>);"></figure>
    <?php endwhile; ?>
  </section>
  <div class="site-menu__content">
    <nav class='site-menu__nav'>
      <ol>
       <?php 
       $menu_count = 0;
       while( have_rows($site_menu, 'option') ): the_row(); 
        $name  = get_sub_field('name');
        $link = get_sub_field('link');
        $ext_link = get_sub_field('external_link');
        $img = get_sub_field('image');
        $menu_count++;

        $page_link = "";
        if ($ext_link) {
           $page_link = $ext_link;
        } else {
           $page_link = $link;
        }
        ?>
        <li><span><a class="js-site-menu-link" href="<?php echo $page_link; ?>"><span class="site-menu__numb">0<?php echo $menu_count; ?></span> <?php echo $name; ?></a></span></li>
      <?php endwhile; ?>
      </ol>
    </nav>
  </div>
</section>