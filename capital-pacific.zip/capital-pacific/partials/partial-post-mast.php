<?php
/**
 *  Post Mast
 *
 *  The Partial for Post Masts/Headers and
 *  Featured Posts on blog index (with conditionals to show link)
 *
 * @author    Stephen Scaff
 * @package   vaela/partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$subtitle = get_field('subtitle');

?>

<!-- MAST -->
<section class="mast mast--post">
  <figure class="mast__bg " style="background-image:url(<?php echo jumpoff_ft_img('full'); ?>)"></figure>
  <div class="grid-med">
    <header class="mast__header">
      <?php if (is_home()) : ?>
      <span class="mast__pretitle">Featured</span>
    <?php endif; ?>
      <h1 class="mast__title"><?php the_title(); ?></h1>
    </header>
    <?php if ($subtitle) : ?>
    <div class="mast__cols">
      <div class="mast__col">
        <span class="mast__text"><?php echo $subtitle; ?></span>
      </div>
    </div>
  <?php endif; ?>
    <?php if (is_home()) :?>
      <a class="mast__btn btn-draw btn--white" href="<?php the_permalink(); ?>"><span class="btn-draw__text"><span>Read More</span></span></a>
    <?php endif; ?>
  </div>
</section>