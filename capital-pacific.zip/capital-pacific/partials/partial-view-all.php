<?php
/**
 * Section: Pagination
 *
 * Calls pagination funciton
 *  
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<?php 
/**
 * Get Posts past first.
 */
$args = array(
  'post_type'       => 'events',
  'posts_per_page'  => 1,
);
$first_event = get_posts( $args );
if ( !is_paged() ) : 
  if ($first_event) : 
    foreach ( $first_event as $post ) : setup_postdata( $post );
      get_template_part( 'partials/content/content', 'event-featured' ); 
    endforeach; 
  endif;
  wp_reset_postdata();
endif;

?>


<section class="events pad">
  <div class="grid">
    <div class="events__grid">
    <?php 
    $first_event_id = $first_event[0]->ID;
    $args = array(
      'posts_per_page'   => 9,
      'post_type'        => 'events',
      'post__not_in' => array($first_event_id)
    );

    $events = get_posts( $args );

    foreach ( $events as $post ) : setup_postdata( $post );
      get_template_part( 'partials/content/content', 'events' );
    endforeach;
    wp_reset_postdata();
    ?>

    </div>
  </div>
</section>

<section class="view-all">
  <div class="grid">
    <a class="btn-draw btn--alpha" href="<?php echo get_post_type_archive_link( 'events' ); ?>"><span class="btn-draw__text"><span>View All Events</span></span></a>
  </div>
</section>