<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly
/**
 *  Partial: Filter Bar
 *  A sticky filterbar to filter post taxonomies.
 *
 *  @author     Stephen Scaff
 *  @package    partials
 *  @version    1.0
 */

?>
<div class="sticky-wrap">
  <section class="filter-bar js-sticky">
    <div class="grid-lg">
      <div class="filter-bar__content">
        <span class="filter-bar__label">Our Thoughts and Latest News</span> <br/>
        
        <div class="dropdown js-dropdown">
          <span class="dropdown__caret"></span>
          <nav>
            <ul>
              <li class="dropdown__label"><span data-label="View by Category">Select Category</span></li>
              <?php echo jumpoff_categories_list(); ?>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </section>
</div>