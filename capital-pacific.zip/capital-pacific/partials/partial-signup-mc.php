<?php
/**
 * Partial Signup
 *
 * MC Signup Partial
 *
 * @author    Stephen Scaff
 * @package   partials/
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


?>

<section id="signup-newsletter" class="popup" aria-hidden="true">  
  <button class="popup__close js-close-popup" aria-label="Close">
    <div class="popup__x"></div>
  </button> 

  <section class="signup signup--dark">
    <div class="signup__content">
      
      <div class="grid">
          
        <header class="signup__header">
          <h3 class="signup__title color-alpha">Join The Mailing List</h3>
        </header>  
        <form id="mc-embedded-subscribe-form" class="signup-form form--minimal form--dark" name="mc-embedded-subscribe-form" action="https://sprealestate.us12.list-manage.com/subscribe/post-json?u=7f66acd0a723eb267712053a2&amp;id=e484081e75&amp;c=?" method="POST" target="_blank" novalidate>
          
          <div class="signup__inputs signup__cols">
            
            <div class="signup__control">
              <input class="signup__input" id="mce-FNAME" name="FIRSTNAME"  value="" type="text" aria-label="First Name" aria-required="true" required="" placeholder="First Name">
            </div>

            <div class="signup__control">
              <input class="signup__input" id="mce-LNAME" type="text" value="" name="LNAME" placeholder="Last Name" >
            </div>

            <div class="signup__control">
              <input class="signup__input" id="mce-PHONE" type="text" name="PHONE" class="required" value="" placeholder="Phone Number">
            </div>

            <div class="signup__control">
              <input class="signup__input email" id="mce-EMAIL" name="EMAIL"  value="" type="email" aria-label="Email Address" aria-required="true" placeholder="Enter you email address">
            </div>

            <div class="signup__control">
              <label class="signup__select-label">
                <select class="signup__select" id="" name="">
                  <option disabled="" selected="">Property Region</option>
                  <option value="">Midwest</option>
                  <option value="">Pacific Northwest</option>
                  <option value="">Westcoast</option>
                </select>
              </label>
            </div>

            <div class="signup__control">
              <label class="signup__select-label">
                <select class="signup__select" id="" name="">
                  <option disabled="" selected>Investor Profile</option>
                  <option value="" disabled="">Midwest</option>
                  <option value="" disabled="">Pacific Northwest</option>
                  <option value="" disabled="">Westcoast</option>
                </select>
              </label>
            </div>

            <div class="signup__control">
              <label class="signup__select-label">
                <select class="signup__select" id="" name="">
                  <option disabled="" selected>Investor Profile</option>
                  <option value="" disabled="">Midwest</option>
                  <option value="" disabled="">Pacific Northwest</option>
                  <option value="" disabled="">Westcoast</option>
                </select>
              </label>
            </div>

            <div class="signup__control">
              <label class="signup__select-label">
                <select class="signup__select" id="" name="">
                  <option disabled="" selected>Property Type</option>
                  <option value="" disabled="">Midwest</option>
                  <option value="" disabled="">Pacific Northwest</option>
                  <option value="" disabled="">Westcoast</option>
                </select>
              </label>
            </div>

            <div class="signup__control">
              <label class="signup__select-label">
                <select class="signup__select" id="" name="">
                  <option disabled="" selected>Price Rabge</option>
                  <option value="" disabled="">Midwest</option>
                  <option value="" disabled="">Pacific Northwest</option>
                  <option value="" disabled="">Westcoast</option>
                </select>
              </label>
            </div>


            <div style="position: absolute; left: -5000px;"><input type="text" name="b_7f66acd0a723eb267712053a2_e484081e75" value=""></div>
              
            <div class="signup__btn-control">
            <button class="btn-draw btn--lg" value="Subscribe" name="subscribe" id="mc-embedded-subscribe"><span class="btn-draw__text"><span>Subscribe</span></span></button>

            </div>
            </div>
          </form>

        <!-- Signup Message -->
        <div class="signup-message">
          <p>Thanks for signing up for updates</p>
        </div>   
      </div>
    </div>
  </section>
</section>

<section class="signup-notice">
  
</section>
