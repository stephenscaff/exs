<?php
/**
 * Partial: Team
 *
 * Partial that builds out the team archive blocks, 
 * orgainized by term.
 *  
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 * @version  team-archive.php
 * @since     1.2 = changed $term to $term->name in jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<article class="team team-tax">
  <div class="team-tax__content">
  <h3 class="team-tax__title"><?php echo $name; ?></h3>
  <p class="team-tax__text"><?php echo $desc; ?></p>
</div>
</article>
<?php 
// @since1.2 = changed $term to $term->name
jumpoff_cpt_tax('team', 'team_cat', $term->name, -1, 'team'); ?>