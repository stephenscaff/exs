<?php
/**
* Content: Conferences
* Content template for conferences post type
*
* @author    Stephen Scaff
* @package   partials/content
* @version   1.0
* @version   inc/post-types/post-type-conferences
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$conference_date = get_field('conference_date');
?>

<article class="conference">
  <a class="conference__link" href="<?php the_permalink(); ?>">
    <header class="conference__header">
      <span class="conference__date"><?php echo $conference_date; ?></span>
      <h4 class="conference__title"><?php the_title(); ?></h4>
      <span class="conference__btn btn-line">Learn More</span>
    </header>
  </a>
</article>