<?php
/**
* Content: EVents
* Content for the events post type
*
* @author    Stephen Scaff
* @package   partials/content
* @version   1.0
* @see       inc/post-types/post-type-events.php
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$team_position = get_field('team_position');
$team_phone = get_field('team_phone');
$team_email = get_field('team_email');
$office = jumpoff_post_term('office_location', 'slug');
?>

<article class="event <?php echo $third; ?>" >
  <a class="event__link" href="<?php the_permalink(); ?>">
    <figure class="event__figure has-preloader">
      <div class="event__img js-lazy" style="background-image:url()" data-src="<?php echo jumpoff_ft_img('medium'); ?>"></div>
      <span class="preloader preloader--white"></span>
    </figure>
    <div class="event__content">
      <div>
        <span class="event__tag">Past Event</span>
        <h4 class="event__title"><?php the_title(); ?></h4>
        <p class="event__text"><?php echo jumpoff_excerpt('150'); ?></p>
        <i class="event__icon icon-right"></i>
      </div>
    </div>
  </a>
</article>