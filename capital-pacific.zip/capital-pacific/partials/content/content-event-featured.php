<?php
/**
* Content: Event Featured
* Tempalte for displaying Featured EVents
*
* @author    Stephen Scaff
* @package   partials/content
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<article class="feed feed--full feed--event <?php echo $third; ?>" >
  <a class="feed__link" href="<?php the_permalink(); ?>">
    <figure class="feed__figure has-preloader">
      <div class="feed__img js-lazy" style="background-image:url()" data-src="<?php echo jumpoff_ft_img('large'); ?>"></div>
      <span class="preloader preloader--white"></span>
    </figure>
    <div class="feed__content">
      <div>
        <span class="feed__tag">Past Event</span>
        <h4 class="feed__title"><?php the_title(); ?></h4>
        <span class="btn-line btn--white">See This Event</span>
      </div>
    </div>
  </a>
</article>