<?php
/**
* Content: Team
* Tempalte for displaying Team Items
*
* @author    Stephen Scaff
* @package   partials/content
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$cs_price = get_field('cs_price');
$cs_cap_rate = get_field('cs_cap_rate');
$office = jumpoff_post_term('office_location', 'slug');
?>

<article class="work has-margin  <?php echo $third; ?> ">
  <a class="work__link" href="<?php the_permalink(); ?>">
    <figure class="work__figure has-preloader">
      <span class="work__img js-lazy" style="background-image:url()" data-src="<?php echo jumpoff_ft_img('large'); ?>"></span>
      <span class="preloader preloader--white"></span>
    </figure>
    <div class="work__content">
      <div> 
        <div class="work__metas">
          <span class="mast__meta"><?php echo $cs_price; ?></span>
        </div>

        <header class="work__header">
          <h3 class="work__title"><?php the_title(); ?></h3>
          <p class="work__text"><?php echo jumpoff_excerpt(200); ?></p>
        </header>
        <footer class="work__footer">
          <span class="btn-line btn--white">Learn More</span>
        </footer>
      </div>
    </div>
  </a>
</article>