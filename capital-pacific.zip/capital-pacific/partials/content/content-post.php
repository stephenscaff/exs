<?php
/**
* Content: Posts / Feeds
*
* @author    Stephen Scaff
* @package   partials/content/content-post
* @version   1.0
* @see       scss/components/_feeds.scss
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<article class="feed <?php if (is_home()) : echo $third; endif; ?>" >
  <a class="feed__link" href="<?php the_permalink(); ?>">
    <figure class="feed__figure has-preloader">
      <div class="feed__img js-lazy" style="background-image:url()" data-src="<?php echo jumpoff_ft_img('large'); ?>"></div>
      <span class="preloader preloader--white"></span>
    </figure>
    <div class="feed__content">
      <div>
        <span class="feed__tag" data-sim-link="<?php echo jumpoff_post_cat('url'); ?>"><?php echo jumpoff_post_cat('name'); ?></span>
        <h4 class="feed__title"><?php the_title(); ?></h4>
        <span class="btn-line btn--white">Read More</span>
      </div>
    </div>
  </a>
</article>