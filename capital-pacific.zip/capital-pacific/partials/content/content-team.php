<?php
/**
* Content: Team
* Tempalte for displaying Team Items
*
* @author    Stephen Scaff
* @package   partials/content
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$team_position = get_field('team_position');
$team_phone = get_field('team_phone');
$team_email = get_field('team_email');
$office = jumpoff_post_term('office_location', 'slug');
?>

<article class="team  <?php echo $office; ?>">
  <a class="team__link" href="<?php the_permalink(); ?>">
    <figure class="team__figure has-preloader">
      <img class="team__img js-lazy" data-src="<?php echo jumpoff_ft_img('team'); ?>">
      <span class="preloader preloader--white"></span>
    </figure>
    <header class="team__header">
      <h4 class="team__title"><?php the_title(); ?></h4>
      <?php if ($team_position) : ?><span class="team__position"><?php echo $team_position; ?></span><?php endif; ?>
    </header>
    <div class="team__content">
      <span class="team__phone"><span><?php echo $team_phone; ?></span></span>
      <span class="team__email"><span><?php echo $team_email; ?></span></span>
    </div>
    <footer class="team__footer">
      <span class="team__btn"><span>View Profile</span></span>
      <i class="team__icon icon-right"></i>
    </footer>
  </a>
</article>