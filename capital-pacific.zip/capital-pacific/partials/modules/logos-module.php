<?php
/**
* IMage Module
*
* The module for adding dymanically sizes images..
*
* @author       Stephen Scaff
* @package      partials/modules
* @see          scss/components/_logos.scss
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Vars
$logos = 'logos';
$logos_pretitle = get_sub_field('logos_pretitle');
$logos_title = get_sub_field('logos_title');

?>

<section class="logos">
  <div class="grid">
    <header class="logos__header">
      <span class="logos__pretitle"><?php echo $logos_pretitle; ?></span>
      <h3 class="logos__title"><?php echo $logos_title; ?></h3>
    </header>

    <div class="logos__items">
      <?php while( have_rows($logos) ): the_row(); 
      $img = get_sub_field('image');
      ?>
      <figure class="logos__item"><img class="logos__img" src="<?php echo $img['url']; ?>"></figure>
    <?php endwhile; ?>
    </div>
  </div>
</section>  