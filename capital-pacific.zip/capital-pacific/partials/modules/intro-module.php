<?php
/**
 * Module: Intro
 *
 * The module for creating Intro Sections
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @see          kit/scss/components/_intros.scss
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

//vars 
$intro_pretitle = get_sub_field('intro_pretitle'); 
$intro_title = get_sub_field('intro_title'); 
$intro_text = get_sub_field('intro_text');
$intro_padding = get_sub_field('intro_padding');
?>

<!-- Intro -->
<section class="intro <?php if ($intro_padding) : echo $intro_padding; endif ?>">
  <div class="grid">
    <header class="intro__header">
      <?php if ($intro_pretitle) : ?><span class="intro__pretitle"><?php echo $intro_pretitle; ?></span><?php endif; ?>
      <h2 class="intro__title"><?php echo $intro_title; ?></h2>
    </header>
    <div class="intro__content">
      <p><?php echo $intro_text; ?></p>
    </div>
  </div>
</section>
