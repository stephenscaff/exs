<?php
/**
* Vide Block Module
*
* The module for creating CTA Video Block Sections
*
* @author       Stephen Scaff
* @package      partials/modules
* @see          kit/scss/components/_vid-blocks.scss
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

//vars 
$vid_title = get_sub_field('vid_title');
$vid_img = get_sub_field('vid_image');
$vid_link_text = get_sub_field('vid_link_text');
$vid_file = get_sub_field('vid_file_name');
$vid_vimeo_id = get_sub_field('vid_vimeo_id');
$vid_pad = get_sub_field('vid_padding');

?>

<!-- Video Block Module -->
<section class="vid-block <?php if ($vid_pad) : echo $vid_pad; endif; ?>">
  <div class="grid-lg" data-scroll="stagger-up">
    <a class="vid-block__link" href="#" data-popup="video-<?php echo $vid_vimeo_id; ?>" data-vimeo-id="<?php echo $vid_vimeo_id; ?>" data-vimeo-color="fb4f42">
      <figure class="vid-block__bg" style="background-image:url(<?php echo $vid_img['url'] ?>)"></figure>

      <?php if ($vid_file) : ?><div class="vid-block__video bg-vid" data-vide-bg="mp4:<?php echo jumpoff_path(); ?>/videos/<?php echo $vid_file; ?>"></div><?php endif; ?>
      
      <header class="vid-block__header">

        <button type="button" name="button" class="play-button vimeo-id">
          <span class="play-button__circle"></span>
          <svg x="0px" y="0px"
             viewBox="0 0 15 25" style="enable-background:new 0 0 15 25;" xml:space="preserve" class="play-button__triangle">
             <polygon class="st0" points="1.5,1.5 13.8,12.5 1.5,23.5 "/>
          </svg>
          <svg x="0px" y="0px"
             viewBox="0 0 61 61" style="enable-background:new 0 0 61 61;" xml:space="preserve" class="play-button__circle-inner">
             <circle class="st0" cx="30.5" cy="30.5" r="28.5"/>
          </svg>
        </button>
        
        <h3 class="vid-block__title"><?php echo $vid_title; ?></h3>
        <span class="vid-block__btn btn-line btn--white"><?php echo $vid_link_text; ?></span>

      </header>
    </a>
  </div>
</section>

<!-- Video Block Video Popup -->
<section id="video-<?php echo $vid_vimeo_id; ?>" class="popup" aria-hidden="true">  
  <button class="popup__close js-close-popup" aria-label="Close">
    <div class="popup__x"></div>
  </button> 
  <div class='flex-vid vimeo popup__vid'></div>
</section>