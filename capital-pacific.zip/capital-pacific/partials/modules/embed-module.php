<?php
/**
* module: Maptive
*
* The module for creating Maptive embeds.
*
* @author       Stephen Scaff
* @package      SandP
* @see          kit/scss/components/_content.scss
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$embed = get_sub_field('embed'); 

?>

<!-- Emebeds -->
<section class="embed">
  <div class="grid-lg">
  <?php echo $embed; ?>
  </div>
</section>
