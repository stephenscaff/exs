<?php
/**
* intro-module
*
* The module for creating Intro Sections
*
* @author       Stephen Scaff
* @package      SandP
* @see          kit/scss/components/_intros.scss
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

//vars 
$title = get_sub_field('title'); 
$subtitle = get_sub_field('subheader'); 
$color = get_sub_field('color'); 


?>

<!-- Intro -->
<header class="slidee-info__header">
  <h2 class="slidee-info__title <?php if ($color) : echo $color; endif; ?>"><?php echo $title; ?></h2>
  <span class="sep-h"><span></span></span>
  <p class="slidee-info__subtitle"><?php echo $subtitle; ?></p>
</header>