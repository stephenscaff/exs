<?php
/**
 * Number list Module
 *
 * The module for created stylized numeric call outs
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @see          kit/scss/components/_num-list.scss
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
$number_list = 'number_list';

$grid = '';
if (is_page('about')) {
  $grid = 'grid-full';
} else {
  $grid = 'grid';
}
?>

<!-- Number List -->
<section class="num-list">
  <div class="<?php echo $grid; ?>">
  <ul class="num-list__list">
  <?php while( have_rows($number_list) ): the_row(); 
  $number = get_sub_field('number');
  $number_title = get_sub_field('number_title');  
  $number_text = get_sub_field('number_text'); ?>
    <li class="num-list__item">
      <div class="num-list__number"><span><?php echo $number; ?></span></div>
      <div class="num-list__content">
        <h3 class="num-list__title"><?php echo $number_title; ?></h3>
        <p class="num-list__text"><?php echo $number_text; ?></p>
      </div>
    </li>
  <?php endwhile; ?>
  </ul>
  </div>
</section>