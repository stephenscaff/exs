<?php
/**
* Testimonial module
*
* The module for adding quote/testimonials.
*
* @author       Stephen Scaff
* @package      Partials/Modules
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post ; 

//vars 
$quote = get_sub_field('testimonial_quote');
$quote_cite = get_sub_field('testimonial_cite');
$quote_img = get_sub_field('testimonial_image');
$quote_link = get_sub_field('testimonial_link');
?>

<section class="banner banner--quote">
  <?php if ($quote_link) : ?>
  <a class="banner__link" href="<?php echo $quote_link; ?>">
  <?php else : ?>
  <div class="banner__wrap">
  <?php endif; if ($quote_img) : ?>
  <figure class="banner__bg " style="background-image:url(<?php echo $quote_img['url'] ?>)"></figure>
  <?php endif ; ?>
  <div class="grid">
    <div class="banner__content">
      <blockquote class="quote">
        <?php echo $quote; ?>
        <?php if ($quote_cite) : ?><cite><?php echo $quote_cite; ?></cite><?php endif; ?>
      </blockquote>
      </div>
    </div>
  <?php if ($quote_link) : ?>
  </a>
  <?php else : ?>
  </div>
  <?php endif; ?>
</section>