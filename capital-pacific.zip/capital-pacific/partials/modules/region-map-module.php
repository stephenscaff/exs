<?php
/**
 * Region Map Module
 *
 * The module for adding a region svg map.
 *
 * @author       Stephen Scaff
 * @package      Partials/Modules
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

//vars 
$map_title = get_sub_field('map_title');
$map_text = get_sub_field('map_text');

?>

<section class="intro intro--center pad-t">
  <div class="grid">
    <header class="intro__header">
      <h4 class="intro__title"><?php echo $map_title; ?></h4>
      <?php if ($map_text) : ?><p class="intro__text"><?php echo $map_text; ?></p><?php endif; ?>
    </header>
  </div>
</section>

<?php get_template_part( 'partials/partial', 'region-map' ); ?>