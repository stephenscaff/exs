<?php
/**
 * Gallery Module
 *
 * The module for adding gallery like images.
 *
 * @author       Stephen Scaff
 * @package      SandP
 * @see          kit/scss/components/_auto-grid.scss
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Vars
$gallery = 'gallery';
$bg_color = get_sub_field('gal_bg_color');
$gal_width = get_sub_field('gallery_width');
$gal_has_pad = get_sub_field('gallery_has_padding');

$gal_offset = '';

if ($gal_width == 'gal-full') {
  $gal_offset == 'no-pad';
}

?>

<section class="gal <?php if ($gal_has_pad) : echo 'has-pad'; endif; ?>">
  <div class="<?php echo $gal_width; ?>">
    <div class="gal__grid <?php echo $gal_offset; ?>">
      <?php  
      while( have_rows($gallery) ): the_row(); 
        $img = get_sub_field('image');
        $size = get_sub_field('size'); ?>
        <figure class="gal__item <?php echo $size; ?>">
          <img class="gal__img"  src="<?php echo $img['url']; ?>">
        </figure>
      <?php endwhile; ?>
    </div>
  </div>
</section>