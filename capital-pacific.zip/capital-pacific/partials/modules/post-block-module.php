<?php
/**
 * Post Block Modules
 *
 * The module for adding gallery like images.
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @see          kit/scss/components/_post-blocks.scss
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Vars
$post_blocks = 'post_blocks';
$pbs_title = get_sub_field('pbs_title');
$pbs_link = get_sub_field('pbs_link');
$pbs_link_text = get_sub_field('pbs_link_text');
$pbs_pad = get_sub_field('pbs_padding');
?>


<section class="post-blocks <?php if ($pbs_pad) : echo $pbs_pad; endif; ?>">
  <div class="grid">
    <?php if ($pbs_title) : ?>
    <header class="post-blocks__header">
      <h4 class="post-blocks__title"><?php echo $pbs_title; ?></h4>
    </header>
    <?php endif; ?>

    <div class="post-block__grid">
      <?php  
      while( have_rows($post_blocks) ): the_row(); 
      $img = get_sub_field('image');
      $pretitle = get_sub_field('pretitle');
      $title = get_sub_field('title');
      $text = get_sub_field('text');
      $link = get_sub_field('link');
      ?>
      <article class="post-block ">
        <?php if ($link) : ?>
        <a class="post-block__wrap" href="<?php echo $link; ?>">
        <?php else : ?>
        <div class="post-block__wrap">
        <?php endif; ?>
          <figure class="post-block__figure has-preloader">
            <div class="post-block__img js-lazy" style="background-image:url()" data-src="<?php echo $img['url'] ?>"></div>
            <span class="preloader preloader--alpha"></span>
          </figure>
          <div class="post-block__content">
            <div>
              <span class="post-block__tag"><?php echo $pretitle; ?></span>
              <h4 class="post-block__title"><?php echo $title; ?></h4>
              <p class="post-block__text"><?php echo $text; ?></p>
            </div>
          </div>
        <?php if ($link) : ?>
        </a>
        <?php else : ?>
        </div>
        <?php endif; ?>
      </article>
      <?php endwhile; ?>
    </div>

    <?php if ($pbs_link) : ?>
    <footer class="post-blocks__footer">
      <a class="post-blocks__btn btn-draw btn--lg" href="<?php echo $pbs_link; ?>"><span class="btn-draw__text"><span><?php echo $pbs_link_text; ?></span></span></a>
    </footer>
    <?php endif; ?>
  </div>
</section>