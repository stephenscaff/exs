<?php
/**
 * Banner Module
 *
 * The module for adding quote/testimonials.
 *
 * @author       Stephen Scaff
 * @package      Partials/Modules
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post ; 

//vars 
$ban_pretitle = get_sub_field('banner_pretitle');
$ban_title = get_sub_field('banner_title');
$ban_text = get_sub_field('banner_text');
$ban_image = get_sub_field('banner_image');
$ban_align = get_sub_field('banner_align');
$ban_link = get_sub_field('banner_link');
?>

<section class="banner <?php echo $ban_align; ?>">
  <?php if ($ban_link) : ?>
  <a class="banner__link" href="<?php echo $quote_link; ?>">
  <?php else : ?>
  <div class="banner__wrap">
  <?php endif; if ($ban_image) : ?>
    <figure class="banner__bg " style="background-image:url(<?php echo $ban_image['url'] ?>)"></figure>
    <?php endif ; ?>
    <div class="grid">
      <div class="banner__content">
      <?php if ($ban_pretitle) : ?><span class="banner__pretitle"><?php echo $ban_pretitle; ?></span><?php endif; ?>
        <h3 class="banner__title"><?php echo $ban_title; ?></h3>
        <p class="banner__text"><?php echo $ban_text; ?></p>
      </div>
    </div>
    <?php if ($ban_link) : ?>
    </a>
    <?php else : ?>
  </div>
<?php endif ; ?>
</section>