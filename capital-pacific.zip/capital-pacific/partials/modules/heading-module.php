<?php
/**
 * Heading Module
 *
 * The module for creating Headings, with modifiers for 
 * single columns centered and left aligned 2 columns
 *
 * @author       Stephen Scaff
 * @package      partials/module
 * @see          components/_headings.scss
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

//vars 
$heading_title = get_sub_field('heading_title'); 
$heading_subtitle = get_sub_field('heading_subtitle'); 
$heading_content = get_sub_field('heading_content');
$heading_pad = get_sub_field('heading_padding');
$heading_alignment = get_sub_field('heading_alignment');

?>


<!-- Heading -->
<section class="heading  <?php if ($heading_pad) : echo $heading_pad.' '; endif;  if ($heading_alignment) :  echo $heading_alignment; endif; ?>">
  <div class="grid-med">
    <div class="heading__grid">
      <?php if ($heading_title) : ?>
        <header class="heading__header">
        <h3 class="heading__title"><?php echo $heading_title; ?></h3>
      </header>
    <?php endif; ?>
      <div class="heading__content">
      <?php if ($heading_subtitle) : ?><h4 class="heading__subtitle"><?php echo $heading_subtitle; ?></h4><?php endif; ?>
        <?php echo $heading_content; ?>
      </div>
    </div>
  </div>
</section>