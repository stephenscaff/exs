<?php
/**
* Page Anchor Module
*
* The module for creating linkable page anchors
*
* @author       Stephen Scaff
* @package      SandP
* @see          kit/scss/components/_content.scss
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$anchor = get_sub_field('page_anchor'); 
$anchor_lowercase = strtolower($anchor);
$anchor_sanitized = sanitize_title($anchor_lowercase);
?>

<!-- Section: <?php echo $anchor_sanitized; ?> -->
<section id="<?php echo $anchor_sanitized; ?>" class="page-anchor"></section>