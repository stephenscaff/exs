<?php
/**
 * CaptionSlider Module
 *
 * The module for adding the caption image slider option
 *
 * @author       Stephen Scaff
 * @package      SandP
 * @see          kit/scss/components/_auto-grid.scss
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Vars
$caption_slider = 'caption_slider';
$caption_slider_pad = get_sub_field('caption_slider_padding');
?>

<section class="caption-slider <?php if ($caption_slider_pad) : echo $caption_slider_pad; endif; ?>">
  <div class="grid">
    <div class="caption-slider__grid">
      
      
      <div class="caption-slider__images js-caption-slider">
        
      <?php  
      $count = '1';
      $total_count = count(have_rows($caption_slider));
      while( have_rows($caption_slider) ): the_row();  

      $img = get_sub_field('image');
       ?>

      
        <div class="caption-slider__item">
          <figure class="caption-slider__image">
            <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
          </figure>


          <footer class="caption-slider__footer">
            <div class="caption-slider__footer-content">
              <div class="caption-slider__caption">
                <p><?php echo $img['caption']; ?></p>
              </div>
              <div class="caption-slider__counts">
                <span class="count"><?php echo $count; ?></span>
                <span class="count js-caption-slider-items"><?php echo $total_count; ?></span>
              </div>
            </div>
          </footer>
        </div>
    <?php 
    $count++;
    endwhile; ?>
    </div>
    <nav id="caption-slider__nav" class="caption-slider__nav"></nav>
  </div>
  </div>
</section>
