<?php
/**
 * Partial Signup
 *
 *
 * @author    Stephen Scaff
 * @package   partials/
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


?>

<section id="signup-newsletter" class="popup" aria-hidden="true">  
  <button class="popup__close js-close-popup" aria-label="Close">
    <div class="popup__x"></div>
  </button> 

  <section class="signup signup--dark">
    <div class="signup__content">
      
      <div class="grid">
          
        <header class="signup__header">
          <h3 class="signup__title color-alpha">Join The Mailing List</h3>
        </header>  

            
        <?php echo do_shortcode('[contact-form-7 id="1361" title="Newsletter Signup"]'); ?>  
      </div>
    </div>
  </section>
</section>
