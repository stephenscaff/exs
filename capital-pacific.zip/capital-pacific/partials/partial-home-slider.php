<?php
/**
 * Partial: Home Slider
 *
 * Partial that constructs the home page custom slider jaun.
 * Interaction used Velocity.js for enhanced tween engine animation
 *
 * The images are added via an acf repeater so we can deliver 
 * random images if so desired.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 * @see       js/components/_cp-slider.js
 * @see       scss/components/cp-slider.scss
 * @see       js/vendor/velocity.js
 * @see       js/components/_velocity-effects.js
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<section class="velo-slides" data-velo-slider="on" data-velo-theme="light">

<?php

$args = array(
  'post_type' => 'home_slides',
  'posts_per_page'   => 3,
);

$home_slides = get_posts ($args);

foreach ( $home_slides as $post ) : setup_postdata( $post ); 
  // Fields
  $pretitle = get_field('slide_pretitle');
  $title = get_field('slide_title');
  $text = get_field('slide_text');
  $btn = get_field('slide_button');
  $link = get_field('slide_link');
  $images = 'slide_images';
  
  // Image array for image randomizer
  $img_arr = array();

  // Repeater for image / images
  while( have_rows('slide_images') ): the_row(); 
    $img = get_sub_field('image');
    $img = $img['url'];
    $img_arr[] = "$img";
  endwhile;

  $randomize_img = array_rand($img_arr);
  $random_img = $img_arr[$randomize_img];

?>

<!-- Slide -->
<section class="velo-slide">

  <!-- Pretitle Hint -->
  <span class="velo-slider__hint"><span><?php echo $pretitle; ?></span></span>

  <!-- Slide BG -->
  <div class="velo-slide__bg">
    <!-- Borders -->
    <span class="border"><span></span></span>
    <!-- Img -->
    <figure class="velo-slide__figure" style="background-image: url(<?php echo $random_img; ?>)"></figure>
  </div>

  <!-- Header -->
  <header class="velo-slide__header">

    <p class="velo-slide__text">
      <span class="oh"><span><?php echo $text; ?></span></span>
    </p>

    <h3 class="velo-slide__title">
      <?php echo jumpoff_line_wrap($title, 'slice'); ?>
    </h3>

    <span class="velo-slide__btn"><a class="btn-draw btn--white" href="<?php echo $link; ?>"><span class="btn-draw__text"><span><?php echo $btn; ?></span></span></a></span>
  </header>

</section>
<?php endforeach; ?>

<!-- Slides Nav -->
<nav class="velo-slides-nav">
  <ul class="velo-slides-nav__list">
    <li><a href="" class="js-velo-slides-prev velo-slides-nav__prev inactive"><i class="icon-up-arrow"></i></a></li>
    <li><a href="" class="js-velo-slides-next velo-slides-nav__next"><i class="icon-down-arrow"></i></a></li>
  </ul>
</nav>

</section>

