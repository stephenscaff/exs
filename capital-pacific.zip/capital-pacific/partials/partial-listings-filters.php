<?php
/**
 * Partial : Listings Filters
 *
 * Includes Filter actions for listings index / archive.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<!-- Listing Filters -->
<section class="listing-filters">
  <div class="grid-xl">
    <div class="listing-filters__grid">
    <header class="listing-filters__header">
      <h4 class="listing-filters__title">Listing Filters</h4>
    </header>

    <nav class="listing-filters__nav">
      <select class="listing-filters__select listing-select js-select js-select-tags">
        <option value=""  disabled selected>Type</option>
        <option value="Retail - Single Tenant">Office - Single Tenant</option>
        <option value="Office - Single Tenant">Office - Multi Tenant</option>
        <option value="Retail - Single Tenant">Retail - Single Tenant</option>
        <option value="Retail - Multi Tenant">Retail - Multi Tenant</option>
      </select>

      <select class="listing-filters__select listing-select js-select js-select-tags">
        <option value="" disabled selected>Price</option>
        <option value="0 - $500k">0 - $500k</option>
        <option value="$500 - $999">$500 - $999</option>
        <option value="$1 - 2m">$1 - 2m</option>
        <option value="$2 - 5m">$2 - 5m</option>
        <option value="Over $5m">Over $5m</option>
      </select>

      <select class="listing-filters__select listing-select js-select js-select-tags">
        <option value="" disabled selected>Cap Rate</option>
        <option value="3 - 5%">3 - 5%</option>
        <option value="5 - 7%">5 - 7%</option>
        <option value="7 - 10%">7 - 10%</option>
        <option value="10 - 15%">10 - 15%</option>
        <option value="15 - 20%">15 - 20%</option>
      </select>

      <select class="listing-filters__select listing-select js-select js-select-tags">
        <option value="" disabled selected>Region</option>
        <option value="Pacific North West">Pacific North West</option>
        <option value="West">West</option>
        <option value="Mountain West">Mountain West</option>
        <option value="South">South</option>
        <option value="Midwest">Midwest</option>
        <option value="East">East</option>
      </select>

      <select class="listing-filters__select listing-select js-select js-select-tags">
        <option value="" disabled="" selected="">Status</option>
        <option value="Active">Active</option>
        <option value="Pending">Pending</option>
        <option value="Closed">Closed</option>
      </select>
    </nav>

    <div class="listing-filters__toggle">
      <a class="js-listing-search-toggle listing-search-toggle" href="#"><i class="icon-search"></i></a>
    </div>
  </div>
  </div>
</section>

<!-- Listing Search -->
<section class="listing-search-drawer is-hidden">
  <div class="grid-xl">
    <div class="listing-search-drawer__search">
      <input id="" class="listing-search-drawer__input" name="" novalidates="novalidate" placeholder="Search" required="required" type="search" />
      <button class="listing-search-drawer__btn" type="submit" aria-label="Submit" title="Submit">
        <i class='icon-search'></i>
      </button>
    </div>
  </div>
</section>

<!-- Lising Tags Output -->
<section class="listing-tags">
  <div class="grid-xl">
    <div class="listing-tags__grid">
      <select class="listing-tags__select listing-select js-select">
        <option value="" disabled="" selected="">Sort By</option>
        <option value="Price">Price</option>
        <option value="State">State</option>
        <option value="Cap Rate">Cap Rate</option>
      </select>
      <!-- Tags Output -->
      <div class="listing-tags__output js-listing-tags-output"></div>
    </div>
  </div>
</section>

<!-- Listing Pagination Top -->
<section class="listing-pagination listing-pagination--top">
  <div class="grid-xl">
    <div class="listing-pagination__grid">
      <div class="listing-pagination__totals">
        <span class="totals-numbers">1 - 6</span>
        <span class="totals-numbers">241 Listings</span>
      </div>

      <nav class="listing-pagination__pages">
        <ul>
          <li><a class="is-active" href="#">1</a></li>
          <li><a href="#">2</a></li>
          <li><a href="#">3</a></li>
          <li><a href="#">4</a></li>
          <li><a href="#"><i class="icon-right-chev"></i></a></li>
        </ul>
      </nav>

      <div class="listing-pagination__controls">
        <a class="" href="">Export to a PDF <i class="icon-right-arrow"></i></a>
      </div>
    </div>
  </div>
</section>
