<?php
/**
 * Post Footer
 *
 * The Partial for Post Footers, used on blogposts and the mondalite post type.
 *
 * @author    Stephen Scaff
 * @package   Jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
$related_team = get_field('related_team');

if ($related_team) : ?>
  
<section class="related-team">
  <div class="grid-sm">
    <header class="related-team__header">
      <h5 class="related-team__heading">For more information, contact</h5>
    </header>

    <div class="related-team__grid">
  <?php
  foreach ( $related_team as $post ) : setup_postdata( $post ); 
    $team_phone = get_field('team_phone');
    $team_email = get_field('team_email');
  ?>

  <div class="related-team__item">
    <h5 class="related-team__title"><?php the_title(); ?></h5>
    <span class="related-team__contact"><?php echo $team_phone; ?></span>
    <span class="related-team__contact"><?php echo $team_email; ?></span>

    <a class="related-team__link" href="<?php the_permalink(); ?>">View Profile</a>
  </div>
  <?php
  endforeach;
  wp_reset_postdata();
  ?>
    </div>
  </div>
</section>
<?php endif; ?>

<footer class="post-footer">
  <div class="grid-sm">
    <div class="post-footer__grid">   

    <?php if (is_singular('post')) : ?>
    <!-- Post Bylines -->
      <aside class="post-byline">
        <span class="post-byline__meta post-footer__pretitle">Author</span>
        <h4 class="post-byline__author"><?php the_author_meta('display_name'); ?></h4>
        <?php if (get_the_author_meta('description')) : ?>
          <p class="post-byline__bio"><?php the_author_meta('description'); ?></p>
        <?php endif; ?>
        <a class="post-byline__author-link" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>">View All Posts</a>
      </aside>
    <?php endif; ?>
      <!-- Post Shares -->
      <aside class="post-shares">
        <span class="post-shares__title post-footer__pretitle">Share</span>
        <a class="post-shares__link" href="http://twitter.com/intent/tweet?text=<?php the_title(); ?>+<?php the_permalink(); ?>"><i class="icon-twitter"></i></a>
        <a class="post-shares__link" href="http://www.facebook.com/share.php?u=<?php the_permalink(); ?>/&amp;title=<?php the_title(); ?>"><i class="icon-facebook"></i></a>
      </aside>
    </div>
  </div>
</footer>