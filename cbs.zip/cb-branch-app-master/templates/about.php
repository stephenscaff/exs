<?php
/**
 * Template Name: About
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

while (have_posts()) : the_post();

$title = get_the_title();
$mast_title = get_field('mast_title');
$mast_subtitle = get_field('mast_subtitle');
$ft_img = jumpoff_ft_img('full');
/**
 * Featured or Latest Logic
 * @see inc/fields/fields-featured
 */
$featured_or_latest = "";
$featured = get_field('featured_home_post');

if ($featured) {
  $featured_or_latest = $featured;
} else {
  # Get Posts: Latest
  $latest_args = array(
    'post_type'        => 'community',
    'posts_per_page'   => 1,
  );
  $latest = get_posts( $latest_args );
  $featured_or_latest = $latest;
}
?>

<!-- Main -->
<main role="main" class="has-header-offset">

<!-- Post Header -->
<section class="post-mast is-page">
  <header class="post-mast__header">
    <h1 class="post-mast__title"><?php echo $mast_title; ?></h1>
    <?php if ($mast_subtitle) : ?><h5 class="post-mast__subtitle"><?php echo $mast_subtitle; ?></h5><?php endif; ?>
  </header>
  <?php if ($ft_img) : ?>
  <div class="post-mast__media grid">
    <figure class="post-mast__figure">
      <img class="post-mast__img" src="<?php echo $ft_img; ?>" alt="">
    </figure>
  </div>
<?php endif; ?>
</section>

<!--Post Content -->
<section class="post-content">
  <div class="grid-sm">
      <?php the_content(); ?>
  </div>
</section>

<section class="heading">
  <div class="grid">
    <h2 class="heading__title">Community Stories</h2>
  </div>
</section>

<!-- posts cards -->
<section class="cards carousel is-to-edge">
  <div class="grid">
    <div class="carousel__items js-carousel">
      <?php
      /**
       * Get Community and Resources Posts
       */
      $cards_args = array(
        'post_type'        => array('community', 'resources'),
        'posts_per_page'   => -1,
        'post__not_in'     =>  array($featured_or_latest[0]->ID)
      );
      $cards = get_posts( $cards_args );
      if ($cards) :
        foreach( $cards as $post) :
          setup_postdata( $post );
            include(locate_template('partials/content/content-card.php' ));
          wp_reset_postdata();
        endforeach;
      endif;
      ?>
    </div>
  </div>
</section>

</main>

<!-- Footer -->
<?php

endwhile;

get_footer(); ?>
