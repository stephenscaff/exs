<?php
/**
 * Template Name: Cart
 *
 * Template for displayin the primary cart page of cart items and checkout form.
 *
 * @author    Stephen Scaff
 * @package   template
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

/**
 * Define Cart Array
 */
$cart = array(0);

/**
 * If we have cart items in session,
 * pass the product ids to wp_query loop
 */
if ( isset($_SESSION['cart']) && (!empty($_SESSION['cart'])) ) {

  $cart = $_SESSION['cart'];

  $args = array(
    'post_type'       => array('product', 'community', 'resource'),
    'post__in' => $cart,
    'posts_per_page'  => -1,
  );

} else {
  $args = array();
}

/**
 * Init WP_Query with our cart items
 */
$cart_items = new WP_Query($args);

?>

<main class="has-header-offset">

<section class="mast-title">
  <div class="grid">
    <h1 class="mast-title__title">Your Cart Items</h1>
    <p class="mast-title__text color-alpha">On checkout, you will receive an email regarding the following products. If you requested to be contacted about any products, an expert will reach out shortly.</p>
  </div>
</section>

<?php if ( $cart_items->have_posts() ) : ?>

<section class="cart-tools">
  <div class="grid">
    <div class="cart-tools__grid">
      <div class="cart-tools__notice">
        <span>You have</span>
        <span class="js-cart-count"></span>
        <span>items in your cart</span>
      </div>
      <div class="cart-tools__controls">
        <a class="cart-tools__clear js-cart-clear" data-action="empty" href="#">
          <i class="icon-trash"></i>
          <span>Clear Cart</span>
        </a>
      </div>
    </div>
  </div>
</section>

<section class="cart-items">
  <div class="grid products js-cart-products has-products">
    <?php
    /**
     * Get Cart Items if they exist
     *
     * @var product_eid Eloqua id to send info
     * @var product_eid_r Eloqua id to for referral contact
     */
    while ( $cart_items->have_posts() ) : $cart_items->the_post();
      $product_title = get_the_title();
      $product_id = get_the_id();
      $product_eid = get_field('product_eloqua_id');
      $product_eid_r = $product_eid.'-R';
      $product_overview = get_field('product_overview');

      # If not an actual product with overview, use excerpt
      if ($product_overview) {
        $product_overview = $product_overview;
      } else {
        $product_overview = jumpoff_excerpt('150');
      }
    ?>

    <article class="cart-item js-cart-product"
      data-product-id="<?php echo $product_id; ?>"
      data-product-eid="<?php echo $product_eid; ?>"
      data-product-eid-r="<?php echo $product_eid_r; ?>">
      <div class="cart-item__bg">
        <div class="cart-item__grid">
          <div class="cart-item__check">
            <i class="icon-check-o"></i>
          </div>
          <div class="cart-item__main">
            <h4 class="cart-item__title"><?php echo $product_title; ?></h4>
            <p class="cart-item__excerpt"><?php echo $product_overview; ?></p>
          </div>
          <div class="cart-item__controls">
            <div class="switch">
              <span class="switch__text">Contact Me</span>
              <label class="switch__label" for="<?php echo $product_eid; ?>">
                <input type="checkbox" id="<?php echo $product_eid ?>" class="cart-item__checkbox checkbox" value="<?php echo $product_eid_r; ?>" />
                <div class="switch__slider"></div>
              </label>
            </div>
            <a href="#" class="cart-item__remove js-remove" data-action="remove"><i class="icon-x"></i></a>
          </div>
        </div>
      </div>
    </article>
  <?php endwhile; ?>
  <article class="cart-item is-empty-message">
    <div class="cart-item__bg">
      <i class="icon-shopping-bag"></i>
      <h4 class="cart-item__title">Your Cart is Empty</h4>
      <p class="cart-item__text">Feel free to explore our Product Pages to learn more about Columbia Bank's offerings and services.</p>
    </div>
  </article>
  </div>
</section>

<?php include(locate_template('partials/partial-cart-form.php' )); ?>

<?php
# Empty cart on load element
else : ?>

<section class="cart-items is-empty">
  <div class="grid">
    <article class="cart-item is-empty-message">
      <div class="grid">
        <div class="cart-item__bg">
          <i class="icon-shopping-bag"></i>
          <h4 class="cart-item__title">Your Cart is Empty</h4>
          <p class="cart-item__text">Feel free to explore our Product Pages to learn more about Columbia Bank's offerings and services.</p>
        </div>
      </div>
    </article>
  </div>
</section>

<?php endif; ?>

<?php //echo cart_arry(); ?>

</main>

<!-- Footer -->
<?php get_footer(); ?>
