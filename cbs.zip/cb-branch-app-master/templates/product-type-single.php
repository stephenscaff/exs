<?php
/**
 * Product Types View
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 * @see       inc/
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>

<main class="has-header-offset product-page">

<?php
get_template_part( 'partials/partial', 'product-mast' );
get_template_part( 'partials/partial', 'product-tabs' );
get_template_part( 'partials/partial', 'modules' );
?>

</main>

<!-- Footer -->
<?php get_footer(); ?>
