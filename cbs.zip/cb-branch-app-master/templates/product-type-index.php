<?php
/**
 * Combined template for single product Pages
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>

<!-- Footer -->
<?php get_footer(); ?>
