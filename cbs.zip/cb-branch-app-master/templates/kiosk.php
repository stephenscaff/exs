<?php
/**
 * Template Name: Kiosk
 *
 * @author    Stephen Scaff
 * @package   template
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

global $current_user;

$kiosk_obj = get_location_kiosk_obj();
$kiosk_id = $kiosk_obj->id;
$kiosk_slug = $kiosk_obj->name;
$mast_title = get_field('mast_title', $kiosk_id);
$mast_subtitle = get_field('mast_subtitle', $kiosk_id);
$mast_text = get_field('mast_text', $kiosk_id);
$featured = get_field('featured_home_post', $kiosk_id);
$articles_heading_title = get_field('articles_heading_title', $kiosk_id);
$articles_heading_text = get_field('articles_heading_text', $kiosk_id);
$wifi_name = get_field('wifi_name', $kiosk_id);
$wifi_pass = get_field('wifi_pass', $kiosk_id);

?>

<main class="has-header-offset">

  <section class="mast-title">
    <div class="grid">
      <h1 class="mast-title__title">
        <?php if ($mast_title) : echo $mast_title; else: ?>
        Welcome to the <?php echo jumpoff_svg('neighborhub'); ?>
        <?php endif; ?>
      </h1>
      <?php if ($mast_subtitle) : ?>
        <h3 class="mast-title__subtitle"><?php echo $mast_subtitle; ?></h3>
      <?php endif; if ($mast_text) : ?>
      <p class="mast-title__text"><?php echo $mast_text; ?></p>
      <?php endif; ?>
    </div>
  </section>

<?php

get_template_part( 'partials/partial', 'alert' );
get_template_part( 'partials/partial', 'team-selector' );

# If Featured
if ($featured) :
  foreach( $featured as $post) :
    setup_postdata( $post );
      include(locate_template('partials/content/content-featured.php' ));
    wp_reset_postdata();
  endforeach;
endif;

# Product CTAs
get_template_part( 'partials/partial', 'product-ctas' );

# Articles - Community and Resources
$cards_args = array(
  'post_type'        => array('community'),
  'posts_per_page'   => -1,
  'tax_query' => array(
      array(
        'taxonomy' => 'location',
        'field'    => 'slug',
        'terms'    => $kiosk_slug
      )
    )
  );

if ($featured) $cards_args['post__not_in'] = array($featured[0]->ID);

$cards = get_posts( $cards_args );

if ($cards) :
  if ($articles_heading_title) : ?>

<section class="heading no-pad-t">
  <div class="grid">
    <h2 class="heading__title"><?php echo $articles_heading_title; ?></h2>
    <?php if ($articles_heading_text) : ?>
      <p class="heading__text"><?php echo $articles_heading_text; ?></p>
    <?php endif; ?>
  </div>
</section>

<?php endif; ?>

<section class="cards carousel is-to-edge">
  <div class="grid">
    <div class="carousel__items js-carousel">
      <?php foreach( $cards as $post) : setup_postdata( $post ); ?>
        <div><?php
          include(locate_template('partials/content/content-card.php' ));
        ?></div><?php
          wp_reset_postdata();
        endforeach;
      ?>
    </div>
  </div>
</section>

<?php endif;

# Wifi Card - now on home/kiosk home.
if ($wifi_name) :
?>

<section class="wifi-card">
  <div class="wifi__content">
    <h5 class="wifi-card__title">Today's Wifi</h5>
    <p class="wifi-card__line">
      <strong>Network</strong>
      <span><?php echo $wifi_name; ?></span>
    </p>
    <p class="wifi-card__line">
      <strong>Password</strong>
      <span><?php echo $wifi_pass; ?></span>
    </p>
  </div>
</section>

<?php endif; ?>

</main>

<?php get_footer(); ?>
