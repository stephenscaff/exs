<?php
/**
 * Template Name: Modules
 *
 * Template that calls the Modules partial
 * Logic in Fields determins which modules are applied via page/post or page template
 *
 * @author    Stephen Scaff
 * @package   template
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>

<main class="has-header-offset">

<?php
get_template_part( 'partials/partial', 'mast-title' );
get_template_part( 'partials/partial', 'modules' );
?>

</main>

<!-- Footer -->
<?php get_footer(); ?>
