<?php
/**
 * Template Name: Team
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<main class="has-header-offset" role="main">
  <section class="mast-title">
    <div class="grid">
      <h1 class="mast-title__title">Welcome to Your Neighborhood Hub</h1>
    </div>
  </section>

  <section class="team">
    <div class="grid">
      <div class="team__grid">
        <?php
        # get bankers (user role:banker)
        $args = array(
        	'blog_id'      => $GLOBALS['blog_id'],
        	'role'         => 'banker',
        	'role__in'     => array(),
        	'role__not_in' => array(),
        	'meta_key'     => '',
        	'meta_value'   => '',
        	'meta_compare' => '',
        	'meta_query'   => array(),
        	'date_query'   => array(),
        	'include'      => array(),
         );
         $bankers = get_users( $args );

         foreach ( $bankers as $user ) :
           echo $user->display_name;
         endforeach;

        ?>
      </div>
    </div>
  </section>
</main>

<?php get_footer(); ?>
