<?php
/**
 * Template Name: Thanks
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- Main -->
<main role="main" class="has-header-offset">

<!-- Mast -->
<section class="cart-items pad-t-lg">
  <div class="grid">
    <article class="cart-item is-complete-message">
      <div class="grid">
        <div class="cart-item__bg">
          <i class="icon-check-o"></i>
          <h3 class="cart-item__title">Order Complete</h3>
          <p class="cart-item__text">Your requested info is on its way. We appreciate your interest in Columbia Bank. Thanks for stopping by.</p>
        </div>
      </div>
    </article>
  </div>
</section>

</main>

<!-- Footer -->
<?php get_footer(); ?>
