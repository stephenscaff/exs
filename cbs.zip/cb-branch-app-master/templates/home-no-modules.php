<?php
/**
 * Template Name: Home: No Modules
 *
 * @author    Stephen Scaff
 * @package   template
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

/**
 * Featured or Latest Logic
 * @see inc/fields/fields-featured
 */
$featured_or_latest = "";
$featured = get_field('featured_home_post');

if ($featured) :
  $featured_or_latest = $featured;
else :
  # Get Posts: Latest
  $latest_args = array(
    'post_type'        => 'community',
    'posts_per_page'   => 1,
  );
  $latest = get_posts( $latest_args );
  $featured_or_latest = $latest;
endif;

?>

<main class="has-header-offset">

<?php
# Mast Title
get_template_part( 'partials/partial', 'mast-title' );

if (is_page('kiosk')) :
  get_template_part( 'partials/partial', 'alert' );
  get_template_part( 'partials/partial', 'team-selector' );
endif;

# Featured or latest logic
if ($featured_or_latest) :
  foreach( $featured_or_latest as $post) :
    setup_postdata( $post );
      include(locate_template('partials/content/content-featured.php' ));
    wp_reset_postdata();
  endforeach;
endif;

# Product CTAs
get_template_part( 'partials/partial', 'product-ctas' );

# Optional Articles Heading
$articles_heading_title = get_field('articles_heading_title');
$articles_heading_text = get_field('articles_heading_text');

if ($articles_heading_title) : ?>

<section class="heading no-pad-t">
  <div class="grid">
    <h2 class="heading__title"><?php echo $articles_heading_title; ?></h2>
    <?php if ($articles_heading_text) : ?>
      <p class="heading__text"><?php echo $articles_heading_text; ?></p>
    <?php endif; ?>
  </div>
</section>

<?php endif; ?>

<section class="cards carousel is-to-edge">
  <div class="grid">
    <div class="carousel__items js-carousel">
      <?php
      # Articles - Community and Resources
      $cards_args = array(
        'post_type'        => array('community', 'resources'),
        'posts_per_page'   => -1,
        'post__not_in'     =>  array($featured_or_latest[0]->ID)
      );
      $cards = get_posts( $cards_args );
      if ($cards) :
        foreach( $cards as $post) :
          setup_postdata( $post );
      ?>
        <div><?php
          include(locate_template('partials/content/content-card.php' ));
        ?></div><?php
          wp_reset_postdata();
        endforeach;
      endif;
      ?>
    </div>
  </div>
</section>

<?php

# Wifi Card - now on home/kiosk home.
// $kiosk_id = get_id_by_name('kiosk');
// $wifi_name = get_field('wifi_name', $kiosk_id);
// $wifi_pass = get_field('wifi_pass', $kiosk_id);
$kiosk_obj = get_location_kiosk_obj();
$kiosk_id = $kiosk_obj->id;
$kiosk_slug = $kiosk_obj->name;
$wifi_name = get_field('wifi_name', $kiosk_id);
$wifi_pass = get_field('wifi_pass', $kiosk_id);

if ($wifi_name) :

?>

<section class="wifi-card">
  <div class="wifi__content">
    <h5 class="wifi-card__title">Today's Wifi</h5>
    <p class="wifi-card__line">
      <strong>Network</strong>
      <span><?php echo $wifi_name; ?></span>
    </p>
    <p class="wifi-card__line">
      <strong>Password</strong>
      <span><?php echo $wifi_pass; ?></span>
    </p>
  </div>
</section>

<?php endif; ?>

</main>

<?php get_footer(); ?>
