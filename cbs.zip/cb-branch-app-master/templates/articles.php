<?php
/**
 * Articles - Community and Resources archives
 *
 * @author    Stephen Scaff
 * @package   template
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

# Get Curent Post Type Object
$post_type_obj = get_queried_object();

# Ids Helper
$ids = jumpoff_ids();

# Init Featured / Latest Vars
$featured = "";
$latest = "";
$featured_or_latest = "";
$mast_title = "";

 # Determine Field based on current post type
if ($post_type_obj->name == "community") {
  $featured = get_field('featured_community_post', $ids);
  $mast_title = 'Community News';
} elseif ($post_type_obj->name == "resource") {
  $featured = get_field('featured_resource_post', $ids);
  $mast_title = 'Resources';
}

# If Featured exists, use featured, else get latest
if ($featured) {
  $featured_or_latest = $featured;
} else {
  # Get Posts: Latest
  $latest_args = array(
    'post_type'        => $post_type_obj->name,
    'posts_per_page'   => 1,
  );
  $latest = get_posts( $latest_args );
  $featured_or_latest = $latest;
}

# Mast Title Logic
$mast_title = '';

if ($post_type_obj->name == 'resource') {
  $mast_title = 'Resources';
} else {
  $mast_title = $post_type_obj->name;
}

?>

<main class="has-header-offset">

  <section class="mast-title">
    <div class="grid">
      <h1 class="mast-title__title"><?php echo ucwords($mast_title) ?></h1>
    </div>
  </section>

<?php
# Loop Logic
if ($featured_or_latest) :
  foreach( $featured_or_latest as $post) :
    setup_postdata( $post );
      include(locate_template('partials/content/content-featured.php' ));
    wp_reset_postdata();
  endforeach;
endif;
?>

  <section class="cards pad">
    <div class="grid">
      <div id="js-posts" class="cards__grid has-fetch-more">
        <?php
        # Exclude featured / latest
        $excluded_post = array($featured_or_latest[0]->ID);
        $ppp = intval(get_option('posts_per_page'));

        /**
         * Filter our query for fetch more
         * @see inc/post-helpers/query-filters
         */
        add_filter('post_limits', 'jumpoff_limit_posts');

        $args = array(
          'post_type'       => $post_type_obj->name,
          'posts_per_page'  => 9,
          'post__not_in'    => $excluded_post ,
        );

        $posts = new WP_Query($args);

        if (have_posts()) :
          while ( $posts->have_posts() ) : $posts->the_post();
            include(locate_template('partials/content/content-card.php'));
          endwhile;
        endif;

        remove_filter('post_limits', 'jumpoff_limit_posts');
      ?>
      </div>
    </div>
  </section>

  <!-- Fetch more -->
  <?php get_template_part( 'inc/fetch-more/partial', 'fetch-more' );?>

</main>

<!-- Footer -->
<?php get_footer(); ?>
