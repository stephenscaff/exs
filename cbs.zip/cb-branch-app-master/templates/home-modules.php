<?php
/**
 * Template Name: Home: Modules
 *
 * @author    Stephen Scaff
 * @package   template
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

/**
 * Featured or Latest Logic
 * @see inc/fields/fields-featured
 */
// $featured_or_latest = "";
// $featured = get_field('featured_home_post');
//
// if ($featured) {
//   $featured_or_latest = $featured;
// } else {
//   # Get Posts: Latest
//   $latest_args = array(
//     'post_type'        => 'community',
//     'posts_per_page'   => 1,
//   );
//   $latest = get_posts( $latest_args );
//   $featured_or_latest = $latest;
// }

?>

<main class="has-header-offset" role="main">
  <?php get_template_part( 'partials/partial', 'mast-title' ); ?>
  <?php include(locate_template('partials/partial-modules.php')); ?>
</main>

<?php get_footer(); ?>
