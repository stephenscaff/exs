<?php
/**
 *  Partial: Cart Form
 *
 *  Houses our Eloqua Form for the main Cart action.
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version   1.0
 *  @see       inc/acf-utils/class-acf-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $current_user;

$kiosk_obj = get_location_kiosk_obj();
$kiosk_id = $kiosk_obj->id;

/**
 * If logged in, user current user.
 * Else, use Kiosk User NeighborHub (id: 25)
 */
if ( 0 != $current_user->ID ) {
  $user_id = $current_user->ID;
} else {
  $user_id = 25;
}
//$user_id = $current_user->ID;
$user_name = get_the_author_meta('display_name', $user_id);
$user_position = get_the_author_meta('user_position', $user_id);
$user_email = get_the_author_meta('email', $user_id);
$user_linkedin = get_the_author_meta('user_linkedin', $user_id);
$user_phone = get_the_author_meta('user_phone', $user_id);
$user_avatar_src = get_user_avatar_eloqua_src();

# Session Type
$session_type = '';

if (is_kiosk_or_kiosk_user()) {
  $session_type = 'kiosk';
} else {
  $session_type = 'banker';
}

# Branch ID
$branch_id = get_field('branch_id', $kiosk_id);

?>

<section class="heading">
  <div class="grid">
    <h3 class="heading__title">Complete Checkout</h3>
  </div>
</section>

<section class="cart-form">
  <div class="grid">
    <form id="form89"
      class="elq-form cart-form__form js-cart-form"
      method="post"
      name="BranchApp_CartForm"
      action="https://s856856423.t.eloqua.com/e/f2"
      onsubmit="setTimeout(function(){if(document.querySelector){var s=document.querySelector('form#form89 input[type=submit]');if(s){s.disabled=true;}}},100);return true;"
      >
      <input value="BranchApp_CartForm" type="hidden" name="elqFormName"  />
      <input value="856856423" type="hidden" name="elqSiteId"  />
      <input name="elqCampaignId" type="hidden"  />

      <div class="form-grid">
        <div class="form-grid__col" id="formElement0">
          <input id="field0" name="FirstName" type="text" value="" class="field-size-top-large"  placeholder="First Name *" />
        </div>

        <div class="form-grid__col" id="formElement1">
          <input id="field1" name="LastName" type="text" value="" class="field-size-top-large"  placeholder="Last Name *"/>
        </div>

        <div class="form-grid__col" id="formElement2">
          <input id="field2" name="EMailAddr" type="text" value="" class="field-size-top-large" placeholder="Email Address *" />
        </div>

        <div class="form-grid__col" id="formElement3">
          <input id="field3" name="PhoneNumber" type="text" value="" class="field-size-top-large"  placeholder="Phone *"/>
        </div>

        <div class="form-grid__col" id="formElement4">
          <label class="radios-label"> Are you a current Columbia Bank client?</label>

          <div class="radios">
            <input name="CurrentClient_radio" id="CurrentClient_radio-1" type="radio" value="Yes" class="input"  />
            <label for="CurrentClient_radio-1">Yes</label>

            <input name="CurrentClient_radio" id="CurrentClient_radio-2" type="radio" value="No" class="input"  />
            <label for="CurrentClient_radio-2">No</label>
          </div>
        </div>

        <div class="form-grid__hide">
          <div id="formElement5"><input id="field5"  class="cart-codes"  type="hidden" name="ContentCode_hidden" value=""/></div>
          <div id="formElement6"><input id="field6" type="hidden" name="BranchCode_hidden" value="<?php echo $branch_id; ?>"  /></div>
          <div id="formElement7"><input id="field7" type="hidden" name="BankerName_hidden" value="<?php echo $user_name; ?>"  /></div>
          <div id="formElement8"><input id="field8" type="hidden" name="BankerTitle_hidden" value="<?php echo $user_position; ?>"  /></div>
          <div id="formElement9"><input id="field9" type="hidden" name="BankerEmail_hidden" value="<?php echo $user_email; ?>"  /></div>
          <div id="formElement10"><input id="field10" type="hidden" name="BankerPhone_hidden" value="<?php echo $user_phone; ?>"  /></div>
          <div id="formElement11"><input id="field11" type="hidden" name="BankerImage_hidden" value="<?php echo $user_avatar_src; ?>"  /></div>
          <div id="formElement12"><input id="field12" type="hidden" name="SessionType_hidden" value="<?php echo $session_type; ?>"  /></div>
        </div>

      <div class="form-grid__full form-grid__control text-center" id="formElement12">
        <button class="btn -lg -raised submit-button js-cart-btn" type="submit" value="Submit">Check Out</button>
      </div>
    </form>
  </div>
</section>

<script src="https://img04.en25.com/i/livevalidation_standalone.compressed.js" type="text/javascript" ></script>

<style type="text/css" media="screen" >
  .LV_validation_message{
    font-weight:bold;
    margin: 0 0 0 5px;
  }
  .LV_valid{
    color:#00CC00;
    display:none;
  }
  .LV_invalid{
    color:#CC0000;
    font-size:10px;
  }
  .LV_valid_field, input.LV_valid_field:hover, input.LV_valid_field:active, textarea.LV_valid_field:hover, textarea.LV_valid_field:active {
    outline: 1px solid #00CC00;
  }
  .LV_invalid_field, input.LV_invalid_field:hover, input.LV_invalid_field:active, textarea.LV_invalid_field:hover, textarea.LV_invalid_field:active {
    outline: 1px solid #CC0000;
  }
</style>
<script type="text/javascript">

  var dom0 = document.querySelector('#form89 #field0');
  var field0 = new LiveValidation(dom0, {
    validMessage: "",
    onlyOnBlur: false,
    wait: 30000
  });

  field0.add(Validate.Custom, {
    against: function(value) {
      return !value.match(/(telnet|ftp|https?):\/\/(?:[a-z0-9][a-z0-9-]{0,61}[a-z0-9]\.|[a-z0-9]\.)+[a-z]{2,63}/i);
    }, failureMessage: "Value must not contain any URL's"
  });

  field0.add(Validate.Presence, {
    failureMessage:"This field is required"
  });

  var dom1 = document.querySelector('#form89 #field1');
  var field1 = new LiveValidation(dom1, {
    validMessage: "",
    onlyOnBlur: false,
    wait: 30000
  });

  field1.add(Validate.Custom, {
    against: function(value) {
      return !value.match(/(telnet|ftp|https?):\/\/(?:[a-z0-9][a-z0-9-]{0,61}[a-z0-9]\.|[a-z0-9]\.)+[a-z]{2,63}/i);
    }, failureMessage: "Value must not contain any URL's"
  });

  field1.add(Validate.Presence, {
    failureMessage:"This field is required"
  });

  var dom2 = document.querySelector('#form89 #field2');
  var field2 = new LiveValidation(dom2, {
    validMessage: "",
    onlyOnBlur: false,
    wait: 30000
  });

  field2.add(Validate.Length, {
    tooShortMessage:"Invalid length for field value",
    tooLongMessage: "Invalid length for field value",
    minimum: 5,
    maximum: 50
  });

  field2.add(Validate.Presence, {
    failureMessage:"This field is required"
  });

  field2.add(Validate.Format, {
    pattern: /^([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})$/i,
    failureMessage: "A valid email address is required"
  });

  var dom3 = document.querySelector('#form89 #field3');
  var field3 = new LiveValidation(dom3, {validMessage: "", onlyOnBlur: false, wait: 300});

  field3.add(Validate.Custom, {
    against: function(value) {
      return !value.match(/(telnet|ftp|https?):\/\/(?:[a-z0-9][a-z0-9-]{0,61}[a-z0-9]\.|[a-z0-9]\.)+[a-z]{2,63}/i);
    }, failureMessage: "Value must not contain any URL's"}
  );
  field3.add(Validate.Length, {
    tooShortMessage:"Invalid length for field value",
    tooLongMessage: "Invalid length for field value",
    minimum: 7,
    maximum: 35
  });
  field3.add(Validate.Presence, {
    failureMessage:"This field is required"}
  );

  function resetSubmitButton(e){
    var submitButtons = e.target.form.getElementsByClassName('submit-button');
    for(var i=0;i<submitButtons.length;i++){
      submitButtons[i].disabled = false;
    }
  }

  function addChangeHandler(elements){
    for(var i=0; i<elements.length; i++){
      elements[i].addEventListener('change', resetSubmitButton);
    }
  }

  var form = document.getElementById('form89');

  addChangeHandler(form.getElementsByTagName('input'));
  addChangeHandler(form.getElementsByTagName('select'));
  addChangeHandler(form.getElementsByTagName('textarea'));

  var nodes = document.querySelectorAll('#form89 input[data-subscription]');
  if (nodes) {
    for (i = 0, len = nodes.length; i < len; i++) {
      var status = nodes[i].dataset ? nodes[i].dataset.subscription : nodes[i].getAttribute('data-subscription');
      if(status ==='true') {
        nodes[i].checked = true;
      }
    }
  };

  var nodes = document.querySelectorAll('#form89 select[data-value]');
  if (nodes) {
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      var selectedValue = node.dataset ? node.dataset.value : node.getAttribute('data-value');
      if (selectedValue) {
        for (var j = 0; j < node.options.length; j++) {
          if(node.options[j].value === selectedValue) {
            node.options[j].selected = 'selected';
            break;
          }
        }
      }
    }
  }
</script>
