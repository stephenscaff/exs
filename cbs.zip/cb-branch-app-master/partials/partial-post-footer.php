<?php
/**
 * Post Mast - masthead with ft image or video for articles
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$eid = get_post_meta($post->ID,'product_eloqua_id', true);

if ($eid) : ?>
<!-- Post Footer -->
<footer class="post-footer pad-t">
  <div class="grid-sm">
    <section class="product-card js-product  is-parent is-on-post" data-product-id="<?php echo get_the_id(); ?>" data-product-eid="<?php echo $eid; ?>">
      <div class="product-card__bg">
        <header class="product-card__header">
          <h5 class="product-card__title">Send this story to your inbox</h5>
          <div class="btn btn-cart " href="#">
            <span class="btn-cart__text action add" data-action="add">Add to Cart</span>
            <span class="btn-cart__active action remove" data-action="remove">
              <i class="icon-check"></i>Added
            </span>
          </div>
        </header>
      </div>
    </section>
  </div>
</footer>
<?php endif; ?>
