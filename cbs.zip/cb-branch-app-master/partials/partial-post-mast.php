<?php
/**
 * Post Mast - masthead with ft image or video for articles
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$post_title = get_the_title();
$post_ft_img = jumpoff_ft_img('full');
$post_ft_vid_mp4 = get_field('featured_video_mp4');
$post_ft_vid_vimeo_id = get_field('featured_video_vimeo_id');
$post_ft_vid_youtube_id = get_field('featured_video_youtube_id');
$post_subtitle = get_post_meta($post->ID,'subtitle', true);

?>

<!-- Post Mast -->
<section class="post-mast">
  <header class="post-mast__header">
    <h1 class="post-mast__title"><?php echo $post_title; ?></h1>
    <h5 class="post-mast__subtitle"><?php echo $post_subtitle; ?></h5>
  </header>

  <section class="post-mast__media grid">
    <?php if ($post_ft_vid_mp4 OR $post_ft_vid_vimeo_id OR $post_ft_vid_youtube_id) : ?>
    <div class="post-mast__vid js-plyr">
      <?php if ($post_ft_vid_vimeo_id) : ?>
        <div class="" data-type="vimeo" data-video-id="<?php echo $post_ft_vid_vimeo_id; ?>"></div>
      <?php elseif ($post_ft_vid_youtube_id) : ?>
        <div class="js-plyr" data-type="youtube" data-video-id="<?php echo $post_ft_vid_youtube_id; ?>" ></div>
      <?php else : ?>
        <video class="vid__video " poster="" controls crossorigin poster="">
          <source type="video/mp4" src="<?php echo $post_ft_vid_mp4['url']; ?>">
        </video>
      <?php endif; ?>
    </div>
    <?php else : ?>
    <figure class="post-mast__figure">
      <img class="post-mast__img" src="<?php echo $post_ft_img; ?>" alt="">
    </figure>
    <?php endif; ?>
  </section>
  </div>
</section>
