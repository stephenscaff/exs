<?php
/**
* Content: content-Posts
*
* @author    Stephen Scaff
* @package   jumpoff/content/content-posts
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post;
$title = get_the_title();
$url = get_the_permalink();
$img = jumpoff_ft_img('medium');
$excerpt = jumpoff_excerpt(125);
$post_type_obj = get_queried_object();

if (is_page('kiosk')) :
  $kiosk_id = get_id_by_name('kiosk');
  $featured_home_title = get_field('featured_home_title', $kiosk_id);
  $featured_home_text = get_field('featured_home_text', $kiosk_id);

  if ($featured_home_title) :
?>


<section class="heading">
  <div class="grid">
    <h2 class="heading__title"><?php echo $featured_home_title ?></h2>
    <p class="heading__text"><?php echo $featured_home_text ?></p>
  </div>
</section>
<?php endif; endif; ?>

<article class="featured">
  <div class="grid">
    <a class="featured__link" href="<?php echo $url; ?>">
      <figure class="featured__figure" style="background-image: url(<?php echo $img; ?>)"></figure>
      <header class="featured__header">
        <span class="featured__meta"><?php echo $post_type_obj->name; ?></span>
        <h1 class="featured__title"><?php echo $title; ?></h1>
        <p class="featured__excerpt"><?php echo $excerpt; ?></p>
        <span class="featured__btn btn-link">Read More</span>
      </header>
    </a>
  </div>
</article>
