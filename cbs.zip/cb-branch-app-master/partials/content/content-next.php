<?php
/**
* Content: content-Posts
*
* @author    Stephen Scaff
* @package   jumpoff/content/content-posts
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$title = get_the_title($next_post);
$subtitle = get_field('subtitle', $next_post);
$link = get_the_permalink($next_post);
$img = jumpoff_ft_img('full', $next_post);

?>


<article class="featured is-next">
  <div class="grid">
    <a class="featured__link" href="<?php echo $link; ?>">
      <figure class="featured__figure" style="background-image: url(<?php echo $img; ?>)"></figure>
      <header class="featured__header">
        <div>
          <span class="featured__meta">Read Next</span>
          <h1 class="featured__title"><?php echo $title; ?></h1>
          <h5 class="featured__subtitle"><?php echo $subtitle; ?></h5>
        </div>
      </header>
    </a>
  </div>
</article>
