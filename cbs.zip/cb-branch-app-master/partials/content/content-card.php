<?php
/**
* Content: content-Posts
*
* @author    Stephen Scaff
* @package   jumpoff/content/content-posts
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


$id = $post->ID;
$title = get_the_title();
$url = get_the_permalink();
$img = jumpoff_ft_img('medium');

$excerpt = jumpoff_excerpt(125);

$post_type = get_post_type_object(get_post_type());


?>
<article class="card ">
  <a class="card__link" href="<?php echo $url; ?>">
    <div>
    <figure class="card__figure">
      <img class="card__img" src="<?php echo $img; ?>"/>
    </figure>
    <div class="card__content">
      <!-- <span class="card__meta"><?php echo $post_type->label; ?></span> -->
      <h4 class="card__title"><?php echo $title; ?></h4>
      <p class="card__excerpt"><?php echo $excerpt; ?></p>
    </div>
  </div>
  </a>
</article>
