<?php
/**
 * Partial: Notice Bar
 *
 * A global notice bar that renders below the main header/nav.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$notice_date = get_field('notice_date', 'options');
$date = new DateTime($notice_date);
$notice_url = get_field('notice_url', 'options');
$notice_text = get_field('notice_text', 'options');

if ($notice_text) :

?>
<style>
html:not(.header-is-fixed) {
  padding-top: 5em;
}
</style>
<section class="notice notice-bar bg-alpha is-active">
  <a class="notice__link" href="<?php echo $notice_url; ?>">
    <div class="notice__content">
      <time class="notice__date"><?php echo $notice_date; ?> - </time>
      <p class="notice__text"><?php echo $notice_text; ?></p>
      <span class="notice__btn">Learn More</span>
    </div>
  </a>
</section>

<?php endif; ?>
