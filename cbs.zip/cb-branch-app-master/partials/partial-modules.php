<?php
/**
 *  Partial: Modules
 *
 *  Calls our modules system based on acf flexible content fields.
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version   1.0
 *  @see       inc/acf-utils/class-acf-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Modules
while (has_sub_field('modules')) :
  ACF_Modules::render(get_row_layout());
endwhile;
