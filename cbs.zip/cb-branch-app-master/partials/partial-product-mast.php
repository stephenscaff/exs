<?php
/**
 *  Partial: Product Mast
 *
 *  Partial for the global product Mast
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

# Ids Helper
$ids = jumpoff_ids();
$product_mast_title = get_field('product_mast_title', $ids);
$product_mast_text = get_field('product_mast_text', $ids);
$product_mast_image = get_field('product_mast_image', $ids);
$product_mast_theme = get_field('product_mast_theme', $ids)
?>

<section class="mast <?php echo $product_mast_theme; ?>">
  <div class="grid">
    <div class="mast__wrap">
      <figure class="mast__figure" style="background-image: url(<?php echo $product_mast_image['url']; ?>)"></figure>
      <header class="mast__header">
        <h1 class="mast__title"><?php echo $product_mast_title; ?></h1>
        <p class="mast__text"><?php echo $product_mast_text; ?></p>
      </header>
    </div>
  </div>
</section>
