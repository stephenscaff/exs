<?php
/**
 * Partial: Idle Popup
 *
 * Idle popup if user is inactive.
 *
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version    1.0
 * @see       js/components/_idle.js
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="popup js-idle-popup">
  <article class="modal">
    <div class="modal__main">
      <i class="modal__icon icon-clock"></i>
      <h3>Hello. Still There?</h3>
      <p>Looks like you've been inactive for a while. Did you want to end this session or continue browsing?</p>
    </div>
    <footer class="modal__footer modal__btns">
      <a class="modal__btn js-close-popup">Keep Browsing</a>
      <a class="modal__btn js-end-session">End Session</a>
    </footer>
  </article>
</section>
