<?php
/**
 * Partial: partials/partial-footer
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<footer class="app-footer">
  <div class="grid-sm">
    <p class="app-footer__creds">
      <a class="app-footer__link" href="https://www.cbneighborhub.com/wp-content/uploads/2018/05/0600903-privacypolicy-061616-final.pdf">Privacy Policy</a>
      <span class="app-footer__copy">© <?php echo date("Y"); ?> Columbia Bank.  All rights reserved.</span>
      <span class="app-footer__text fdic">Member FDIC</span>
      <span class="eoh">
        <img class="eoh__icon" src="<?php echo jumpoff_img(); ?>/brand/icon-eoh.png" alt="Equal Housing Lender"/>
        <span class="eoh__text">Equal Housing Lender</span>
      </span>
    </p>
  </div>
</footer>

<?php
# Activitiy PopUp
get_template_part( 'partials/partial', 'idle-popup' );
# Activitiy PopUp
get_template_part( 'partials/partial', 'screensaver' );

# Javascript
wp_footer();

?>

<!-- BugHerd -->
<!-- <script type='text/javascript'>
  (function (d, t) {
   var bh = d.createElement(t), s = d.getElementsByTagName(t)[0];
   bh.type = 'text/javascript';
   bh.src = 'https://www.bugherd.com/sidebarv2.js?apikey=0ytxym0dfcslq20ebvfila';
   s.parentNode.insertBefore(bh, s);
   })(document, 'script');
</script> -->

</body>
</html>
