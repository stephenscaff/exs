<?php
/**
 *  Partial: Recommended Products
 *
 *  Template for displaying the Recommended Products.
 *
 *  @author    Stephen Scaff
 *  @package   partials/modules
 *  @version   1.0
 *  @see       fields/fields-products
 *  @see       post-helpers/product-templates.php  For var helpers
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$post_type_obj = get_queried_object();
$post_type_name = $post_type_obj->post_type;
$recommended_or_related = "";
$recommended = get_field('recommended_products');

if ($recommended) {
  $recommended_or_related = $recommended;
} else {
  $related_args = array(
    'post_type'        => $post_type,
    'posts_per_page'   => 3,
    'post__not_in'     =>  array($post->ID)
  );
  $related = get_posts( $related_args );
  $recommended_or_related = $related;
}

?>

<section class="heading">
  <div class="grid">
    <h3 class="heading__title">Recommended Products</h3>
  </div>
</section>

<section class="cards">
  <div class="grid">
    <div class="cards__grid">
    <?php
    foreach( $recommended_or_related as $post ) : setup_postdata( $post );
      $recommended_link = get_the_permalink();
      # @see inc/post-helpers/product-templates.php
      $recommended_title = get_full_product_title($post_type_name);
      $recommended_excerpt = get_module_field('intro-module', 'content');
    ?>
      <article class="card is-recommended">
        <a class="card__link" href="<?php echo $recommended_link; ?>">
          <div>
            <div class="card__content">
              <span class="card__meta"></span>
              <h4 class="card__title"><?php echo $recommended_title; ?></h4>
              <p class="card__excerpt"><?php echo $recommended_excerpt; ?></p>
            </div>
          </div>
        </a>
      </article>
    <?php
    wp_reset_postdata();
    endforeach; ?>
    </div>
  </div>
</section>
