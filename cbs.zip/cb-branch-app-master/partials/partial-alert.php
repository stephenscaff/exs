<?php
/**
 * Partial: Notice Bar
 *
 * A global notice bar that renders below the main header/nav.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $current_user;

$kiosk_obj = get_location_kiosk_obj();
$kiosk_id = $kiosk_obj->id;
$kiosk_slug = $kiosk_obj->name;

$global_alert_text = get_field('alert_text', 'options');
$location_alert_text = get_field('location_alert_text', $kiosk_obj->id);

$alert_text = "";

if ($global_alert_text) {
  $alert_text = $global_alert_text;
} elseif ($location_alert_text) {
  $alert_text = $location_alert_text;
}

if ($alert_text) :

?>

<section class="alert bg-alpha">
  <div class="grid">
    <div class="alert__wrap">
      <p class="notice__text"><?php echo $alert_text; ?></p>
    </div>
  </div>
</section>

<?php endif; ?>
