<?php
/**
 * Today's Tea,
 *
 * Partial that calls users selected from kiosk page in admin.
 * Note that "Team" is actually the Custom User Type = Banker.
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @see          fields/field-team-selector
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$kiosk_obj = get_location_kiosk_obj();
$kiosk_id = $kiosk_obj->id;
$users = get_field('team_selector', $kiosk_id);

if ($users) :

?>

<section class="heading">
  <h4 class="heading__title">Meet Today's Team</h4>
</section>

<section class="teams">
  <div class="grid">
    <div class="teams__grid">
      <?php

        foreach ($users as $user) :
          $user_id = $user['ID'];
          $user_name = $user['display_name'];
          $user_nicename = $user['user_nicename'];
          $user_avatar = get_user_meta($user_id, 'user_avatar', true);
          $user_avatar_src = jumpoff_ft_img('full', $user_avatar);
          $user_link = get_author_posts_url( $user_id, $user_nicename );
      ?>

      <article class="team">
        <a class="team__link" href="<?php echo $user_link; ?>">
          <figure class="team__figure">
            <img class="team__img" src="<?php echo $user_avatar_src; ?>" alt=""/>
          </figure>
          <header class="team__header">
            <h3 class="team__title"><?php echo $user_name; ?>
          </header>
        </a>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>
