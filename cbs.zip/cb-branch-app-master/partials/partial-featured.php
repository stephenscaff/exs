<?php
/**
 *  Partial: Featured
 *
 *  Template for displaying featured content
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


if ($featured) :
  foreach( $featured as $post) :
    setup_postdata( $post );
      include(locate_template('partials/content/content-featured.php' ));
    wp_reset_postdata();
  endforeach;
endif;
