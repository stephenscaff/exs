<?php
/**
 *  Partial: Screensaver
 *
 *  Adds a screensaver that turns the kiosk screen black after midnight
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version   1.0
 *  @see       js/components/_idle.js
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<section class="screensaver"></section>
