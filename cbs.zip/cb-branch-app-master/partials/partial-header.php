<?php
/**
 * Partial: partials/partial-header
 *
 * @author    Stephen Scaff
 * @package   jumpoff/partials/partial-header
 * @version    1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Get Current User
 */
global $current_user;

/**
 * Get current users location info
 */
$kiosk_obj = get_location_kiosk_obj();
$kiosk_id = $kiosk_obj->id;
$kiosk_slug = $kiosk_obj->name;

/**
 * Current Date for our clock.
 */
$date = date("l, F j, Y");

/**
 * Get avatar Image src
 */
$avatar_src = get_user_avatar_src();

/**
 * Menu's Location Address Info
 */
$contact_title = get_field('contacts_location_name', $kiosk_id);
$contact_street = get_field('contacts_address_street', $kiosk_id);
$contact_city_state = get_field('contacts_address_city_state', $kiosk_id);
$contact_phone = get_field('contacts_phone', $kiosk_id);
$show_community = get_field('show_community', $kiosk_id);
$show_resources = get_field('show_resources', $kiosk_id);
$show_about = get_field('show_about', $kiosk_id);


/**
 * Get Home / Kiosk Link
 */
$home_link = '';

if (is_kiosk()) {
  $home_link = jumpoff_page_url('kiosk');
} else {
  $home_link = jumpoff_page_url('home');
}
?>

<body id="top" <?php body_class(); ?>>

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T3XBT4J"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<header class="app-header">
  <div class="app-header__grid">
    <nav class="app-header__tools -left">
      <a class="u-menu-toggle -alpha js-menu-toggle" data-drawer="menu"><span class="u-menu-toggle__bars"></span></a>
      <time class="app-header__date"><?php echo $date; ?></time>
    </nav>

    <a class="app-header__brand" href="<?php echo $home_link ?>"><?php echo jumpoff_svg('cb-icon'); ?></a>

    <nav class="app-header__tools -right">
      <time class="app-header__time"><span id="js-clock"></span></time>
      <?php if (!is_kiosk()) : ?>
      <figure class="app-header__avatar">
        <img class="app-header__avatar-img" src="<?php echo $avatar_src; ?>"/>
      </figure>
      <?php endif; ?>
      <a class="app-header__cart js-cart-url" href="<?php echo jumpoff_page_url('cart'); ?>"><i class="icon-paper-plane"></i></a>
    </nav>
  </div>
</header>

<section class="app-menu">
  <div class="app-menu__wrap">
    <section class="app-menu__main">
      <div class="app-menu__navs">
        <nav class="app-menu__nav -left">
          <a class="app-menu__link" href="<?php echo jumpoff_page_url('personal_banking', true); ?>/personal-checking"><span>Personal Banking</span></a>
          <a class="app-menu__link" href="<?php echo jumpoff_page_url('business_banking', true); ?>/business-checking"><span>Business Banking</span></a>
          <a class="app-menu__link" href="<?php echo jumpoff_page_url('wealth_management', true); ?>/financial-services"><span>Wealth Management</span></a>
        </nav>
        <nav class="app-menu__nav -right">
          <?php if ($show_community) : ?>
          <a class="app-menu__link" href="<?php echo jumpoff_page_url('community', true); ?>"><span>Community</span></a>
          <?php endif; if ($show_resources) : ?>
          <a class="app-menu__link" href="<?php echo jumpoff_page_url('resource', true); ?>"><span>Resources</span></a>
          <?php endif; if ($show_about) : ?>
          <a class="app-menu__link" href="<?php echo jumpoff_page_url('about'); ?>"><span>About</span></a>
          <?php endif; ?>
          <a class="app-menu__link" href="<?php echo jumpoff_page_url('help & support'); ?>"><span>Help & Support</span></a>
        </nav>
      </div>
    </section>
    <footer class="app-menu__footer">
      <address class="app-menu__address">
        <div><span class="font-700"><?php echo $contact_title; ?></span></div>
        <div><span><?php echo $contact_street; ?></span></div>
        <div><span><?php echo $contact_city_state; ?></span></div>
        <div><a href="">ph: <?php echo $contact_phone; ?></a></div>
      </address>
    </footer>
  </div>
</section>

<!-- Cart Notices -->
<section class="notice js-cart-notice">
  <div class="notice__content">
    <p>Product was added to your <a href="<?php echo jumpoff_page_url('cart'); ?>">Cart</a></p>
  </div>
</section>
