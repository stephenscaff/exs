<?php
/**
 *  Partial: Product Tabs
 *
 *  Partial for handling the Product Type/Page tab navigation.
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<section class="tab-nav">
  <header class="tab-nav__header">
    <h5 class="tab-nav__title">Choose from the list below to get started</h5>
  </header>
  <div class="grid-sm">
    <nav class="tab-nav__nav">
      <?php
      /**
       * Build Nav Links from
       * current post type.
       */
      $post_type_obj = get_queried_object();

      $product_nav_args = array(
        'post_type'        => $post_type_obj->post_type,
        'posts_per_page'   => -1,
      );

      $product_nav = get_posts( $product_nav_args );

      foreach( $product_nav as $post) : setup_postdata( $post );
        $title = get_the_title();
        $url = get_the_permalink();
        $active_class = $post->post_name == $post_type_obj->post_name ? 'is-active' : '' ;
      ?>
        <a class="tab-nav__link <?php echo $active_class ?>" href="<?php echo $url; ?>"><?php echo $title; ?></a>
      <?php
      wp_reset_postdata();
      endforeach;
      ?>
    </nav>
  </div>
</section>
