<?php
/**
 *  Partial: Mast Title
 *
 *  Template for displaying the simple Mast Title section
 *
 *  @author    Stephen Scaff
 *  @package   partials/modules
 *  @version   1.0
 *  @see       fields/field-mast-title.php
 */

if ( ! defined( 'ABSPATH' ) ) exit;

//vars
$id = jumpoff_ids();
$mast_title = get_field('mast_title');
$mast_subtitle = get_field('mast_subtitle');
$mast_text = get_field('mast_text');

?>

<section class="mast-title">
  <div class="grid">
    <h1 class="mast-title__title">
      <?php
      if (is_page('kiosk')) : ?>
        Welcome to the <?php echo jumpoff_svg('neighborhub'); ?>
      <?php else :
      if ($mast_title) :
        echo $mast_title;
      else :
        echo get_the_title();
      endif;
    endif;?>
    </h1>
    <?php if ($mast_subtitle) : ?>
      <h3 class="mast-title__subtitle"><?php echo $mast_subtitle; ?></h3>
    <?php endif; if ($mast_text) : ?>
    <p class="mast-title__text"><?php echo $mast_text; ?></p>
    <?php endif; ?>
  </div>
</section>
