<?php
/**
* Product CTA Module
*
* The module creating the 2x2 product cta section.
*
* @author       Stephen Scaff
* @package      partials/modules
* @see          fields/field-vars-modules
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit;

$ctas = 'ctas';

?>

<section class="product-ctas pad">
  <div class="grid">
    <div class="product-ctas__grid is-raised">
      <?php while( have_rows($ctas) ): the_row();
      $link = get_sub_field('cta_link');
      $title = get_sub_field('cta_title');
      $image = get_sub_field('cta_image');
      ?>
      <article class="product-cta is-light">
        <a class="product-cta__link" href="<?php echo $link; ?>">
          <header class="product-cta__header">
            <h4 class="product-cta__title"><?php echo $title; ?></h4>
          </header>
          <figure class="product-cta__figure">
            <img class="product-cta__img" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
          </figure>
        </a>
      </article>
      <?php endwhile; ?>
    </div>
  </div>
</section>
