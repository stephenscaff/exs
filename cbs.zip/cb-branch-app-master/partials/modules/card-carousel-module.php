<?php
/**
* Posts module
*
* The module for adding posts or post type sections.
*
* @author       Stephen Scaff
* @package      partials/moduels
* @see          fields/fields-vars-modules
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


$post_selector = get_sub_field('post_type_select');
$post_types = implode(', ', $post_selector);
echo $post_type;
//echo $post_selector;



 $value = get_sub_field('post_type_select');
 // foreach ($values as $value ){
 //
 // }

?>


<section class="cards carousel is-to-edge">
  <div class="grid">
    <div class="carousel__items js-carousel">

      <?php
      # Loop Logic
      $cards_args = array(
        'post_type'        => array($value[0], $value[1]),
        'posts_per_page'   => -1,
      );
      $cards = get_posts( $cards_args );


      if ($cards) :
        foreach( $cards as $post) :
          setup_postdata( $post );
            include(locate_template('partials/content/content-card.php' ));
          wp_reset_postdata();
        endforeach;
      endif;
      ?>
  </div>
