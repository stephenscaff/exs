<?php
/**
* Intro module
*
* @author       Stephen Scaff
* @package      inc/modules
* @see          fields/field-product-modules
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


//vars
$title = get_sub_field('title');
$content = get_sub_field('content');

?>
<section class="intro module">
  <div class="intro__content grid">
    <h2 class="intro__title"><?php echo get_sub_field('title') ?></h2>
    <p class="intro__text"><?php echo $content; ?></p>
  </div>
</section>
