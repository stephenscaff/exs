<?php
/**
* Products module
*
* The module for adding posts or post type sections.
*
* @author       Stephen Scaff
* @package      partials/modules
* @see          fields/fields-var-modules.php
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post ;

/**
 * Product Select Field
 * @var obj post object of products selected by author
 */
$products = get_sub_field('product_select');

/**
 * Loop Through
 */
foreach( $products as $post ) :
  setup_postdata( $post);
  $product_id = get_the_id();
  $product_eid = get_field('product_eloqua_id');
  $product_title = get_the_title();
  $product_overview = get_field('product_overview');
  $product_content = get_field('product_content');
  $product_table = 'product_table';
  $product_files = 'product_files';
  $product_table_disclaimer = get_field('product_table_disclaimer');
  $is_in_cart = cart_active_class($product_id);
  $is_product_parent = '';
  $exteded_class = '';
  $btn_class = '';

  $pt = get_field('product_table');
  $pt_rows = "";
  if ($pt) $pt_rows = count(get_field('product_table'));


  if (is_product_parent()) {
    $is_product_parent = 'is-parent';
  } else {
    $btn_class = '-white';
  }

  if (!$product_content && $pt_rows <= 1) {
    $exteded_class = 'is-extended';
  }

  $product_name_id = preg_replace('/\s+/', '', $product_title);
?>

<section class="product-card module js-product <?php echo $is_in_cart . ' ' . $is_product_parent; ?>"
         data-product-id="<?php echo $product_id; ?>"
         data-product-eid="<?php echo $product_eid; ?>">
  <div class="grid">
    <div class="product-card__bg">
      <header class="product-card__header">
        <div>
          <?php if (!is_product_parent()) : ?>
          <span class="product-card__meta">Product</span>
          <?php endif; ?>
          <h3 class="product-card__title"><?php echo $product_title; ?></h3>
        </div>
        <div class="btn btn-cart <?php echo $btn_class; ?>" href="#">
          <span id="<?php echo $product_name_id; ?>" class="btn-cart__text action add"  data-action="add">Add to Cart</span>
          <span class="btn-cart__active action remove"  data-action="remove">
            <i class="icon-check"></i>Added
          </span>
        </div>
      </header>
      <?php if (!is_product_parent()) : ?>
      <section class="product-card__main">
        <div class="product-card__grid">
          <div class="product-card__col -left  <?php echo $exteded_class; ?>">
            <h4 class="product-card__heading">Overview</h4>
            <p class="font-sm"><?php echo $product_overview; ?></p>
          </div>
          <div class="product-card__col -right">

            <?php if ($product_content) : ?>
              <div class="product-card__content">
                <?php echo $product_content; ?>
              </div>
            <?php elseif (have_rows($product_table)): ?>

            <table class="product-card__table">
              <tbody>
              <?php
                while ( have_rows($product_table) ) : the_row();
                  $title = get_sub_field('title');
                  $description  = get_sub_field('description'); ?>
                <tr>
                  <th scope="row"><?php echo $title; ?></th>
                  <td><?php echo $description; ?></td>
                </tr>
              <?php endwhile; ?>
              </tbody>
            </table>
          <?php endif; ?>
          </div>
        </div>
      </section>
      <?php if (have_rows($product_files)) : ?>
      <section class="product-card__files">
        <div class="product-card__grid">
          <div class="product-card__col -left">
            <h4 class="product-card__heading">Documents</h4>
          </div>

          <div class="product-card__col -right">
            <div class="grid-1-2">
            <?php
            while( have_rows($product_files) ): the_row();
              $file = get_sub_field('file');
              $file_sizer = @filesize( get_attached_file( $file['id'] ) );
              $file_size = size_format($file_sizer, 2);
              $file_type = pathinfo($file['url']);
              $file_title = $file['title'];
              $file_url = $file['url'];

              ?>
              <a class="file no-trans" href="<?php echo $file_url; ?>">
                <i class="file__icon icon-plus is-raised"></i>
                <div>
                  <span class="file__title"><?php echo $file_title; ?></span>
                  <span class="file__size"><?php echo $file_size; ?></span>
                </div>
              </a>
              <?php endwhile; ?>
                </div>
              </a>
            </div>
        </div>
      </section>
    <?php endif; if ($product_table_disclaimer) : ?>
    <footer class="product-card__footer has-disclaimer">
      <section class="expander">
        <h5 class="expander__title js-expander-trigger">
          <i class="icon-plus"></i>
          View Disclosures
        </h5>
        <div class="expander__content">
          <small><?php echo $product_table_disclaimer; ?></small>
        </div>
      </section>
    </footer>
    <?php endif; endif;?>
    </div>
  </div>
</section>
<?php
wp_reset_postdata();
endforeach;
