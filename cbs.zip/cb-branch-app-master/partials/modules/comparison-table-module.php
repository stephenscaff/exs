<?php
/**
* Comparison Module
*
* The module for creating the Product Competition links/
*
* @author       Stephen Scaff
* @package      partials/moduels
* @see          fields/fields-vars-modules
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$table = get_sub_field( 'comparison_table' );
$is_text_table = get_sub_field('is_text_table');
$comparison_table_disclaimer = get_sub_field('comparison_table_disclaimer');

$class_mod = '';
if ($is_text_table == true) {
  $class_mod = 'is-text-table';
}
?>

<section class="comparison-table module <?php echo $class_mod; ?>">
  <div class="grid">
    <div class="comparison-table__bg">
      <header class="comparison-table__header">
        <h4 class="comparison-table__title">Compare and find the right option for you</h4>
      </header>
      <section class="table-scroller">
      <table>
        <tbody>
        <?php foreach ( $table['body'] as $tr ) : ?>
        <tr>
        <?php foreach ( $tr as $td ) :?>
          <td><?php echo str_replace('++','<i class="icon-check"></i>',$td['c']); ?></td>
        <?php endforeach; ?>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </section>
    <?php if ($comparison_table_disclaimer) : ?>
    <footer class="comparison-table__footer has-disclaimer">
      <section class="expander">
        <h5 class="expander__title js-expander-trigger">
          <i class="icon-plus"></i>
          View Disclosures
        </h5>
        <div class="expander__content">
          <small><?php echo $comparison_table_disclaimer; ?></small>
        </div>
      </section>
    </footer>
  <?php endif; ?>
    </div>
  </div>
</section>
