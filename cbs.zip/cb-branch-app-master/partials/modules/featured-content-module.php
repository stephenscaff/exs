<?php
/**
* Featured Content Module
*
* The module for adding posts or post type sections.
*
* @author       Stephen Scaff
* @package      partials/modules
* @see          fields/
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post ;

/**
 * Featured or Latest Logic
 * @see inc/fields/fields-featured
 */
$featured_or_latest = "";
$featured = get_sub_field('post_selector');

if ($featured) {
  $featured_or_latest = $featured;
} else {
  # Get Posts: Latest
  $latest_args = array(
    'post_type'        => 'community',
    'posts_per_page'   => 1,
  );
  $latest = get_posts( $latest_args );
  $featured_or_latest = $latest;
}

?>


<?php
# Loop Logic
if ($featured_or_latest) :
  foreach( $featured_or_latest as $post) :
    setup_postdata( $post );

      include(locate_template('partials/content/content-featured.php' ));
    wp_reset_postdata();
  endforeach;
endif;
?>
