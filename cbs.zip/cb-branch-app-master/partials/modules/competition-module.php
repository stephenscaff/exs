<?php
/**
* Competition Module
*
* The module for creating the Product Competition links/
*
* @author       Stephen Scaff
* @package      partials/moduels
* @see          fields/fields-vars-modules
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$competition_banks = 'competition_banks';

# Hide on Kiosk since module houses external links
if (!is_kiosk()) :

?>

<section class="competition module">
  <div class="grid">
    <div class="competition__bg">
      <header class="competition__header">
        <h4 class="competition__title">View the Competition</h4>
        <p class="competition__text">See how this Columbia Bank Product compares to our competition.</p>
      </header>
      <div class="competition__logos">
      <?php while( have_rows($competition_banks) ): the_row();
        $bank = get_sub_field('competition_select');
        $logo = jumpoff_img() . '/competition/logo-'.$bank.'.png';
        $url = get_sub_field('competition_url');
      ?>
        <a class="competition__link" href="<?php echo $url; ?>" target="_blank">
          <img class="competition__logo" src="<?php echo $logo; ?>"/>
        </a>
      <?php endwhile; ?>
      </div>
    </div>
  </div>
</section>

<?php endif; ?>
