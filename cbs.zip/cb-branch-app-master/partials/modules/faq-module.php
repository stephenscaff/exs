<?php
/**
 * FAQ Module
 *
 * The module for creating an FAQ Section
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @see          fields/fields-vars-modules.php || fields/fields-products.php
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$faqs = 'faqs';

?>

<section class="faq-card module">
  <div class="grid">
    <div class="faq-card__bg">
      <header class="faq-card__header">
        <h4 class="faq-card__title">Frequently Asked Questions</h4>
      </header>
      <section class="faq-card__content">
        <ul class="faq-card__list">
          <?php while( have_rows($faqs) ): the_row();
            $question = get_sub_field('question');
            $answer = get_sub_field('answer');
          ?>
          <li class="faq-card__item">
            <h4 class="faq-card__question"><?php echo $question; ?></h4>
            <div class="faq-card__answer"><?php echo $answer; ?></div>
          </li>
          <?php endwhile; ?>
        </ul>
      </section>
    </div>
  </div>
</section>
