<?php
/**
 * Protips Module
 *
 * The module for creating the ProTips carousel featuing an svg icon and text region.
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @see          fields/fields-vars-modules.php || fields/fields-products.php
 * @see          jumpoff_svg (inc/utils/paths.php)
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$protips = 'protips';

?>

<section class="protips carousel is-to-edge module">
  <div class="grid">
    <header class="protips__header">
      <h3 class="protips__title">Pro-Tips</h3>
    </header>
    <div class="protips__items carousel__items js-carousel">
      <?php while( have_rows($protips) ): the_row();
        $icon = get_sub_field('icon');
        $content = get_sub_field('content');
      ?>
      <article class="protip">
        <figure class="protip__icon"><?php echo jumpoff_svg($icon); ?></figure>
        <p class="protip__text"><?php echo $content; ?></p>
      </article>
      <?php endwhile; ?>
    </div>
  </div>
</section>
