<?php
/**
 * Contacts Module
 *
 * The module for creating an FAQ Section
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @see          fields/fields-vars-modules.php || fields/fields-products.php
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$contacts = 'contacts';

?>

<section class="contact-cards module">
  <div class="grid">
    <!-- <header class="contact-cards__header">
      <h4 class="contact-cards__title">Customer Support</h4>
    </header> -->

    <section class="contact-cards__grid">
      <?php while( have_rows($contacts) ): the_row();
        $title = get_sub_field('title');
        $email = get_sub_field('email');
        $hours = get_sub_field('hours');
        $notes = get_sub_field('notes');
        $phones = 'phones';
      ?>

      <article class="contact-card">
        <div class="contact-card__bg">
          <div class="contact-card__content">
          <h4 class="contact-card__title"><?php echo $title; ?></h4>
          <?php while( have_rows($phones) ): the_row();
            $phone = get_sub_field('phone');
          ?>
            <span class="contact-card__phone"><?php echo $phone; ?></span>
          <?php endwhile; ?>
          <span class="contact-card__email"><?php echo $email; ?></span>
          <div class="contact-card__hours">
            <?php echo $hours; ?>
          </div>
          <div class="contact-card__notes">
            <?php echo $notes; ?>
          </div>
        </div>
        </div>
      </article>
    <?php endwhile; ?>
  </div>
</section>
