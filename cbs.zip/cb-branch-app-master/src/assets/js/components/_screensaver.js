/**
 * ScreenSaver
 * Activates a screensaver between certian times.
 * Currently, 12am - 5am.
 * Activate just adds a class to html tag, if on kiosk, that fades in an overlay div
 * A pause method is called via idle.js to leverage it's activity monitor method.
 *
 * @see scss/components/screensaver.scss
 * @see js/components/_idle.js
 * @author stephen scaff
 */
var ScreenSaver = function() {

  /**
   * Els
   */
  var html = document.querySelector('html');

  /**
   * Settings
   */
  var settings = {
    clockThrottle: 100000, // 30mins = 180000
    beginTime: 23,
    endTime: 6,
  }

  /**
   * Flags
   */
  var isActive, wasPaused = false;

  return {

    init: function() {
      this.bindEvents();
    },

    bindEvents: function() {
      ScreenSaver.startClock();
    },

    /**
     * Start the Clock
     */
    startClock: function() {
      setInterval(function () {
        ScreenSaver.checkTime();
      }, settings.clockThrottle);
    },

    /**
     * check Time
     */
    checkTime: function() {
      var d = new Date(); // current time
      var hours = d.getHours();

      if ( hours >= settings.beginTime || hours <= settings.endTime ) {
        isActive = true;
        ScreenSaver.activate();
      }
    },

    /**
     * Activate ScreenSaver
     */
    activate: function() {
      if (isActive && !html.classList.contains('screensaver-is-active') ) {
        html.classList.add('screensaver-is-active');
      }
    },

    /**
     * Pause
     * Called by idle.js if cursor is moved.
     */
    pause: function() {
      html.classList.remove('screensaver-is-active');
      wasPaused = true;
    },

    /**
     * Kill Function
     * @todo build this out better when needed.
     */
    kill:function() {
      return;
    },
  }
}();
ScreenSaver.init();
