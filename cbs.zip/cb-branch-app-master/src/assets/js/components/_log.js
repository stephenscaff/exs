/*
 * console.log() by Paul Irish stops console.console.log() breaking Ajax in IE
 * http://paulirish.com/2009/console.log-a-lightweight-wrapper-for-consoleconsole.log/
 */

 window.log = function(){
   log.history = log.history || [];   // store logs to an array for reference
   log.history.push(arguments);
   if(this.console){
     console.log( Array.prototype.slice.call(arguments) );
   }
 };
