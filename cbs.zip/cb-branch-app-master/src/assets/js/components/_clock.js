/**
 * Simple JS Clock
 * @see _utils.js
 * @author Stephen Scaff
 */
(function() {

  var Clock = function () {

    var el = document.querySelector('#js-clock');
    var timeFormat = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute:'2-digit',
      second:'2-digit'
    });

    /**
     * Pass vars to out Render Util
     */
    Util.render(timeFormat, el);
  }

/**
 * Start the Clock Interval
 */
window.setInterval(Clock, 1000);

}());



// var Clock = function(){
//
//   let el = document.querySelector('#js-clock');
//   let timeFormat = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'});
//
//   return {
//     init: function() {
//       this.go();
//       console.log('clock init')
//     },
//
//     tick: function() {
//       render(timeFormat, el);
//     },
//
//     go: function() {
//       window.setInterval(Clock.tick, 1000);
//     }
//   }
// }();
//
// Clock.init();
