/**
 * Idle
 * Detect if user is idle and do stuff.
 * Reset Session via ajax
 * @author stephen scaff
 */
var Idle = function() {

  var html = document.querySelector('html');
  var idlePopUp = document.querySelector('.js-idle-popup');
  var timeout;

  /**
   * Settings
   */
  settings = {
    idleTime: 360000, // @v1.2 = 6mins was 120000 @v1,
    idleTimeCart: 60000, // @v1.2 = 1min. was 30000 @v1
    idleTimePopUp: 36000, // @v1.2 = 0.6min was 12000 @v1,
    throttle: 500,
  };

  /**
   * Flags
   */
  var isHomePage,
      isCartPage,
      cartIsEmpty,
      popUpIsOpen,
      currentPage;

  return {

    /**
     * Initialize
     */
    init: function() {
      this.bindEvents();
    },

    /**
     * Bind Main Events
     */
    bindEvents:function() {
      Idle.cartCheck();
      Idle.pageCheck();
      Idle.startTimer();
      Idle.activityCheck();
      Idle.clickHandlers();
    },

    /**
     * Page Checks
     * Determine Current Page
     */
    pageCheck: function() {
      if ( document.body.classList.contains('page-cart') ) {
        currentPage = 'cart';
        isCartPage = true;
        isHomePage = false;
      } else if (document.body.classList.contains('home') || document.body.classList.contains('page-kiosk')) {
        currentPage = 'home';
        isHomePage = true;
      }
      //console.log('page',currentPage)
    },

    /**
     * Cart Check
     * Check to see if the cart is empty.
     */
    cartCheck: function() {
      var cartCount = parseInt(document.querySelector('.js-cart-count').innerText);

      if (cartCount == 0) {
        cartIsEmpty = true
      } else {
        cartIsEmpty = false
      }
    },

    /**
     * Start Timer
     */
    startTimer: function() {
      // Time Check debug
      //console.log("start Timer: " + new Date().toLocaleString());
      var idleTime;

      if (popUpIsOpen) {
        //console.log('popup is open', popUpIsOpen);
        timeout = window.setTimeout(Idle.onIdle, settings.idleTimePopUp);
        return;
      }
      else if (isHomePage && cartIsEmpty) {
        return
      }
      else if (isCartPage) {
        idleTime = settings.idleTimeCart;
      }
      else {
        idleTime = settings.idleTime;
      }

      // Set Timeout
      timeout = window.setTimeout(Idle.onIdle, idleTime);
    },

    /**
     * Reset Timer
     * @v1.2 - removed ScreenSaver.js reference as we removed screensaver.js
     */
    resetTimer: function() {
      //console.log('Clear Timer')
      window.clearTimeout(timeout);
      Idle.startTimer();
      //ScreenSaver.pause();
    },

    /**
     * Activity Check
     */
    activityCheck: function() {
      window.addEventListener('click',      Idle.resetTimer);
      window.addEventListener('touchstart', Idle.resetTimer);
      window.addEventListener('keydown',    Idle.resetTimer);
      window.addEventListener('mousewheel', Util.throttle(Idle.resetTimer, settings.throttle));
      window.addEventListener('mousemove',  Util.throttle(Idle.resetTimer, settings.throttle));
      window.addEventListener('touchmove',  Util.throttle(Idle.resetTimer, settings.throttle));
    },

    /**
     * TimesUp Function
     * Calls stuff when Idle.
     */
    onIdle: function() {
      //console.log("timesUp at: " + new Date().toLocaleString());

      if (popUpIsOpen) {
        //console.log('popup is idle', popUpIsOpen);
        Idle.resetSession()
        Idle.goHome();
      }

      // Open Popup
      Idle.openPopUp(idlePopUp);
    },

    /**
     * Click Handlers
     * On click stuff, currently only on the Idle Popup
     */
    clickHandlers: function() {
      var keepBrowsing = document.querySelector('.js-close-popup');
      var resetSession = document.querySelector('.js-end-session');

      keepBrowsing.addEventListener('click', function(e) {
        e.preventDefault();
        Idle.closePopUp(idlePopUp);
      });

      resetSession.addEventListener('click', function(e) {
        e.preventDefault();
        Idle.resetSession()
        Idle.goHome();
      });
    },

    /**
     * Open Modal
     */
    openPopUp: function(el){
      html.classList.remove('popup-is-closed');
      html.classList.add('popup-is-opening');
      el.classList.remove('is-closed');
      el.classList.add('is-open');

      setTimeout(function(){
        html.classList.remove('popup-is-opening');
        html.classList.add('popup-is-open');
        popUpIsOpen = true;
        Idle.resetTimer();
      }, 200);
    },

    /**
     * Close Modal
     */
    closePopUp: function(el){
      html.classList.add('popup-is-closing');
      el.classList.add('is-closing');

      setTimeout(function(){
        html.classList.remove('popup-is-open');
        el.classList.remove('is-open');
        html.classList.remove('popup-is-closing');
        html.classList.add('popup-is-closed');
        el.classList.remove('is-closing');
        el.classList.add('is-closed');

        popUpIsOpen = false;
        Idle.resetTimer();

      }, 800);
    },

    /**
     * Go to Home Page
     */
    goHome: function() {
      if (isTouch.Kiosk()) {
        window.location.href = "/kiosk";
      } else {
        window.location.href = "/";
      }
    },

    /**
     * Reset Cart Session
     * @var cart_ajax pulled from page if on cart page
     */
    resetSession: function() {

      var xhr = new XMLHttpRequest();

      xhr.open('POST', cart_ajax, true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
      xhr.send('action=cart_end_session');
      xhr.onreadystatechange = function() {
        // if ( xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
        //   window.location.href = '/';
        // }
      }
    },
  }
}();

setTimeout(function(){
  Idle.init();
}, 300);
