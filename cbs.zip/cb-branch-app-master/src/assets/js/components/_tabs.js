/**
 * Tab System
 * Stupid simple global, flexible, and resuable tab system that alows for multiple tabs on the
 * same page, with identical markup/classes. Uses css keyframes for the all sexy
 * like fade ins.
 *
 * @author stephen scaff
 * @version 1.2.0;
 * @see assets/scss/_tabs.js
 */
(function($) {

  var s, Tabbies = {

    settings: {
      tabWrap    : $('.js-tabs'),
      tabViewer  : ('.tabs-viewer .tabs-viewer__item'),
      tabNav     : ('.tabs-nav  .tabs-nav__item'),
    },

    init:function() {
      s = this.settings;
      this.doTabs();
      //this.deepLink();
    },

    doTabs:function() {
      s.tabWrap.each(function(){

        var $tabs = $(this);

        Tabbies.setUpTabs($tabs);

        // On Click
        $tabs.find(s.tabNav).on('click', function () {

          var currentTabView = $tabs.find(s.tabViewer + ':eq(' + $(this).index() + ')');
          var currentTabViewId = currentTabView.attr('id');

          $tabs.find(s.tabViewer).removeClass('is-active');
          $tabs.find(s.tabNav).removeClass("is-active");

          $(this).addClass("is-active");

          currentTabView.show().addClass('is-active').siblings().hide();

          Tabbies.updateHash(currentTabViewId);

          if (s.tabWrap.hasClass('js-company-tabs')) {
            $('html, body').animate({
              scrollTop: s.tabWrap.offset().top - 40
            }, 200);
          }
        });
      });
    },

    /**
     * Initial Setup of nav/view active state
     */
    setUpTabs: function(el) {
      el.find(s.tabViewer).hide();
      el.find(s.tabViewer + ':first-child').show();
      el.find(s.tabNav + ':first-child').addClass("is-active");
      el.find('li:first-child').addClass("is-active");
    },


    /**
     * Update Hash
     * Send the click on tab/anchor to the hash without reload
     */
    updateHash: function(id){
      if(history.pushState) {
        history.pushState(null, null, '#'+id);
      }
      else {
        location.hash = '#'+id;
      }
    },

    /**
     * Deep Link
     * Allow Direct linking to an active tab
     * from the hash
     */
    deepLink: function() {
      var hash = window.location.hash;

      if (hash) {
        setTimeout(function() {
          $(hash).trigger('click');
        }, 0);
      }
    },
  };

  if($('.js-tabs').length) {
    Tabbies.init();
  }
})(jQuery);
