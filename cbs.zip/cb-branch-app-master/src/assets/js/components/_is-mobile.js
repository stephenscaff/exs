/**
 * Is Mobile Test
 */
var isTouch = {
  Android: function() {
    return navigator.userAgent.match(/Android/i);
  },
  BlackBerry: function() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  iOS: function() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  Opera: function() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  Windows: function() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  Kiosk: function() {
    return navigator.userAgent.match(/SiteKiosk/i);
  },
  any: function() {
    return (isTouch.Android() || isTouch.BlackBerry() || isTouch.iOS() || isTouch.Opera() || isTouch.Windows());
  }
};

/**
 * Bind Touch start Events
 */
if (isTouch.any()) {
  document.addEventListener("touchstart", function(){}, true);
}

/**
 * Is Kiosk
 */
if (isTouch.Kiosk()) {}
