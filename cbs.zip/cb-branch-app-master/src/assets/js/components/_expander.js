/**
 * Accordions
 * A simple Accordion pattern that toggles
 * on click and only allows one list item open at a time.
 * @see components/_accordions.scss
 */
var Expanders = (function() {

  var expander = document.querySelectorAll('.expander');
  var activeClass = 'is-active';
  var isOpen = false;

  return{

    /**
     * Init
     */
    init: function() {
      this.bindEvents();
    },


    bindEvents:function() {

      Util.forEach(expander, function (index, item) {
        var trigger = item.querySelector('.js-expander-trigger');
        var content = item.querySelector('.expander__content');

        item.addEventListener('click', function() {
          if (!isOpen) {
          Expanders.open(content)
          } else {
            Expanders.close(content);
          }
        });
      });
    },

    open: function(el){
      el.parentElement.classList.add(activeClass);
      isOpen = true;
    },

    close: function(el) {
      el.parentElement.classList.remove(activeClass);
      isOpen = false;
    },
  };
})();

Expanders.init();

document.addEventListener('DOMContentLoaded',function(){
 if (document.querySelector('.expander')) {
   Expanders.init();
 }
});
