/**
 * App Menu
 * Main app menu/nav interaction
 * @author Stephen Scaff
 */
 var AppMenu = (function() {

   var html = document.querySelector('html');
   var menuToggle = document.querySelector('.js-menu-toggle');
   var openingTime = 0;
   var closingTime = 500;
   var isOpen = false;

   return{

     /**
      * Init
      */
     init: function() {
       this.bindEvents();
     },

     /**
      * Bind Events
      */
     bindEvents:function() {

       // Main Click Event
       menuToggle.addEventListener('click', function (e) {
         AppMenu.transitionState();
         e.preventDefault();
       });

       // Close on Esc key
       window.onkeydown = function(e) {
         if (isOpen && e.keyCode === 27) {
           AppMenu.transitionState();
           e.preventDefault();
         }
       }
     },

     /**
      * Transition State logic
      */
     transitionState: function(elem){
       if (isOpen) {
         AppMenu.close();
       } else {
         AppMenu.open();
       }
     },

     /**
      * Close Menu
      */
     close: function(){
       html.classList.add('menu-is-closing');

       setTimeout(function(){
         html.classList.remove('menu-is-open');
         html.classList.add('menu-is-closed');
         html.classList.remove('menu-is-closing');
         isOpen = false;
       }, closingTime);
     },

     /**
      * Open Menu
      */
     open: function(){
       html.classList.add('menu-is-opening');

       setTimeout(function(){
         html.classList.remove('menu-is-closed');
         html.classList.add('menu-is-open');
         html.classList.remove('menu-is-opening');
        isOpen = true;

      }, openingTime);
     },
   };
  })();

 AppMenu.init();
