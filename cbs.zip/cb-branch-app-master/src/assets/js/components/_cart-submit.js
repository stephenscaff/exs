/**
 * Cart Submit
 * Handles getting the eloqua ids from our cart items and setting
 * them as an array to a hidden input to send along to Eloqua.
 *
 * @author stephen scaff
 * @see inc/cart/*
 */
var CartSubmit = function(){

  var formBtn = document.querySelector('.js-cart-btn');
  var cartForm = document.querySelector('.js-cart-form');
  var cartItems = document.querySelectorAll('.js-cart-product');
  var cartInputIds = document.querySelector('.cart-codes');
  var eid = '';
  var inputValues = [];

  return {

    /**
     * Init
     */
    init: function() {
      if (cartForm) {
        this.bindEvents();
      }
    },

    /**
     * Bind Main Events
     */
    bindEvents: function() {

      /**
       * On Form Submit
       */
      // formBtn.addEventListener('click', function (e) {
      //   CartSubmit.handleSubmit();
      //   e.preventDefault;
      // });

      cartForm.addEventListener("submit", function(e) {
        CartSubmit.handleSubmit();
      });
    },

    /**
     * Handle Submit
     * On submit (or maybe click), loop through cart items and get
     * Eloqua IDs and Eloqua Referral IDs if checked.
     */
    handleSubmit: function() {


    },

    /**
     * Get Eloqua ID helper
     * @return {string} Eloqua ID
     */
    getEid: function(el) {
      return el.dataset.productEid;
    },

    /**
     * Get Eloqua Referral Id
     * @return {string} Eloqua ID Referral
     */
    getEidR: function(el) {
      return el.dataset.productEidR;
    },

    /**
     * Set Values to out Hidden input
     */
    setValue: function(value) {
      cartInputIds.value = value;
      CartSubmit.submitForm();
    },

    /**
     * Submit Form
     */
    submitForm: function() {
      //cartForm.submit();
      CartSubmit.endSession();
    },

    /**
     * End Session
     */
    endSession: function() {

      var siteURL = 'http://' + top.location.host.toString() || 'https://' + top.location.host.toString();

      var xhr = new XMLHttpRequest();
      xhr.open('POST', cart_ajax, true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
      xhr.send('action=cart_end_session');
      xhr.onreadystatechange = function() {
        if ( xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
          //location.href = '/cb-branch-app/thanks';
        }
      }
    },
  }
}();

if (document.querySelectorAll('.page-cart').length) {
  CartSubmit.init();
}
