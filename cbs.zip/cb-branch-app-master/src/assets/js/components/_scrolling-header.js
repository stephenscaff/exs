/**
 * Scroll Nav/header
 * Toggles header state on scroll.
 * @author stephen scaff
 */
var ScrollNav = (function() {
  //var menu_toggle = document.querySelector('.site-header');

  var settings = {
    html: document.querySelector('html'),
    site_header: document.querySelector('.app-header'),
    fixed_class: 'is-fixed',
    scroll_threshold: 350,
    scroll_throttle: 50,
  };

  return{

    /**
     * Init
     */
    init: function(){
      this.bindEvents()
    },

    /**
     * BindEvents
     */
    bindEvents: function(){
      this.toggleHeaderState();
    },

    /**
     * Toggle Header State on scroll
     */
    toggleHeaderState: function(el){
      var winY = window.innerHeight || document.documentElement.clientHeight;

      window.addEventListener('scroll', Util.throttle(function() {

        var scroll_distance = window.scrollY;

        if (scroll_distance >= settings.scroll_threshold) {
          settings.site_header.classList.add(settings.fixed_class)
          settings.html.classList.add('header-is-fixed')
        } else {
          settings.site_header.classList.remove(settings.fixed_class)
          settings.html.classList.remove('header-is-fixed')
        }
      }, settings.scroll_throttle), false);
    },
  };
})();

ScrollNav.init();
