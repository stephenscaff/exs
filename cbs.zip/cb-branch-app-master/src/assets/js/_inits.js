 /**
  * Site Inits
  */
 var site = {

    /**
     * Support
     */
    js_support: function() {
      document.body.className = document.body.className.replace('no-js','js');
    },


   /**
    * Plyr Init
    */
    plyr: function() {
      plyr.setup(document.querySelectorAll('.js-plyr'), {});
    },

   /**
    * Slider - Testimonials
    */
   card_carousel: function() {
     var $card_carousel = $('.js-carousel');

     $card_carousel.slick({
        mobileFirst: true,
        dots: true,
        touchThreshold:20,
        edgeFriction: 0.015,
        cssEase: 'linear',
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: true,
        infinite:false,
        nextArrow: '<button class="carousel__next"><i class="icon-right-chev"></i></button>',
        prevArrow: '<button class="carousel__prev"><i class="icon-left-chev"></i></button>',
        responsive: [
          {
            breakpoint: 500,
            settings: {
              slidesToShow: 3
            }
          },
      ]
    });
  },
};

/**
 * JS Support
 */
 site.js_support();

/**
 * Init Testimonials Slider
 */
if (document.querySelectorAll('.js-carousel').length) {
  site.card_carousel();
}

/**
 * Init Plyrs
 */
if (document.querySelectorAll('.js-plyr').length) {
  site.plyr();
}
