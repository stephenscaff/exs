/**
 * JS Includes
 * Include js files here, in the desired order.
 */
 /* jshint -W030 */
 /* globals feature: false */

//=include vendors/_slick.js
//=include vendors/_plyr.js
//=include components/_is-mobile.js
//=include components/_utils.js
//=include components/_log.js
//=include components/_page-transitions.js
//=include components/_app-menu.js
//=include components/_scrolling-header.js
//=include components/_clock.js
//=include components/_app-menu.js
//=include components/_idle.js
//=include components/_expander.js
//=include components/_cart-submit.js
//=include _inits.js
