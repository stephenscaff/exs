<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<path style="fill:#A7A9AC;" d="M44.9,41.9H2c-1.1,0-2-0.9-2-2V12.6c0-1.1,0.9-2,2-2h42.9c1.1,0,2,0.9,2,2v27.3
	C46.9,41,46,41.9,44.9,41.9z"/>
<rect y="15.4" style="fill:#464748;" width="46.9" height="6.3"/>
<rect x="4.3" y="28.2" style="fill:#FFFFFF;" width="29.6" height="3.1"/>
<rect x="4.3" y="34.1" style="fill:#FFFFFF;" width="19.2" height="3.1"/>
<g>
	<path style="fill:#DBDBDB;" d="M41.3,36.9h-2V26.3c0-5.1,4.2-9.3,9.3-9.3s9.3,4.2,9.3,9.3v1.8h-2v-1.8c0-4-3.3-7.3-7.3-7.3
		s-7.3,3.3-7.3,7.3V36.9z"/>
	<path style="fill:#EEAD55;" d="M58,49.4H39.1c-1.1,0-2-0.9-2-2V32.3c0-1.1,0.9-2,2-2H58c1.1,0,2,0.9,2,2v15.1
		C60,48.5,59.1,49.4,58,49.4z"/>
	<path style="fill:#A17539;" d="M51.1,37.1c0-1.4-1.1-2.6-2.6-2.6c-1.4,0-2.6,1.1-2.6,2.6c0,1,0.5,1.8,1.3,2.2l-1.3,6h4.7l-1-6
		C50.5,39,51.1,38.1,51.1,37.1z"/>
</g>
</svg>
