<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<rect x="2.8" y="15.1" style="fill:#FFBF5C;" width="54.4" height="37"/>
<g>
	<path style="fill:#F05F50;" d="M4,21.5H3.5C1.6,21.5,0,19.9,0,18V8h7.5v10C7.5,19.9,5.9,21.5,4,21.5z"/>
	<path style="fill:#F1F2F2;" d="M11.5,21.5H11c-1.9,0-3.5-1.6-3.5-3.5V8H15v10C15,19.9,13.4,21.5,11.5,21.5z"/>
	<path style="fill:#F05F50;" d="M19,21.5h-0.5c-1.9,0-3.5-1.6-3.5-3.5V8h7.5v10C22.5,19.9,20.9,21.5,19,21.5z"/>
	<path style="fill:#F1F2F2;" d="M26.5,21.5H26c-1.9,0-3.5-1.6-3.5-3.5V8H30v10C30,19.9,28.4,21.5,26.5,21.5z"/>
	<path style="fill:#F05F50;" d="M34,21.5h-0.5c-1.9,0-3.5-1.6-3.5-3.5V8h7.5v10C37.5,19.9,35.9,21.5,34,21.5z"/>
	<path style="fill:#F1F2F2;" d="M41.5,21.5H41c-1.9,0-3.5-1.6-3.5-3.5V8H45v10C45,19.9,43.4,21.5,41.5,21.5z"/>
	<path style="fill:#F05F50;" d="M49,21.5h-0.5c-1.9,0-3.5-1.6-3.5-3.5V8h7.5v10C52.5,19.9,50.9,21.5,49,21.5z"/>
	<path style="fill:#F1F2F2;" d="M56.5,21.5H56c-1.9,0-3.5-1.6-3.5-3.5V8H60v10C60,19.9,58.4,21.5,56.5,21.5z"/>
</g>
<rect x="35" y="25.5" style="fill:#5C5D5E;" width="14.3" height="26.5"/>
<rect x="8.7" y="25.5" style="fill:#5C5D5E;" width="21.3" height="14.7"/>
<rect x="10" y="26.8" style="fill:#F1F2F2;" width="18.7" height="12"/>
<rect x="36.3" y="26.8" style="fill:#F1F2F2;" width="11.6" height="25.2"/>
<rect x="2.8" y="52" style="fill:#5C5D5E;" width="54.4" height="2.3"/>
<rect y="5.7" style="fill:#5C5D5E;" width="60" height="2.3"/>
<rect x="35.5" y="38.8" style="fill:#5C5D5E;" width="13.3" height="1.3"/>
<rect x="18.7" y="26.2" style="fill:#5C5D5E;" width="1.3" height="13.3"/>
</svg>
