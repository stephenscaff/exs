<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<g>
	<rect x="9.7" y="20.4" style="fill:#3FA49A;" width="40.6" height="19.1"/>
	<path style="fill:#41C19D;" d="M11,26.8v6.4c2.5,0.5,4.5,2.5,5,5.1h28c0.5-2.5,2.5-4.5,5-5.1v-6.4c-2.5-0.5-4.5-2.5-5-5.1H16
		C15.5,24.3,13.5,26.3,11,26.8z"/>
	<circle style="fill:#2F988C;" cx="30" cy="30" r="5.3"/>
	<circle style="fill:#3FA49A;" cx="19.9" cy="30" r="2"/>
	<circle style="fill:#3FA49A;" cx="40.1" cy="30" r="2"/>
</g>
<path style="fill:#F05F50;" d="M30,0C13.5,0,0,13.5,0,30s13.5,30,30,30s30-13.5,30-30S46.5,0,30,0z M5,30C5,16.2,16.2,5,30,5
	c6,0,11.5,2.1,15.8,5.7L10.6,45.8C7.1,41.5,5,36,5,30z M30,55c-6,0-11.5-2.1-15.8-5.7l35.2-35.2C52.9,18.5,55,24,55,30
	C55,43.8,43.8,55,30,55z"/>
</svg>
