<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<path style="fill:#464748;" d="M47.3,60H12.7c-2.2,0-4-1.8-4-4V4c0-2.2,1.8-4,4-4h34.6c2.2,0,4,1.8,4,4v52
	C51.3,58.2,49.5,60,47.3,60z"/>
<circle style="fill:#A7A9AC;" cx="18.6" cy="25.7" r="3.4"/>
<circle style="fill:#A7A9AC;" cx="30" cy="25.7" r="3.4"/>
<circle style="fill:#A7A9AC;" cx="41.4" cy="25.7" r="3.4"/>
<circle style="fill:#A7A9AC;" cx="18.6" cy="36.6" r="3.4"/>
<circle style="fill:#A7A9AC;" cx="30" cy="36.6" r="3.4"/>
<circle style="fill:#EEAD55;" cx="41.4" cy="36.6" r="3.4"/>
<circle style="fill:#A7A9AC;" cx="18.6" cy="47.6" r="3.4"/>
<circle style="fill:#A7A9AC;" cx="30" cy="47.6" r="3.4"/>
<circle style="fill:#F05F50;" cx="41.4" cy="47.6" r="3.4"/>
<path style="fill:#E1E6E8;" d="M41.4,16.3H18.6c-1.9,0-3.4-1.5-3.4-3.4l0,0c0-1.9,1.5-3.4,3.4-3.4h22.9c1.9,0,3.4,1.5,3.4,3.4l0,0
	C44.8,14.8,43.3,16.3,41.4,16.3z"/>
</svg>
