<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<g>
	<g>
		<rect x="0" y="10.3" style="fill:#3FA49A;" width="60" height="28.2"/>
		<path style="fill:#41C19D;" d="M2,19.7v9.5c3.7,0.8,6.6,3.7,7.4,7.5h41.3c0.7-3.7,3.7-6.7,7.4-7.5v-9.5c-3.7-0.8-6.6-3.7-7.4-7.5
			H9.4C8.6,15.9,5.7,18.9,2,19.7z"/>
		<circle style="fill:#2F988C;" cx="30" cy="24.4" r="7.9"/>
		<circle style="fill:#3FA49A;" cx="15.1" cy="24.4" r="3"/>
		<circle style="fill:#3FA49A;" cx="44.9" cy="24.4" r="3"/>
	</g>
	<rect y="38.5" style="fill:#2F988C;" width="60" height="1.8"/>
	<rect y="40.3" style="fill:#3FA49A;" width="60" height="1.8"/>
	<rect y="42.1" style="fill:#2F988C;" width="60" height="1.8"/>
	<rect y="44" style="fill:#3FA49A;" width="60" height="1.8"/>
	<rect y="45.8" style="fill:#2F988C;" width="60" height="1.8"/>
	<rect y="47.6" style="fill:#3FA49A;" width="60" height="1.8"/>
	<rect x="26.2" y="9.4" style="fill:#FFBF5C;" width="7.5" height="41.2"/>
</g>
</svg>
