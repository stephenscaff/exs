<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<path style="fill:#27A2DF;" d="M58,50H2c-1.1,0-2-0.9-2-2V12c0-1.1,0.9-2,2-2h56c1.1,0,2,0.9,2,2v36C60,49.1,59.1,50,58,50z"/>
<rect y="16.1" style="fill:#464748;" width="60" height="8"/>
<rect x="5.5" y="32.5" style="fill:#E1E6E8;" width="37.8" height="4"/>
<rect x="5.5" y="40" style="fill:#E1E6E8;" width="24.5" height="4"/>
</svg>
