<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<g>
	<rect x="25.5" y="32.5" style="fill:#D3D7D9;" width="33.1" height="2.5"/>
	<rect x="25.5" y="48.4" style="fill:#D3D7D9;" width="33.1" height="2.5"/>
	<rect x="24.2" y="50.9" style="fill:#E1E6E8;" width="35.8" height="2.5"/>
	<rect x="26.7" y="47.2" style="fill:#E1E6E8;" width="6.6" height="1.2"/>
	<rect x="26.7" y="34.9" style="fill:#E1E6E8;" width="6.6" height="1.2"/>
	<rect x="27.8" y="36.1" style="fill:#EBF0F2;" width="4.4" height="11.1"/>
	<rect x="34.7" y="47.2" style="fill:#E1E6E8;" width="6.6" height="1.2"/>
	<rect x="34.7" y="34.9" style="fill:#E1E6E8;" width="6.6" height="1.2"/>
	<rect x="35.8" y="36.1" style="fill:#EBF0F2;" width="4.4" height="11.1"/>
	<rect x="42.7" y="47.2" style="fill:#E1E6E8;" width="6.6" height="1.2"/>
	<rect x="42.7" y="34.9" style="fill:#E1E6E8;" width="6.6" height="1.2"/>
	<rect x="43.9" y="36.1" style="fill:#EBF0F2;" width="4.4" height="11.1"/>
	<rect x="50.8" y="47.2" style="fill:#E1E6E8;" width="6.6" height="1.2"/>
	<rect x="50.8" y="34.9" style="fill:#E1E6E8;" width="6.6" height="1.2"/>
	<rect x="51.9" y="36.1" style="fill:#EBF0F2;" width="4.4" height="11.1"/>
	<polygon style="fill:#EBF0F2;" points="60,32.5 24.2,32.5 24.2,30 42.1,17.9 60,30 	"/>
	<polygon style="fill:#D3D7D9;" points="42.1,21.1 29.6,30 54.6,30 	"/>
	<circle style="fill:#EBF0F2;" cx="42.1" cy="26.2" r="2.3"/>
</g>
<rect x="2.4" y="9.3" style="fill:#6779A2;" width="30.9" height="41.4"/>
<rect x="6.4" y="6.7" style="fill:#525154;" width="22.7" height="2.7"/>
<rect y="50.7" style="fill:#525154;" width="35.6" height="2.7"/>
<rect x="4.7" y="11.5" style="fill:#FFBF5C;" width="11.9" height="7.6"/>
<rect x="19" y="11.5" style="fill:#FFBF5C;" width="11.9" height="7.6"/>
<rect x="4.7" y="21.3" style="fill:#FFBF5C;" width="11.9" height="7.6"/>
<rect x="19" y="21.3" style="fill:#FFBF5C;" width="11.9" height="7.6"/>
<rect x="4.7" y="31.1" style="fill:#FFBF5C;" width="11.9" height="7.6"/>
<rect x="19" y="31.1" style="fill:#FFBF5C;" width="11.9" height="7.6"/>
<rect x="4.7" y="40.9" style="fill:#FFBF5C;" width="11.9" height="7.6"/>
<rect x="19" y="40.9" style="fill:#FFBF5C;" width="11.9" height="7.6"/>
</svg>
