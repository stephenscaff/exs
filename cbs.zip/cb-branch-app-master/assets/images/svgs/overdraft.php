<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<rect x="7.8" y="29.1" style="fill:#E1E6E8;" width="44.5" height="2.2"/>
<polygon style="fill:#F05F50;" points="36.4,47.7 36.4,37.5 23.6,37.5 23.6,47.7 18.1,47.7 30,60 41.9,47.7 "/>
<polygon style="fill:#E1E6E8;" points="23.6,12.3 23.6,22.5 36.4,22.5 36.4,12.3 41.9,12.3 30,0 18.1,12.3 "/>
</svg>
