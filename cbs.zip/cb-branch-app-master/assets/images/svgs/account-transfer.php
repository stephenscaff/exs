<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 22.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<g>
	<rect x="0.9" y="16" style="fill:#D3D7D9;" width="22.8" height="1.7"/>
	<rect x="0.9" y="27" style="fill:#D3D7D9;" width="22.8" height="1.7"/>
	<rect y="28.7" style="fill:#E1E6E8;" width="24.6" height="1.7"/>
	<rect x="1.7" y="26.1" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="1.7" y="17.7" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="2.5" y="18.5" style="fill:#EBF0F2;" width="3" height="7.6"/>
	<rect x="7.3" y="26.1" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="7.3" y="17.7" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="8" y="18.5" style="fill:#EBF0F2;" width="3" height="7.6"/>
	<rect x="12.8" y="26.1" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="12.8" y="17.7" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="13.5" y="18.5" style="fill:#EBF0F2;" width="3" height="7.6"/>
	<rect x="18.3" y="26.1" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="18.3" y="17.7" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="19.1" y="18.5" style="fill:#EBF0F2;" width="3" height="7.6"/>
	<polygon style="fill:#EBF0F2;" points="24.6,16 0,16 0,14.3 12.3,6 24.6,14.3 	"/>
	<polygon style="fill:#D3D7D9;" points="12.4,8.2 3.7,14.3 20.9,14.3 	"/>
	<circle style="fill:#EBF0F2;" cx="12.3" cy="11.7" r="1.6"/>
</g>
<g>
	<rect x="36.3" y="39.7" style="fill:#D3D7D9;" width="22.8" height="1.7"/>
	<rect x="36.3" y="50.6" style="fill:#D3D7D9;" width="22.8" height="1.7"/>
	<rect x="35.4" y="52.3" style="fill:#E1E6E8;" width="24.6" height="1.7"/>
	<rect x="37.1" y="49.8" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="37.1" y="41.4" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="37.9" y="42.2" style="fill:#EBF0F2;" width="3" height="7.6"/>
	<rect x="42.6" y="49.8" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="42.6" y="41.4" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="43.4" y="42.2" style="fill:#EBF0F2;" width="3" height="7.6"/>
	<rect x="48.1" y="49.8" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="48.1" y="41.4" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="48.9" y="42.2" style="fill:#EBF0F2;" width="3" height="7.6"/>
	<rect x="53.6" y="49.8" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="53.6" y="41.4" style="fill:#E1E6E8;" width="4.6" height="0.8"/>
	<rect x="54.4" y="42.2" style="fill:#EBF0F2;" width="3" height="7.6"/>
	<polygon style="fill:#EBF0F2;" points="60,39.7 35.4,39.7 35.4,38 47.7,29.6 60,38 	"/>
	<polygon style="fill:#D3D7D9;" points="47.7,31.8 39.1,38 56.3,38 	"/>
	<circle style="fill:#EBF0F2;" cx="47.7" cy="35.3" r="1.6"/>
</g>
<path style="fill:#B2D4C9;" d="M48.3,20.2c-0.2-3.6-1.4-6.3-3.7-8c-4.8-3.7-12.2-1.7-12.5-1.6l0.5,1.8c0.1,0,6.9-1.8,10.9,1.3
	c1.8,1.4,2.8,3.6,2.9,6.5h-3l4,5.2l4-5.2H48.3z"/>
<path style="fill:#B2D4C9;" d="M26.8,47.9c-0.1,0-6.9,1.8-10.9-1.3c-1.8-1.4-2.8-3.6-2.9-6.5h3L12,35l-4,5.2h3.1
	c0.2,3.6,1.4,6.3,3.7,8c2.3,1.8,5.2,2.2,7.6,2.2c2.6,0,4.7-0.5,4.9-0.6L26.8,47.9z"/>
</svg>
