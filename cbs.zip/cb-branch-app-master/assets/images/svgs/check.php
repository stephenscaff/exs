<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<rect y="14.2" style="fill:#D3EBE4;" width="60" height="31.5"/>
<path style="fill:#B2D4C9;" d="M58.7,44.6H1.3V15.4h57.5L58.7,44.6L58.7,44.6z M2.3,43.6h55.5V16.4H2.3V43.6z"/>
<rect x="6.2" y="39.4" style="fill:#B2D4C9;" width="17" height="1"/>
<rect x="6.2" y="27" style="fill:#B2D4C9;" width="36.6" height="1"/>
<rect x="6.2" y="30.6" style="fill:#B2D4C9;" width="48.1" height="1"/>
<rect x="45.5" y="20.6" style="fill:#B2D4C9;" width="8.8" height="1"/>
<rect x="33.9" y="39.4" style="fill:#B2D4C9;" width="20.4" height="1"/>
<rect x="6.2" y="19.6" style="fill:#B2D4C9;" width="6.7" height="3"/>
<rect x="45.5" y="24.4" style="fill:#EDFAF6;" width="8.8" height="3.5"/>
</svg>
