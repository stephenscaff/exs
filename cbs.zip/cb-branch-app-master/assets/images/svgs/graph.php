<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<rect y="27" style="fill:#41C19D;" width="12.4" height="23.2"/>
<rect x="16" y="14.4" style="fill:#2CA4DE;" width="12.4" height="35.8"/>
<rect x="31.8" y="22.9" style="fill:#F05F50;" width="12.4" height="27.4"/>
<rect y="50.2" style="fill:#36A183;" width="12.4" height="3.8"/>
<rect x="16" y="50.2" style="fill:#216C94;" width="12.4" height="3.8"/>
<rect x="31.8" y="50.2" style="fill:#CF5245;" width="12.4" height="3.8"/>
<rect x="47.6" y="6" style="fill:#FBD462;" width="12.4" height="44.2"/>
<rect x="47.6" y="50.2" style="fill:#D6B554;" width="12.4" height="3.8"/>
</svg>
