<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<path style="fill:#E6E7E8;" d="M47.9,60H6.4c-0.1,0-0.2-0.1-0.2-0.2V3.2C6.2,3.1,6.3,3,6.4,3h44.2c0.1,0,0.2,0.1,0.2,0.2v53.9
	C50.8,58.7,49.5,60,47.9,60z"/>
<rect x="30.4" y="10.8" style="fill:#BCBEC0;" width="13.9" height="1.5"/>
<rect x="12.6" y="17.4" style="fill:#BCBEC0;" width="31.8" height="1.5"/>
<rect x="12.6" y="22.2" style="fill:#BCBEC0;" width="31.8" height="1.5"/>
<rect x="12.6" y="26.9" style="fill:#BCBEC0;" width="31.8" height="1.5"/>
<rect x="12.6" y="31.7" style="fill:#BCBEC0;" width="31.8" height="1.5"/>
<rect x="12.6" y="36.5" style="fill:#BCBEC0;" width="31.8" height="1.5"/>
<rect x="21.7" y="45.2" style="fill:#BCBEC0;" width="22.7" height="1.5"/>
<rect x="14.9" y="43.2" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -27.9199 24.5532)" style="fill:#F05F50;" width="1.5" height="5.5"/>
<rect x="12.9" y="45.3" transform="matrix(0.7071 -0.7071 0.7071 0.7071 -27.9778 24.5524)" style="fill:#F05F50;" width="5.5" height="1.5"/>
<path style="fill:#E6E7E8;" d="M6.2,3c0-1.7,1.4-3,3-3h44.5c-1.7,0-3,1.4-3,3H6.2z"/>
<path style="fill:#BCBEC0;" d="M53.8,0c-1.7,0-3,1.4-3,3h6.1C56.8,1.4,55.4,0,53.8,0z"/>
<path style="fill:#BCBEC0;" d="M3.2,57c0,1.7,1.4,3,3,3h41.6c-1.7,0-3-1.4-3-3H3.2z"/>
</svg>
