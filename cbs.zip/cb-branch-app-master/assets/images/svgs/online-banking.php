<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
<path style="fill:#464748;" d="M42,60H18c-2.2,0-4-1.8-4-4V4c0-2.2,1.8-4,4-4h24c2.2,0,4,1.8,4,4v52C46,58.2,44.2,60,42,60z"/>
<rect x="24.9" y="4.1" style="fill:#5C5D5E;" width="10" height="2"/>
<circle style="fill:#5C5D5E;" cx="30" cy="55" r="2"/>
<rect x="16" y="10" style="fill:#27A2DF;" width="28" height="40"/>
<path style="fill:#E8E8E8;" d="M40.4,46.3H19.6c-0.6,0-1-0.4-1-1V14.7c0-0.6,0.4-1,1-1h20.8c0.6,0,1,0.4,1,1v30.5
	C41.4,45.8,40.9,46.3,40.4,46.3z"/>
<path style="fill:#E8E8E8;" d="M40.4,46.3H19.6c-0.6,0-1-0.4-1-1V14.7c0-0.6,0.4-1,1-1h20.8c0.6,0,1,0.4,1,1v30.5
	C41.4,45.8,40.9,46.3,40.4,46.3z"/>
<path style="fill:#FFFFFF;" d="M41.4,19.2H18.6v-4.5c0-0.6,0.4-1,1-1h20.8c0.6,0,1,0.4,1,1V19.2z"/>
<path style="fill:#BBD632;" d="M18.6,40.8h22.8v4.5c0,0.6-0.4,1-1,1H19.6c-0.6,0-1-0.4-1-1V40.8z"/>
<rect x="20.8" y="23" style="fill:#FFFFFF;" width="18.4" height="3.2"/>
<rect x="20.8" y="27.6" style="fill:#FFFFFF;" width="18.4" height="3.2"/>
<rect x="20.8" y="42.7" style="fill:#E8E8E8;" width="8.1" height="1.6"/>
<rect x="30.3" y="42.7" style="fill:#E8E8E8;" width="8.1" height="1.6"/>
<rect x="20.8" y="34.3" style="fill:#27A2DF;" width="18.4" height="3.2"/>
</svg>
