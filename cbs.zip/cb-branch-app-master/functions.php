<?php
/**
 * Includes from inc
 * Represents The Jumpoff's functionality
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once('inc/login/login.php');

# Admin and Admin Theme
require_once('inc/admin/admin.php');

# Settings
require_once('inc/setup/setup.php');

# Custom Users
require_once('inc/users/users.php');

# ACF Utils
require_once('inc/acf/includes.php');

# Utilities and Helpers
require_once('inc/utils/utils.php');

# Utilities and Helpers
require_once('inc/media/includes.php');

# Post/Content Types and Taxonomies
require_once('inc/post-types/post-types.php');

# Custom Fields (via acf and StoutLogic)
require_once('inc/fields/fields.php');

# Fetch More Posts
require_once('inc/fetch-more/fetch-more.php');

# Custom Video
require_once('inc/plyr/plyr.php');

# Custom Video
require_once('inc/users/users.php');

# ACF table builder
require_once('inc/acf-table-builder/table-builder.php');

# Cart Funcitonality
require_once('inc/cart/cart.php');
