<?php
/**
 * Template Name: DEV - Product Page
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();



# Get Curent Post Type Object
$post_type_obj = get_queried_object();

# Ids Helper
$ids = jumpoff_ids();

$product_mast_title = get_field('product_mast_title', $ids);
$product_mast_text = get_field('product_mast_text', $ids);
$product_mast_image = get_field('product_mast_image', $ids);


?>

<main class="has-header-offset product-page">

<section class="mast">
  <div class="grid">
    <div class="mast__wrap">
      <figure class="mast__figure" style="background-image: url(<?php echo $product_mast_image['sr']?>)"></figure>
      <header class="mast__header">
        <h1 class="mast__title">Personal Banking</h1>
        <p class="mast__text">A sense of community is important, especially for banks. We answer our own phones and we never forget a face. From checking to lending and everything in between, our personal banking options will make you feel right at home.</p>
      </header>
    </div>
  </div>
</section>

<section class="tab-nav">
  <header class="tab-nav__header">
    <h5 class="tab-nav__title">Choose from the list below to get started</h5>
  </header>

  <nav class="tab-nav__nav">
    <a class="tab-nav__link is-active" href="">Checking Account</a>
    <a class="tab-nav__link" href="">Savings Account</a>
    <a class="tab-nav__link" href="">Credit Cards</a>
    <a class="tab-nav__link" href="">Debit Cards</a>
    <a class="tab-nav__link" href="">Loans</a>
    <a class="tab-nav__link" href="">Overdraft Protection</a>
  </nav>
</section>

<section class="intro">
  <div class="intro__content grid">
    <h2 class="intro__title">Handmade checking just for you</h2>
    <p class="intro__text">Flexible and secure checking accounts are the cornerstone of our community banking philosophy. With numerous account options and plenty of local banking experts, you can be sure your money will be well looked after.</p>
  </div>
</section>

<!-- Pro Tips -->
<section class="protips carousel is-to-edge mar">
  <div class="grid">
    <header class="protips__header">
      <h4 class="protips__title">Pro-Tips</h4>
    </header>
    <div class="protips__items carousel__items js-carousel">

      <article class="protip">
        <figure class="protip__icon"><?php echo jumpoff_svg('account-transfer'); ?></figure>
        <p class="protip__text">If you use your debit card more than 10 times a month, you can get your Neighborhood Checking account fee waived.</p>
      </article>


      <article class="protip">
        <figure class="protip__icon"><?php echo jumpoff_svg('atm'); ?></figure>
        <p class="protip__text">If you keep a minimum balance of $10,000, you can save ATM and maintenance fees with our Relationship checking account.</p>
      </article>


      <article class="protip">
        <figure class="protip__icon"><?php echo jumpoff_svg('cash'); ?></figure>
        <p class="protip__text">Our check-free, overdraft-protection-free Foundation account is for those just starting out or those rebuilding their credit.</p>
      </article>

      <article class="protip">
        <figure class="protip__icon"><?php echo jumpoff_svg('dollar-sign'); ?></figure>
        <p class="protip__text">Our check-free, overdraft-protection-free Foundation account is for those just starting out or those rebuilding their credit.</p>
      </article>

      <article class="protip">
        <figure class="protip__icon"><?php echo jumpoff_svg('calculator'); ?></figure>
        <p class="protip__text">Our check-free, overdraft-protection-free Foundation account is for those just starting out or those rebuilding their credit.</p>
      </article>

    </div>
  </div>
</section>



<section class="product-card">
  <div class="grid">
    <div class="product-card__bg">
      <header class="product-card__header">
        <div>
          <span class="product-card__meta">Account</span>
          <h3 class="product-card__title">Neighborhood</h3>
        </div>
        <a class="product-card__btn btn -white">Add to Cart</a>
      </header>
      <section class="product-card__main">
        <div class="product-card__grid">
          <div class="product-card__col -left">
            <h4 class="product-card__heading">Overview</h4>
            <p class="font-sm">Make purchases, transfer money between linked accounts, and get cash from any ATM safely and securely.</p>
          </div>
          <div class="product-card__col -right">
            <div class="product-card__content">

              <h5>Convenience</h5>
              <p>Your Columbia Bank Business Visa Debit Card is welcome at millions of merchant locations where Visa is accepted and at thousands of ATMs worldwide. Make purchases in person, by phone, by mail—even online. Use your Columbia Bank Business Visa Debit Card to pay for business expenses instead of writing checks.</p>

              <h5>Control</h5>
              <p>At restaurants, hotels or millions of other locations, simply present your card to the merchant, sign your receipt and go. It’s as easy as that. At grocery stores, gas stations or other self-service terminals, pass your card through the reader and select Credit on the keypad.</p>

              <h5>Security</h5>
              <p>Purchase Security and Extended Protection are provided by Visa on items purchased with a Columbia Bank Business Visa Debit Card. Using a Columbia Bank Business Visa Debit Card doesn’t require you to disclose personal information when you make a purchase—unlike a check.</p>

              <ul>
                <li>A list item one</li>
                <li>List item 2</li>
                <li>One more list item</li>
              </ul>

            </div>
          </div>
        </div>
      </section>
      <footer class="product-card__footer">
        <div class="product-card__grid">
          <div class="product-card__col -left">
            <h4 class="product-card__heading">Documents</h4>
          </div>
          <div class="product-card__col -right">
            <div class="grid-1-2">
              <a class="file" href="">
                <i class="file__icon icon-plus is-raised"></i>
                <div>
                  <span class="file__title">Personal Checking Accounts</span>
                  <span class="file__size">3.5mb</span>
                </div>
              </a>
              <a class="file" href="">
                <i class="file__icon icon-plus is-raised"></i>
                <div>
                  <span class="file__title">Personal Checking Accounts</span>
                  <span class="file__size">3.5mb</span>
                </div>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>
</section>


<section class="product-card">
  <div class="grid">
    <div class="product-card__bg">
      <header class="product-card__header">
        <div>
          <span class="product-card__meta">Account</span>
          <h3 class="product-card__title">Neighborhood</h3>
        </div>
        <a class="product-card__btn btn -white">Add to Cart</a>
      </header>
      <section class="product-card__main">
        <div class="product-card__grid">
          <div class="product-card__col -left">
            <h4 class="product-card__heading">Overview</h4>
            <p class="font-sm">Here, you'll find everything you need in a checking account. Designed to meet the needs of our neighbors new and old, our Neighborhood account is perfect for your main account.</p>
          </div>
          <div class="product-card__col -right">
            <table class="product-card__table">
              <tbody>
                <tr>
                  <th scope="row">Monthly Maintenance Fee</th>
                  <td>$5 minimum daily balance of $2,500, 10 debit card transactions, one direct deposit, age 62 and older, Military ID, or Student ID on record</td>
                </tr>
                <tr>
                  <th scope="row">Minimal Opening Deposit</th>
                  <td>$25</td>
                </tr>
                <tr>
                  <th scope="row">Check/Debit Charges</th>
                  <td>No charge</td>
                </tr>
                <tr>
                  <th scope="row">Interest Earnings Calculated Paid/Compounded</th>
                  <td>Not applicable</td>
                </tr>
                <tr>
                  <th scope="row">Paper Statement Fee</th>
                  <td>$3 waived with enrollment in eStatements or age 62 and older</td>
                </tr>
                <tr>
                  <th scope="row">
                    ATM Transaction Charges <br/>
                    Columbia Bank ATMs <br/>
                    Non-Columbia Bank ATMs
                  </th>
                  <td>
                    <br/>
                    No charge <br/>
                    $2.50
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </section>
      <footer class="product-card__footer">
        <div class="product-card__grid">
          <div class="product-card__col -left">
            <h4 class="product-card__heading">Documents</h4>
          </div>
          <div class="product-card__col -right">
            <div class="grid-1-2">
              <a class="file" href="">
                <i class="file__icon icon-plus is-raised"></i>
                <div>
                  <span class="file__title">Personal Checking Accounts</span>
                  <span class="file__size">3.5mb</span>
                </div>
              </a>
              <a class="file" href="">
                <i class="file__icon icon-plus is-raised"></i>
                <div>
                  <span class="file__title">Personal Checking Accounts</span>
                  <span class="file__size">3.5mb</span>
                </div>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>
</section>


<section class="compare pad">
  <div class="grid">
    <div class="compare__bg">
      <header class="compare__header">
        <h3 class="compare__title">View the Competition</h3>
        <p class="compare__text">Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper.</p>
      </header>

      <div class="compare__logos">
        <a class="compare__link" href="" target="_blank">
          <img class="compare__logo" src="<?php echo jumpoff_img(); ?>/logos/logo-wellsfargo.png"/>
        </a>
        <a class="compare__link" href="" target="_blank">
          <img class="compare__logo" src="<?php echo jumpoff_img(); ?>/logos/logo-chase.png"/>
        </a>
        <a class="compare__link" href="" target="_blank">
          <img class="compare__logo" src="<?php echo jumpoff_img(); ?>/logos/logo-becu.png"/>
        </a>
      </div>
    </div>
  </div>
</section>


</main>

<!-- Footer -->
<?php get_footer(); ?>
