<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 *  Post Type: Team
 *
 *  Slug :      Team
 *  Supports : 'title','thumbnail','editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'community';
 $labels = jumpoff_post_type_labels('Community Article', 'Community Articles');

 $args = [
   'public'             => true,
   'description'        => 'Columbia Bank\'s Community stories and articles',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 3,
   'menu_dashicon'      => 'dashicons-testimonial',
   'menu_icon'          => 'dashicons-testimonial',
   'query_var'          => true,
   'supports'              => array( 'title','thumbnail', 'editor', 'author' ),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'publicly_queryable' => true,
   'rewrite'            => array('slug' => 'community', 'with_front' => false),
 ];
 register_post_type( $type, $args);
});


/**
 *  Taxonomy: Team Role
 *
 *  @version    1.0
 */

 add_action( 'init', function() {
   $tax    = 'community_cat';
   $type   = 'community';
   $labels = jumpoff_post_type_labels('Community Category', 'Community Categories');

   $args = [
       'description'         => 'Wecu Team Members.',
       'labels'              => $labels,
       'hierarchical'        => true,
       'show_ui'             => true,
       'show_admin_column'   => true,
       'show_in_quick_edit'  => true,
       'rewrite'             => array('slug' => 'community-categories', 'with_front' => false),
   ];
   register_taxonomy( $tax, $type, $args);
 });
