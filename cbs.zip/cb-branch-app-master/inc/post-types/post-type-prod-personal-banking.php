<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Personal Banking
 *
 *  Slug :      Personal Banking
 *  Supports : 'title','thumbnail','editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

# Init Work
add_action('init', 'create_personal_banking_post_type');

function create_personal_banking_post_type() {
  register_post_type( 'personal_banking',

  array(
    'labels'              => array(
    'name'                => __( 'Personal Banking' ),
    'singular_name'       => __( 'Personal Banking' ),
    'add_new'             => __( 'Add New' ),
    'add_new_item'        => __( 'Add Another Personal Banking Page' ),
    'edit'                => __( 'Edit This Personal Banking Page' ),
    'edit_item'           => __( 'Edit This Personal Banking Page' ),
    'new_item'            => __( 'New Personal Banking Page' ),
    'view'                => __( 'View This Personal Banking Page' ),
    'view_item'           => __( 'View All Personal Banking Pages' ),
    'search_items'        => __( 'Search Personal Banking Pages' ),
    'not_found'           => __( 'Sorry. That Personal Banking Page cannot be found.' ),
    'not_found_in_trash'  => __( 'That Personal Banking Page is not in the Trash.' ),
  ),

  'description'           => __( 'Columbia Bank\'s Personal Banking Product Type' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_position'         => 6,
  'menu_dashicon'         => 'dashicons-vault',
  'menu_icon'             => 'dashicons-vault',
  'query_var'             => true,
  'supports'              => array( 'title','thumbnail' ),
  'capabilities' => array(
    'read_post'           => 'read_product',
    'read_private_posts'  => 'read_private_products',
    'edit_post'           => 'edit_product',
    'edit_posts'          => 'edit_products',
    'edit_others_posts'   => 'edit_others_products',
    'publish_posts'       => 'publish_products',
    'delete_posts'        => 'delete_products'
    ),
  'can_export'            => true,
  'has_archive'           => true,
  'rewrite'               => array('slug' => 'personal-banking', 'with_front' => false),
  ));
}
