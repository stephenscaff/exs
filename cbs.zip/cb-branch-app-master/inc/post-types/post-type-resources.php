<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 *  Post Type: Resource
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'resource';
 $labels = jumpoff_post_type_labels('Resource', 'Resources');

 $args = [
   'public'             => true,
   'description'        => 'Columbia Bank\'s Resource Articles',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 3,
   'menu_dashicon'      => 'dashicons-book-alt',
   'menu_icon'          => 'dashicons-book-alt',
   'query_var'          => true,
   'supports'              => array( 'title','thumbnail', 'editor', 'author' ),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'publicly_queryable' => true,
   'rewrite'            => array('slug' => 'resources', 'with_front' => false),
 ];
 register_post_type( $type, $args);
});


/**
 *  Taxonomy: Team Role
 *
 *  @version    1.0
 */

 add_action( 'init', function() {
   $tax    = 'resource_cat';
   $type   = 'resource';
   $labels = jumpoff_post_type_labels('Resources Category', 'Resources Categories');

   $args = [
       'description'         => 'Categories for Columbia Bank\'s Resource Articles',
       'labels'              => $labels,
       'hierarchical'        => true,
       'show_ui'             => true,
       'show_admin_column'   => true,
       'show_in_quick_edit'  => true,
       'rewrite'             => array('slug' => 'resources-categories', 'with_front' => false),
   ];
   register_taxonomy( $tax, $type, $args);
 });
