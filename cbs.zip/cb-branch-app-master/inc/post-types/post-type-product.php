<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: product
 *
 *  Slug :      product
 *  Supports : 'title','thumbnail','editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

# Init Work
add_action('init', 'create_product_post_type');

function create_product_post_type() {
  register_post_type( 'product',

  array(
    'labels'              => array(
    'name'                => __( 'Products' ),
    'singular_name'       => __( 'Product' ),
    'add_new'             => __( 'Add New Product' ),
    'add_new_item'        => __( 'Add Another Product.' ),
    'edit'                => __( 'Edit This Product' ),
    'edit_item'           => __( 'Edit This Product' ),
    'new_item'            => __( 'New Product' ),
    'view'                => __( 'View This Product' ),
    'view_item'           => __( 'View All Product ' ),
    'search_items'        => __( 'Search Your Product' ),
    'not_found'           => __( 'Sorry. That Product cannot be found.' ),
    'not_found_in_trash'  => __( 'That Product is not in the Trash.' ),
  ),

  'description'           => __( 'Columbia Bank\'s products and offerings' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_position'         => 6,
  'menu_dashicon'         => 'dashicons-cart',
  'menu_icon'             => 'dashicons-cart',
  'query_var'             => true,
  'supports'              => array( 'title'),
  'capabilities' => array(
    'read_post'           => 'read_product',
    'read_private_posts'  => 'read_private_products',
    'edit_post'           => 'edit_product',
    'edit_posts'          => 'edit_products',
    'edit_others_posts'   => 'edit_others_products',
    'publish_posts'       => 'publish_products',
    'delete_posts'        => 'delete_products'
    ),
  'map_meta_cap'          => true,
  'can_export'            => true,
  'publicly_queryable'  => false,
  'query_var'           => false,
  'has_archive'           => false,
  //'rewrite'               => array('slug' => 'product', 'with_front' => false),
  ));
}

/**
 *  Taxonomy: product Cat
 *
 *  Creates 'product_cat' custom taxonomy
 *
 *  Slug : product-categories
 *  hierarchical : true
 *
 *  @author     Stephen Scaff
 *  @version    1.0
 */
add_action( 'init', 'product_cat');

function product_cat() {
  register_taxonomy(
  'product_cat',
  'product',
    array(
      'labels'            => array(
      'name'              => _x('Product Categories', 'taxonomy general name'),
      'singular_name'     => _x('Product Categories', 'taxonomy singular name'),
      'search_items'      => __('Search Product Categories '),
      'all_items'         => __('All Product Categories'),
      'edit_item'         => __('Edit Product Categories'),
      'update_item'       => __('Update Product Categories'),
      'add_new_item'      => __('Add New Product Categories'),
      'new_item_name'     => __('New Product Categories'),
      'menu_name'         => __('Product Categories'),
    ),
    'hierarchical'        => true,
    'show_ui'             => true,
    'show_admin_column'   => true,
    'show_in_quick_edit'  => true,
    'rewrite'             => array(
        'slug'            => 'product-categories',
        'with_front'      => false,
      ),
  ));
}
