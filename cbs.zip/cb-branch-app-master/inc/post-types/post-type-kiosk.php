<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Kisok
 *
 *  Slug :      activities
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'kiosk';

 // Call the function and save it to $labels
 $labels = jumpoff_post_type_labels('Kiosk', 'Kiosks');

 $args = [
   'public'             => true,
   'description'        => 'Location based Kiosk Screens',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 3,
   'menu_dashicon'      => 'dashicons-schedule',
   'menu_icon'          => 'dashicons-schedule',
   'query_var'          => true,
   'supports'           => array( 'title' ),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => false,
   'publicly_queryable'  => false
 ];

 register_post_type( $type, $args);

});
