<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 * Define Single Template for Community/Resource Archive Views
 */
add_filter( 'template_include', 'articles_archive_template', 99 );

function articles_archive_template( $template ) {
  if ( is_post_type_archive( array('community', 'resource' ))){
    $new_template = locate_template( 'templates/articles.php' );

    if ( '' != $new_template ) {
      return $new_template ;
    }
  }
  return $template;
}

/**
 * Define Single Template for Community/Resource Archive Views
 */
# add_filter( 'template_include', 'product_type_archive_template', 99 );

function product_type_archive_template( $template ) {

  if ( is_post_type_archive( array('personal_banking', 'buisness_banking', 'wealth_management' ))){
    $new_template = locate_template( 'templates/product-type-index.php' );

    if ( '' != $new_template ) {
      return $new_template ;
    }
  }
  return $template;
}

/**
 * Define Single Template for Community/Resource Archive Views
 */
add_filter( 'template_include', 'product_type_single_template', 99 );

function product_type_single_template( $template ) {

  if ( is_singular( array('personal_banking', 'business_banking', 'wealth_management' ))){
    $new_template = locate_template( 'templates/product-type-single.php' );

    if ( '' != $new_template ) {
      return $new_template ;
    }
  }
  return $template;
}
