<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Business Banking
 *
 *  Slug :      Business Banking
 *  Supports : 'title','thumbnail','editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

# Init Work
add_action('init', 'create_business_banking_post_type');

function create_business_banking_post_type() {
  register_post_type( 'business_banking',

  array(
    'labels'              => array(
    'name'                => __( 'Business Banking' ),
    'singular_name'       => __( 'Business Banking' ),
    'add_new'             => __( 'Add New ' ),
    'add_new_item'        => __( 'Add Another Business Banking Page' ),
    'edit'                => __( 'Edit This Business Banking Page' ),
    'edit_item'           => __( 'Edit This Business Banking Page' ),
    'new_item'            => __( 'New Business Banking Page' ),
    'view'                => __( 'View This Business Banking Page' ),
    'view_item'           => __( 'View All Business Banking Pages' ),
    'search_items'        => __( 'Search Business Banking Pages' ),
    'not_found'           => __( 'Sorry. That Business Banking Page cannot be found.' ),
    'not_found_in_trash'  => __( 'That Business Banking Page is not in the Trash.' ),
  ),

  'description'           => __( 'Columbia Bank\'s Business Banking Product Type' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_position'         => 6,
  'menu_dashicon'         => 'dashicons-vault',
  'menu_icon'             => 'dashicons-vault',
  'query_var'             => true,
  'supports'              => array( 'title','thumbnail' ),
  'capabilities' => array(
    'read_post'           => 'read_product',
    'read_private_posts'  => 'read_private_products',
    'edit_post'           => 'edit_product',
    'edit_posts'          => 'edit_products',
    'edit_others_posts'   => 'edit_others_products',
    'publish_posts'       => 'publish_products',
    'delete_posts'        => 'delete_products'
  ),
  'map_meta_cap'          => true,
  'can_export'            => true,
  'has_archive'           => true,
  'rewrite'               => array('slug' => 'business-banking', 'with_front' => false),
  ));
}
