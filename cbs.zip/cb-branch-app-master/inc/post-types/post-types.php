<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Flush Rewrites
 */
add_action( 'after_switch_theme', 'jumpoff_flush_rewrite_rules' );

function jumpoff_flush_rewrite_rules() {
  flush_rewrite_rules();
}

# Community
require_once('post-type-community.php');

# Resources
require_once('post-type-resources.php');

# Products
require_once('post-type-product.php');

# Product: Personal Banking
require_once('post-type-prod-personal-banking.php');

# Product: Business Banking
require_once('post-type-prod-business-banking.php');

# Product: Wealth Managent
require_once('post-type-prod-wealth-management.php');

# CPT Template Views Controllers
require_once('post-type-controllers.php');

# CPT Template Views Controllers
require_once('post-type-kiosk.php');
