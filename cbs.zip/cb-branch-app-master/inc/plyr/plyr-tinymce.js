/**
 * Plyr Tiny MCE Button Addition
 * Integrates Plyr.js with Tiny MCE editor
 * via toolbar button and Thickbox popup form.
 * @author stephen scaff
 */
(function() {
	tinymce.create('tinymce.plugins.plyr', {

		/**
		 * Init
		 */
		init: function(ed, url) {

			/**
			 * AddButton
			 * @see https://www.tinymce.com/docs/api/tinymce/tinymce.editor/#addbutton
			 */
			ed.addButton('plyr', {
				title: 'Insert HTML5 Video',
				//image: 'image-path.png',
        icon: 'play icon-youtube-play',
				onclick: function() {
					var width = jQuery(window).width(),
							H = jQuery(window).height(),
							W = ( 720 < width ) ? 720 : width;
							W = W - 80;
							H = H - 124;
					tb_show('Add Video', '#TB_inline?inlineId=plyrpopup&width=' + W + '&height=' + H);

					jQuery("#TB_window").animate({
						height: H + 40 + 'px'
					});

					return false;
				}
			});
		},

		createControl: function(n, cm) {
			return null;
		},

		getInfo: function() {
			return {
				longname: 'Plyr Wordpress Integration',
				author: 'Stephen Scaff',
				authorurl: 'http://stephenscaff.com/',
				infourl: 'http://stephenscaff.com/',
				version: '1.0'
			};
		}
	});

	/**
	 * Add Plyr
	 */
	tinymce.PluginManager.add('plyr', tinymce.plugins.plyr);

	/**
	 * Plyr Thickbox Popup & Form
	 */
	jQuery(function() {

		var form = jQuery('<div id="plyrpopup">\
		<table id="plyrtable" class="form-table">\
			<tr>\
				<th><label for="plyr-mp4">MP4 Source</label></th>\
				<td><input type="text" name="plyr-mp4" id="plyr-mp4"><br>\
				<small>The location of the h.264/MP4 source for the video.</small></td>\
			</tr>\
			<tr>\
				<th><label for="plyr-webm">WebM Source</label></th>\
				<td><input type="text" name="plyr-webm" id="plyr-webm"><br>\
				<small>The location of the VP8/WebM source for the video.</small></td>\
			</tr>\
			<tr>\
				<th><label for="plyr-ogg">OGG Source</label></th>\
				<td><input type="text" name="plyr-ogg" id="plyr-ogg"><br>\
				<small>The location of the Theora/Ogg source for the video.</small></td>\
			</tr>\
			<tr>\
				<th><label for="plyr-youtube">YouTube ID</label></th>\
				<td><input type="text" name="plyr-youtube" id="plyr-youtube"><br>\
				<small>YouTube ID.</small></td>\
			</tr>\
      <tr>\
				<th><label for="plyr-vimeo">Vimeo ID</label></th>\
				<td><input type="text" name="plyr-vimeo" id="plyr-vimeo"><br>\
				<small>Vimeo ID.</small></td>\
			</tr>\
		</table>\
		<p class="submit">\
				<input type="button" id="plyr-submit" class="button-primary" value="Insert Video" name="submit" />\
		</p>\
		</div>');

		var table = form.find('table');
		form.appendTo('body').hide();

		/**
		 * On Submit
		 */
		form.find('#plyr-submit').click(function(){

			var shortcode = '[plyr';

			//text options
			var options = {
				'mp4'      : '',
				'webm'     : '',
				'ogg'      : '',
        'youtube'      : '',
        'vimeo'      : '',
			};

			for ( var index in options ) {
				var value = table.find('#plyr-' + index).val();

				// attaches the attribute to the shortcode only if it's different from the default value
				if ( value !== options[index] )
					shortcode += ' ' + index + '="' + value + '"';
			}

			// close shortcode
			shortcode += ']';

			// insert shortcode into the active editor
			tinyMCE.activeEditor.execCommand('mceInsertContent', 0, shortcode);

			// closes Thickbox
			tb_remove();
		});
	});
})();
