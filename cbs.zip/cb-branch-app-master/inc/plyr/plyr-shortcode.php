<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * VIdeo / Plyr Shortcode
 */
add_shortcode('plyr', 'video_shortcode');
add_shortcode('video', 'video_shortcode');

function video_shortcode($atts, $content=null){

	$options = get_option('plyr_options'); //load the defaults

  extract(shortcode_atts(array(
		'mp4' => '',
		'webm' => '',
		'ogg' => '',
		'youtube' => '',
    'vimeo' => '',
	), $atts));

	$dataSetup = array();
  $vid_source = '';

	// MP4 Source Supplied
	if ($mp4)
		$mp4_source = '<source src="'.$mp4.'" type=\'video/mp4\' />';
	else
		$mp4_source = '';

	// WebM Source Supplied
	if ($webm)
		$webm_source = '<source src="'.$webm.'" type=\'video/webm; codecs="vp8, vorbis"\' />';
	else
		$webm_source = '';

	// Ogg source supplied
	if ($ogg)
		$ogg_source = '<source src="'.$ogg.'" type=\'video/ogg; codecs="theora, vorbis"\' />';
	else
		$ogg_source = '';

  if ($youtube)
    $vid_source='<div data-type="youtube" data-video-id="'.$youtube.'"></div>';

  if ($vimeo)
    $vid_source='<div data-type="vimeo" data-video-id="'.$vimeo.'"></div>';

	//Output the <video> tag
	$plyr = <<<_end_
<section class="vid -gridbreak">
  <div class="js-plyr">
    {$vid_source}
		<!--
  	<video class="video-js">
  		{$mp4_source}
  		{$webm_source}
  		{$ogg_source}
  	</video>
		-->
</div>
</section>
_end_;

  return $plyr;

}
