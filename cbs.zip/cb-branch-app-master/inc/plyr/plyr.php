<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


# Query Filters
require_once('plyr-shortcode.php');

# Taxonomies
require_once('plyr-tinymce.php');
