<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Plyr JS Loader
 */

add_action( 'wp_enqueue_scripts', 'plyr_js_loader' );

function plyr_js_loader() {
  wp_register_script( 'plyr_js', 'https://cdnjs.cloudflare.com/ajax/libs/plyr/3.1.0/plyr.js', '', false, true );

  if (is_single()){
    wp_enqueue_script('plyr_js');
  }
}
