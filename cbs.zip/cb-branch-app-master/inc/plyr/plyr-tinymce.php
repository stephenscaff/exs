<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * PlyrMCE
 * Plyr.js integration for TinyMCE.
 */
class PlyrMCE{

  function __construct(){
		if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
			return;
		add_filter('mce_external_plugins', array($this, 'get_mce_js'));
		add_filter('mce_buttons', array($this,'get_mce_button'));
  }


	/**
	 * Register Plyr Button
	 */
	function get_mce_button($buttons) {
		array_push($buttons, "|", "plyr");
		//$options = get_option('plyr_options');

		return $buttons;
	}


	function get_mce_js($plugin_array) {
		$plugin_array['plyr'] = get_template_directory_uri().'/inc/plyr/plyr-tinymce.js';
		return $plugin_array;
	}
}

new PlyrMCE;
