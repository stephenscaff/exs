<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once 'image-settings.php' ;
require_once 'max-upload-size.php' ;
require_once 'featured-images.php' ;
