<?php
/**
 * Todays' Team
 * Fields to Select the daily Team Members (Users: Bankers) for the Kiosk View.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$team_selector = new StoutLogic\AcfBuilder\FieldsBuilder('team_selector', [
  'key' => 'group_team_selector',
  'position' => 'normal',
  'menu_order' => '2',
  'label' => 'Today\'s Team',
]);
$team_selector
  ->addMessage('', 'Select Today\'s Team Members')
  ->addUser('team_selector', [
   'role' => array('banker'),
   'multiple' => true,
  ])

  # Locations
  ->setLocation('page', '==', get_id_by_name('kiosk'))
  ->or('post_type', '==', 'kiosk');

 add_action('acf/init', function() use ($team_selector) {
    acf_add_local_field_group($team_selector->build());
 });
