<?php
/**
 * Modules Library
 * Modules registed are are inteded to be reused by variable
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;


$modules = new FieldsBuilder('home_modules', [
  'key' => 'group_home_modules',
  'position' => 'acf_after_title',
  'menu_order' => '3',
]);
$modules
  ->addFlexibleContent('modules', [
    'button_label'=> "Add Module",
  ])

  # Featured COntent
  ->addLayout($featured_content_module, [
    'name'=> 'featured-content-module',
  ])

  # Product CTAs
  ->addLayout($product_ctas_module, [
    'name'=> 'product-ctas-module',
  ])

  # Card Carousel Module
  ->addLayout($card_carousel_module, [
    'name'=> 'card-carousel-module',
  ])

  ->setLocation('page', '==', get_id_by_name('home'));

add_action('acf/init', function() use ($modules) {
   acf_add_local_field_group($modules->build());
});
