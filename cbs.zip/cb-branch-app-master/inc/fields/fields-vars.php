<?php
/**
 * Global Fields
 * Fields registered here can be reused by variable.
 * Hopefully, this keeps things a bit tidier.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Product Eloqua Id
 */
 $product_eid = new FieldsBuilder('product_eloqua_id');
 $product_eid->addText('product_eloqua_id');

/**
 * Title
 */
$title_field = new FieldsBuilder('title');
$title_field->addText('title');

/**
 * Pre Titles
 */
$pretitle_field = new FieldsBuilder('pretitle');
$pretitle_field->addText('pretitle');

/**
 * Content - Textarea
 */
$content_field = new FieldsBuilder('content');
$content_field
  ->addTextArea('content',  [
    'rows' =>  '4',
    'label' => 'Content'
  ]);


/**
 * Icon Selector
 */
$icon_select = new FieldsBuilder('icon_select');
$icon_select
  ->addSelect('icon',  [
    'placeholder' => 'Select an Icon',
  ])
  ->addChoice('account-transfer', 'Account Transfer')
  ->addChoice('atm', 'ATM')
  ->addChoice('calculator', 'Calculator')
  ->addChoice('cash', 'Cash')
  ->addChoice('check', 'Check')
  ->addChoice('commercial-banking', 'Commercial Banking')
  ->addChoice('credit-debit', 'Credit Debit')
  ->addChoice('digital-wallet', 'Digital Wallet')
  ->addChoice('dollar-sign', 'Dollar Sign')
  ->addChoice('graph', 'Graph')
  ->addChoice('id-theft', 'ID Theft')
  ->addChoice('loan', 'Loan')
  ->addChoice('id-theft', 'ID Theft')
  ->addChoice('low-balance', 'Low Balance')
  ->addChoice('online-banking', 'Online Banking')
  ->addChoice('overdraft', 'Overdraft')
  ->addChoice('peace-of-mind', 'Peace of Mind')
  ->addChoice('safe-vault', 'Safe Vault')
  ->addChoice('storefront', 'Storefront');


/**
 * Buttons
 */
$button_field = new FieldsBuilder('button');
$button_field
  # Button URL
  ->addPageLink('button_url', [
    'allow_null'  => 'true',
    'wrapper' =>  ['width' => '33.333%']
  ])
  # Button External URL
  ->addUrl('button_url_ext', [
    'wrapper' =>  ['width' => '33.333%']
  ])
  # Button Text
  ->addText('button_text', [
    'wrapper' =>  ['width' => '33.333%']
  ]);
