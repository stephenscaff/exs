<?php
/**
 *   Eloqua ID
 *   Appears where - Post, Collection
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$branch_id = new StoutLogic\AcfBuilder\FieldsBuilder('branch_options', [
  'menu_order' => '99',
]);;

$branch_id
  ->addText('branch_id')
  ->addTrueFalse('show_community',
    [
      'label' => 'Show Community Posts and Menu link',
      'default_value' => 0,
      'wrapper' =>  ['width' => '50%']
    ]
  )
  ->addTrueFalse('show_resources',
    [
      'label' => 'Show Resources',
      'default_value' => 0,
      'wrapper' =>  ['width' => '50%']
    ]
  )
  ->addTrueFalse('show_about',
    [
      'label' => 'Show About Page Menu link',
      'default_value' => 0,
      'wrapper' =>  ['width' => '100%']
    ]
  )
  ->setLocation('post_type', '==', 'kiosk');

add_action('acf/init', function() use ($branch_id) {
   acf_add_local_field_group($branch_id->build());
});



$branch_options = new StoutLogic\AcfBuilder\FieldsBuilder('branch_options', [
  'menu_order' => '8',
]);

$branch_options
  ->addTrueFalse('show_community',
    [
      'label' => 'Show Community Posts and Menu link',
      'default_value' => 0
    ]
  )
  ->addTrueFalse('show_resources',
    [
      'label' => 'Show Community Posts and Menu link',
      'default_value' => 0
    ]
  )
  ->addTrueFalse('show_about_page_link',
    [
      'label' => 'Show About Page Menu link',
      'default_value' => 0
    ]
  )
  ->setLocation('post_type', '==', 'kiosk');

add_action('acf/init', function() use ($branch_id) {
   acf_add_local_field_group($branch_id->build());
});
