<?php
/**
 * Modules Library
 * Modules registed are are inteded to be reused by variable
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;


$modules = new FieldsBuilder('product_modules', [
  'key' => 'group_product_modules',
  'position' => 'acf_after_title',
  'menu_order' => '3',
]);
$modules
  ->addFlexibleContent('modules', [
    'button_label'=> "Add Module",
  ])

  # Product Module
  ->addLayout($intro_module, [
    'name'=> 'intro-module',
  ])

  # Pro Tips
  ->addLayout($protips_module, [
    'name'=> 'protips-module',
  ])

  # Product Module
  ->addLayout($products_module, [
    'name'=> 'products-module',
  ])

  # Competition Module
  ->addLayout($competition_module, [
    'name'=> 'competition-module',
  ])

  # Product Module
  ->addLayout($comparison_table_module, [
    'name'=> 'comparison-table-module',
  ])

  ->setLocation('post_type', '==', 'personal_banking')
           ->or('post_type', '==', 'business_banking')
           ->or('post_type', '==', 'wealth_management');

add_action('acf/init', function() use ($modules) {
   acf_add_local_field_group($modules->build());
});



/**
 * Featured Community Post on Home / Kiosk
 */
$recommended_products = new StoutLogic\AcfBuilder\FieldsBuilder('recommended_products', [
  'key' => 'group_recommended_products',
  'position' => 'normal',
  'menu_order' => '1',
]);
$recommended_products
  ->addMessage('Recommended Products', 'Select 3 recommended products. If no products are selected, 3 products will be automatically selected from within the product type.')
  ->addRelationship('recommended_products',  [
    'post_type' =>  array('personal_banking', 'business_banking', 'wealth_management'),
    'filters' => array('search', '', ''),
    'max'  => 3,
  ])
  ->setLocation('post_type', '==', 'personal_banking')
           ->or('post_type', '==', 'business_banking')
           ->or('post_type', '==', 'wealth_management');

add_action('acf/init', function() use ($recommended_products) {
  acf_add_local_field_group($recommended_products->build());
});
