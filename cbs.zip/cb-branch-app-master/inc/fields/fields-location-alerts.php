<?php
/**
 * Location Alert
 * Location specific alerts
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$location_alert = new StoutLogic\AcfBuilder\FieldsBuilder('location_alert', [
  'menu_order' => '9',
]);

$location_alert
  ->addMessage('Location Alert', 'Create an Alert for this location. Activates the Alert bar on the home and kiosk pages.')
  ->addTextArea('location_alert_text', [
    'wrapper' =>  ['width' => '100%'],
    'rows'    => '3',
  ])
  ->setLocation('post_type', '==', 'kiosk');

add_action('acf/init', function() use ($location_alert) {
   acf_add_local_field_group($location_alert->build());
});
