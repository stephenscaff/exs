<?php
/**
 * CPT ACF
 *
 * Adds a Menu Item for custom post types to add options page fields.
 *
 * @author    Stephen Scaff
 * @package   Jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly


add_action( 'init', 'cpt_index_options_pages', 99 );

function cpt_index_options_pages() {

  if( function_exists('acf_add_options_page') ) { //Check if installed acf

      $cpt_index_pages = get_post_types( array(
          '_builtin' => false,
          'has_archive' => true
      ) ); //get post types

      foreach ( $cpt_index_pages as $cpt ) {

        if( post_type_exists( $cpt ) ) {

          $cpt_name = get_post_type_object( $cpt )->labels->name;

          $cpt_index_page = array(
              'page_title' => ucfirst( $cpt_name ) . ' Index',
              'menu_title' => ucfirst( $cpt_name ) . ' Index',
              'menu_slug' => 'cpt-index-' . $cpt,
              'capability' => 'edit_posts',
              'position' => false,
              'parent_slug' => 'edit.php?post_type=' . $cpt,
              'icon_url' => false,
              'redirect' => false,
              'post_id' => 'cpt_' . $cpt,
              'autoload' => false
          );

          acf_add_options_page( $cpt_index_page );

      } // end if
    }
  } else {
    // Activation Warning
    add_action( 'admin_notices', 'cpt_index_admin_error_notice' );

    function cpt_index_admin_error_notice(){
      // $output = '<section class="admin-alert"><p>Whoops... Better create that post type first.</p></section>';
      //   echo $output;
    }
  }
}



// if ( function_exists( 'acf_add_options_sub_page' ) ){
//   acf_add_options_sub_page(array(
//     'title'      => 'Blog Index',
//     'parent'     => 'edit.php',
//     'capability' => 'manage_options'
//   ));
// }
