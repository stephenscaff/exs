<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Require Composer Autoload for StoutLogic ACF Builder
 * @see https://github.com/StoutLogic/acf-builder
 * @see https://github.com/StoutLogic/acf-builder/wiki
 */
$autoload = get_template_directory().'/vendor/autoload.php';

if (is_file($autoload)) {
  require_once( $autoload);
} else {
  trigger_error("Whoops! Make sure to run `composer install` first, so vendor/autoload.php exists for our ACF Fields Builder. Included in: ", E_USER_WARNING);
  die();
}

# Global Field Variables
require_once('fields-vars.php');
require_once('fields-vars-modules.php');

# Contact Admin Page and Fields
require_once('options-contacts.php');

# CPT Index/Archive Fields
require_once('options-cpt-indexes.php');

# Alerts
require_once('options-alerts.php');

# Alerts Location
require_once('fields-location-alerts.php');

# SEO
require_once('fields-seo.php');

# Subtitles
require_once('fields-subtitle.php');

# Mastheads
require_once('fields-mast.php');

# Featured Videos
require_once('fields-featured-video.php');

# Featured Content Selector
require_once('fields-featured.php');

# Product Items
require_once('fields-product.php');

# Product Items
require_once('fields-product-mast.php');

# Product Pages
require_once('fields-products.php');

# Product CTAs
require_once('fields-product-ctas.php');

# Headings
require_once('fields-headings.php');

# EID
require_once('fields-eloqua-id.php');

# Branch ID
require_once('fields-branch-id.php');

# User Selector
require_once('fields-team-selector.php');

# Wifi Creds
require_once('fields-wifi.php');

# Support Page
require_once('fields-support.php');
