<?php
/**
 *   Eloqua ID
 *   Appears where - Post, Collection
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$eid_field = new StoutLogic\AcfBuilder\FieldsBuilder('eloqua_id', [
  'key' => 'group_eid',
  'position' => 'acf_after_title',
  'menu_order' => '1',
]);;

$eid_field
  ->addfields($product_eid)
  ->setLocation('post_type', '==', 'post')
    ->or('post_type', '==', 'community')
    ->or('post_type', '==', 'resource');

add_action('acf/init', function() use ($eid_field) {
   acf_add_local_field_group($eid_field->build());
});
