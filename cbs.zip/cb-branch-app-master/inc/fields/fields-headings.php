<?php
/**
 * Headings
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Articles Headings on Home
 */
$articles_headings = new StoutLogic\AcfBuilder\FieldsBuilder('articles_heading', [
  'key' => 'group_articles_heading',
  'position' => 'normal',
  'menu_order' => '9',
]);
$articles_headings
  ->addText('articles_heading_title')
  ->addText('articles_heading_text')
  ->setLocation('post_type', '==', 'kiosk')
              ->or('page', '==', get_id_by_name('home'));

add_action('acf/init', function() use ($articles_headings) {
  acf_add_local_field_group($articles_headings->build());
});
