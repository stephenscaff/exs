<?php

if ( ! defined( 'ABSPATH' ) ) exit;

if( function_exists('acf_add_options_page') ) {

 /**
  * Add Admin page for Alerts
  */
 $page_alerts = acf_add_options_page(array(
   'page_title'  => 'Global Alerts',
   'menu_title'  => 'Global Alerts',
   'menu_slug'   => 'alerts',
   'icon_url'    => 'dashicons-info',
   'capability'  => 'edit_posts',
   'position'    =>  '2',
   'redirect'    => false
 ));
}

/**
 * Notice Bar Fields
 */
$alerts_fields = new StoutLogic\AcfBuilder\FieldsBuilder('alerts');
$alerts_fields
->addMessage('', 'Creating a Global Alert to display on the Kiosk Screen. <br/>Note - an alert here will override any Location-specific Alerts.')
  ->addTextArea('alert_text', [
    'label'   => 'Alert Message',
    'wrapper' =>  ['width' => '100%'],
    'rows'    => '3',
  ])
  ->setLocation('options_page', '==', 'alerts');

add_action('acf/init', function() use ($alerts_fields) {
   acf_add_local_field_group($alerts_fields->build());
});
