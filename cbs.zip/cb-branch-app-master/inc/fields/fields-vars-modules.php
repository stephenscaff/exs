<?php
/**
 * Modules Library
 *
 * A lib of modules saved to vars for adding to other locations/field groups
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Featured Content Module
 *
 * @see partials/modules/featured-content-module.php
 * @see scss/components/ft-cards.scss
 */
$featured_content_module = new FieldsBuilder('featured_content_module');
$featured_content_module
  ->addMessage('', 'The Featured Content Module allows you to select various content types to display as cards. You can search for a title or filter with the selects.')
  ->addRelationship('post_selector',  [
   'post_type' =>  array('community', 'resource'),
   'min' => 0,
   'max' => 1,
   //'filters' => array('search', 'testimonai', 'audience'),
 ]);

/**
 * Intro Module
 * A simple intro section.
 *
 * @see scss/_intros.scss
 */
$intro_module = new FieldsBuilder('intro_module');
$intro_module
  ->addMessage('', 'The intro Module creates an introductory section for the page.')
  ->addFields($title_field)
  ->addFields($content_field);
 //  ->addRelationship('product_select',  [
 //   'post_type' =>  array('product'),
 //   'filters' => array('search', '', ''),
 // ]);


/**
 * Protips Module
 * Creates a carousel of 'ProTips', consisting of an svg icon and text region.
 * @see scss/components/_protips
 */
$protips_module = new FieldsBuilder('protips_module');
$protips_module
  ->addMessage('', 'The Pro Tips Module allows you to add pro tips for the banker, featuring an icon selector and text region..')
  ->addRepeater('protips', [
    'button_label' => 'Add Protip',
    'layout' => 'table',
  ])
    ->addFields($icon_select)
    ->addFields($content_field)
  ->endRepeater();

/**
 * Products Module
 * A post object selector for our "Product" post type.
 * Part of the Product Type Pages and "Cart" feature
 *
 * @see inc/partials/modules/products-module.php
 * @see inc/cart/*
 */
$products_module = new FieldsBuilder('products_module');
$products_module
  ->addMessage('', 'The Products Module enables you to select Products to show.')
  ->addRelationship('product_select',  [
   'post_type' =>  'product',
   'filters' => array('search', '', ''),
 ]);

 /**
  * Comparison Table Module
  * Table builder for the Comparison Table
  *
  * @see inc/acf-table-builder
  * @see partials/modules/comparison-table-module.php
  */
 $comparison_table_module = new FieldsBuilder('comparison_table_module');
 $comparison_table_module
   ->addMessage('', 'The Comparison Table Module provides a table builder to construct high level product compairsons.
   Add / Remove rows and columns with the (+) and (-) buttons.
   You can create checkmarks by adding "++" in the relevant cell.')
   ->addField('comparison_table', 'table', [
     'use_header' => '1',
   ])
   ->addTrueFalse('is_text_table', [
     'message' => 'Does this table use text instead of checks?',
   ])
   ->addTextArea('comparison_table_disclaimer',  [
     'rows' =>  '5',
     'new_lines'	 => 'br',
   ])
     ->conditional('is_text_table', '==', '1');;

/**
* Competition Module
* Fields for the competition module that provides
* linking to competitor banks similar products.
* The Select will be used to add competitor logos as pngs within 'assets/images/competition/*'
*
* @see partials/modules/competition-module.php
*/
$competition_module = new FieldsBuilder('competition_module');
$competition_module
 ->addMessage('', 'The Competition Module enables you to provide links to comparitive products.')
 ->addRepeater('competition_banks', [
   'button_label' => 'Add Competition Link',
   'layout' => 'table',
 ])
 ->addSelect('competition_select',  [
   'placeholder' => 'Select Competition Bank ',
   'return_format'	=> 'value',
 ])
  ->addChoice('boa', 'Bank of America')
  ->addChoice('becu', 'Becu')
  ->addChoice('chase', 'Chase')
  ->addChoice('homestreet', 'Homestreet')
  ->addChoice('keybank', 'Key')
  ->addChoice('umpqua', 'Umpqua')
  ->addChoice('usaa', 'USAA')
  ->addChoice('wafd', 'Washington Federal')
  ->addChoice('wellsfargo', 'Wells Fargo')
->addUrl('competition_url');

/**
* Product CTAs Module
* Repeater for constructing the 2x2 Product CTA blocks.
*
* @see partials/modules/product-module.php
*/
$product_ctas_module = new FieldsBuilder('product_ctas_module');
$product_ctas_module
 ->addMessage('', 'The Products CTA Module allows you to create CTA blocks for advertising the Banks Main Product Pa .')
 ->addRepeater('ctas', [
   'button_label' => 'Add CTA',
   'layout' => 'block',
 ])
 ->addPageLink('cta_link', [])
 ->addText('cta_title')
 ->addImage('cta_image')
 ->endRepeater();


 /**
 * Card Carousel Module
 * Post object selector for building a card carousel.
 */
 $card_carousel_module = new FieldsBuilder('card_carousel_module');
 $card_carousel_module
  ->addMessage('', 'The Card Carousel Module call the card carousel to display latest posts from the Community and or Resources Post Type')
  ->addSelect('post_type_select',  [
    'placeholder' => 'Select A ',
    'multiple' => 1,
    'return_format'	=> 'value',
  ])
  ->addChoice('community', 'Community')
  ->addChoice('resource', 'Resources');



/**
 * FAQ Module
 * Creates an FAQ Section
 *
 * @see scss/components/_faq-cards
 * @see partials/modules/faq-module.php
 */
$faq_module = new FieldsBuilder('faq_module');
$faq_module
  ->addMessage('', 'The Faq Module allows you to create a Question and Answer section.')
  ->addRepeater('faqs', [
    'button_label' => 'Add Faq Item',
    'layout' => 'block',
  ])
   ->addText('question')
   ->addWysiwyg('answer', [
     'media_upload' => 0,
   ])
  ->endRepeater();

/**
 * Contacts Module
 * Creates an FAQ Section
 *
 * @see scss/components/_contact-cards.scss
 * @see partials/modules/contacts-module.php
 */
$contacts_module = new FieldsBuilder('contacts_module');
$contacts_module
  ->addMessage('', 'The Contacts Module provides a repeater for adding various contact info blocks.')
  # Contacts Repeater
  ->addRepeater('contacts', [
    'button_label' => 'Add Contact Block',
    'layout' => 'block',
  ])
    # Title
    ->addText('title')
    # Phone Numbers repeater
    ->addRepeater('phones', [
     'button_label' => 'Add Additional Phone',
     'layout' => 'block',
     'min'    => '1'
    ])
      ->addText('phone')
    ->endRepeater()
    # Email
    ->addText('email')
    # Hours
    ->addTextArea('hours',  [
     'rows' =>  '2',
     'new_lines'	 => 'br',
    ])
    # Additional Notes
    ->addTextArea('notes',  [
     'rows' =>  '2',
     'new_lines'	 => 'br',
    ])
    # Optional Alert
    ->addTextArea('alert',  [
     'rows' =>  '2'
    ])
  ->endRepeater();


/**
 * Content Module
 * Creates an content / wysi section
 * @see scss/components/_content (post-content)
 */
$content_module = new FieldsBuilder('content_module');
$content_module
  ->addMessage('', 'The Content Module creates an all purpose content/wysi region.')
   ->addWysiwyg('content');
