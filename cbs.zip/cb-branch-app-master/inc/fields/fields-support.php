<?php
/**
 * Modules Library
 * Modules registed are are inteded to be reused by variable
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;


$modules = new FieldsBuilder('support_modules', [
  'key' => 'group_support_modules',
  'position' => 'acf_after_title',
  'menu_order' => '3',
]);
$modules
  ->addFlexibleContent('modules', [
    'button_label'=> "Add Module",
  ])

  # Contacts Module
  ->addLayout($contacts_module, [
    'name'=> 'contacts-module',
  ])

  # FAQ Module
  ->addLayout($faq_module, [
    'name'=> 'faq-module',
  ])

  # General Content
  ->addLayout($content_module, [
    'name'=> 'content-module',
  ])

  ->setLocation('page', '==', get_id_by_name('support'));

add_action('acf/init', function() use ($modules) {
   acf_add_local_field_group($modules->build());
});
