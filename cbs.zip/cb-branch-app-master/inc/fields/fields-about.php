<?php
/**
 * Modules Library
 * Modules registed are are inteded to be reused by variable
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;


$modules = new FieldsBuilder('about_modules', [
  'key' => 'group_about_modules',
  'position' => 'acf_after_title',
  'menu_order' => '3',
]);
$modules
  ->addFlexibleContent('modules', [
    'button_label'=> "Add Module",
  ])

  # FAQ Module
  ->addLayout($faq_module, [
    'name'=> 'faq-module',
  ])

  # Pro Tips
  ->addLayout($content_module, [
    'name'=> 'content-module',
  ])

  ->setLocation('page', '==', get_id_by_name('about'));

add_action('acf/init', function() use ($modules) {
   acf_add_local_field_group($modules->build());
});
