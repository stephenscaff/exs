<?php
/**
 * Products CTAs
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$product_ctas = new StoutLogic\AcfBuilder\FieldsBuilder('product_ctas', [
 'key' => 'group_product_ctas',
 'position' => 'normal',
 'menu_order' => '8',
]);
$product_ctas
  ->addMessage('', 'Create CTA blocks for advertising the the App\'s main products and pages.')
  ->addRepeater('ctas', [
   'button_label' => 'Add CTA',
   'layout' => 'block',
  ])
  ->addPageLink('cta_link', [
    'wrapper' =>  ['width' => '50%']
  ])
  ->addText('cta_title', [
    'wrapper' =>  ['width' => '50%']
  ])
  ->addImage('cta_image', [
    'wrapper' =>  ['width' => '50%']
  ])
  ->addSelect('cta_color_theme',  [
   'placeholder' => 'Select a Color Theme',
   'default_value' => 'is-dark',
   'wrapper' =>  ['width' => '50%']
  ])
   ->addChoice('is-light', 'Light')
   ->addChoice('is-dark', 'Dark')
  # Locations
    ->setLocation('page', '==', get_id_by_name('home'));

 add_action('acf/init', function() use ($product_ctas) {
    acf_add_local_field_group($product_ctas->build());
 });
