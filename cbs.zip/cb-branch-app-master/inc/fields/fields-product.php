<?php
/**
 * Fields: Product
 * Fields relating to the Product post type.
 *
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$product_fields = new StoutLogic\AcfBuilder\FieldsBuilder('product', [
  'key' => 'group__product',
  'position' => 'acf_after_title',
  'menu_order' => '1',
]);;

$product_fields
  ->addMessage('Product Meta Info', '')
  ->addFields($product_eid)
  ->addMessage('Product Details', '')

  # Product Overview
  ->addTextArea('product_overview',  [
    'rows' =>  '4'
  ])
  ->addMessage('Product Table or Content', 'Provide either a product table or product content region. Not both. Seriously.')
  # Product Comparison Table
  ->addRepeater('product_table', [
    'button_label' => 'Add Row',
    'layout' => 'table',
    'min'    => 0
  ])
    ->addText('title')
    ->addWysiwyg('description',  [
      'media_upload'	 => '0',
      'tabs' => 'text',
    ])
  ->endRepeater()
  # Product Table Disclaimer
  ->addMessage('Product Table Disclaimer', 'Provide disclaimer text if needed.')
  ->addTextArea('product_table_disclaimer',  [
    'rows' =>  '5',
    'new_lines'	 => 'br',
  ])
  ->addTextArea('product_content', [
    'rows' => '7',
    'new_lines' => 'wpautop'
    ])
  # Product Files Repeater
  ->addMessage('Product Files', 'Upload optional Product Brochures / Files')
  ->addRepeater('product_files', [
    'button_label' => 'Add Row',
    'layout' => 'block',
  ])
    ->addFile('file')
  ->endRepeater()
  ->setLocation('post_type', '==', 'product');

add_action('acf/init', function() use ($product_fields) {
   acf_add_local_field_group($product_fields->build());
});
