<?php
/**
 * Fields - SEO
 * Location: all pages, posts and post types
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$wifi_fields = new StoutLogic\AcfBuilder\FieldsBuilder('wifi', [
  'key' => 'wifi',
  'position' => 'normal',
  'menu_order' => '4',
]);

$wifi_fields
  ->addMessage('Wifi', 'Provide the network name and daily password')
  ->addText('wifi_name', [
    'wrapper' =>  ['width' => '50%']
  ])
  ->addText('wifi_pass', [
    'wrapper' =>  ['width' => '50%']
  ])
  ->setLocation('post_type', '==', 'kiosk');

add_action('acf/init', function() use ($wifi_fields) {
   acf_add_local_field_group($wifi_fields->build());
});
