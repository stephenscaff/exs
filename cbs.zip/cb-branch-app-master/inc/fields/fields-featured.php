<?php
/**
 * Fields: Featured Content Selector
 * A featured post selector, for a featured post block on Home, Kiosk, and CPT archives.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Label Vars
 */
$message_label = "Select a Post to Feature";
$message_text = "If nothing is selected here, the latest or dragged to the top post will be featured.";

/**
 * Featured Community Post on Community
 */
$featured_community = new StoutLogic\AcfBuilder\FieldsBuilder('featured_community', [
  'key' => 'group_featured_community',
  'position' => 'normal',
  'menu_order' => '1',
]);
$featured_community
  ->addMessage($message_label, $message_text)
  ->addRelationship('featured_community_post',  [
   'post_type' =>  array('community'),
   'filters' => array('search', '', ''),
   'max'  => 1,
  ])
  ->setLocation('options_page', '==', 'cpt-acf-community');

add_action('acf/init', function() use ($featured_community) {
  acf_add_local_field_group($featured_community->build());
});

/**
 * Featured Resource Post on Resources
 */
$featured_resource = new StoutLogic\AcfBuilder\FieldsBuilder('featured_resource', [
  'key' => 'group_featured_resource',
  'position' => 'normal',
  'menu_order' => '1',
]);
$featured_resource
  ->addMessage($message_label, $message_text)
  ->addRelationship('featured_resource_post',  [
   'post_type' =>  array('resource'),
   'filters' => array('search', '', ''),
   'max'  => 1,
  ])
  ->setLocation('options_page', '==', 'cpt-acf-resource');

add_action('acf/init', function() use ($featured_resource) {
  acf_add_local_field_group($featured_resource->build());
});


/**
 * Featured Community Post on Home / Kiosk
 */
$featured_home = new StoutLogic\AcfBuilder\FieldsBuilder('featured_home', [
  'key' => 'group_featured_home',
  'position' => 'normal',
  'menu_order' => '1',
]);
$featured_home
  ->addMessage($message_label, $message_text)
  ->addText('featured_home_title')
  ->addText('featured_home_text')
  ->addRelationship('featured_home_post',  [
   'post_type' =>  array('community', 'product'),
   'filters' => array('search', '', ''),
   'max'  => 1,
  ])
  ->setLocation('page', '==', get_id_by_name('home'))
    ->or('post_type', '==', 'kiosk');

add_action('acf/init', function() use ($featured_home) {
  acf_add_local_field_group($featured_home->build());
});
