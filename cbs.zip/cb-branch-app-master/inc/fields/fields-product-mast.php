<?php
/**
 * Product Masts
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$product_mast_fields = new StoutLogic\AcfBuilder\FieldsBuilder('product_mast', [
  'key' => 'group_product_mast',
  'position' => 'acf_after_title',
  'menu_order' => '1',
]);;

$product_mast_fields
  ->addText('product_mast_title')
  ->addTextArea('product_mast_text',  [
    'rows' =>  '3'
  ])
  ->addImage('product_mast_image')
  ->addSelect('product_mast_theme',  [
   'placeholder'   => 'Select a Color Theme',
   'default_value' => 'is-dark',
   'wrapper'       =>  ['width' => '100%']
  ])
   ->addChoice('is-light', 'Light')
   ->addChoice('is-dark', 'Dark')
  ->setLocation('options_page', '==', 'cpt-index-personal_banking')
  ->or('options_page', '==', 'cpt-index-business_banking')
  ->or('options_page', '==', 'cpt-index-wealth_management');

add_action('acf/init', function() use ($product_mast_fields) {
   acf_add_local_field_group($product_mast_fields->build());
});
