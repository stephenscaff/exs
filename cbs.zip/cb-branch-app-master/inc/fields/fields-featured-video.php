<?php
/**
 *  Fields: Featured Video
 *
 *  Adds a Featured Video field, like Featured Images,
 *  intended for plyr.js integration.
 *
 *  Locations: Community Posts, Resource Posts
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$ft_video = new StoutLogic\AcfBuilder\FieldsBuilder('featured_video', [
    'key' => 'group_featured_video',
    'position' => 'acf_after_title',
    'menu_order' => '2',
]);
$ft_video
  ->addMessage('', 'Upload an Mp3 OR provide a Vimeo ID OR Youtube ID')
  ->addFile('featured_video_mp3', [
    'wrapper' =>  ['width' => '33.333%'],
    'label'   =>  'Mp3'
  ])
  ->addText('featured_video_vimeo_id', [
    'wrapper' =>  ['width' => '33.333%'],
    'label'   =>  'Vimeo ID'
  ])
  ->addText('featured_video_youtube_id', [
    'wrapper' =>  ['width' => '33.333%'],
    'label'   =>  'YouTube ID'
  ])
  ->setLocation('post_type', '==', 'work');

add_action('acf/init', function() use ($ft_video) {
   acf_add_local_field_group($ft_video->build());
});
