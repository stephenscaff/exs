<?php

/**
 * Load Cart JS
 *
 * Cart js handles adding and removing products to
 * session['cart'] via ajax calls to our php actions.
 *
 * @see inc/cart/cart.js
 */
add_action('wp_enqueue_scripts', 'cart_js_loader');

function cart_js_loader() {
  if (!is_admin()) {

    wp_register_script( 'cart-js', get_bloginfo('template_directory') . '/inc/cart/cart.js', array( 'jquery' ), '', true );

    wp_localize_script( 'cart-js', 'cart_ajax', admin_url( 'admin-ajax.php' ) );
    wp_enqueue_script( 'cart-js' );
  }
}


add_action('wp_enqueue_scripts', 'cart_js_vars');

function cart_js_vars() {
  if (!is_admin()) {
    wp_localize_script('cart-js', 'siteUrls', array(
      'home' => get_option('siteurl'),
      'thanks' => jumpoff_page_url('thanks')
    ));
  }
}


/**
 * Start Cart Session
 */
add_action('init', 'cart_start_session', 1);

function cart_start_session() {
  if ( !session_id() ) {
    session_start();
  }
}

/**
 * Product Count
 */
function list_count() {
  if(isset($_SESSION['cart'])) {
    echo count($_SESSION['cart']);
  } else {
    echo '0';
  }
}

/**
 * Cart Session debug util
 */
function cart_debug() {
	echo '<pre>';
	if(!empty($_SESSION['cart'])) {
		print_r($_SESSION['cart']);
	} else {
		echo 'Session is empty.';
	}
	echo '</pre>';
}

/**
 * Cart Active Class
 * Return 'is-selected' class to
 * indicate that a product is already in the cart/session
 *
 */
function cart_active_class($id) {
  $active_class = '';
	if (isset($_SESSION['cart'])) {
		if ( in_array($id, $_SESSION['cart']) ) {
			$active_class = 'is-in-cart';
      return $active_class;
		}
	}
}

/**
 * Cart Values
 * Return's id/eids of items current in cart (session);
 * Called via admin-ajax request.
 */
add_action('wp_ajax_cart_values', 'cart_values');
add_action('wp_ajax_nopriv_cart_values', 'cart_values');

function cart_values() {

  $cart_ids = $_SESSION['cart'];
  $items = array();

  if(!empty($cart_ids)) {

    foreach ($cart_ids as $cart_id) {
      $eid = get_field('product_eloqua_id', $cart_id);
      $items[] = $eid;
      echo ',' . $eid;
    }
    exit();
  }
}

/**
 * Cart End Session
 * Helper to end cart session.
 * Called via admin-ajax request on form submit.
 * @see js/components/_cart-submit.js
 */
add_action('wp_ajax_cart_end_session', 'cart_end_session');
add_action('wp_ajax_nopriv_cart_end_session', 'cart_end_session');

function cart_end_session() {

  $cart_ids = $_SESSION['cart'];
  session_destroy();
  exit();
}
