<?php

/**
 * Start Session
 */

if(!session_id()) {
  session_start();
}

if ( isset($_SESSION['cart']) ) {
  echo count($_SESSION['cart']);
  //
  // $cart_ids = $_SESSION['cart'];

  // foreach ($cart_ids as $cart_id) {
  //   echo $cart_id;
  // }
} else {
  echo '0';
}
