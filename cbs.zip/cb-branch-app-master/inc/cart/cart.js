/**
 * Columbia Bank "Cart"
 * Primary js to handle adding and removing products
 * to the 'cart' via ajax calls to the Php "Cart" Session.
 * @author Stephen Scaff
 */
var CBCart = (function($) {

  /**
   * Define obj literal container
   */
  var CBCart = {};

  /**
   * Path to ajax files
   */
  var homeURL = window.location.protocol + "//" + window.location.host + "/";
  var filePath = homeURL + 'cb-branch-app/wp-content/themes/cb-branch-app/inc/cart/';

  /**
   * Fade and Remove Util
   */
  CBCart.fadeRemove = function(el, speed){
    el.fadeOut(speed,function(){
      el.remove();
    })
  };

  /**
   * Add Cart Counter
   * Appends a counter for products in the cart.
   */
  CBCart.addCartCounter = function() {
    var cartNavProduct = $('.js-cart-url');

    cartNavProduct.append('<span class="badge is-raised"><span class="js-cart-count">0</span></span>');
  };

  /**
   * Get Product Total
   * Method to update the cart counter
   */
  CBCart.getProductTotal = function() {
    var counter = $('.js-cart-count'),
        clearAll = $('.js-cart-clear');

    $.ajax({
      type: 'GET',
      url: filePath + 'total.php',
      success: function(data) {
        counter.text(data);
      },
      error: function() {
        log('Dang, the function getProductTotal failed');
      }
    });
  };

  /**
   * Cart Refresh Ids
   * Keeps a running store of current cart items.
   */
  CBCart.refreshProductIds = function() {
    var cartValues = $('.cart_values');
    $.ajax({
        type: 'GET',
        url: cart_ajax,
        data: {
          action: 'cart_values'
        },
        success: function( data ) {
          log(data);
          cartValues.html(data);
        },
        error: function() {
          log('Sorry, the ajax function refreshProductIds failed.');
        }
    });
  };

  /**
   * Add & remove actions for individual products
   * ajax cart is wrapped inside productActions() function
   * cart has 'button' parameter so jQuery object
   * can be passed in and run via $(button).on('click'...)
   * @var {element} button
   */
  CBCart.productActions = function(button) {

    $(button).on('click', function(e) {

      var target        = $(this),
          product       = target.closest('.js-product'),
          productID     = product.data('product-id'),
          productEID    = product.data('product-eid'),
          productAction = target.data('action');

      // test bindings
      log("Clicked:", productAction, productID);

      $.ajax({
        type: 'GET',
        url: filePath + 'actions.php',
        data: 'action=' + productAction + '&id=' + productID + '&productEID=' + productEID,
        success: function() {
          CBCart.getProductTotal();
          //cart.refreshProductIds();
        },
        error: function() {
          log('Nah bruv, your productActions funtion has an error');
        }
      });

      if (productAction === 'remove') {
        product.removeClass('is-in-cart');
      } else {
        product.addClass('is-in-cart');

        // Run cart notice
        CBCart.cartNotice();
      }

      e.preventDefault();
    });
  };

  /**
   * Page Actions
   * Remove product from cart.
   */
  CBCart.pageActions = function () {

    var cartPage        = $('.page-cart'),
        cartPageProduct = $('.js-cart-product'),
        removeProduct   = cartPageProduct.find('[data-action]');

    // Remove Product Click Event
    removeProduct.on('click', function(e) {

      var target = $(this),
          productID = target.closest('.js-cart-product').data('product-id');

      $.ajax({
        type: 'GET',
        url: filePath + 'actions.php',
        data: 'action=remove&id=' + productID,
        success: function() {
          CBCart.getProductTotal();
          //cart.refreshProductIds();
          log('removed product ' + productID);
        },
        error: function() {
          log('Nah Bruv, you have an error with the removeProduct action.');
        }
      });

      log('Remove Clicked:', cartPageProduct, removeProduct)

      // Fade and remove the item
      CBCart.fadeRemove(target.closest('.js-cart-product'), 800);

      // Run Qty check
      CBCart.checkCartQty();

      e.preventDefault();
    });
  };


  /**
   * Clear All
   * cart to empty session with clear button on cart page
   */
  CBCart.clearAll = function () {

    var cartClear = $('.js-cart-clear'),
        cartProducts = $('.js-cart-products');

    cartClear.on('click', function(e) {

      $.ajax({
        type: 'GET',
        url: filePath + 'actions.php',
        data: 'action=empty',
        success: function() {
          CBCart.getProductTotal();
          CBCart.fadeRemove(cartProducts, 800);
        },
        error: function() {
          log('error with clearAll action');
        }
      });

      // Run Qty check
      CBCart.checkCartQty();

      e.preventDefault();
    });
  };

  /**
   * Cart Notice
   */
  CBCart.cartNotice = function () {
    var cartNotice = $('.js-cart-notice'),
        noticeTime = 2700;

    cartNotice.addClass('is-active');

    setTimeout(function(){
      cartNotice.removeClass('is-active');
    }, noticeTime);
  };

  /**
   * Check Cart Quantity
   */
  CBCart.checkCartQty = function() {
    var cartTools = $('.cart-tools'),
        cartProducts = $('.js-cart-products'),
        cartProduct = $('.js-cart-product'),
        cartQty = cartProduct.length - 1;

    log('Cart Quantity:', cartQty)

    if (cartQty == 0 ) {
      log('Cart is now empty');
      cartProducts.removeClass('has-products');
      cartProducts.addClass('is-empty');
      cartTools.addClass('is-empty');
    } else {
      cartTools.removeClass('is-empty');
      cartProducts.removeClass('is-empty');
      cartProducts.addClass('has-products');
    }
  };

  // Return Methods
  return CBCart;

}(jQuery)); // end of cart constructor

/**
 * Invoke Methods
 */
(function($){

  // select products, excluding those on cart page
  var action = $('.js-product .action:not(.page-cart .js-cart-product .action)');

  CBCart.addCartCounter();
  CBCart.getProductTotal();
  CBCart.productActions( action );
  CBCart.pageActions();
  CBCart.clearAll();

}(jQuery));


/*
 * log() by Paul Irish stops console.log() breaking Ajax in IE
 * http://paulirish.com/2009/log-a-lightweight-wrapper-for-consolelog/
 */
window.log = function(){
  log.history = log.history || [];   // store logs to an array for reference
  log.history.push(arguments);
  if(this.console){
    console.log( Array.prototype.slice.call(arguments) );
  }
};
