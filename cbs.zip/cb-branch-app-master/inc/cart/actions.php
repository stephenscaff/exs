<?php

/**
 * Cart Actions
 * Control the IDs added / removed from our Cart Session.
 * Actions called by the ajax methods that adds / remove
 * products and cart-items from the "Cart".
 *
 * @see inc/cart/cart.js
 * @see templates/cart.php
 * @see partials/modules/product-module.php
 */


/**
 * Begin Session
 */
if (!session_id()) {
    session_start();
}

/**
 * Define Cart Session array
 */
if ( !isset($_SESSION['cart']) ) {
	$_SESSION['cart'] = array();
}

/**
 * Default Vars
 */
$action = null;
$id = 0;


/**
 * Assign action param if set
 * @var action {action from url}
 */
if ( isset( $_GET['action'] ) && !empty( $_GET['action'] ) ) {
	$action = $_GET['action'];
}

/**
 * Assign product ID param if set
 * @var id {proudct id from url}
 */
if ( isset( $_GET['id'] ) && !empty( $_GET['id'] ) ) {
	$id = $_GET['id'];
}


/**
 * Add / Remove Session Logic
 * Based on $action value, add/remove the $id from session
 */
switch($action) {

	case "add":
    # Add product $id if not already in array
		if ( ($key = array_search($id, $_SESSION['cart']) ) === false ) {
			array_push( $_SESSION['cart'], $id );
		}
	break;

	case "remove":
    # Search for product id by value, remove if found
		if ( ($key = array_search($id, $_SESSION['cart']) ) !== false ) {
		   unset($_SESSION['cart'][$key]);
		}
	break;

	case "empty":
		# Remove All
		unset($_SESSION['cart']);
    $_SESSION['cart'] = array();
	break;

}
