<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

require_once('admin-setup.php');
require_once('admin-ft-image-col.php');
require_once('admin-post-duplicator.php');
