<?php

/**
 *  Admin Dash View
 *
 *
 *  @version    1.0
 *  @see        admin-dash.php
 *  @see        admin/admin-theme/assets (for styles)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

# Wp admin bootstrap
require_once( ABSPATH . 'wp-load.php' );
require_once( ABSPATH . 'wp-admin/admin.php' );
require_once( ABSPATH . 'wp-admin/admin-header.php' );

?>

<section class="dash">

  <header class="dash-header">
    <h1 class="dash-header__title">Welcome to the Columbia Bank Branch App</h1>
    <p class="dash-header__text">From here you can create and manage the font-end experience.</p>
  </header>

  <section class="dash-cards is-halfs">

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo site_url( '' ); ?>" target="_blank">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-open-in-browser"></i>

          <h3 class="dash-card__title">Launch App</h3>

          <p class="dash-card__text">Go to the App's Home Page.</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo site_url( 'kiosk' ); ?>" target="_blank">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-open-in-browser"></i>

          <h3 class="dash-card__title">Launch Kiosk View</h3>

          <p class="dash-card__text">Go to the front-end Kiosk's Home Screen view.</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'post.php?post=89&action=edit' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-tv"></i>

          <h3 class="dash-card__title">Kiosk Home</h3>

          <p class="dash-card__text">Manage Kiosk Home Screen and Today's Bankers</p>
        </div>
      </a>
    </article>


    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=community' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-accessibility"></i>

          <h3 class="dash-card__title">Community</h3>

          <p class="dash-card__text">Manage and create content for the Community content type </p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=resource' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-announcement"></i>

          <h3 class="dash-card__title">Resources</h3>

          <p class="dash-card__text">Create and manage content for the Resources content type</p>
        </div>
      </a>
    </article>


  </section>
</section>
<?php //include( ABSPATH . 'wp-admin/admin-footer.php' );
