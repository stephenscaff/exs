<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Custom Dash
 *
 *  Class to establish a new dash/welcome view
 *
 *  @version    1.0
 */

class CustomDash {

  /**
   * @var string - Name of the banker role
   * @see inc/users where our custom roles are defined.
   */
   const MARKETER = 'marketer';

  /**
   * @var string - Name of the banker role
   * @see inc/users where our custom roles are defined.
   */
   const BANKER = 'banker';

  /**
   * @var WP_User Retrieve the current user object (WP_User).
   */
  public $current_user;

  /**
   * Constructor
   */
  function __construct() {
    # Get current user
    $this->current_user = wp_get_current_user();

    # Register dash page, based on user/role
    add_action('admin_menu', array( $this,'register_page') );

    # New dash redirect logic
    add_action('load-index.php', array( $this,'redirect_dash') );
  }

  /**
   * Redirects to our custom dash at welcome
   */
  function redirect_dash() {

    if( is_admin() ) {
      $screen = get_current_screen();

      if( $screen->base == 'dashboard' ) {
        wp_redirect( admin_url( 'index.php?page=welcome' ) );
      }
    }
  }

  /**
   * Register page based on role.
   */
  function register_page() {

    $role_name = $this->current_user->roles[0];

    if (self::BANKER == $role_name) {
      add_dashboard_page( 'Welcome', 'Welcome', 'read', 'welcome', array( $this, 'dash_view_bankers') );
    }
    elseif (self::MARKETER == $role_name)  {
      add_dashboard_page( 'Welcome', 'Welcome', 'read', 'welcome', array( $this, 'dash_view_marketers') );
    }
    else {
      add_dashboard_page( 'Welcome', 'Welcome', 'read', 'welcome', array( $this, 'dash_view') );
    }
  }

  /**
   * Admin dash view
   */
  function dash_view() {
    require_once('dash-view.php');;
  }

  /**
   * Marketers Dash View
   */
  function dash_view_marketers() {
    require_once('dash-view-marketers.php');;
  }

  /**
   * Banker Dash View
   */
  function dash_view_bankers() {
    require_once('dash-view-bankers.php');;
  }
}

# Init our custom dash
new CustomDash;
