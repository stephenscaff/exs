<?php

/**
 *  Admin Dash View
 *
 *
 *  @version    1.0
 *  @see        admin-dash.php
 *  @see        admin/admin-theme/assets (for styles)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

# Wp admin bootstrap
require_once( ABSPATH . 'wp-load.php' );
require_once( ABSPATH . 'wp-admin/admin.php' );
require_once( ABSPATH . 'wp-admin/admin-header.php' );

?>

<section class="dash">

  <header class="dash-header">
    <h1 class="dash-header__title">Welcome to the Columbia Bank Branch App</h1>
    <p class="dash-header__text">From here you can create and manage the font-end experience.</p>
  </header>

  <section class="dash-cards">

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo site_url( '' ); ?>" target="_blank">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-open-in-browser"></i>

          <h3 class="dash-card__title">Launch App</h3>

          <p class="dash-card__text">Go to the App's Home Page.</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'post.php?post=6&action=edit' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-home"></i>

          <h3 class="dash-card__title">Home</h3>

          <p class="dash-card__text">Manage Home Screen Content</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'post.php?post=89&action=edit' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-tv"></i>

          <h3 class="dash-card__title">Kiosk Home</h3>

          <p class="dash-card__text">Manage Kiosk Home Screen and Today's Bankers</p>
        </div>
      </a>
    </article>


    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=product' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-note-add"></i>

          <h3 class="dash-card__title">Products</h3>

          <p class="dash-card__text">Create and manage CB Products</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=personal_banking' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-users"></i>

          <h3 class="dash-card__title">Personal Banking</h3>

          <p class="dash-card__text">Create and edit personal banking product pages</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=business_banking' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-card-travel"></i>

          <h3 class="dash-card__title">Buisness Banking</h3>

          <p class="dash-card__text">Create and edit Business Banking product pages</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=wealth_management' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-institution"></i>

          <h3 class="dash-card__title">Wealth Management</h3>

          <p class="dash-card__text">Create and edit Wealth Management product pages</p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=community' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-accessibility"></i>

          <h3 class="dash-card__title">Community</h3>

          <p class="dash-card__text">Edit global links, contacts, socials, etc. </p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php?post_type=resource' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-announcement"></i>

          <h3 class="dash-card__title">Resources</h3>

          <p class="dash-card__text">Create and manage Resource Articles</p>
        </div>
      </a>
    </article>

  </section>
</section>
<?php //include( ABSPATH . 'wp-admin/admin-footer.php' );
