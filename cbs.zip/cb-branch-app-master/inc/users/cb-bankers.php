<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 * Columbia Bank User Roles
 * CB Marketing / CB Banker
 */
class CBBankers extends CBUsers {

  /**
   * Role Name
   * @var string from current_user
   */
  public $role_name;

  /**
   * Branch Team (Bankers)
   * @var string CB Banker role
   */
  const BANKER_USER = 'banker';
  const BANKER_NAME = 'CB Banker';

  /**
   * Constructor
   */
  function __construct() {
    parent::__construct();
    $this->create_banker();
    add_action( 'admin_menu', array( $this, 'remove_menu_items') );
    add_filter( 'parse_query', array( $this, 'kiosk_page_only') );
    add_filter('admin_body_class', array( $this, 'role_to_body') );
  }

  /**
   * Create Banker Role
   *
   * Remove Role first to ensure all add_role capabilities get
   * added due to how the function stores in the db.
   * Note the custom 'products' capabilities.
   */
  function create_banker() {

    remove_role(self::BANKER_USER);
    add_role(self::BANKER_USER, self::BANKER_NAME, array(
      'read'                    => true,
      'upload_files'            => true,
      'publish_pages'           => true,
      'read_pages'              => true,
      'edit_pages'              => true,
      'edit_others_pages'       => true,
      'edit_published_pages'    => true,
      'delete_pages'            => true,
      'delete_others_pages'     => true,
      'delete_published_pages'  => true,
      'delete_private_pages	'   => true,
      'publish_posts'           => true,
      'edit_posts'              => true,
      'edit_posts'              => true,
      'edit_others_posts'       => true,
      'edit_published_posts'    => true,
      'delete_posts'            => true,
      'delete_others_posts'     => true,
      'delete_published_posts'  => true,
      'delete_private_posts	'   => true,
      'read_private_posts	'     => true,
    ));
  }

  /**
   * Remove Menu Items
   */
  function remove_menu_items() {
    $role_name = $this->current_user->roles[0];
    if ( self::BANKER_USER == $role_name ) {
      remove_menu_page( 'edit.php?post_type=product' );
      remove_menu_page( 'edit.php?post_type=personal_banking' );
      remove_menu_page( 'edit.php?post_type=business_banking' );
      remove_menu_page( 'edit.php?post_type=wealth_management' );
      remove_menu_page( 'plugins.php' );
      remove_menu_page( 'tools.php' );
      remove_menu_page( 'edit.php?post_type=acf-field-group' );
      remove_menu_page( 'themes.php' );
      remove_menu_page( 'edit-comments.php' );
    }
  }

  /**
   * Kiosk View
   */
  function kiosk_page_only($query) {
    global $pagenow, $post_type;

    $kisok_id = get_id_by_name('Kiosk');
    if ( self::BANKER_USER == $this->role_name && $pagenow == 'edit.php' && $post_type == 'page' ) {
      $query->query_vars['post__in'] = array( $kisok_id );
    }
  }


  // Add role class to body
  function role_to_body($classes) {

    global $current_user;
    $user_role = array_shift($current_user->roles);

    $classes .= ' role-'. $user_role;
    return $classes;
  }
}


if (class_exists('CBUsers')) {
  new CBBankers;
}
