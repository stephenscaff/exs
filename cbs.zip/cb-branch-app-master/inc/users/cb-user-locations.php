<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Columbia Bank User Locations
 * Creates a location tax users
 */
class CBLocations {

  public static $instance;

  public static function init() {
   if ( is_null( self::$instance ) )
     self::$instance = new CBLocations();
   return self::$instance;
  }

  /**
   * Constructor
   */
  private function __construct() {
    add_action('init', array($this, 'register'));
    add_action('admin_menu', array($this, 'menu'));
    add_action( 'show_user_profile', array($this, 'render_selector'));
    add_action( 'edit_user_profile', array($this, 'render_selector'));
    add_action( 'personal_options_update', array($this, 'save'));
    add_action( 'edit_user_profile_update', array($this, 'save'));
    add_action( 'created_term', array($this, 'create_kiosk'), 10, 2);
    //add_action( 'edit_terms', array($this, 'create_kiosk'));
  }

  /**
   * Register
   */
  function register() {
    $tax  = 'location';
    $type = array('user', 'community');
    $labels = jumpoff_post_type_labels('Location', 'Locations');
    $args = [
        'description'        => 'User Locations',
        'labels'             => $labels,
        'hierarchical'        => true,
        'show_ui'             => true,
        'show_admin_column'   => true,
        'show_in_quick_edit'  => true,
        'rewrite'            => array('slug' => 'users/locations', 'with_front' => false),
        'capabilities'       => array(
             'manage_terms'  => 'edit_users', // Using 'edit_users' cap to keep this simple.
             'edit_terms'    => 'edit_users',
             'delete_terms'  => 'edit_users',
             'assign_terms'  => 'read',
  			),
    ];
    register_taxonomy( $tax, $type, $args);
  }


  /**
   * Menu
   */
  function menu() {
    $tax = get_taxonomy( 'location' );

  	add_users_page(
  		esc_attr( $tax->labels->menu_name ),
  		esc_attr( $tax->labels->menu_name ),
  		$tax->cap->manage_terms,
  		'edit-tags.php?taxonomy=' . $tax->name
  	);
  }

  /**
   * Create Term Selector
   */
  function render_selector($user) {

    $tax = get_taxonomy( 'location' );

  	if ( !current_user_can( $tax->cap->assign_terms ) ) return;

  	$terms = get_terms( 'location', array( 'hide_empty' => false ) ); ?>

  	<h3>Location</h3>
  	<table class="form-table">
      <tr>
        <th><label for="location">Select Location</label></th>
  			<td>
        <?php
  			if ( !empty( $terms ) ) :
          foreach ( $terms as $term ) : ?>
  					<input
              type="radio"
              name="location"
              id="location-<?php echo esc_attr( $term->slug ); ?>"
              value="<?php echo esc_attr( $term->slug ); ?>"
              <?php checked( true, is_object_in_term( $user->ID, 'location', $term ) ); ?>
            />
            <label for="location-<?php echo esc_attr( $term->slug ); ?>"><?php echo $term->name; ?></label>
            <br />
  		 <?php
        endforeach;
      endif; ?>
          </td>
  		  </tr>
      </table><?php
  }

  /**
   * Save Location Selections
   */
  function save($user_id) {
    $tax = get_taxonomy( 'location' );

    if ( !current_user_can( 'edit_user', $user_id )
        && current_user_can( $tax->cap->assign_terms ) ) return false;

    $term = esc_attr( $_POST['location'] );

    // Sets the terms (we're just using a single term) for the user
    wp_set_object_terms( $user_id, array( $term ), 'location', false);

    clean_object_term_cache( $user_id, 'location' );
  }

  /**
   * Create Kiosk Admin Page
   * Create Kiosk page from added locations
   */
  function create_kiosk($term_id, $tt_id) {
    $term = get_term( $term_id);

    if ($_POST['taxonomy'] == 'location') {
      $kiosk_post = array(
        'post_title'    => $term->name,
        'post_type'     => 'kiosk',
        'post_status'   => 'publish',
      );

      wp_insert_post( $kiosk_post );
    }
  }
}

CBLocations::init();

// add_action( 'created_term',  'wpse_updated_post_tag', 10, 2 );
//
// /**
//  * @param int      $term_id    Term ID
//  * @param int      $tt_id       Taxonomy ID
//  */
// function wpse_updated_post_tag( $term_id, $tt_id) {
//   //$term_id = esc_attr( $_POST['tag_ID'] );
//   $term = get_term( $term_id);
//
//   if ($_POST['taxonomy'] == 'location') {
//     $kiosk_post = array(
//       'post_title'    => $term->name,
//       'post_type'     => 'kiosk',
//       'post_status'   => 'publish',
//     );
//
//     wp_insert_post( $kiosk_post );
//   }
// }
