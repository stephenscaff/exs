<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Alter Author Permalink
 * Edit the author url strutre to better accomidate
 * our Bankers/Users.
 */
add_action('init','cb_author_permalinks');

function cb_author_permalinks() {
  global $wp_rewrite;
  $URL_BASE = 'team';

  $wp_rewrite->author_base = $URL_BASE;
  $wp_rewrite->author_structure = '/' . $wp_rewrite->author_base. '/%author%';
}
