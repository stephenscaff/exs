<?php

if ( ! defined( 'ABSPATH' ) ) exit;

# Create Custom CB Users
require_once('cb-users.php');
require_once('cb-bankers.php');
require_once('cb-marketers.php');
require_once('cb-user-locations.php');

# User funcitons / helpers
require_once('user-functions.php');

# User Fields and Cleanup
require_once('user-fields.php');

# User / Author Page routing
require_once('user-routing.php');
