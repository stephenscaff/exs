<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 *  Get Current User Image Src
 *  Returns image path for current user's avatar field
 *  @return string Image src
 */
 function get_user_avatar_src() {
   global $current_user;
   $user_id = get_current_user_id();
   $user_avatar = get_user_meta($user_id, 'user_avatar', true);
   $user_avatar_src = wp_get_attachment_image_src($user_avatar)[0];

   $fallback_avatar = '/avatars/avatar-fallback.jpg';
   $fallback_avatar_src = get_bloginfo('template_directory') . '/assets/images' . $fallback_avatar;
   $src = "";

   // If we have a logged in user
   if ($user_id = !0 && $user_avatar_src) {
     $src =   $user_avatar_src;
   } else {
     $src = $fallback_avatar_src;
   }

   return $src;
 }

/**
 * Get User Avatar Eloqua SRC
 * Checks for Eloqua avatar, then normal avatar
 * @return string Image src
 */
 function get_user_avatar_eloqua_src() {
   global $current_user;
   $user_id = get_current_user_id();
   $user_avatar_eloqua = get_user_meta($user_id, 'user_avatar_eloqua', true);
   $user_avatar_eloqua_src = wp_get_attachment_image_src($user_avatar_eloqua)[0];
   $user_avatar_src = get_user_avatar_src();

   $src = "";

   // If we have a logged in user
   if ($user_avatar_eloqua) {
     $src = $user_avatar_eloqua_src;
   } else {
     $src = $user_avatar_src;
   }

   return $src;
 }



/**
 * Get UA Branch name
 * Gets Branch ID and maps it to the Branch name.
 * Leveraged by get_location_kiosk_obj()
 * to obtain branch related fields without logged in user.
 *
 * @return string Branch Name
 * @example Kiosk UA: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.82 Safari/537.36; SiteKiosk 9.6 Build 4572; BranchID=1188
 */
 function get_ua_branch_name() {

   $ua_array = explode(";", $_SERVER['HTTP_USER_AGENT']);

   $ua_branch_id = end($ua_array);

   if (strpos($ua_branch_id, 'BranchID') !== false) {

     switch (true){
       case strpos($ua_branch_id, '1188'):
        return 'Bellevue';
        break;
       case strpos($ua_branch_id, '1187'):
        return 'Ballard';
        break;
       default:
        return 'Ballard';
      }
   }
 }

 /**
  * Get Location Kiosk Object Helper
  * Returns an object with location info that's used to get Branch content
  * that's authored from the Branch's Kiosk Post Type page.
  * When creating a User Location term, a Kiosk POst Type page of that same name is created.
  * Branches can then author thier Kisok related info there.
  *
  * This helper uses get_page_by_title() to get the proper field id by matching the Branch Name,
  * either by logged in user (via user location term), or Kiosk User Agent.
  *
  * 1. If on Kiosk, get kiosk branch info/id and use that to complete get_page_by_title()
  * 2. If not Kiosk and has terms location, get that slug and use it to get_page_by_title()
  *
  * @return obj
  *         id - page id,
  *         name - lowecase post name,
  *         title - friendly post Title
  * @see 'inc/users/cb-user-locations.php' for user location term stuff.
  */
 function get_location_kiosk_obj() {
   global $current_user;

   $terms = wp_get_post_terms($current_user->ID, 'location');
   $page_obj = get_page_by_title( 'ballard', object, 'kiosk' );

   if (is_kiosk()) {
      $ua_branch = get_ua_branch_name();
      $page_obj = get_page_by_title( $ua_branch, object, 'kiosk' );
   }
   elseif ($terms) {
    $page_obj = get_page_by_title( $terms[0]->slug, object, 'kiosk' );
   }

   $obj = array(
     'id' => $page_obj->ID,
     'name' => (string)$page_obj->post_name,
     'title' => (string)$page_obj->post_title
   );
   return (object)$obj;
 }
