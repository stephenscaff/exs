<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Columbia Bank User Roles
 * CB Marketing / CB Banker
 */
class CBUsers {

  /**
   * Current User
   */
  public $current_user;

  /**
   * Admin Role
   * @var string WP's built in Administrator Role
   */
  const ADMIN_USER = 'administrator';

  /**
   * Constructor
   */
  function __construct() {
    $this->current_user = wp_get_current_user();
    $this->remove_roles();
    add_action('admin_init', array($this, 'add_product_caps'), 999);
  }

  /**
   * Remove Roles
   */
  function remove_roles(){
    remove_role('subscriber');
    remove_role('contributor');
    remove_role('author');
  }

  /**
   * Add Product Roles
   * We defined custom caps/access for our Product Post Type
   * and manually add caps to users here.
   * @see inc/post-types/post-type-product.php
   * @link https://developer.wordpress.org/reference/functions/add_role/
   */
  function add_product_caps() {
    global $wp_roles;
    $role = get_role(self::ADMIN_USER);
    $role->add_cap( 'read_product');
    $role->add_cap( 'read_private_products' );
    $role->add_cap( 'edit_product' );
    $role->add_cap( 'edit_products' );
    $role->add_cap( 'edit_others_products' );
    $role->add_cap( 'publish_products' );
    $role->add_cap( 'delete_products' );
  }
}

/**
 * Run and then Comment Out
 * Could hook this into something profile update I guess.
 * But, in the end, you just have to let it run and then remove.
 */
if (class_exists('CBUsers')) {
  new CBUsers;
}
