<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 * Columbia Bank User Roles
 * CB Marketing / CB Banker
 */
class CBMarketers extends CBUsers {

  /**
   * CB Maketers
   * @var string New CB Marketer role
   */
  const MARKETER_USER = 'marketer';
  const MARKETER_NAME = 'CB Marketer';

  /**
   * Constructor
   */
  function __construct() {
    parent::__construct();
    $this->create_marketer();
  }

  /**
   * Create Role
   *
   * Remove Role first to ensure all add_role capabilities get
   * added due to how the function stores in the db.
   * Note the custom 'products' capabilities.
   *
   * @link https://developer.wordpress.org/reference/functions/add_role/
   */
  function create_marketer() {
    remove_role(self::MARKETER_USER);
    add_role(self::MARKETER_USER, self::MARKETER_NAME, array(
      'read'                    => true,
      'create_users'            => true,
      'delete_users'            => true,
      'edit_users'              => true,
      'upload_files'            => true,
      'publish_pages'           => true,
      'edit_pages'              => true,
      'edit_others_pages'       => true,
      'edit_published_pages'    => true,
      'delete_pages'            => true,
      'delete_others_pages'     => true,
      'delete_published_pages'  => true,
      'delete_private_pages	'   => true,
      'read_private_pages'      => true,
      'publish_posts'           => true,
      'edit_posts'              => true,
      'edit_posts'              => true,
      'edit_others_posts'       => true,
      'edit_published_posts'    => true,
      'delete_posts'            => true,
      'delete_others_posts'     => true,
      'delete_published_posts'  => true,
      'delete_private_posts	'   => true,
      'read_private_posts	'     => true,
      'read_product'            => true,
      'read_private_products'   => true,
      'edit_product'            => true,
      'edit_products'           => true,
      'edit_others_products'    => true,
      'publish_products'        => true,
      'delete_products'         => true,
    ));
  }
}

/**
 * Run and then Comment Out
 * Could hook this into something profile update I guess.
 * But, in the end, you just have to let it run and then remove.
 */
if (class_exists('CBUsers')) {
  new CBMarketers;
}
