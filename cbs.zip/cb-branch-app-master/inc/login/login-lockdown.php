<?php

/**
 * Force Login
 */
class LoginLockDown {

  /**
   * Constructor
   */
  function __construct() {
    add_action( 'template_redirect', array( $this, 'force_login' ) );
    add_filter( 'auth_cookie_expiration', array ($this, 'autologout_time') );
  }

  /**
   * Get URL of users existing page for redirect back to it after login
   * @return string Url
   */
  function get_url() {
    $url  = isset( $_SERVER['HTTPS'] ) && 'on' === $_SERVER['HTTPS'] ? 'https' : 'http';
    $url .= '://' . $_SERVER['HTTP_HOST'];

    if ( strpos( $_SERVER['HTTP_HOST'], ':' ) === FALSE ) {
      $url .= in_array( $_SERVER['SERVER_PORT'], array('80', '443') ) ? '' : ':' . $_SERVER['SERVER_PORT'];
    }

    $url .= $_SERVER['REQUEST_URI'];
    // if ( preg_replace('/\?.*/', '', $url) != preg_replace('/\?.*/', '', wp_login_url()) ) {  wp_safe_redirect( wp_login_url( $url ), 302 );}

    return $url;
  }

  /**
   * Force Login
   */
  function force_login() {
    # Bail if ajax/cron/cli
    if ( ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ||
         ( defined( 'DOING_CRON' ) && DOING_CRON ) ||
         ( defined( 'WP_CLI' ) && WP_CLI )         ||
         (is_kiosk())     )    {
      return;
    }

    # If user is not logged in
    if ( !is_user_logged_in() ) {
      wp_safe_redirect( wp_login_url(  ), 302 );
      exit;
    }
  }

  /**
   * Extend the autologout time
   * @return YEAR_IN_SECONDS Wp constant
   */
  function autologout_time($expirein) {
    $expirein = YEAR_IN_SECONDS;
    return $expirein;
  }
}

new LoginLockDown;
