<?php
/*
Plugin Name: Advanced Custom Fields: Table Field
Plugin URI: http://www.johannheyne.de/
Description: This free Add-on adds a table field type for the Advanced Custom Fields plugin
Version: 1.2.1
Author: Johann Heyne
Author URI: http://www.johannheyne.de/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/


require_once('class-table-builder.php');
