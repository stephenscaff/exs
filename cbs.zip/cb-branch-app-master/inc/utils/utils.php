<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

# Post Templates
require_once('post-templates.php');

# Product Templates
require_once('product-templates.php');

# Query Filters
require_once('query-filters.php');

# Taxonomies
require_once('taxonomies.php');

# Useful Conditionals and Checks
require_once('conditionals.php');

# Body Class
require_once('body-class.php');

# Debuggers
require_once('debuggers.php');

# Nav Helpers
require_once('nav.php');

# Path Helpers
require_once('paths.php');

# CSS/JS Loader
require_once('styles-scripts.php');

# Formating Helpers
require_once('formating.php');

# Formating Helpers
require_once('post-type-labels.php');
