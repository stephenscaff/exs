<?php

if ( ! defined( 'ABSPATH' ) ) exit;

# Post Templates
require_once('post-templates.php');

# Product Templates
require_once('product-templates.php');

# Query Filters
require_once('query-filters.php');

# Taxonomies
require_once('taxonomies.php');
