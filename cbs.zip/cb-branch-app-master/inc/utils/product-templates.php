<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 * Get Module Field
 * Returns the value of a specific module field from within a loop.

 * @var $module_name string Name of the module
 * @var $module_field string Name of the module's field
 * @return string Field value
 */
function get_module_field($module_name, $module_field) {
  $field = "";
  $modules = get_field("modules");

  if ($modules[0]["acf_fc_layout"] == $module_name) {
    $field = $modules[0][$module_field];
  }

  return $field;
}

/**
 * Get Recommended Title
 * Creates a full product type title by prefixing the post type's
 * first word against the actual post title.
 *
 * @var $name string Post Type Name
 * @return string $title The built full title of the product type post.
 */
function get_full_product_title($name) {
  $title = substr($name, 0, strrpos($name, '_'));
  $title = ucfirst($title) . ' ' . get_the_title();

  return $title;
}
