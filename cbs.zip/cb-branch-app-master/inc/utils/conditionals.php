<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 *  Is Post Type
 *  Conditional to determine if is a specified post type.
 *
 *  @param string $type Post Type Name
 *  @return boolean
 */
function is_post_type( $type ){
  global $wp_query;

  if( $type == get_post_type($wp_query->post->ID)){
    return true;
  }
  return false;
}


// add_action('current_screen', 'get_current_post_type');
//
// function get_current_post_type() {
//   global $current_screen;
//
//   $current_screen = get_current_screen();
//   $current_post_type = $current_screen->post_type;
//
//   return $current_post_type;
//
// }

/**
 * Is Kiosk
 * Conditional to determin if we're on a Kiosk.
 * Uses a custom user agent - SiteKiosk.
 *
 * @return boolean
 */
function is_kiosk() {
  $kiosk = stripos($_SERVER['HTTP_USER_AGENT'], 'SiteKiosk');
  if ($kiosk) {
    return true;
  }
  return false;
}

/**
 * Is Kiosk or Kiosk User
 * Checks if user is actually on kisok via useragent
 * or if is specified user id
 */
function is_kiosk_or_kiosk_user() {
  global $current_user;
  $current_user_id = get_current_user_id();

  if (is_kiosk() OR in_array($current_user_id, array('25'))) {
    return true;
  }
  return false;
}


/**
 * Is Product Parent
 * Conditional to determine if a Product
 * is in the product_cat tax: 'parent'
 *
 * @see inc/post-types/post-type-product
 * @see partials/modules/product-module
 *
 * @return boolean
 */
function is_product_parent() {
  if (has_term('parent', 'product_cat')) {
    return true;
  } return false;
}

/**
 *  Jumpoff IDs
 *  Retrieves IDs to use in calling fields.
 *
 *  @return integar the post id
 *  @example $postidd = jumpoff_ids();
 */
function jumpoff_ids() {
  global $post;
  $page_for_posts = get_option( 'page_for_posts' );
  $post_type_obj = get_queried_object();

  $id="";

  if ( !is_object( $post ) ) {
    return;
  }

  if (is_front_page()) {
     $id = get_option('page_on_front');
  } elseif (is_post_type_archive()){
    //$post_type = get_queried_object();
    $post_type = get_post_type( $post->ID );
    $cpt = $post_type;
    $id = "cpt_$cpt";
  } elseif (is_singular($post_type_obj->post_type)) {
    $id = "cpt_$post_type_obj->post_type";
  } elseif (is_home()){
    $id = 'options';
  } else{
    $id = $post->ID;
  }
  return $id;
}

/**
 * Get id by page name
 * @return integar Page id.
 */
function get_id_by_name($page) {
  $slug = get_page_by_path($page);
  $id = $slug->ID;

  return $id;
}

/**
 * Custom Field Fallback
 * Defines a string fallback for custom fields.
 *
 * @param mixed $field Custom Field
 * @param mixed fallback, probably a string
 * @return mixed Custom field or fallback
 */
function jumpoff_field_fallback ($field, $fallback) {
  $output;

  if ($field) {
    $output = $field;
  } else {
    $output = $fallback;
  }
  return $output;
}
