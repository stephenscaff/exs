
<?php
/**
 * Template for author posts archives.                                                                                                               n
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

$user = get_queried_object();
$user_id = $user->ID;

$user_name = get_the_author_meta('display_name', $user_id);
$user_position = get_the_author_meta('user_position', $user_id);
$user_email = get_the_author_meta('email', $user_id);
$user_linkedin = get_the_author_meta('user_linkedin', $user_id);
$user_phone = get_the_author_meta('user_phone', $user_id);
$user_avatar = get_user_meta($user_id, 'user_avatar', true);
$user_avatar_src = jumpoff_ft_img('full', $user_avatar);
$user_content = get_user_meta($user_id, 'user_content', true);
$user_youtube_id = get_user_meta($user_id, 'user_youtube_id', true);
$user_vimeo_id = get_user_meta($user_id, 'user_vimeo_id', true);
$user_nmls = get_user_meta($user_id, 'user_nmls', true);

?>

<!-- Main -->
<main class="has-header-offset">

  <section class="mast-title">
    <div class="grid">
      <h1 class="mast-title__title">NeighborHub Team</h1>
    </div>
  </section>

  <section class="bio-card">
    <div class="grid">
      <div class="bio-card__bg">

        <header class="bio-card__header">
          <div class="bio-card__media">
            <figure class="bio-card__figure">
              <img class="bio-card__img" src="<?php echo $user_avatar_src; ?>"/>
            </figure>
          </div>
          <div class="bio-card__main">
            <h3 class="bio-card__title"><?php echo $user_name; ?></h3>
            <p class="bio-card__position"><?php echo $user_position; ?></p>
            <div class="bio-card__content"><?php echo wpautop($user_content); ?></div>

            <?php if ($user_nmls) : ?>
              <p class="bio-card__nmls"><strong>NMLS No:</strong> <?php echo $user_nmls; ?></p>
            <?php endif; ?>

            <?php if ($user_linkedin) : ?>
              <a class="bio-card__social" href="http://<?php echo $user_linkedin; ?>"><i class="icon-linkedin"></i> <?php echo $user_linkedin; ?></a>
            <?php endif; ?>

            <?php if ($user_phone || $user_email) : ?>
            <div class="bio-card__contacts">
              <?php if ($user_phone) : ?><a class="bio-card__phone" href="tel:<?php echo $user_phone; ?>"><strong>Ph </strong>  <?php echo $user_phone; ?></a><?php endif; ?>
              <?php if ($user_email) : ?><a class="bio-card__email" href="mailto:<?php echo $user_email; ?>"><strong>Email </strong><?php echo $user_email; ?></a><?php endif; ?>
            </div>
            <?php endif; ?>
          </div>
        </header>
        <?php if ($user_youtube_id) : ?>
        <section class="bio-card__vid">
          <div class="js-plyr" data-type="youtube" data-video-id="<?php echo $user_youtube_id; ?>"></div>
        </section>
        <?php endif; ?>
        <?php if ($user_vimeo_id) : ?>
        <section class="bio-card__vid">
          <div class="js-plyr" data-type="vimeo" data-video-id="<?php echo $user_vimeo_id; ?>"></div>
        </section>
        <?php endif; ?>
    </div>
  </section>

</main>

<!-- Footer  -->
<?php get_footer(); ?>
