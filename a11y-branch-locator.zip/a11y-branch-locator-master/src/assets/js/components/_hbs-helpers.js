/**
 * Handlebars Helpers for scorecards data
 * @author Stephen Scaff
 */
var hbHelpers = (function() {

  return {

    /**
     * Init
     */
    init: function() {
      this.hbHelpers();
    },

    /**
     * Our Global HB Helpers
     */
    hbHelpers: function(){

      /**
       * Debug Helper
       * Logs debug info on object context
       */
      Handlebars.registerHelper('debug', function(optionalValue) {
        console.log('Current Context');
        console.log('====================');
        console.log(this);
      });

      /**
       * Remove HTML
       * Helper to strip out any html in our data response
       * @return {string}
       */
      Handlebars.registerHelper('removeHTML', function(str) {
        var formatedStr = str.replace(/<(?:.|\n)*?>/gm, '');
        return new Handlebars.SafeString(formatedStr);
      });


      /**
       * Region Links
       * Test data's region property to return proper link to
       * Columbia Bank's A11y region page.
       * @return string (url)
       */
     Handlebars.registerHelper('regionLinks', function(str) {

       switch (str) {
        case "Columbia":
            region = 'cr'
            break;
        case "Puget":
            region = 'p'
            break;
        case "Snake":
            region = 'sr'
            break;
        case "Willamette":
            region = 'wr'
            break;
        }

        var url = 'https://columbiabank.com/ada/rates/' + region;

        return new Handlebars.SafeString(url);
     });
    }
  };
})();

hbHelpers.init();
