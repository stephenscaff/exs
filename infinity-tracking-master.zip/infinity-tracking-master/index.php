<?php
/**
 * Silence is golden bruv
 */
