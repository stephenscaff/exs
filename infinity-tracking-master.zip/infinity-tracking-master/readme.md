# Infinity Call Tracking

A simple app to hit the infinity call tracking api and return/save a json file.

Currently, the app is running at [api.greenrubino.com/infinity](http://api.greenrubino.com.php72-37.lan3-1.websitetestlink.com/infinity/tasks/run.php)

### Infinity Service

Infinity API docs can be found at [infinity.co/service/api/](https://www.infinity.co/service/api/)


### Tasks

`tasks/run.php` is what the cron job will hit once a day to make the request and save the file.

The cron format will be something like `0 23 * * http://api.greenrubino.com.php72-37.lan3-1.websitetestlink.com/infinity/tasks/run.php`

### Tests

`tests/run.php` will run a test and, add a json file witin it's directory, and dump the json output.

[See test](http://api.greenrubino.com.php72-37.lan3-1.websitetestlink.com/infinity/tests/run.php)


### inc

`inc/InfinityRequest.php` - Class that makes the actual api request to infinity and passes in the date range.

`inc/CreateFile.php` - A little create file helper

`inc/FormatJson.php` - A simple pretty printer for json tests.


### Files

`files/tracking.json` is the actual output file. Note that this can be easily changed. See params for `inc/CreateFile.php`
