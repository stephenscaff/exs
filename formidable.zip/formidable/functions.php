<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Functions Includes
 * All Origninate from inc/ directory
 */

# Includes: Enqueue
require_once('inc/functions/styles-scripts.php');

# Includes: CleanUp
require_once('inc/functions/cleanup.php');

# Includes: Settings
require_once('inc/functions/settings.php');

# Includes: Theme Support
require_once('inc/functions/theme-support.php');

# Includes: Admin
require_once('inc/functions/admin.php');

# Includes: Globals
require_once('inc/functions/admin-menu-order.php');

# Includes: Editor
require_once('inc/functions/editor.php');

# Includes: Dash
require_once('inc/functions/dash.php');

# Includes: Users
require_once('inc/functions/users.php');

# Includes: Nav
require_once('inc/functions/nav.php');

# Includes: Posts
require_once('inc/functions/posts.php');

# Includes: Categories and Taxonomies
require_once('inc/functions/cats-taxes.php');

# Includes: Pagination
require_once('inc/functions/pagination.php');

# Includes: Image
require_once('inc/functions/images.php');

# Includes: helpers
require_once('inc/functions/helpers.php');

# Includes: Dynamic Classes
require_once('inc/functions/dynamic-classes.php');

# Includes: Custom Post Types (CPTs) & Taxonomies
require_once('inc/post-types/post-types.php');

# ACF Module loader
require_once('inc/functions/modules.php');

# Includes: Post Order Drag & Drop
require_once('inc/functions/post-order/post-order.php');

# Includes: XML Sitemap genny
require_once('inc/functions/xml-sitemap.php');

# Includes: CPT ACF
require_once('inc/functions/cpt-acf.php');

# Includes: Globals
require_once('inc/functions/options-globals.php');

# Includes: Globals
require_once('inc/functions/shortcodes.php');

# Includes: Globals
require_once('inc/functions/theme-glossary/class-themeglossary.php');

# Includes: MD
//require_once('inc/functions/markdown/md.php');
