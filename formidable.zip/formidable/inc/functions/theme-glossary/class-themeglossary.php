<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/*-----------------------------------------------*/
/*  Theme Glossary
/*-----------------------------------------------*/
if (!class_exists('ThemeGlossary')) {
  class ThemeGlossary {

    function __construct() {
      add_action( 'admin_menu', array( $this, 'admin_menu' ) );
    }

    // Add Menu Page
    function admin_menu() {
      add_menu_page(
        'Theme Glossary',     // $page_title
        'Theme Glossary',     // $menu_title
        'manage_options',     // $capability
        'theme-glossary',     // $menu_slug
        array(
          $this,
          'glossary_output'
        ),                    // $function (callback)
        'dashicons-book'      // $icon
      );
    }

    // Include content/output file
    // @see theme-glossary/theme-glossary
    function  glossary_output() {
      require_once (dirname(__FILE__).'/theme-glossary.php');
    }
  }
}

// Init Class
new ThemeGlossary;

?>