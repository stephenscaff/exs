<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Get category by page slug. Used for passing as var in `get_posts args
 *  @example
 *  @example:
 *   if ( is_home() ) {
 *    $slug = null;
 *   } else {
 *    $slug = jumpoff_slug();
 *   }  
 */
function jumpoff_slug() {
  global $post;
  $slug = get_post( $post )->post_name;
  return $slug;
}

/**
 * Echos a list of all avaialable 
 *  @param $taxonomy
 */
function jumpoff_tax_list($taxonomy) {
  
  $terms = get_terms($taxonomy);
  if ($terms) {
    // Loop through available terms
    foreach ( $terms as $term ) {
      $list_item = '<li><a class="post-cats__cat" href="' . get_term_link( $term->term_id ) . '">' . $term->name . '</a></li>';
      echo $list_item;
    }
  }
}

/**
 * jumpoff_taxt()
 * Echos taxonomy links with BEM naming
 *
 *  @see    
 *  @param: $taxonomy     name of taxonomy
 *  @param: $class_name   BEM style class name prefix
 */
function jumpoff_tax($taxonomy, $class_name) {
  
  $terms = get_the_terms( $post->ID, $taxonomy);

  if ($terms) {
    // Loop through available terms
    foreach ( $terms as $term ) {
      $term_link = '<a class="'. $class_name . '__item" href ="'. get_term_link( $term->term_id ) .'">' . $term->name . '</a>';
      echo $term_link;

    }
  }
}

/**
 * Get Single Cat from slug
 * @return $categories (post_name);
 */
function jumpoff_get_cat_slug(){
  // Import global post object
  global $post;
  
  $categories = get_the_category($post->ID);
  
  return $categories[0]->slug;
}

/**
 * Builds category archive links by passing in the Cat Name
 * @example <?php echo jumpoff_get_cat_archive('Category Name') ?>
 */
function jumpoff_get_cat_archive($cat_name){
  // Import global post object
  global $post;
  // Get the ID of a given category
  $category_id = get_cat_ID($cat_name);

  // Get the URL of this category
  $category_link = get_category_link( $category_id  );
  $cat_url = '<a href="'. $category_link .'" title="'.$cat_name.'">'.$catn_ame.'</a>';
  return $cat_url;
}
   
?>