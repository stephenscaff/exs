<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/** 
 *  jumpoff_body_class
 *  Cleans up body classes, then adds custom, based on page or cpt names
 *  @return: $classes (string)
 */ 
function jumpoff_body_class($classes) {
  global $post, $page;

  // Add page name to body class
  if (is_single() || is_page() && !is_front_page()) {
    $classes[] = basename(get_permalink());
  }
  if (is_home() || is_singular('post') || is_post_type_archive( 'post' )) {
    $classes[] = 'blog';
  }

  //Example for CPTs
  if (is_singular('work') || is_post_type_archive( 'work' )) {
    $classes[] = 'work';
  }

  // Remove Classes
  $home_id_class = 'page-id-' . get_option('page_on_front');
  $page_id_class = 'page-id-' . get_the_ID();
  $post_id_class = 'postid-' . get_the_ID();
  $page_template_pagename = 'page-template-' . $post->post_name .'';
  $page_template_name_class = 'page-template-page-' . basename(get_permalink());
  $page_template_name_php = 'page-template-page-' . basename(get_permalink()) . '-php';
  $page_template_page_templates = 'page-template-page-templates' . $post->post_name . '-php';
  
  $remove_classes = array(
    'page-template-default', 
    'page-template', 
    'single-format-standard',
    'page-template-page-templates',
    $home_id_class,
    $page_id_class,
    $post_id_class,
    $page_template_pagename,
    $page_template_name_class,
    $page_template_name_php,
    $page_template_page_templates
 );

 //Add specific classes
 $classes[] = 'ani-fade-in-page';
 $classes = array_diff($classes, $remove_classes);
  return $classes;
}

add_filter('body_class', 'jumpoff_body_class');


/** 
 *  Retrieves IDs to use in calling fields.
 *  @return: $id (the id of the post)
 *  @example: $postidd = jumpoff_get_ids();
 */
function jumpoff_get_ids() {
  global $post;
  $id;
  if (is_post_type_archive('oss')){
    $id = "cpt_oss";
  } elseif (is_post_type_archive('work')){
    $id = "cpt_work";
  } elseif (is_home()){
    $id = get_option('page_for_posts');
  } elseif (is_front_page()) {
    $id = get_option('page_on_front');
  } else{
    $id = get_the_ID();
  }
  return $id;
}



/** 
 *  Perserver BEM naming for banner fields
 */
function jumpoff_banner_text ( $textarea){
  $lines = explode("\n", $textarea);
  
  if ( !empty($lines) ) {
    foreach ( $lines as $line ) {
      echo '<p class="banner__text">'. trim( $line ) .'</p>';
    }
  }
}



?>