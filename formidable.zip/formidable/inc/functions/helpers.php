<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Get author for metas, fallback to just 'Formidable
 * @return $meta_author
 */
function jumpoff_get_author() {
  global $post;
  $author_id=$post->post_author;
  $meta_author = 'formy';
  if (is_singular('post')){
    $meta_author = get_the_author_meta('display_name', $author_id);
  } else {
    $meta_author = 'Formidable';
  }
  return $meta_author;
}

/** 
 *  jumpoff_img()
 *  An image path helper that gets template path of images
 */
function jumpoff_path(){
  $template_path = bloginfo('template_directory');
  $path = $template_path . '/assets';
  echo $path;
}


/**
 * Helper to determine if is a post type
 */
function jumpoff_is_post_type($type){
  global $wp_query;
  if($type == get_post_type($wp_query->post->ID)) return true;
  return false;
}   
