<?php
/**
* Nav Helpers
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
*   Nav Active Class.
*   Adds active class, since we're not using native wp menus
*
*   @param    string $page_name
*   @return   string 'is-active';
*/
function jumpoff_active_class($page_name){
  if (is_page( $page_name ) || is_post_type_archive($page_name)) {
    return 'is-current';
  }
}

/**
*   Gets page link.
*   For use with our custom navigations
*
*   @param    string $page_name
*   @return   string 'is-active';
*   @todo   change echo to return and updates instances accordingly
*/
function jumpoff_page_url($page_name, $cpt=''){
  if ($cpt == true) {
    $page_link = esc_url( get_post_type_archive_link($page_name) );
  } else {
    $page_link = esc_url( get_permalink( get_page_by_title( $page_name ) ) );
  }
  echo $page_link;
}

