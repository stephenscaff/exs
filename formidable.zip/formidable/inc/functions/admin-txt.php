

<style>
.docs{
  background: #fff;
  padding: 2em;
  margin: 1em 0;
  width: 94%;
}

code{
  border: 1px solid #eee;
  background: #fefefe;
  padding: 0.75em 0.5em;
  display: block;
  line-height: 1.8;
}

table{
  min-width: 47%;
  table-layout: fixed;
  text-align: left;
  border: 1px solid #eee;
}
th, td {
  border-bottom: 1px solid #eee;
  padding: 1em;
}

tr:last-child td{
  border-bottom: 0;
}

.pre-offset{
  margin: 3em 0 -1.5em;;
}
i {
  display: inline-block;
  margin-bottom: 1em;
  padding-right: 0.6em;
  font-family: Consolas,Monaco,monospace;
  font-style: normal;
}
.details{
  margin: 2em 0 1em;
}

.sep{
  border: 0;
  margin: 3em 0 4em;
  background-color: #eee;
  width: 100%;
  height: 3px;
}


</style>

<section class="docs">
  <div class="docs__content">
    
  <h1>Theme Glossary</h1>
  <p>Run down of theme specfic stuff</p>

  <hr class="sep"/>
  
  <h3>Quote Shortcode</h3>
  <p><pre><code>[quote]</code></pre></p>
  <p class="details">Creates blockquotes with options .</p> 

  <h4>OPTIONS</h4>
  <table>
    <tr>
      <th>Option</th>
      <th>Description</th>
      <th>Value(s)</th>
    </tr>
    <tr>
      <td><strong>class</strong></td>
      <td>Outputs Class Names</td>
      <td><i>null</i>             Default bq styles, left aligned no border. <br/>
          <i>quote-long</i>       For long quotes, has left border. <br/>
          <i>quote-bordered</i>   shorter quotes, has top & bottom border. <br/>
          <i>quote-centered</i>   Centered quotes. <br/>
        </td>
    </tr>
    <tr>
      <td><strong>cite</strong></td>
      <td>Adds the author cite</td>
    </tr>
  </table>

  <h5 class="pre-offset">EXAMPLE</h5>
<pre>
  <code>
  [quote class="quote-long"  cite="Carlos Danger"]
  </code>
</pre>
        
  
<hr class="sep"/>


<h3>Markdown</h3>
<p>Posts can now use Github-flavored Markdown (with Extras, so stardard html will still work). </p>

<a href="http://hoducha.com/markdown-guide.html" target="_blank">MD Quick Reference</a>
<br/><br/>
<h5>HIGHLIGHTING</h5>
<p>To init syntax highlighting, just add the language name at the end of the md code block.</p>
      <pre><code>```jsx 
      Your Dope Code
```</code></pre>
  <p>Note: you no longer have to wrap code in a div, so don't.</p>
  
  <br/>
  <h4>Current Supported Langs</h4>
  <ul>
    <li>javascript</li>
    <li>jsx</li>
    <li>typescript</li>
    <li>coffeescript</li>
    <li>handlebars</li>
    <li>json</li>
    <li>css</li>
    <li>sass</li>
    <li>scss</li>
    <li>clike</li>
    <li>markup</li>
    <li>git</li>
    <li>php</li>
  </ul>
    
    </div>
    </section><!--wrap-->
