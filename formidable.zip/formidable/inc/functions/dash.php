<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


/**
 * Remove Widgets from dash
 */
function jumpoff_disable_default_dashboard_widgets() {
  global $wp_meta_boxes;

  // Right Now Widget
  unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);

  // Activity Widget
  unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_activity']);    

  // Comments Widget
  unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);

  // Incoming Links Widget
  unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);

  // Plugins Widge
  unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);    

  // Quick Press Widget
  unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);   

  // Recent Drafts Widget
  unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']);

  // Primary 
  unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);

  // Secondary
  unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']); 
}

add_action('admin_head', 'jumpoff_disable_default_dashboard_widgets');


/**
 * Add Dash widgets
 */
function jumpoff_add_dashboard_widgets() {
  wp_add_dashboard_widget( 'jumpoff_logo_widget', 'Greetings...', 'jumpoff_logo_widget' );
  wp_add_dashboard_widget( 'jumpoff_theme_glossary_widget', 'Theme Glossary', 'jumpoff_theme_glossary_widget' );
  wp_add_dashboard_widget( 'jumpoff_site_links_widget', 'Front End Pages', 'jumpoff_site_links_widget' );
  wp_add_dashboard_widget( 'jumpoff_admin_widget', 'Admin Management', 'jumpoff_admin_widget' );
  wp_add_dashboard_widget( 'jumpoff_whatsnew_widget', 'New in v1.2', 'jumpoff_whatsnew_widget' );

}

add_action( 'wp_dashboard_setup', 'jumpoff_add_dashboard_widgets' );

/**
 * Add logo to dash
 */
function jumpoff_logo_widget() { ?>
   <article class="widget">
    <img  style="max-width: 70%;" src="<?php jumpoff_imgpath(); ?>/logo-formidable-bnw.png"/>

    <footer class="widget__footer box__footer">
      <h1>Welcome to Formidable.</h1>
      <p>From this admin you can manage most aspects of your site.</p>
    </footer>

   </article>
<?php }

/**
 * Theme Glossary widget
 */
function jumpoff_theme_glossary_widget() { ?>
   <article class="widget box">
    <div class="widget__content box__content">
      <p>For details on available Shortcodes and other theme-oriented docs, check the</p>
      <p><a class="" href="admin.php?page=theme-glossary">Theme Glossary</a></p>
    </div>
    <footer class="widget__footer box__footer"></footer>
   </article>
<?php }

/**
 * Site Links Widget
 */
function jumpoff_site_links_widget() { ?>
   <article class="widget box">
    <div class="widget__content box__content">
      <p><a class="" href="<?php jumpoff_page_url('home') ?>" target="_blank">Visit Homepage→</a></p>
      <p><a class="" href="<?php jumpoff_page_url('blog') ?>" target="_blank">Visit Blog→</a></p>
      <p><a class="" href="<?php jumpoff_page_url('work', 1) ?>" target="_blank">Visit Work→</a></p>
      <p><a class="" href="<?php jumpoff_page_url('oss') ?>" target="_blank">Visit OSS→</a></p>
      <p><a class="" href="<?php jumpoff_page_url('careers') ?>" target="_blank">Visit Careers→</a></p>
      <p><a class="" href="<?php jumpoff_page_url('about') ?>" target="_blank">Visit About→</a></p>
    </div>
    <footer class="widget__footer box__footer"></footer>
   </article>
<?php }

/**
 * Admin Widget
 */
function jumpoff_admin_widget() { ?>
   <article class="widget box">
    <div class="widget__content box__content">
      <p><a class="" href="edit.php">Create a Blog Post</a></p>
      <p><a class="" href="edit.php?post_type=page">Edit a Page / Page Copy</a></p>
      <p><a class="" href="edit.php?post_type=jobs">Manage Jobs</a></p>
      <p><a class="" href="edit.php?post_type=events">Manage Events</a></p>
      <p><a class="" href="edit.php?post_type=work">Manage Projects</a></p>
      <p><a class="" href="edit.php?post_type=oss">Manage OSS</a></p>
      <p><a class="" href="edit.php?post_type=team">Manage Team Members</a></p>
    </div>
    <footer class="widget__footer box__footer"></footer>
   </article>
<?php }


/**
 * What's New Widget
 */
function jumpoff_whatsnew_widget() { ?>
   <article class="widget box">
    <div class="widget__content box__content">
      <h2 style="font-weight: 600; font-size: 1.3em">Markdown</h2>
      <p>Posts can now use Github-flavored Markdown (with Extras, so stardard html will still work). </p>
      <a href="http://hoducha.com/markdown-guide.html" target="_blank">MD Quick Reference</a>
      <p><strong>Highlighting</strong></p>
      <p>To init syntax highlighting, just add the language name at the end of the md code block.</p>
      <pre><code style="background: none;">```jsx 
      Your Dope Code
```</code></pre>
  <p>Note: you no longer have to wrap code in a div, so don't.</p>
      <hr style="margin-top: 2em; margin-bottom: 0.5em"/>
      <h2 style="font-weight: 600; font-size: 1.3em">Team Images</h2>
      <p>You can now add an optional team pic that appears on hover. Note - make sure to follow image size prompts</p>
      <hr style="margin-top: 2em; margin-bottom: 0.5em"/>
      <h2 style="font-weight: 600; font-size: 1.3em">OSS Cats</h2>
      <p>Taxonomy has been added to the OSS post type.</p>
      <a href="http://127.0.0.1/formidable/wp-admin/edit-tags.php?taxonomy=categories&post_type=oss">Manage OSS Categories</a>
    </div>
    <footer class="widget__footer box__footer"></footer>
   </article>
<?php }

?>