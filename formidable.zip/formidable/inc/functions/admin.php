<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Editor: Remove Visual Editor form Admin
 */
//add_filter ( 'user_can_richedit' , create_function ( '$a' , 'return false;' ) , 50 );

/**
 * Remove front end toolbar
 */
add_filter('show_admin_bar', '__return_false');  

/**
 * Remove color picker
 */
remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
remove_action( 'additional_capabilities_display', 'additional_capabilities_display' );


/**
 * Remove via css where no hooks exist
 */
function jumpoff_admin_hides() {
 echo '<style type="text/css">
         .user-comment-shortcuts-wrap,
         .show-admin-bar,
         .user-rich-editing-wrap,
         .user-description-wrap,.user-url-wrap{display:none}
       </style>';
}

add_action('admin_head', 'jumpoff_admin_hides');


/**
 * Remove Admin Bar stuffs
 */
function jumpoff_admin_bar_remove() {
  global $wp_admin_bar;

  $wp_admin_bar->remove_menu('wp-logo');          // Remove the WordPress logo
  $wp_admin_bar->remove_menu('about');            // Remove the about WordPress link
  $wp_admin_bar->remove_menu('wporg');            // Remove the WordPress.org link
  $wp_admin_bar->remove_menu('documentation');    // Remove the WordPress documentation link
  $wp_admin_bar->remove_menu('support-forums');   // Remove the support forums link
  $wp_admin_bar->remove_menu('feedback');         // Remove the feedback link
  //$wp_admin_bar->remove_menu('site-name');        // Remove the site name menu
  $wp_admin_bar->remove_menu('view-site');        // Remove the view site link
  $wp_admin_bar->remove_menu('updates');          // Remove the updates link
  $wp_admin_bar->remove_menu('comments');         // Remove the comments link
  $wp_admin_bar->remove_menu('new-content');      // Remove the content link
  //$wp_admin_bar->remove_menu('my-account'); 
}

add_action('wp_before_admin_bar_render', 'jumpoff_admin_bar_remove', 0);

/**
 * Replace admin footer text
 */
function jumpoff_custom_admin_footer() {
  _e( '<span id="footer-thankyou">Developed by <a href="http://urbaninfluence.com" target="_blank">Urban Influence</a></span>' );
}
// adding it to the admin area
add_filter( 'admin_footer_text', 'jumpoff_custom_admin_footer' );


