<?php
/**
 *  More logical custom menu ordering, 
 *  using custom_menu_order filtering
 * 
 *  @return $menu_order 
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


function jumpoff_menu_order($menu_order) {
  if (!$menu_order) return true;
  
  return array(
    'index.php',                    // Dashboard
    'edit.php?post_type=page',      // Pages
    'edit.php',                     // Posts
    'edit-comments.php',            // Comments
    'edit.php?post_type=work',      // Work
    'edit.php?post_type=oss',       // OSS
    'edit.php?post_type=team',      // Team
    'edit.php?post_type=jobs',      // Jobs
    'edit.php?post_type=events',    // Events
    'globals',                      // Globals (options table)
    'wpcf7',                        // Contact
    'upload.php',                   // Media
    'users.php',                    // Users
    'separator2',                   // Second separator
    'plugins.php',                  // Plugins
    'tools.php',                    // Tools
    'options-general.php',          // Settings
    'themes.php',                   // Appearance
  );
}

add_filter('custom_menu_order', 'jumpoff_menu_order'); // Activate 
add_filter('menu_order', 'jumpoff_menu_order');
