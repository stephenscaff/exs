<?php 
//silence is golder 
?>