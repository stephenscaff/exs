<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Add support for featured images
 */
add_theme_support( 'post-thumbnails' ); 


/**
 * Initially position featured image box
 */

add_action( 'add_meta_boxes', 'jumpoff_add_metaboxes' );

function jumpoff_add_metaboxes(){
  add_meta_box('postimagediv', __('Featured Image'), 'post_thumbnail_meta_box', 'post', 'side', 'high');
}

/**
 * HTML5 Syntax support
 */
add_theme_support( 'html5', array( 'search-form', 'caption' ) );
