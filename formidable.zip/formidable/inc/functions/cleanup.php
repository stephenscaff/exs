<?php

if ( ! defined( 'ABSPATH' ) ) exit; 

/** 
*  Head Clean Up
*  Actions to remove all wp's grimey head stuffs
*  @return: string $classes
*/
function jumpoff_head_cleanup() {
  remove_action('wp_head', 'feed_links', 2);
  remove_action('wp_head', 'feed_links_extra', 3);
  remove_action('wp_head', 'rsd_link');
  remove_action('wp_head', 'wlwmanifest_link');
  //remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
  remove_action('wp_head', 'wp_generator');
  remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0);
  remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
  remove_action( 'wp_print_styles', 'print_emoji_styles' );
}
add_action('init', 'jumpoff_head_cleanup');


/** 
*  Remove Versioning for security
*/
add_filter('the_generator', 'jumpoff_remove_wp_version');

function jumpoff_remove_wp_version() {
  return '';
}

/**
 * Remove versions from css/js
 */
add_filter('style_loader_src', 'jumpoff_remove_cssjs_ver', 1000 );
add_filter('script_loader_src', 'jumpoff_remove_cssjs_ver', 1000 );

function jumpoff_remove_cssjs_ver( $src ) {
  if( strpos( $src, '?ver=' ) ) {
    $src = remove_query_arg( 'ver', $src );
  }
  return $src;
}