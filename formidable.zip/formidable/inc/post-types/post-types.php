<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Flush Rewrites on Theme Switch
 */
add_action( 'after_switch_theme', 'jumpoff_flush_rewrite_rules' );

function jumpoff_flush_rewrite_rules() {
  flush_rewrite_rules();
}

# Featured Taxonomy
//require_once('post-taxonomy-post-functions.php');
# Work
require_once('post-type-work.php');

# OSS
require_once('post-type-oss.php');

#Team
require_once('post-type-team.php');

# Events
require_once('post-type-events.php');

# Jobs
require_once('post-type-jobs.php');

?>