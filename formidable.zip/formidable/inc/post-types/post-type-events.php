<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Events
 *
 *  Our post type for Events. Non hierarchal, so no single view
 *  We're just linking the event listing off site.
 *
 *  @author     Stephen SCaff
 *  @version    1.0
 */
function create_events_post_types() {
  register_post_type( 'events', 

  array(
    'labels'              => array(
    'name'                => __( 'Events' ),
    'singular_name'       => __( 'Event' ),
    'add_new'             => __( 'Add New Event' ),
    'add_new_item'        => __( 'Add New Event' ),
    'edit'                => __( 'Edit Event' ),
    'edit_item'           => __( 'Edit Event' ),
    'new_item'            => __( 'New Event' ),
    'view'                => __( 'View This Event' ),
    'view_item'           => __( 'View This Event' ),
    'search_items'        => __( 'Search Event' ),
    'not_found'           => __( 'Sorry Buddy. That Event is not found' ),
    'not_found_in_trash'  => __( 'That Event is not in the Trash' ),
  ),

  'description'           => __( 'The Team' ),
  'public'                => false,
  'show_ui'               => true,
  'menu_position'         => 8,
  'menu_dashicon'         => 'dashicons-calendar',
  'menu_icon'             => 'dashicons-calendar',
  'query_var'             => true,  
  'hierarchical'          => false,
  //'taxonomies' => array( 'category'),
  'supports'              => array( 'title' ),
  'capability_type'       => 'post',
  'can_export'            => true,
  'has_archive'           => false,
  'rewrite'               => array('slug' => 'about', 'with_front' => false),
  ));
}

# Init Team
add_action('init', 'create_events_post_types');
?>