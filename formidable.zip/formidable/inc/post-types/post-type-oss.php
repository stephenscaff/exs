<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: OSS
 *
 *  Our post type for Formidable's Open Source Projects. 
 *  Non hierarchical, the posts just link off to Githib repos or micro sites.
 *
 *  @author     Stephen Scaff
 *  @version    1.0
 */

function create_oss_post_types() {
  register_post_type( 'oss', 

  array(
    'labels'              => array(
      'name'                => __( 'Open Source' ),
      'singular_name'       => __( 'OSS' ),
      'add_new'             => __( 'Add New OSS Project' ),
      'add_new_item'        => __( 'Add New OSS Project' ),
      'edit'                => __( 'Edit OSS Project' ),
      'edit_item'           => __( 'Edit OSS Project' ),
      'new_item'            => __( 'New OSS Project' ),
      'view'                => __( 'View This OSS Project' ),
      'view_item'           => __( 'View This OSS Project ' ),
      'search_items'        => __( 'Search OSS Projects' ),
      'not_found'           => __( 'Sorry Buddy. That OSS Project is ghost' ),
      'not_found_in_trash'  => __( 'That OSS Project is not in the Trash' ),
    ),

  'description'           => __( 'A collection of Formidable\'\s Open Source projects' ),
  'public'                => true,
  'show_ui'               => true,
  'menu_position'         => 5,
  'menu_dashicon'         => 'dashicons-star-empty',
  'menu_icon'             => 'dashicons-star-empty',
  'query_var'             => true,  
  //'taxonomies' => array( 'category'),
  'supports'              => array( 'title','thumbnail', 'excerpt', 'custom-fields', 'editor' ),
  'capability_type'       => 'post',
  'can_export'            => true,
  'has_archive'           => false,
  'hierarchical'          => true,
  'rewrite'               => array('slug' => 'open-source', 'name' =>'oss', 'with_front' => false),
  ));
}

# Init OSS
add_action('init', 'create_oss_post_types');


/**
 * OOS Taxonomy
 * 
 */
function oss_categories() {
  register_taxonomy(
  'categories',         
  'oss',           
    array(  
      'hierarchical'  => true,
      'labels'        => array(
      'name'          => _x('Categories', 'taxonomy general name'),
      'singular_name' => _x('Category', 'taxonomy singular name'),
      'search_items'  => __('Search Categories'),
      'all_items'     => __('All Categories'),
      'edit_item'     => __('Edit Categories'),
      'update_item'   => __('Update Category'),
      'add_new_item'  => __('Add New Category'),
      'new_item_name' => __('New Category'),
      'menu_name'     => __('Categories'),
    ),
    'rewrite'         => array(
      'slug'          => 'categories', // This controls the base slug that will display before each term
      'with_front'    => false, 
    ),
  ));
}
# Init OSS Cats
add_action( 'init', 'oss_categories');
?>