<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Jobs
 *
 *  Provides a GUI for creating jobs that link off to Lever (or whereve)
 *  Non hierarchical, so no single view. But we can modify if you 
 *  ever want to drop the third party job board.
 *
 *  @version    1.0
 */
function create_jobs_post_types() {
  register_post_type( 'jobs', 

  array(
    'labels'              => array(
    'name'                => __( 'Jobs' ),
    'singular_name'       => __( 'Job' ),
    'add_new'             => __( 'Add New Job' ),
    'add_new_item'        => __( 'Add New Job' ),
    'edit'                => __( 'Edit Jobs' ),
    'edit_item'           => __( 'Edit Job' ),
    'new_item'            => __( 'New Job' ),
    'view'                => __( 'View This Job' ),
    'view_item'           => __( 'View This Job' ),
    'search_items'        => __( 'Search Job' ),
    'not_found'           => __( 'Sorry Buddy. That Job is not found' ),
    'not_found_in_trash'  => __( 'That Job is not in the Trash' ),
  ),

  'description'           => __( 'Formidable Jobs' ),
  'public'                => false,
  'show_ui'               => true,
  'menu_position'         => 7,
  'menu_dashicon'         => 'dashicons-pressthis',
  'menu_icon'             => 'dashicons-pressthis',
  'query_var'             => true,  
  'hierarchical'          => false,
  //'taxonomies'          => array( 'category'),
  'supports'              => array( 'title','custom-fields' ),
  'capability_type'       => 'post',
  'can_export'            => true,
  'has_archive'           => false,
  //'rewrite'             => array('slug' => 'careers', 'with_front' => false),
  ));
}

# Init Jobs
add_action('init', 'create_jobs_post_types');

?>