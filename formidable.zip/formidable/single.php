<?php
/**
* The default template for single blog posts.
*
* @author    Urban Influence
* @package   jumpoff/single
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

?>

<!-- MAIN -->
<main role="main">
<?php while (have_posts()) : the_post(); ?>

<article class="post">

  <!-- Post Heading -->
  <header class="post__heading section--light">
    <time class="post__pretitle"><?php the_time('F j, Y'); ?></time>
  </header>

  <!-- Post Mast -->
  <section class="post-mast">
    <div class="grid">
      <header class="post-mast__header  g-8 ">
        <h1 class="post__title"><?php the_title(); ?></h1>
        <span class="post__meta">Author</span>
        <span class="post__author"><?php the_author_meta('display_name'); ?></span>
        <?php if (get_the_author_meta('twitter')) : ?>
          <a class="post__link" href="http://twitter.com/<?php the_author_meta('twitter'); ?>" target="_blank" rel="external">@<?php the_author_meta('twitter'); ?></a>
        <?php endif; ?>
      </header>
      <hr class="sep sep--full">
    </div>
  </section>

  <!-- Post Main -->
  <section class="post__main post-content">
    <div class="grid">
      <div class="post__col g-7">
        <?php the_content(); ?>

        <!-- Post Cats -->
        <aside class="post-cats">
          <span class="post-cats__title">Posted In : </span>
          <span class="post-cats__item"><?php the_category('</span><span class="post-cats__item">'); ?></span>
          </aside>

        <!-- Post Shares -->
        <aside class="post-shares">
          <span class="post-shares__title">Share</span>
          <a class="post-shares__link" href="http://twitter.com/intent/tweet?text=<?php the_title(); ?>+<?php the_permalink(); ?>">Twitter</a>
          <a class="post-shares__link" href="http://www.facebook.com/share.php?u=<?php the_permalink(); ?>/&amp;title=<?php the_title(); ?>">Facebook</a>
        </aside>
      </div>
    </div>
  </section>

  <!-- Post Footer -->
  <footer class="byline  section--dark">
    <figure class="byline__bg" style="background-image: url(<?php jumpoff_imgpath(); ?>/blog/post-byline-bg.jpg)"></figure>
    <div class="grid  grid--pad">
      <div class="post__col">
        <span class="post__meta">Author</span>
        <span class="post__author"><?php the_author_meta('display_name'); ?></span>
        <?php if (get_the_author_meta('description')) : ?>
          <p class="byline__bio"><?php the_author_meta('description'); ?></p>
        <?php endif; ?>
        <a class="byline__author-link" href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>">View All Journal Entries</a>
      </div>
    </div>
  </footer>
</article>
<?php endwhile; ?>

<?php get_template_part( 'partials/partial', 'next' );?>

</main>


<!-- FOOTER -->    
<?php get_footer(); ?>