<?php
/**
* The default template for single work projects
*
* @author    stephen scaff
* @package   formdiable/single-work
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

$pretitle = get_field('mast_pretitle');
$text = get_field('mast_text');
$theme = get_field('color_theme'); 
?>

<!-- MAIN -->
<main role="main">
<?php while (have_posts()) : the_post(); ?>
<!-- FOLIO -->
<section class="folio <?php if ($theme) : echo $theme; endif; ?>">
  <!-- Heading -->
  <header class="folio__heading  js-clippy">
    <h5 class="folio__pretitle">Case Study: <?php the_title(); ?></h5>
  </header>
  <!-- bg Image -->
  <figure class="oss__bg"  style="background-image: url(<?php jumpoff_ftimg_fallbacks('fullsize') ?>)"></figure>

  <div class="grid">
    <div class="folio__content">
      <span class="folio__preheader"><?php if ($pretitle) : echo $pretitle; endif; ?></span>
      <h2 class="folio__title"><?php the_title(); ?></h2>
      <hr class="folio__sep sep-center sep--white"/>
      <p class="folio__text"><?php if ($text) : echo $text; endif; ?></p>
    </div>
  </div>
</section>

<?php while (has_sub_field('modules')) : ?>
  <?php ACF_Modules::render(get_row_layout()); ?>
<?php endwhile; ?>
  
<?php endwhile; ?>

<!-- Next -->
<?php get_template_part( 'partials/partial', 'next-work' );?>

</main>

<!-- FOOTER -->    
<?php get_footer(); ?>