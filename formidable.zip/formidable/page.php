<?php
/**
 * Default tempalte for pages
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

?>

<main role="main">

<!-- MAST -->
<section class="mast mast--contact section--dark">
  <figure class="mast__bg"></figure>

  <div class="mast__content grid u-align-center">
    <hr class="sep-center sep--white">
    <h2 class="mast__title"><?php the_title(); ?></h2>
  </div>
  <div class="starfield"></div>
</section>

<!-- Post Main -->
<section class="post__main post-content">
  <div class="grid">
    <div class="post__col g-7">
  <?php 
   while (have_posts()) : the_post();
    the_content();
   endwhile; // End content loop ?>
    </div>
  </div>
</section>
</main>

<!-- Footer --> 
<?php get_footer(); ?>