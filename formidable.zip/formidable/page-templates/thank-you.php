<?php
/**
 * Template Name: Thank You
 *  
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

$thank_you_title = get_field('thank_you_title');
$thank_you_text = get_field('thank_you_text'); 
?>

<!-- MAIN -->
<main role="main">

<!-- MAST -->  
<section class="mast mast--thank-you section--dark">
  <div class="mast__bg"></div>

  <header class="mast__heading  js-clippy">
    <h1 class="mast__pretitle">Thank You</h1>
  </header>

   <div class="grid">
    <div class="mast__content">
      <h1 class="mast__title js-letters"><?php echo $thank_you_title; ?></h1>
      <p class="mast__text"><?php echo $thank_you_text; ?></p>
      <hr class="sep">
      <a href="<?php jumpoff_page_url('home') ?>" class="btn btn--dark"><span>Go Home <i class="icon-right"></i></span></a>
    </div>
  </div>

</section>

</main>

<!-- FOOTER --> 
<?php get_footer(); ?>
