<?php
/**
 * Template Name: About
 *  
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

// Vars
$about_intro_title = get_field('about_intro_title');
$about_intro_content = get_field('about_intro_content');
$about_careers_content = get_field('about_careers_content');
$about_careers_link = get_field('about_careers_link');

?>

<!-- MAIN --> 
<main role="main">

<!-- MAST -->
<section class="mast mast--about  section--dark  js-scene">

    <header class="mast__heading  js-clippy">
      <h5 class="mast__pretitle">About Us</h5>
    </header>

    <figure class="mast__bg"></figure>
    
    <div class="grid">
      <div class="mast__content">
        <span class="mast__col">
          As Part Of
        </span>
        <span class="mast__col">
        Ongoing Humanization Efforts,
        </span>
        <span class="mast__col">
        We're Advised to Say—
        </span>
        <span class="mast__col js-scene-layer" data-depth="0.15" >
          <h3 class="mast__title">Hello.</h3>
        </span>

      </div>
    <hr class="sep sep--white sep--full">
  </div>

  <div class="js-scene-layer layer--100" data-depth="0.75"><div class="moon"></div></div>
  <button class="mast__arrow mast__arrow--center" href="#" data-scroll="section-1" aria-label="Scroll to content"><i class="icon-down" aria-hidden="true"></i></button>
  <div class="starfield starfield--entrance" moz-opaque></div>
</section>

<!-- ABOUT -->
<section id="section-1" class="intro intro--about  section--grey">
  <header class="intro__heading  js-clippy">
    <h2 class="intro__pretitle">Who We Are</h2>
  </header>

  <div class="grid">
    <div class="intro__content">
      <div class="intro__title">
        <h3><?php echo $about_intro_title; ?></h3>
        <span class="sep-img-intro"></span>
      </div>

      <div class="intro__details">
        <?php echo $about_intro_content; ?>
      </div>
    </div>
  </div>
</section>

<!-- TEAMS -->
<section class="teams  section--dark">
 
  <header class="teams__heading  js-clippy">
    <h2 class="teams__pretitle">About Us</h2>
  </header>

  <div class="teams__grid">
  <?php    
    $args = array(
      'post_type' => 'team',
      'posts_per_page'   => -1,
      'orderby'          => 'rand',
    );
    $posts = get_posts( $args );
    if( $posts ) :
      foreach ( $posts as $post ) : setup_postdata( $post );
        get_template_part( 'partials/content/content', 'team' );
      endforeach; wp_reset_postdata();
    endif;
  ?>
  </div>
  <?php if ($about_careers_link):?>
  <footer class="teams__footer section--light">
    <div class="grid">
    <?php if ($about_careers_content): ?><p><?php echo $about_careers_content; ?></p><?php endif; ?>
    <a class="btn btn--dark" href="<?php jumpoff_page_url('careers') ?>"><span><?php echo $about_careers_link; ?> <i class="icon-right"></i></span></a>
  </div>
  </footer>
  <?php endif; ?>
</section>

<?php    
$args = array(
  'post_type' => 'events',
  'posts_per_page'   => -1,
  'meta_key'  => 'event_date',
  'orderby' => 'meta_value_num',
  'order'   => 'ASC'
);
$posts = get_posts( $args );
if( $posts ) : ?>
<!-- EVENTS -->
<section class="events  section--light">
  
  <header class="events__heading  js-clippy">
    <h5 class="events__pretitle">Where We Are</h5>
  </header>

  <div class="grid">    
    <h2 class="events__title">Formidable sightings</h2>
    <h5 class="events__subtitle">Happenings</h5>
    <table class="events__table">
      <thead>
        <tr>
          <th>What</th>
          <th>When</th>
          <th>Where</th>
        </tr>
      </thead>
      <tbody>
      <?php 
      foreach ( $posts as $post ) : setup_postdata( $post );
        get_template_part( 'partials/content/content', 'events' );
      endforeach; wp_reset_postdata();
      ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>

</main>

<!-- Footer
================================================== --> 
<?php get_footer(); ?>
