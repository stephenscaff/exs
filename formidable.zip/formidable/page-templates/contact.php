<?php
/**
 * Template Name: Contact
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 
//vars
$intro = get_field('contact_form_intro');

?>
<script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?key=AIzaSyA3W4MIMK3RcVIy4O59mtUy1rRpcb4v8eQ'></script>

<!-- MAIN -->
<main role="main">

<!-- MAST -->
<section class="mast mast--contact section--dark">
  <header class="mast__heading  js-clippy">
      <h1 class="mast__pretitle">Contact Us</h1>
  </header>

  <figure class="mast__bg"></figure>

  <div class="mast__content grid u-align-center">
    <span class="mast__subtitle">Let's Make</span>
    <hr class="sep-center sep--white">
    <h2 class="mast__subtitle">Contact</h2>
  </div>
  <div class="starfield"></div>
</section>

<!-- CONTACT FORM -->
<section class="section-75vh  section--light">
  <header class="section__heading  js-clippy">
    <h2 class="section__pretitle">Make Contact</h2>
  </header>

  <div class="contact__content grid">
  <?php if ($intro) : ?><p class="contact__subtitle"><?php echo $intro; ?></p><?php endif; ?>
    <br/>
    <form id="contact-form" accept-charset="UTF-8" action="https://formkeep.com/f/be036ccee8ba" method="POST">
      <div class="contact-form">
        <span>
          <input type="text" name="name" class="contact-form__input" placeholder="+ Name">
          <span class="error-message"></span>
        </span>
        <span>
          <input type="email" name="email" class="contact-form__input" placeholder="+ Email">
          <span class="error-message"></span>
        </span>
        <span class="message">
          <textarea name="message" rows="3" class="contact-form__input contact-form__input--message" placeholder="+ Message"></textarea>
          <span class="error-message"></span>
        </span>
        <div class="contact-form__submit">
          <input type="submit" class="contact-form__input contact-form__input--submit btn btn--dark" value="Transmission">
        </div>
      </div>
      <span class="error-response"></span>
    </form>
  </div>
</section>

<!-- MAP -->
<section class="maps">
  <div class="maps__col">
  <section class="map  section--dark">
    <header class="map__heading  js-clippy">
      <h2 class="map__pretitle">Our coordinates</h2>
    </header>
    
    <section class="js-map">
      <div class="location">Formidable, Seattle</div>
      <div class="address">146 N Canal St. #300</div>
      <div class="city">Seattle</div>
      <div class="state">WA</div>
      <div class="zip">98103</div>
      <div class="country">USA</div>
      <div class="phone">206.547.5580</div>
      <div class="zoom">13</div>
    </section>
  </section>
  </div>
  <div class="maps__col">
  <section class="map  section--dark">
    <header class="map__heading  js-clippy">
      <h2 class="map__pretitle">Our coordinates</h2>
    </header>
    
    <section class="js-map">
      <div class="location">Formidable, London</div>
      <div class="address">41 Corsham St.</div>
      <div class="city">London</div>
      <div class="zip">N1</div>
      <div class="country">UK</div>
      <div class="zoom">14</div>
    </section>
  </section>
  </div>
</section>
</main>


<!-- FOOTER --> 
<?php get_footer(); ?>
