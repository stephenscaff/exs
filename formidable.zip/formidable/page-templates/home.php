<?php
/**
 * Template Name: Home
 *
 * @author    Stephen Scaff
 * @package   home
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

// Vars
$work_cta_pretitle = get_field('work_cta_pretitle');
$work_cta_title = get_field('work_cta_title');
$work_cta_content = get_field('work_cta_content');
$oss_cta_title = get_field('oss_cta_title');
$oss_cta_content = get_field('oss_cta_content');
$oss_expander = "oss_expander";
?>

<!-- MAIN -->
<main role="main">

<!-- Mast -->
<section class="mast mast--left mast--home  section--dark  js-scene">
  
  <header class="mast__heading  js-clippy">
    <h5 class="mast__pretitle">Greetings</h5>
  </header>

  <figure class="mast__bg"></figure>

  <div class="grid">
    <div class="mast__content">
      <span class="mast__subtitle">We're Formidable-</span>
      <h1 class="mast__title">The JavaScript Experts.</h1>
      <hr class="sep sep--white">
      <button class="mast__arrow" href="#" data-scroll="section-1" aria-label="Scroll to content"><i class="icon-down"></i></button>
    </div>
    <figure class="mast__graphic">
      <img class="mast__graphic-img"  height="1159" width="972" aria-role="presentation" alt="presentation" src="<?php jumpoff_imgpath(); ?>/home/home-mast-graphic.png">
    </figure>
  </div>

  <div class="starfield"></div>
</section>

<!-- WORK CTA -->
<section id="section-1" class="work-cta section--grey js-ani">

  <header class="work-cta__heading  js-clippy">
    <h5 class="work-cta__pretitle">Our Work</h5>
  </header>

  <!-- Work-Cta: Content -->
  <div class="work-cta__content">
    <span class="work-cta__subtitle  in-circle"><?php echo $work_cta_pretitle; ?></span>
    <h3 class="work-cta__title"><?php echo $work_cta_title; ?></h3>
    <p class="work_cta__text"><?php echo $work_cta_content; ?></p>
    <hr class="sep sep--full"/>
    <a class="btn btn--dark" href="<?php jumpoff_page_url('work', 1) ?>"><span>View <i class="icon-right"></i></span></a>
  </div>

  <!-- Work-Cta: Graphic -->
  <div class="work-cta__graphic">
    <div class="work-cta__bg"></div>
    <figure class="radar">
      <div class="radar__static"></div>
      <div class="radar__inner">
        <span class="radar__cross"></span>
        <span class="radar__spinner"></span>
      </div>
    </figure>
    <span class="coords coords--x u-hide-small" id="js-coords-x">0</span>
    <span class="coords coords--y u-hide-small" id="js-coords-y">0</span>
    <!--<figure class="work-cta__bg" style="background-image:url(<?php jumpoff_imgpath(); ?>/home/home-modern-web-graphic.jpg)"></figure> -->
  </div>
</section>


<!-- OSS AD --> 
<section class="oss-cta section--light">
  <header class="oss-cta__heading  js-clippy">
    <h5 class="oss-cta__pretitle">Open Source</h5>
  </header>
  
  <div class="grid">
  <?php if ($oss_cta_title) : ?><h4 class="oss-cta_subtitle"><?php echo $oss_cta_title; ?></h4><?php endif; ?>
  <?php if ($oss_cta_content) : ?><p class="oss-cta__text"><?php echo $oss_cta_content; ?></p><?php endif; ?>
    <!-- Expander -->
    <div class="expander">
      <?php if ($oss_expander) : ?>
      <!-- Expander: Imgs -->
      <ul class="expander__imgs">
      <?php while( have_rows($oss_expander) ): the_row();
        $img = get_sub_field('oss_image'); 
      ?>
        <li>
          <img src="<?php echo $img['url'] ?>" alt="<?php echo $img['alt'] ?>">
        </li>
      <?php endwhile; ?>
      </ul>
      <?php endif; ?>

      <?php if ($oss_expander) : ?>
      <!-- Expander: Info -->  
      <ul class="expander__info">
      <?php while( have_rows($oss_expander) ): the_row();
        $title = get_sub_field('oss_title'); 
        $excerpt = get_sub_field('oss_excerpt'); 
        $link = get_sub_field('oss_link'); 
        $img = get_sub_field('oss_image'); 
      ?>
        <li role="tab" class="">
          <h3 class="expander__title  js-expander" role="tab" tabindex="0"><?php echo $title; ?></h3>
          <div class="expander__content">
            <p><?php echo $excerpt; ?></p>
            <a href="<?php echo $link; ?>" class="btn btn--dark"><span>Explore <i class='icon-right'></i></span></a>
          </div>
        </li>
      <?php endwhile; ?>
      </ul>
      <?php endif; ?>
    </div>

    <a class="expander__btn btn btn--white" href="<?php jumpoff_page_url('open-source') ?>"><span>View All Projects <i class="icon-right"></i></span></a>
  </div>
</section>
</main>

<!-- FOOTER --> 
<?php get_footer(); ?>