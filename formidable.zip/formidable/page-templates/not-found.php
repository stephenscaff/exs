<?php
/**
 * Template Name: Not Found
 *  
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();
?>

<!-- MAIN -->
<main role="main">

<!-- MAST -->  
<section class="mast mast--404 section--dark">
  <div class="mast__bg"></div>

  <header class="mast__heading  js-clippy">
    <h1 class="mast__pretitle">404</h1>
  </header>

   <div class="grid">
    <div class="mast__content">
      <h1 class="mast__title js-letters">Holy Ryans!</h1>
      <h1 class="mast__title js-letters">It's The 404</h1>
      <hr class="sep">
      <a href="<?php jumpoff_page_url('home') ?>" class="btn btn--dark"><span>Go Home <i class="icon-right"></i></span></a>
    </div>
  </div>
  <div class="starfield"></div>
</section>

</main>

<!-- FOOTER --> 
<?php get_footer(); ?>
