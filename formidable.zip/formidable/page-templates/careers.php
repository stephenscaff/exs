<?php
/**
 * Template Name: Careers
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

// Vars
$intro_title = get_field('careers_intro_title');
$intro_content = get_field('careers_intro_content');
$highlight_heading = get_field('careers_highlight_heading');
$highlight_title = get_field('careers_highlight_title');
$highlight_content = get_field('careers_highlight_content');
$img_grid = 'image_grid';
?>

<!-- MAIN --> 
<main role="main">

<!-- MAST --> 
<section class="mast mast--left mast--careers section--dark">
  <header class="mast__heading  js-clippy">
    <h2 class="mast__pretitle">Careers</h2>
  </header>

  <figure class="mast__bg mast__bg--land"></figure>
  <figure class="mast__bg mast__bg--moon" style="background-image:url(<?php jumpoff_imgpath(); ?>/careers/careers-mast--moon.png)"></figure>

  <div class="mast__content grid u-align-center">
    <span class="mast__subtitle">Be</span>
    <hr class="sep-center sep--white sep--pluses">
    <span class="mast__subtitle">A Part Of</span>
    <hr class="sep-center sep--white sep--pluses">
    <span class="mast__subtitle">Something Great</span>
    <button class="mast__arrow mast__arrow--center" href="#" data-scroll="section-1" aria-label="Scroll to content"><i class="icon-down" aria-hidden="true"></i></button>
  </div>
  <!-- Stars -->
  <div class="starfield"></div>
</section>


<!-- WORK FOR US --> 
<section id="section-1" class="split section--light">
  <header class="split__heading  js-clippy">
    <h2 class="split__pretitle">Work For Us</h2>
  </header>
  <div class="split__content">
    <div class="split__left g-4">
      <h2 class="split__title u-text-center">Level <span class="up">Up</span></h2>
      <img class="split__graphic" src="<?php jumpoff_imgpath(); ?>/careers/careers-cubes-graphic.png">
    </div>

    <div class="split__right g-8">
      <figure class="split__right-bg" style="background-image: url(<?php jumpoff_imgpath(); ?>/careers/careers-levelup-bg.jpg"></figure>
        <div class="split__details">
          <?php if ($intro_title) : ?><h3><?php echo $intro_title; ?></h3><?php endif; ?>
          <?php if ($intro_content) : ?><p><?php echo $intro_content; ?></p><?php endif; ?>

          <hr class="sep sep--full">
      </div>
    </div>
  </div>
</section>

<!-- REMOTE FRIENDLY --> 
<section class="banner section--dark">
  
  <header class="banner__heading  js-clippy">
    <h2 class="banner__pretitle">Remote Friendly</h2>
  </header>
  
  <figure class="banner__bg"  style="background-image: url(<?php jumpoff_imgpath(); ?>/careers/careers-workfromhome-bg.jpg)"></figure>

  <div class="banner__content grid">
    <span class="banner__subtitle"><?php echo $highlight_heading; ?></span>
    <h2 class="banner__title"><?php echo $highlight_title; ?></h2>
    <hr class="sep-center sep--white">
    <?php echo jumpoff_banner_text($highlight_content); ?>
    <a class="btn btn--grey" href="https://jobs.lever.co/formidable/f34a66d7-08ee-4a3b-9155-4b9ee81a96ae "><span>Join Our Team <i class="icon-right"></i></span></a>
  </div>
</section>

<!-- JOBS --> 
<?php 
$args = array(
  'post_type' => 'jobs',
  'posts_per_page'   => -1
);
$posts = get_posts( $args );
if( $posts ) : ?>
<section class="jobs section--light">
  <header class="jobs__heading  js-clippy">
    <h2 class="jobs__pretitle">Job Openings</h2>
  </header>

  <div class="grid">
    <h2 class="jobs__title">Careers</h2>
    <hr class="sep-center sep--full sep--pluses"/>
    <div class="jobs__grid">
    <?php    
    foreach ( $posts as $post ) : setup_postdata( $post );
      get_template_part( 'partials/content/content', 'jobs' );
    endforeach; wp_reset_postdata();
    ?>
  </div>

  <hr class="sep-center sep--full sep--pluses"/>

  <footer class="jobs__footer  u-center-all">
    <div class="jobs__subtitle">Don't See Your Position?</div>
    <a class="btn btn--grey" href="https://jobs.lever.co/formidable/f34a66d7-08ee-4a3b-9155-4b9ee81a96ae "><span>Reach Out <i class="icon-right"></i></span></a>
  </footer>
  </div>
</section>
<?php endif; ?>

<?php if ($img_grid) : ?>
<section class="imgs  section--dark">

  <header class="imgs__heading  js-clippy">
    <h2 class="imgs__pretitle">Our Headquarters</h2>
  </header>

  <section class="img-grid img-grid--darken">
  <?php while( have_rows($img_grid) ): the_row(); ?>
  <?php $img = get_sub_field('img'); ?>
    <img class="img-grid__item" src="<?php echo $img['url'] ?>" alt="<?php echo $img['alt'] ?>"/>
  <?php endwhile; ?>
  </section>
<?php endif; ?>
</section>

</main>

<!-- FOOTER --> 
<?php get_footer(); ?>
