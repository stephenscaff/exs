<?php
/**
 * The template for displaying archives
 *
 *
 * @author    Stephen Scaff
 * @package   jumpoff/archive
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- Main -->
<main role="main">

<?php 
 $counter = 1;
  if ( have_posts() ): while ( have_posts() ) : the_post();
    include(locate_template('partials/content/content-work.php'));
    $counter++; 
  endwhile; else: 
    get_template_part( 'partials/content/content', 'none' );
  endif;
?>

<!-- Pagination -->
<?php get_template_part( 'partials/posts', 'pagination' );?>

</main>

<!-- Footer --> 
<?php get_footer(); ?>