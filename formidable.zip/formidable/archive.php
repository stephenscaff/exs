<?php
/**
 * The defualt tempalte for the Blog Index
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- MAIN --> 
<main role="main">

<!-- MAST -->
<section class="mast mast--taxonomy section--dark">

  <figure class="mast__bg"></figure>

  <div class="mast__content grid u-align-center">
    <span class="mast__subtitle">More From</span>
    <hr class="sep-center sep--white">
    <?php if (is_author()) : ?>
    <h2 class="mast__subtitle"><span class="color-alpha-light"><?php the_author_meta('display_name'); ?></span></h2>
    <?php elseif (is_category()) : ?>
    <h2 class="mast__subtitle"><?php single_cat_title( '', true ); ?></h2>
  <?php endif; ?>
  </div>
  <div class="starfield"></div>
</section>


<!-- FEEDS -->
<section id="section-1" class="feeds section--light">
  <div class="grid">
    <div class="feeds__grid">
  <?php 
  if ( have_posts() ): while ( have_posts() ) : the_post();
    get_template_part( 'partials/content/content', 'posts' );
  endwhile; else: 
    get_template_part( 'partials/content/content', 'none' );
  endif;?>
    </div>
  </div>
</section>

<!-- PAGINATION -->
<?php get_template_part( 'partials/partial', 'pagination' );?>

</main>

<!-- FOOTER -->
<?php get_footer(); ?>