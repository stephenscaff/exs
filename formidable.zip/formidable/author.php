<?php
/**
 * The defualt tempalte for the Author's Posts
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- MAIN --> 
<main role="main">

<!-- MAST -->
<section class="mast mast--left mast--posts  section--dark">
  <header class="mast__heading  js-clippy">
    <h5 class="mast__pretitle">Our Journal</h5>
  </header>
  
  <figure class="mast__bg" style="background-image:url(<?php jumpoff_imgpath(); ?>/blog/posts-mast-bg.jpg)"></figure>
  
  <div class="grid">
    <div class="mast__content">
      <h2 class="mast__subtitle">Posts by <span class="color-alpha"><?php the_author_meta('display_name'); ?></span></h2>
      <hr class="sep sep--white">
      <icon class="icon-down"></icon>
    </div>
  </div>
  <div class="starfield"></div>
</section>

<!-- FEEDS -->
<section class="feeds">
  <div class="grid grid--pad">
    <div class="feeds__grid">
  <?php 
  if ( have_posts() ): while ( have_posts() ) : the_post();
    get_template_part( 'partials/content/content', 'posts' );
  endwhile; else: 
    get_template_part( 'partials/content/content', 'none' );
  endif;?>
    </div>
  </div>
</section>

<!-- PAGINATION -->
<?php get_template_part( 'partials/partial', 'pagination' );?>

</main>

<!-- FOOTER -->
<?php get_footer(); ?>

