<?php
/**
 * The template for displaying archives
 *
 *
 * @author    Stephen Scaff
 * @package   jumpoff/archive
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 
//vars
$mast_heading = get_field('mast_heading', 171);
$mast_title = get_field('mast_title', 171);
$mast_text = get_field('mast_text', 171);
?>

<!-- Main -->
<main role="main" class="bg--lightgrey">

<!-- MAST -->
<section class="mast mast--oss  section--light">

  <header class="mast__heading">
    <?php if ($mast_heading) : ?><h1 class="mast__pretitle"><?php echo $mast_heading; ?></h1><?php endif; ?>
  </header>
  
  <figure class="mast__bg"></figure>
  
  <div class="grid">
    <div class="mast__content">
      <?php if ($mast_title) : ?><h2 class="mast__title g-offset-1"><?php echo $mast_title; ?></h2><?php else : the_title(); endif; ?>
      <?php if ($mast_text) : ?><p class="mast__text"><?php echo $mast_text; ?></p><?php endif; ?>
      <hr class="sep">
      <button class="mast__arrow" href="#" data-scroll="section-1" aria-label="Scroll to content"><i class="icon-down" aria-hidden="true"></i></button>
    </div>
  </div>
</section>

<?php    
$args = array(
  'post_type' => 'oss',
  'posts_per_page'   => -1,
  'orderby'          => 'date',
  'order'            => 'DESC',
  'meta_query' => array(
    array(
      'key' => 'oss_has_lp',
      'value' => '1',
      'compare' => '=='
    )
  )
);
$posts = get_posts( $args ); 
  if( $posts ) : ?>

<section id="section-1" class="oss-featured">
  <?php foreach ( $posts as $post ) : setup_postdata( $post );
    get_template_part( 'partials/content/content', 'oss' );
  endforeach; wp_reset_postdata(); ?>
</section>
<?php endif; ?>

<?php 
$args = array(
  'post_type' => 'oss',
  'posts_per_page'   => -1,
  'orderby'          => 'date',
  'order'            => 'DESC',
  'meta_query' => array(
    array(
      'key' => 'oss_has_lp',
      'value' => '1',
      'compare' => '!='
    )
  )
);
$posts = get_posts( $args ); if( $posts ) : ?>

<?php get_template_part( 'partials/partial', 'cat-filter' );?>

<section class="feeds">
  <div class="grid">
    <div class="feeds__grid">
    <?php
    foreach ( $posts as $post ) : setup_postdata( $post );
       get_template_part( 'partials/content/content', 'oss-feed' );
    endforeach; wp_reset_postdata();
    ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php //get_template_part( 'partials/posts', 'pagination' );?>

</main>

<!-- Footer -->
<?php get_footer(); ?>