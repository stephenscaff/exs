<?php
/**
 *  Section: Next Post
 *  
 *  Next Post preview partial. Includes partial-promo.
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff/partials/partial-next
 *  @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<!-- Formidable Promo -->
<?php get_template_part( 'partials/partial', 'promo' );?>

<?php 
$prevPost = get_previous_post();
if($prevPost) :
  $args = array(
    'posts_per_page' => 1,
    'include' => $prevPost->ID
  );
  $prevPost = get_posts($args);
  foreach ($prevPost as $post) :
  setup_postdata($post);
?>

<!-- Next -->
<article class="next-post">
  <div class="grid grid--pad">
  <hr class="sep-img-blue"/>
    <div class="next-post__content">
      <span class="next-post__preheader"><?php the_time('F j, Y'); ?></span>
      <h3 class="next-post__title"><?php the_title(); ?></h3>
      <a class="btn btn--dark btn--small" href="<?php the_permalink(); ?>"><span>Read Next <i class="icon-right"></i></span></a>
    </div>
  </div>
</article>
<?php
  wp_reset_postdata();
  endforeach; endif;
?>