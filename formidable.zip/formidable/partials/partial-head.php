<?php
/**
 * Partial: partials/partial-head
 *
 * @author    Stephen Scaff
 * @package   jumpoff/partials/partial-head
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<!DOCTYPE html>
<!--
                   #PigeonWisdom
t                                                t
C00i                                          i00C
 iG08G,                                    :G80Gi
 fG:1008f                                f8001:0f
 i@G0t:L000i                          i000L:t0G@i
   ;C0G0i;CG8G,         :CGi       ,G8GC;i0G0C;
  .00;i0GGGCGCG@1      :0GtGC    1@GCGCGG00i;00.
   1000L:f0CCCCC8t     L0GC..;  t8CCCCC0t:L000i
    1i100GCGCCCC0L    ;8CGG,    L0CCCCGCG001i1
    f88f:L0CCCCCG0:   G0ff0C   :0GCCCCC0L:f88f
     18GGGLGCCCCCCG8f:CG00GC;f8GCCCCCCGLGGG81
       .L8GCCCCCCCGG;CGCCCCGG;GGCCCCCCCG8L.
          ,L0800080:f0CCCCCC0L;0800080L,
                   f8CCCCCCCC0L
                  .CGCCCCCCCCGG.
                   L0CCCCCCCC0C
                   .G0CCCCGC00.
                     ,G8008G,
                    f@G1ii1G@f
                  i8G0CCCCCC0G81
                i8GGC,C0ff0C:CGG8i
                 .t00;G8ii8G;00f,
-->
<html lang="en">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/><![endif]-->
<?php
// Meta/OG variables
$id = jumpoff_get_ids();
$meta_author = jumpoff_get_author(); 
$meta_title = get_field('seo_title', $id) ? get_field('seo_title', $id) : wp_title('|', false, 'right') . get_bloginfo('name');
$meta_description = get_field('seo_description', $id) ? get_field('seo_description', $id) : "React.js consultants. JavaScript leaders and OSS innovators. Formidable builds the modern web. Challenge us with your next big problem.";
// get_post_meta( $id, 'seo_title', true ) ? get_post_meta( get_the_ID(), 'seo_title', true ) : wp_title('|', false, 'right') . get_bloginfo('name');
$meta_site_name = get_bloginfo('name') .' - '. get_bloginfo('description');
$meta_keywords = get_post_meta( get_the_ID(), 'seo_keywords', true ) ? get_post_meta( get_the_ID(), 'seo_keywords', true ) : "formidable, react.js, javascript seattle, seattle web development";
?>

<!-- Title and Meta
================================================== -->
<title><?php echo $meta_title; ?></title>
<meta name="author" content="<?php echo $meta_author; ?>">
<meta name="description" content="<?php echo $meta_description ?>">
<meta name="keywords" content="<?php echo $meta_keywords ?>" />

<!-- Facebook Open Graph Meta
================================================== -->
<meta property="og:title" content="<?php echo $meta_title; ?>">
<meta property="og:url" content="<?php echo the_permalink() ?>">
<meta property="og:site_name" content="<?php echo $meta_site_name ?>">
<meta property="og:description" content="<?php echo $meta_description; ?>">
<meta property="og:image" content="<?php jumpoff_ftimg_fallbacks('large');?>">
<?php if (is_single()) : ?>
<meta property="og:image" content="<?php jumpoff_ftimg_fallbacks('large');?>">
<?php else : ?>
<meta property="og:image" content="<?php jumpoff_imgpath(); ?>/no-img.jpg">
<?php endif; ?>

<!-- Twitter Meta
================================================== -->
<meta name="twitter:card" content="summary"/>
<meta name="twitter:description" content="<?php echo $meta_description ?>"/>
<meta name="twitter:title" content="<?php echo $meta_title ?>"/>
<meta name="twitter:url" content="<?php echo the_permalink() ?>">
<meta name="twitter:site" content="@formidablelabs"/>
<meta name="twitter:creator" content="@formidablelabs">
<meta name="twitter:domain" content="http://formidable.com"/>
<?php if (is_single()) : ?>
<meta property="twitter:image" content="<?php jumpoff_ftimg_fallbacks('large');?>">
<?php else : ?>
<meta property="twitter:image" content="<?php jumpoff_imgpath(); ?>/no-img.jpg">
<?php endif; ?>

<!-- Viewport
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale = 1" />       

<!-- Fav and icons
================================================== -->  
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/assets/images/fav.png" type="image/ico" />
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php bloginfo('template_directory'); ?>/assets/images/fav-152.png">
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="<?php bloginfo('template_directory'); ?>/assets/images/fav-120.png">
<link rel="apple-touch-icon-precomposed" sizes="60x60" href="<?php bloginfo('template_directory'); ?>/assets/images/fav-60.png">
<link rel="apple-touch-icon-precomposed" href="<?php bloginfo('template_directory'); ?>/assets/images/fav-152.png">

<!-- Feed
================================================== -->  
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> Feed" href="<?php echo home_url(); ?>/feed/">

<!-- GA
================================================== --> 
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-43290258-1', 'auto');
  ga('send', 'pageview');
</script>

<meta name="google-site-verification" content="4NqL_ixifStXJqZdhrzJ1OokF_CEIIQDB3ILKlUtU7s" />

<!-- CSS & Js
================================================== -->
<?php wp_head(); ?>

<?php 
// Mast Fields
$mast_bg = get_field('mast_bg');
$mast_bg_sm = get_field('mast_bg_sm');
if ($mast_bg) : ?>
<style type="text/css">
.mast__bg{background-image:url(<?php echo $mast_bg_sm['url'] ?>)  }
@media (min-width:32em) {
.mast__bg{background-image:url(<?php echo $mast_bg['url'] ?>) }
}
</style>
<?php endif; ?>
</head>