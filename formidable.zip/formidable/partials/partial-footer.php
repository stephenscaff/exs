<?php
/**
 * Partial: partials/partial-footer
 *
 * @author    Stephen Scaff
 * @package   jumpoff/partials/partial-footer
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<footer class="site-footer">
  <div class="grid grid--pad">
    <nav class="site-footer__socials">
      <a class="js-shuffle-hover js-shuffle-text" href="http://twitter.com/formidablelabs" rel="external" target="_blank" title="Formidable on Twitter">Twitter</a>
      <a class="js-shuffle-hover" href="http://github.com/formidablelabs" rel="external" target="_blank" title="Foromidable on Github">Github</a>
      <a class="js-shuffle-hover" href="<?php jumpoff_page_url('contact') ?>" rel="external" target="_blank" title="Contact Formidable">Contact</a>
    </nav>
  </div>
</footer>

<!-- Le javascript --> 
<?php wp_footer(); ?>

</body>
</html>