<?php
/**
 * Partial: partials/partial-footer
 *
 * @author    Stephen Scaff
 * @package   jumpoff/partials/partial-footer
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
$img_grid = 'img_grid';
?>
<?php if ($img_grid) : ?>
<section class="img-grid">
<?php while( have_rows($img_grid) ): the_row(); ?>
<?php $img = get_sub_field('img'); ?>
  <img class="img-grid__item" src="<?php echo $img['url'] ?>" alt="<?php echo $img['alt'] ?>"/>
<?php endwhile; ?>
</section>
<?php endif; ?>
