<?php
/**
 * Section: Pagination
 *
 * Used for listing blog posts
 *
 * @author    Stephen Scaff
 * @package   pocketprep/partials/sect-pagination
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<section id="cats-popup" class="popup" aria-hidden="true">  
  <button class="popup__close js-close-popup" aria-label="Close">
    <div class="popup__x"></div>
  </button> 
  
  <nav class="cats-list">
    <ul>
      <li><a class="post-cats__cat" href="<?php jumpoff_page_url('oss') ?>">All</a></li>
      <?php echo jumpoff_tax_list('categories'); ?>
    </ul>
  </nav>
</section>

<div class="filter-bar-wrap">
<section class="filter-bar  js-sticky">
  <div class="grid">
  <button class="filter-bar__control" data-popup="cats-popup" data-modal-id="cats-popup" class="popup" href="#">
    <span class="filter-bar__text">Filter By</span>
    <?php if (is_tax()) : ?>
      <span class="filter-bar__value"><?php single_cat_title( '', true ); ?></span> 
    <?php else : ?>
      <span class="filter-bar__value">All</span>
    <?php endif; ?>
  </button>
  </div>
</section>  
</div>