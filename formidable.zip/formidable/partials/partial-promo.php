<?php
/**
 * Section: Promo Text
 *
 * @author    Stephen Scaff
 * @package   jumpoff/content/post-next
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$promo_title = get_field('promo_title', 'option');
$promo_text = get_field('promo_text', 'option');

?>

<section class="promo">
<hr class="sep-img-light"/>
  <div class="grid grid--pad">
    <div class="promo__content">
      <?php if ($promo_title) : ?><h3 class="promo__title"><?php echo $promo_title; ?></h3><?php endif; ?>
      <?php echo $promo_text; ?>
    </div>
  </div>
</section>
