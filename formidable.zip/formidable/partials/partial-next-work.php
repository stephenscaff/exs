<?php
/**
 *  Section: Next Project
 *
 *  Next Project partial for single-work posts. Includes partial-promo.
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff/content/post-next
 *  @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Vars
$previous_post = get_adjacent_post(false, '', false); 
$next_post = get_adjacent_post(false, '', true);
$pretitle = get_field('mast_pretitle', $next_post);
$text = get_field('mast_text', $next_post);
?>

<!-- Formidable Promo -->
<?php get_template_part( 'partials/partial', 'promo' );?>

<?php if ($next_post): // if there are newer articles ?>

<!-- Next -->
<article class="next-post">
  <div class="grid">
    <hr class="sep-img-blue"/>
    <div class="next-post__content">
    <span class="next-post__preheader"><?php echo $pretitle; ?> </span>
        <h3 class="next-post__title"><?php echo get_the_title($next_post); ?></h3>
    <p class="next-post__text"><?php echo $text; ?></p>
        <a class="btn btn--dark btn--small" href="<?php echo get_permalink($next_post); ?>"><span>Next Project <i class="icon-right"></i></span></a>
    </div>
  </div>
</article>

<?php else: ?>

<!-- View All -->
<section class="view-all">
  <header class="view-all__header grid">
    <hr class="sep-img-blue"/>
    <a class="btn btn--dark" href="<?php jumpoff_page_url('work', 1) ?>"><span>View All Work <i class="icon-right"></i></span></a>
  </header>
</section>

<?php endif; ?>  