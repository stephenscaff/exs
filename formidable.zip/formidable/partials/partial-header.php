<?php
/**
 * Partial: partials/partial-header
 *
 * @author    Stephen Scaff
 * @package   jumpoff/partials/partial-header
 * @version    1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<body <?php body_class(); ?>>
<!-- Signup Notice-->
<section class="signup-notice"></section>
<!-- SITE HEADER -->
<header class="site-header">
  <!-- Site-Header: Logo -->
  <a href="/" class="site-header__logo" title="Formidable">
    <svg class="logo-icon" x="0px" y="0px" viewBox="0 0 51.8 70">
      <g>
        <polygon class="logo-layer-1" fill="rgba(195,58,50,1)" points="16.6,2 2,61.8 16.6,44.1  "/>
        <polygon class="logo-layer-2" fill="rgba(252,226,221,1)" points="16.6,2 50,33.2 16.6,44.1   "/>
        <polygon class="logo-layer-3" fill="rgba(238,169,156,1)" points="16.6,68 50,33.2 16.6,44.1  "/>
        <polygon class="logo-layer-4" fill="rgba(221,122,107,1)" points="2,61.8 16.6,44.1 16.6,68   "/>
      </g>
    </svg>
  </a>
  <!-- Site-Header: Toggle -->
  <button class="site-header__menu-toggle  js-menu-toggle"  title="navigation menu" aria-label="navigation menu" role="button" >
    <span class="site-header__menu-text">MENU</span> 
    <span class="site-header__menu-bar"></span>
  </button> 
</header>

<!-- SITE-MENU -->
<section class="site-menu" aria-hidden="true">
  <div class="grid">
    <!-- Site Menu: Header -->
    <header class="site-menu__header">
      <a class="site-menu__logo js-home" href="/"><img src="<?php jumpoff_imgpath(); ?>/logo-formidable-bnw.png" alt="Formidable"></a>
    </header>
    <!-- Site Menu: Nav -->
    <nav class="site-menu__nav">
      <ul>
      <li class="site-menu__nav-item"><a class="js-work" title="Work" href="<?php jumpoff_page_url('work', 1) ?>"><span>02</span>Work</a></li>
        <li class="site-menu__nav-item"><a class="js-about" title="About" href="<?php jumpoff_page_url('about') ?>"><span>03</span>About</a></li>
      </ul><ul>
        <li class="site-menu__nav-item"><a class="js-careers" title="Careers" href="<?php jumpoff_page_url('careers') ?>"><span>04</span>Careers</a></li>
        <li class="site-menu__nav-item"><a class="js-oss" title="Open Source" href="<?php jumpoff_page_url('oss') ?>"><span>05</span>Open Source</a></li>
      </ul><ul>
        <li class="site-menu__nav-item"><a class="js-blog" title="Blog" href="<?php jumpoff_page_url('blog') ?>"><span>06</span>Journal</a></li>
        <li class="site-menu__nav-item"><a class="js-contact" title="Contact" href="<?php jumpoff_page_url('contact') ?>"><span>07</span>Contact</a></li>
      </ul>
    </nav>
    <!-- Site Menu: Footer -->
    <footer class='site-menu__footer'>
      <address class="site-menu__address">
        <span> 146 N Canal St. #300</span>
        <span> Seattle, WA 98103, US</span>
        <span> <a href="tel:206-547-5580" title="Telephone Number"> 206.547.5580</a></span>
      </address>

      <!-- Site Menu: Socials -->
      <nav class="site-menu__socials">
        <a class="js-shuffle-hover" href="http://twitter.com/formidablelabs" rel="external" target="_blank" title="Foromidable on Twitter" data-shuffle="@FormidableLabs" data-initial="Twitter">Twitter</a>
        <a class="js-shuffle-hover" href="http://github.com/formidablelabs" rel="external" target="_blank" title="Foromidable on Github" data-shuffle="FormidableLabs" data-initial="Github">Github</a>
      </nav>

      <!-- Site Menu: Signup -->
      <div class="site-menu__whatsup">
        <form class="signup" id="mc-signup" name="mc-embedded-subscribe-form"  action="https://formidable.us13.list-manage.com/subscribe/post-json?u=e81f336b59176f1478f6d3d6e&amp;id=b263fa60ab&amp;c=?" method="POST" target="_blank" novalidate>
          <div class="signup__inputs">
            <input class="signup__input   email" id="mce-EMAIL" name="EMAIL"  value="" type="email" aria-label="Email Address" aria-required="true" required="" placeholder="YOU@YOUREMAIL.COM">
            <div style="position: absolute; left: -5000px; display:none;"><input type="text" name="b_e81f336b59176f1478f6d3d6e_b263fa60ab" aria-hidden="true" value=""></div>
            <button class="signup__submit  signup__btn btn btn--dark" value="Subscribe" name="subscribe" id="mc-submit"  aria-label="Submit" title="Submit"><span>Get News <i class="icon-right"></i></span></button>
          </div>
        </form>
         <!-- Signup Message -->
        <div class="signup-message">
          <p>Thanks for signing up for updates</p>
        </div>  
        <span class="copyright">© MMXVI Formidable Labs, Inc.</span>
      </div>
    </footer>
    <!-- Site Menu: Helps -->
    <span class="site-menu__helps">
      Keyboard Shortcuts : Press keys 1–7 to navigate through pages
    </span>
  </div>
</section>