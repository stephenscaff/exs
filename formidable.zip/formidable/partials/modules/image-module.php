<?php
/**
* Image Module
*
* @author       Stephen Scaff
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$img_module = 'image-repeater';

if ($img_module) : ?>
<section class="auto-grid auto-grid--darken section--dark">
  <?php 
  while( have_rows($img_module) ): the_row(); 
  $img = get_sub_field('image'); ?>
  <img class="auto-grid__item" src="<?php echo $img['url'] ?>" alt="<?php echo $img['alt'] ?>"/>
  <?php endwhile; ?>
</section>
<?php endif; ?>
