<?php
/**
 * Banner Module
 *
 * @author       Stephen Scaff
 * @version      1.0
 */ 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$heading = get_sub_field('heading'); 
$subtitle = get_sub_field('title'); 
$title = get_sub_field('subtitle'); 
$content = get_sub_field('content');
$img = get_sub_field('bg_image'); 
$theme = get_sub_field('color_theme'); 
?>

<section class="banner banner--work <?php if ($theme) : echo $theme; endif; ?>">
  
  <header class="banner__heading  js-clippy">
    <h2 class="banner__pretitle"><?php echo $heading; ?></h2>
  </header>
  
  <figure class="banner__bg"  style="background-image: url(<?php echo $img['url'] ?>);"></figure>

  <div class="banner__content grid">
    <span class="banner__subtitle"><?php echo $subtitle; ?></span>
    <h3 class="banner__title"><?php echo $title; ?></h3>
    <hr class="sep-center sep--white">
    <?php echo jumpoff_banner_text($content); ?>
  </div>
</section>

