<?php
/**
 * Content Module
 *
 * @author       Stephen Scaff
 * @version      1.0
 */ 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$heading = get_sub_field('heading');
$content_repeater = 'content-repeater';
?>
<section class="auto-cols  section--light">
  <header class="auto-cols__heading  js-clippy">
    <h5 class="auto-cols__pretitle"><?php echo $heading; ?></h5>
  </header>
  <?php if ($content_repeater) : ?>
  <div class="grid grid--flex">
  <?php 
  while( have_rows($content_repeater) ): the_row(); 
  $column = get_sub_field('column'); ?>
    <div class="auto-cols__col">
    <?php echo $column; ?>
    </div>
  <?php endwhile; ?>
  </div>
  <?php endif; ?>
</section>



