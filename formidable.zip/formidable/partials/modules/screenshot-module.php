<?php
/**
 * Screenshot Module
 *
 * @author       Stephen Scaff
 * @version      1.0
 */ 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$heading = get_sub_field('heading');
$screenshot_repeater = 'screenshot-repeater';
?>
<section class="screenshots">
  <header class="screenshots__heading  js-clippy">
    <h5 class="screenshots__pretitle"><?php echo $heading; ?></h5>
  </header>
  <?php if ($screenshot_repeater) : ?>
  <div class="grid u-text-center">
    <div class="screenshots__grid">
  <?php 
  while( have_rows($screenshot_repeater) ): the_row(); 
  $device = get_sub_field('device'); 
  $img = get_sub_field('screenshot'); 
  $caption = get_sub_field('caption'); 
  ?>
    <div class="screenshots__item">
      <figure class="screenshot">
        <div class="<?php echo $device; ?>">
          <?php if ($device == 'screenshot__browser') : ?><span class="browser-dot"></span><?php endif; ?>
          <img src="<?php echo $img['url']; ?>">
        </div>
        <?php if ($caption) : ?><figcaption class="screenshot__caption"><?php echo $caption; ?></figcaption><?php endif; ?>
      </figure>
    </div>
  <?php endwhile; ?>
  </div></div>
  <?php endif; ?>
</section>

