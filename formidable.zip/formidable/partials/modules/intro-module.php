<?php
/**
 * Intro module
 *
 * @author       Stephen Scaff
 * @version      1.0
 */ 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$heading = get_sub_field('heading'); 
$toc = get_sub_field('toc');
$title = get_sub_field('title'); 
$content = get_sub_field('content');
$bg_img = get_sub_field('bg_image'); 
$theme = get_sub_field('color_theme'); 
?>
<!-- Intro Section -->
<section class="intro  <?php if ($theme) : echo $theme; endif; ?>">
  <header class="intro__heading  js-clippy">
    <h5 class="intro__pretitle"><?php echo $heading; ?></h5>
  </header>

  <figure class="intro__bg" style="background-image: url(<?php echo $bg_img['url'] ?>)"></figure>

  <div class="grid">
    <div class="intro__content intro__content--center">
      <div class="intro__title">
        <span class="intro__caps"><?php if ($toc) : echo $toc; endif; ?></span>
        <span class="intro__subtitle"><?php if ($title) : echo $title; endif; ?></span>
      </div>

      <div class="intro__details">
      <?php echo $content; ?>
      </div>
    </div>
  </div>
</section>