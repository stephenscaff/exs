<?php
/**
 *  Section: View All
 *
 *  View All Index link intended for Next Post/Work partials.
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff/content/post-next
 *  @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<section class="view-all">
  <header class="view-all__header grid">
    <hr class="sep-img-blue"/>
    <?php if (is_post_type_archive( 'work' ) ) : ?>
      <a class="btn btn--grey" href="<?php jumpoff_page_url('work', 1) ?>"><span>View All Projects <i class="icon-right"></i></span></a>
    <?php else : ?>
      <a class="btn btn--grey" href="<?php jumpoff_page_url('blog') ?>"><span>View All Articles <i class="icon-right"></i></span></a>
    <?php endif; ?>
  </header>
</section>