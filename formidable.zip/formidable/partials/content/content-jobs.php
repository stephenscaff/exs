<?php
/**
* Content: content-jobs
* Tempalte for displaying the jobs CPTs
*
* @author    Stephen Scaff
* @package   formidable/content/content-jobs
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$job_excerpt = get_field('job_excerpt');
$job_link = get_field('job_link');
?>

<article class="job">
  <h4 class="job__title"><?php the_title(); ?></h4>
  <p class="job__text"><?php echo $job_excerpt; ?></p>
  <a class="btn btn--dark btn--small" href="<?php echo $job_link; ?>"><span>Info <i class="icon-right"></i></span></a>
</article>
