<?php
/**
* Content: content-team
* Template for displaying the team CPT
*
* @author    Stephen Scaff
* @package   jumpoff/content/content-team 
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$team_img = get_field('team_image');
$team_img_hover = get_field('team_image_hover');
$team_email = get_field('team_email');
$team_twitter = get_field('team_twitter');
$team_github = get_field('team_github');
?>

<article class="team">
  <div class="team__content">
    <figure class="team__bg <?php if ($team_img_hover) : ?>team__bg--has-hover<?php endif; ?>">
      <span class="team__img" style="background-image: url(<?php echo $team_img['url'] ?>)"></span>
      <?php if ($team_img_hover) : ?><span class="team__img team__img--hover" style="background-image: url(<?php echo $team_img_hover['url'] ?>)"></span><?php endif; ?>
    </figure>
    <header class="team__header">
      <h4 class="team__title"><?php the_title(); ?></h4>
      <?php if ($team_email) : ?>
        <a class="team__link  js-shuffle-text" href="mailto:<?php echo $team_email; ?>" data-shuffle="<?php echo $team_email; ?>" data-initial="Email" data-animated="false" target="_blank" rel="external">Email</a>
      <?php endif; ?>
      <?php if ($team_twitter) : ?>
        <a class="team__link js-shuffle-text" href="http://twitter.com/<?php echo $team_twitter; ?>" data-shuffle="@<?php echo $team_twitter; ?>" data-initial="Twitter" target="_blank" rel="external">Twitter</a>
      <?php endif; ?>
      <?php if ($team_github) : ?>
        <a class="team__link js-shuffle-text" href="http://github.com/<?php echo $team_github; ?>" data-shuffle="github.com/<?php echo $team_github; ?>" data-initial="Github" target="_blank" rel="external">Github</a>
      <?php endif; ?>
    </header>
  </div>
</article>