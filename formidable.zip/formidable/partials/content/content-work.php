<?php
/**
* Content: content-folio
* Tempalte for displaying the work CPT
*
* @author    Stephen Scaff
* @package   formidable/content/content-work
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$pretitle = get_field('mast_pretitle');
$text = get_field('mast_text');
$post_count_total = wp_count_posts('work')->publish;
$theme = get_field('color_theme'); 
?>

<article class="folio <?php if ($theme) : echo $theme; endif; ?>">
  
  <header class="folio__heading  js-clippy">
    <h5 class="folio__pretitle">Case Study <?php echo $counter . ' of ' . $post_count_total ?></h5>
  </header>

  <figure class="oss__bg"  style="background-image: url(<?php jumpoff_ftimg_fallbacks('fullsize') ?>)"></figure>

  <div class="grid">
    <div class="folio__content">
      <span class="folio__preheader"><?php echo $pretitle; ?></span>
      <h2 class="folio__title"><?php the_title(); ?></h2>
      <hr class="folio__sep sep-center sep--white"/>
      <p class="folio__text"><?php echo $text; ?></p>
      <?php if (is_post_type_archive( 'work' )) : ?><a class="btn btn--white" href="<?php the_permalink(); ?>"><span>View The Case Study <i class="icon-right"></i></span></a><?php endif; ?>
    </div>
  </div>
</article>