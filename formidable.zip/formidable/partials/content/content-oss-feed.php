<?php
/**
* Content: content-oss-feed
*
* Template to dsiplay smaller OSS projects without a Landing page
*
* @author    Stephen Scaff
* @package   formidable/content/content-oss-feed
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$oss_excerpt = get_field('oss_excerpt');
$oss_link = get_field('oss_link');
$oss_non_ft_lp = get_field('non_featured_lp');

?>
<article class="feed section--light">
  <?php if (!is_tax()) : ?>
    <span class="feed__cats"><?php jumpoff_tax('categories', 'feed');?></span>
  <?php endif; ?>
  <h3 class="feed__title"><?php the_title(); ?></h3>
  <p class="feed__excerpt"><?php echo $oss_excerpt; ?></p>
  <?php if ($oss_non_ft_lp) : ?>
    <a class="btn btn--dark" href="<?php echo $oss_non_ft_lp; ?>"><span>Launch <i class="icon-right"></i></span></a>
  <?php else : ?>
  <a class="btn btn--dark" href="<?php echo $oss_link; ?>"><span>View on Github <i class="icon-right"></i></span></a>
  <?php endif; ?>
</article>