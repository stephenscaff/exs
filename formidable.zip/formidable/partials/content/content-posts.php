<?php
/**
* Content: content-Posts
*
* @author    Stephen Scaff
* @package   jumpoff/content/content-posts
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<article class="feed">
  <span class="feed__date"><?php the_time('m/d/y'); ?></span>
  <h3 class="feed__title"><?php the_title(); ?></h3>
  <p class="feed__excerpt"><?php echo jumpoff_excerpt(300); ?></p>
  <a class="btn btn--dark" href="<?php the_permalink(); ?>"><span>Read <i class="icon-right"></i></span></a>
</article>