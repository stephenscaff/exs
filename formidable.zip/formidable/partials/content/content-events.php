<?php
/**
 * Content: content-events
 * Tempalte for displaying the Events CPT scene on the About page
 *
 * @author    Stephen Scaff
 * @package   formidable/content/content-events
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$event_date = get_field('event_date');
$event_location = get_field('event_location');
$event_link = get_field('event_link');

?>
<tr>
  <td><?php the_title(); ?></td>
  <td><?php echo $event_date; ?></td>
  <td><?php echo $event_location; ?></td>
  <td><a class="btn btn--dark btn--small" href="<?php echo $event_link; ?>"><span>Info <i class="icon-right"></i></span></a></td>
</tr>