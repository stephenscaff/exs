<?php
/**
* Content: content-folio
* Tempalte for displaying the Open Source (oss) CPTs
*
* @author    Stephen Scaff
* @package   jumpoff/content/content-oss
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$oss_subtitle = get_field('oss_subtitle');
$oss_excerpt = get_field('oss_excerpt');
$oss_link = get_field('oss_link');
$oss_img = get_field('oss_image');
$oss_bg_img = get_field('oss_bg_image');
$oss_theme = get_field('oss_theme');
 
?>

<article class="oss <?php echo $oss_theme; ?>">

  <header class="oss__heading  js-clippy">
    <h2 class="oss__pretitle">OSS: <?php the_title(); ?></h2>
  </header>

  <figure class="oss__bg"  style="background-image: url(<?php echo $oss_bg_img['url'] ?>)"></figure>

  <div class="grid">
    <figure class="oss__graphic g-6">
      <?php if ($oss_img) : ?><img src="<?php echo $oss_img['url']; ?>" alt="<?php echo $oss_img['alt']; ?>"/><?php endif; ?>
    </figure>
    
    <div class="oss__content g-6">
      <?php if ($oss_subtitle) : ?><span class="oss__subtitle"><?php echo $oss_subtitle; ?></span><?php endif; ?>
      <h2 class="oss__title"><?php the_title(); ?></h2>
      <hr class="oss__sep"/>
      <?php if ($oss_excerpt) : ?><p class="oss__text"><?php echo $oss_excerpt; ?></p><?php endif; ?>
      <a class="btn btn--white" href="<?php echo $oss_link; ?>" target="_blank" rel="external" title="<?php the_title(); ?>"><span>Explore Documentation <i class="icon-right"></i></span></a>
    </div>
  </div>
</article>
