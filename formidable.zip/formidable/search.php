<?php
/**
 * The template for displaying Search results
 *
 *
 * @author    Stephen Scaff
 * @package   jumpoff/archive
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}
get_header(); 

?>

<!-- MAST -->
<section class="mast mast--left mast--posts  section--dark">
  <header class="mast__heading  js-clippy">
    <h5 class="mast__pretitle">Our Journal</h5>
  </header>
  
  <figure class="mast__bg" style="background-image:url(<?php jumpoff_imgpath(); ?>/blog/posts-mast-bg.jpg)"></figure>
  
  <div class="grid">
    <div class="mast__content">
      <h2 class="mast__subtitle">The Future of Front End</h2>
      <hr class="sep sep--white">
      <button class="mast__arrow" href="#" data-scroll="section-1" aria-label="Scroll to content"><i class="icon-down" aria-hidden="true"></i></button>
    </div>
  </div>
  <div class="starfield"></div>
</section>

<!-- Results -->
<section id="section-1" class="feeds section--light">
  <header class="feeds__heading  js-clippy">
    <h5 class="feeds__pretitle">Our Journal</h5>
  </header>
  <div class="grid">
    <div class="feeds__grid">
  <?php 
  if ( have_posts() ): while ( have_posts() ) : the_post();
    get_template_part( 'partials/content/content', 'posts' );
  endwhile; else: 
    get_template_part( 'partials/content/content', 'none' );
  endif;?>
    </div>
  </div>
</section>

<!-- Pagination-->
<?php get_template_part( 'partials/posts', 'pagination' );?>

<!-- Footer  --> 
<?php get_footer(); ?>

