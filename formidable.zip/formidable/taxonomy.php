<?php
/**
 *  The defualt tempalte for Taxonomy Archive, which currently 
 *  only pertains to the OSS CPT's 'Categories' cusotm taxonomy.
 *  If additional taxonomies are created, rename this file 'taxonomy-categories.php'
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();$cat = get_term_by( 'slug', 'categories') ?>

<!-- MAIN -->
<main role="main" class="bg--lightgrey">

<!-- MAST -->
<section class="mast mast--taxonomy section--dark">

  <figure class="mast__bg"></figure>

  <div class="mast__content grid u-align-center">
    <span class="mast__subtitle">More From</span>
    <hr class="sep-center sep--white">
    <h2 class="mast__subtitle"><?php single_cat_title( '', true ); ?></h2>
  </div>
  <div class="starfield"></div>
</section>

<?php get_template_part( 'partials/partial', 'cat-filter' );?>

<!-- FEEDS -->
<section id="section-1" class="feeds section--light">
  <div class="grid">
    <div class="feeds__grid">
  <?php 
  if ( have_posts() ): while ( have_posts() ) : the_post();
    get_template_part( 'partials/content/content', 'oss-feed' );
  endwhile; else: 
    get_template_part( 'partials/content/content', 'none' );
  endif;?>
    </div>
  </div>
</section>

<!-- PAGINATION -->
<?php get_template_part( 'partials/partial', 'pagination' );?>

</main>

<!-- FOOTER -->
<?php get_footer(); ?>