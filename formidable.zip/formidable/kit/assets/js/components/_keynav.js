/** 
 * Keynav 
 * Triggers the keynavs for site navigation
 */
(function($) {
  var keyNav = {
    init: function() { 
      $(document).keydown(function(e) { 

        // Bail if inside an input/textarea
        if ($("input, textarea").is(":focus")) return;

        // Bail if Modifier keys
        if (e.metaKey || e.ctrlKey || e.shiftKey) return;
        //home: 1 
        if (e.which === 49) {
          $('a.js-home')[0].click();
        }
        //work: 2  
        if (e.which === 50) {
          $('a.js-work')[0].click();
        }
        //about: 3  
        if (e.which === 51) {
          $('a.js-about')[0].click();
        }
        //careers: 4  
        if (e.which === 52) {
          $('a.js-careers')[0].click();
        }
        //oss: 5  
        if (e.which === 53) {
          $('a.js-oss')[0].click();
        }
        //blog: 6  
        if (e.which === 54) {
          $('a.js-blog')[0].click();
        }
        //contact: 7
        if (e.which === 55) {
          $('a.js-contact')[0].click();
        }
      });
    },
  };
  keyNav.init();
})(jQuery);