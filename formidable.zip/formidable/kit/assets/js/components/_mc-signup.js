/**
 * Mail Chimp Signups
 * Just a simple ajax for mail chimp signups
 */
function register($form) {
  $.ajax({
    type: $form.attr('method'),
      url: $form.attr('action'),
      data: $form.serialize(),
      timeout: 5000, // Set timeout value, 5 seconds
      cache       : false,
      dataType    : 'jsonp',
      contentType: "application/json; charset=utf-8",
      error       : function(err) { $('.signup-notice').html('<span class="alert">Sorry Dave. I can not do that. Try again later.</span>'); },
      success     : function(data) {
      var message;
      
      if (data.result !== "success") {
        message = data.msg.substring();
        $('.signup-notice').addClass("error").fadeIn(300).html('<span class="alert">'+message+'</span>');
      } 

      else {
        message = data.msg;
        $('body').addClass("submit-success");
        $('.signup').addClass("fade-out").fadeOut(500);
        $('.signup-notice').removeClass("error").addClass("success").html('<span class="success">'+message+'</span>');
        
        
        setTimeout(function(){
          $('.signup-notice.success').fadeOut(600); 
         }, 3000); 
      }
    }
  });
}

$(function () {
  var $form = $('#mc-signup');
  $('#mc-submit').on('click', function(event) {
    if(event) event.preventDefault();
    register($form);
  });
});
