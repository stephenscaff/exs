/**
 * Clippy Headings
 * Creates a scrolling cliprect effect on headings,
 * which are fixed positioned in increaing z-index layers
 *
 * @see: sections.scss, extends.scss
 */
(function($) {
  var s,
  clippy = {
    settings: {
      heading: $('.js-clippy'),
    },
    init: function() {
      s = this.settings;
      this.bindEvents();
    },
    bindEvents: function(){
      $(window).on("load resize scroll", $.proxy(this.getClippy, this));
    },

    getClippy: function(){
        s.heading.each(function() {
          var layerOffset = $(this).closest('article, section').offset(),
              containerOffset = layerOffset.top - $(window).scrollTop(),
              clippy = containerOffset - $(this).css("top").replace(/[^-\d\.]/g, '') - $(this).css("margin-top").replace(/[^-\d\.]/g, '');
              $(this).css('clip', 'rect('+ clippy +'px, auto, auto, auto)');
        });
    },
  };
  if ($(window).width() > 600){
    clippy.init();
  }
})(jQuery);
