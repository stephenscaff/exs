/**
 * Offcanvas Menu Nav
 * Toggles the site's main offcanvas nav (same for mobile and desktop)
 * 
 * @version: 1.2 (added 'm' to open)
 * @see: scss/components/layouts/_site-menu.scss
 * @see: js/components/_site-menu.js
 */
(function($) {
  var s,
  menuNav = {
    settings: {
      body: $('body'),
      menuToggle: $('.js-menu-toggle'),
      siteMenu: $('.site-menu'),
      siteMenuActive: 'js-menu--is-open',
      siteMenu_isClosing: 'js-menu--is-closing',
      siteMenu_isOpening: 'js-menu--is-opening',
      main: $('main'),
    },
    init: function() {
      s = this.settings;
      this.bindEvents();
    },
    bindEvents: function(){
      s.menuToggle.click(function(e) {
          e.preventDefault();
          menuNav.toggleMenu();
          s.menuToggle.focus()
        });
        
        $(document).keyup(function(e) {
        if (s.body.hasClass(s.siteMenuActive) && e.which === 27) {
          menuNav.toggleMenu();
        }
        if ($('input, textarea').is(':focus')) {
          return;
        }
        if (e.which === 77) {
          menuNav.toggleMenu();
        }
      });
    },

    toggleMenu: function(){
      if (s.body.hasClass(s.siteMenuActive)){
        s.body.addClass(s.siteMenu_isClosing);
        s.body.toggleClass(s.siteMenuActive);
        s.siteMenu.attr('aria-hidden', 'true');
            s.main.attr('aria-hidden', 'false');
          setTimeout(function(){
            s.body.removeClass(s.siteMenu_isClosing);
        }, 1000);
      } else {
        s.body.addClass(s.siteMenu_isOpening);
        setTimeout(function(){
          s.body.toggleClass(s.siteMenuActive).removeClass(s.siteMenu_isOpening);
          s.siteMenu.attr('aria-hidden', 'false');
          s.main.attr('aria-hidden', 'true');
        }, 100);
        //s.body.toggleClass(s.siteMenuActive);
        // s.siteMenu.attr('aria-hidden', 'false');
        // s.main.attr('aria-hidden', 'true');
      }
    },
  };
  menuNav.init();
})(jQuery);



