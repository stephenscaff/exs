/**
 * Expander
 * The Expander / Viewer thingy on home.
 * @version: 1.2 (added some accessibility/tabbing and keydown stuff)
 */
(function($) {
  var s,
  expander = {

    settings: {
      viewerItem: $('.expander__imgs'),
      expanderItem: $('.expander__info'),
      expanderToggle: $('.js-expander'),
      expanderContent: $('.expander__content'),
    },
    init: function(){
      s = this.settings;
      this.bindEvents();
    },
    bindEvents: function() {
      $('li', s.viewerItem).hide();
      $('li:first-child', s.viewerItem).show();
      //$('li:first-child .expander__content', s.expanderItem).show();
      s.expanderContent.first().show().parent('li').addClass('is-active');
      // @since: v1.2 : on click and keydown (enter)
      $('li', s.expanderItem).on('keypress click',function(e){
        if (e.which === 13 || e.type === 'click') {
          var index = $('li', s.expanderItem).index(this) + 1;
          $('li', s.viewerItem).hide().removeClass('is-active');
          $('li:nth-child(' + index + ')', s.viewerItem).show().addClass('is-active');
        }
      });
      // @since: v1.2 : on click and keydown (enter)
      s.expanderToggle.on('keydown click',function(e){
        if (e.which === 13 || e.type === 'click') {
          $(this).next().slideToggle('fast').parent('li').addClass('is-active');
          s.expanderContent.not($(this).next()).slideUp('fast').parent('li').removeClass('is-active');
        }
      });
    },
  };
  if($(".js-expander").length) {
    expander.init();
  }
})(jQuery);
