/*global jQuery */
/*jshint unused:false */
/**
 * Scroll to Anchor
 * A stupid simple sroll to anchor using data-attributes 
 * Uses data atts to support multiple unique instances.
 *
 * @version: 1.2 (added aria support)
 * @author  Stephen Scaff
 * @example 
  $('html').scrollAnchor({
    offset: '0',
    addActive: 'true',
    complete : function() {},
  });
 */
(function($) {
  
  $.fn.scrollAnchor = function(options, callback) {
    
    // Defaults
    var defualts = $.extend({
      offset: '0',
    }, options);


    return this.each(function() {

      $('[data-scroll]').click(function(e) {
        e.preventDefault();
        var $this = $(this),
            offset = options.offset,
            target = ('#' + $(this).data('scroll')),
            $target = $(target);
        
        //Add active Class
        if (options.addActive) {
          $('a[data-scroll]').removeClass('active');
        }
                
        //Scroll animation
        $('html, body').stop().animate({
          'scrollTop': $target.offset().top - offset
        }, {
            // Duration
          duration: 300,
          // Easing
          easing: 'easeInExpo',
          //Complete callback
          complete: options.complete
        });
        
        //Callback
        $.isFunction( options.setup );
      });
    });
  };
}(jQuery));

/**
 * Init 
 */
$('html').scrollAnchor({
  offset: '0',
});



