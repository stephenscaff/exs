/**
 *  Page Transitions
 *  All sexy like page transitions between page loads
 *  Adds 'is-loading' | 'is-loaded' classes for loading
 *  Adds 'is-exiting' class while exiting
 *  Exclude links with 'no-trans' class
 *
 *  @since    v1.3. New loading classes
 *  @since    v1.2  Added exclude class
 *  @see      scss/utils/animations-transitions.scss
 *  @author   Stephen Scaff and Thomas Vaeth
 */

// Page Transition
var PageTransition = (function() {
  var s;
  var siteURL = 'http://' + top.location.host.toString();

  return {
    settings: {
      noTransLinks: $('a[href^="' + siteURL + '"], a[href^="/"], a[href^="./"], a[href^="../"]').not('.no-trans'),
      linkLocation: null
    },

    init: function() {
      s = this.settings;
      this.removeClass();
      this.transitionPage();
      this.unloadWindow();
      this.workaround();
    },

    removeClass: function() {
      // Remove class to prevent any Webkit bugs
      setTimeout(function(){
        $("body").removeClass("ani-fade-in-page");
      },5100);
    },  

    /** 
     * Transition Page
     */
    transitionPage: function() {
      s.noTransLinks.on('click', function(e) {

        // Bail if modifer keys (must be before preventDefault)
        if (e.metaKey || e.ctrlKey || e.shiftKey) return;
         
        e.preventDefault();

        s.linkLocation = this.href;
        
        function redirectPage() {
          window.location = s.linkLocation;
        }

        $('body').addClass('ani-fade-out').fadeOut(600, redirectPage);;

      });
    },

    /**
     * UnloadWindow
     * So we're not mucking with back button
     */
    unloadWindow: function() {
      // For back button history
      $(window).unload(function() {
        $(window).unbind('unload');
      });
    },
    /** 
     *  
     */
    workaround: function() {
      // For Safari browser
      $(window).bind('pageshow', function(e) {
        if (e.originalEvent.persisted) window.location.reload();
      });
    }
  }
})(); 


PageTransition.init();
