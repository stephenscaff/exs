/**
 * Markdown Lang Converter
 * Class to Language-[language-name] converter.
 * Converts code.[classname] to code.language-[classname]
 * Used to init Prism.js from markdown on single posts
 */
(function($) {
  var classToLang = {
    
    settings: {
      code: $('code'),
    },
     
    init: function(){
      this.settings.code.each(function() {
        var className = $(this).attr('class');
        if(className && !(className.lastIndexOf('language-', 0) === 0)) {
          $(this).attr('class', 'language-' + className);
        }
      });
    },
  };
// Let's Go!
classToLang.init();

})(jQuery);