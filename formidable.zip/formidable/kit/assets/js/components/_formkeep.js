/**
 * FormKeep JS
 */
$(function() {
  $('#contact-form').submit(function(e) {
    // Validation
    var errorMessage  = $('.error-message');
    var errorResponse = $('.error-response');
    var hasError = false;

    $('input:not(:hidden), select').each(function() {
      var $this = $(this);
      
      if ($this.val() === '') {
        e.preventDefault();
        hasError = true;
        $this.addClass('input-error');
        errorMessage.html('<span role="alert" class="contact-form__invalid ani-fade-in">The field is required.</span>');
        e.preventDefault();
      } else if ($this.val() !== '') {
        $this.removeClass('input-error');
      }
    });
    
    if (hasError) {
      errorResponse.html('<div class="contact-form__error-msg ani-fade-in" role="alert">I\'m sorry Dave, but one or more fields has an error. Please check and try again.</div>');
    }
  });
});
