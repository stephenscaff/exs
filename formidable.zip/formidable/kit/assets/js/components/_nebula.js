/**
 * Nebula Canvas
 */
(function($) {
 
  var Nebula = {
    init: function() { 
    // The canvas element we are drawing into.      
    var $nebula = $('#nebula'),
      $nebulaDisplay = $('#nebula-display'),
      $nebulaDraw = $('#nebula-draw'),
      ctx = $nebula[0].getContext('2d'),
      ctx2 = $nebulaDisplay[0].getContext('2d'),
      ctx3 = $nebulaDraw[0].getContext('2d'),
      w = $nebula[0].width,
      h = $nebula[0].height,
      img = new Image();
   
    var Nebuli = function(p) {
      var opacity,
        sy = (Math.random() * 285) >> 0,
        sx = (Math.random() * 285) >> 0;
      
      this.p = p;
      
      this.move = function(timeFac) {
        p = this.p + 0.4 * timeFac;
        opacity = (Math.sin(p * 0.05) * 0.6);
        if (opacity < 0) {
          p = opacity = 0;
          sy = (Math.random() * 285) >> 0;
          sx = (Math.random() * 285) >> 0;
        }
        this.p = p;
        ctx.globalAlpha = opacity;
        ctx.drawImage($nebulaDraw[0], sy + p, sy + p, 285 - (p * 2), 285 -
          (p * 2), 0, 0, w, h);
      };
    };
    var nebulas = [];
    var sortNebuli = function(p1, p2) {
      return p1.p - p2.p;
    };
    nebulas.push(new Nebuli(0));
    nebulas.push(new Nebuli(20));
    nebulas.push(new Nebuli(40));
    var newTime, oldTime = 0,
      timeFac;
    var loop = function() {
      newTime = new Date().getTime();
      if (oldTime === 0) {
        oldTime = newTime;
      }
      timeFac = (newTime - oldTime) * 0.1;
      if (timeFac > 3) {
        timeFac = 3;
      }
      oldTime = newTime;
      nebulas.sort(sortNebuli);
      for (var i = 0; i < nebulas.length; i++) {
        nebulas[i].move(timeFac);
      }
      ctx2.drawImage($nebula[0], 0, 0, 570, 570);
      setTimeout(loop,60);
    };
    
    $(img).bind('load', null, function() {
      ctx3.drawImage(img, 0, 0, 570,570);
      window.requestAnimationFrame(loop);
    });
    img.src =
      '../formidable/wp-content/themes/formidable/assets/images/nebula-bg-2.jpg';
      //'../wp-content/themes/formidable/assets/images/nebula-bg-2.jpg';
  }
};

if($('.home').length && $(window).width() > 600){
    Nebula.init();
}
})(jQuery);



