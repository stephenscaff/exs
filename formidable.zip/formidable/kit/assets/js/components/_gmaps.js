/* jshint undef: false, unused: false, -W020 */
/* global $vcardGmap, google */
/** 
 * Google Maps 
 * Stupid simple Google maps plugin,
 * that parses text into a Gmap, from a vcard.

 * @Usage:
  <section class="js-map">
    <div class="location">Way of the Dog</div>
    <div class="address">527 S. Juanita Ave</div>
    <div class="city">Redondo Beach</div>
    <div class="state">CA</div>
    <div class="zip">90277</div>
    <div class="country">USA</div>
    <div class="phone">310-543-0375</div>
    <div class="zoom">13</div>
  </section>
 */


//Do maps exist?
if ($(".js-map").length) {
  $(function() {
    // Stylers array
    var styles = [{"featureType":"all","elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#000000"},{"lightness":40}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#000000"},{"lightness":16}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":17},{"weight":1.2}]},{"featureType":"landscape","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":15}]},{"featureType":"landscape","elementType":"labels.icon","stylers":[{"saturation":"-100"},{"lightness":"-54"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"ofd"},{"lightness":"0"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":18}]},{"featureType":"poi","elementType":"labels.icon","stylers":[{"saturation":"-89"},{"lightness":"-55"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#000000"},{"lightness":13}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#000000"},{"lightness":29},{"weight":0.1}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":11}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":9}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":19}]},{"featureType":"transit.station","elementType":"labels.icon","stylers":[{"visibility":"on"},{"saturation":"-100"},{"lightness":"-51"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#000000"},{"lightness":7}]}]

    // Render to
    $maps = $('.js-map');
    $maps.each(function(index, Element) {
      $vcardGmap = $(Element);
      //Map vars
      var map;
      var geocoder;
      var marker;
      var infowindow;
      var address = 
      $vcardGmap.children('.address').text() + ', ' + 
      $vcardGmap.children('.city').text() + ', ' + 
      $vcardGmap.children('.state').text() + ' ' + 
      $vcardGmap.children('.zip').text() + ', ' + 
      $vcardGmap.children('.country').text();
      
      // Info Window Content
      var content = 
      '<div class="map-card">' +
      '<span class="map-card__title">' + $vcardGmap.children('.location').text() + '</span>' + 
      $vcardGmap.children('.address').text() + '<br/>' + 
      $vcardGmap.children('.city').text() + '&nbsp;' + 
      $vcardGmap.children('.state').text() + '&nbsp;' + 
      $vcardGmap.children('.zip').text();
      '</div>';
      //If ya got a phone number, add it to the info window
      if (0 < $vcardGmap.children('.phone').text().length) {
        content += '<br />' + $vcardGmap.children('.phone').text();
      }
      geocoder = new google.maps.Geocoder();
      // Geocode that Address son
      geocoder.geocode({
        'address': address
      }, function(results, status) {
        
        // Status check
        if (status === google.maps.GeocoderStatus.OK) {
          vcardGmapOptions.center = results[0].geometry.location;
          map = new google.maps.Map(Element, vcardGmapOptions);
          
          //Marker customizations  
          marker = new google.maps.Marker({
            map: map,
            position: results[0].geometry.location,
            animation: google.maps.Animation.DROP,
            title: $vcardGmap.children('.location').text(),
            icon: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABIRJREFUeNqsV0lMZGUQrl5otrBvYUkA2cMWYOAAGJEOnjh7MCbGiyflPpmYaMwYjwYzGuegJ28zp0nsCNixBQFliYEgIDTYgDSEtVm76Qb8vpc8fOnp9Q2VVLrfe//766uqr6r+Z7i9vZVQMjAwIAaDQfx+vxwdHcnFxYWcnZ2Zjo+PH2xvb1tPTk5ew7tmLA1kZGS48vPzfy4oKPgjMTExkJqaKllZWWKxWIT7Dw4OSjgxSwySkJAgHo+nZWFh4Quv12vNzs421dXVKQaurq7k4OBA1tbWPgEwB+4/BKDfCT4WMcdifH19/b2ZmZmnFRUVlo6ODsnNzRWz+f9XA4GAHB4eGqempt6cnp7+DVH7qL29/ZtXBkDjc3Nz78P4d1arVZqamuTm5kaur68Vz1WhtwTV398viJJpaGjo6+TkZGNra+sT7bq4ANDQ5ubmg7GxsW/7+voU4z6fT0JxhvcYBQJraGgQo9EoNpvtK/BgrqioaDQSAGO4ByTdxMTE48rKyoTGxkZB7iUcYbVAuI78qK2tNUxOTn5+enpq1gVgY2PjdZDrLeacnsUjjAbfA3G7wR+rrhSsrKy8kZOTo+Q2GMDu7i5zTXJKeXm51NfXC0rw7jnXo1IEpcl9unDrp7gjsLe3V8pNTCbTS6Gn8eXlZYWI/OV1sJCYdAB9o0hXChgdVkGoeqbnka5VYZ+AmPQC8IVjPcMe6VqVy8tL/vh1cQDls7q/v68QilHQAmHOVc9VDgSHnzzg++CBSxeA6upqu8PhuHK73ZaSkhJlJqhCwmlJFyzkDYmKKrrt6upy6EoBCDRbWFj4fHx8/M6rWITr2IjQQ+j9CwAd0wUgMzNTOjs7P4YnR2goKqGiCtdhHrCPnOH9h9xHFwB6AQ+cvb29bwOAl5ti1EbcjM8xO2R0dDTQ09PzDiL4F/fRPYyY96qqqhEQ6l273f6M3mAiSqgBw5LF7JCRkRHp7u7+AO34RbRBFDECZDGVvb2mpuY5htGnw8PDgt6ukCw47zSGKci1T7D2e16zcqLND2Okaagq6xmj9bOkpKRJTMeXANB7jGw2jrW2trZH5+fnCiBGUFs9cQGg51pFNK5bWloeLS0tyc7Ozt2BhDlmVGZnZ6W5ufkx7nvYwAhAVV0AuIlWcR7kYLJDf6S3KrkIZHFxkVH5G/3iB45xNi+t6gLAMAcrjYJcXzqdTg4Z5R5DPD8/Lzg3PEUqfGretaoLAPMerIxCenr6LzDsRJ0rNc+OhxR4S0tLn5EvJGSwvlIVaJXhRBT86A+21dVVJQIul0vS0tKm4b2LXNHmPhYOmCP1gHDVQR7gHPAh2c7ax7WNhqLlOy4A4XLHSMDjP2HsAt8BKTh2SXFx8a/qofTeANC7CAPHDfZvIvw1AOpJSUlZpPFohIuLA6HYrCqJBQL+u7W1xTLcgh4wNeHW33sESD6A2MfXkOA70M3aJwA9YtbzEr2i1yQqDJ/w4/XeAeTl5YV/Cd0PEdrhkQsT0l1WVqarAiICiHQAIQAQ7x/+x+9SqKN7rPKfAAMAeEr6Wg15E0MAAAAASUVORK5CYII='
          });
          
          //Create tile/info window
          infowindow = new google.maps.InfoWindow({
            'content': content
          });
          google.maps.event.addListener(map, 'tilesloaded', function(event) {
            infowindow.open(map, marker);
          });
          
          //Click marker to open tile
          google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map, marker);
          });
          
          // Stay centered on resize
          google.maps.event.addDomListener(window, "resize", function() {
            var center = map.getCenter();
            google.maps.event.trigger(map, "resize");
            map.setCenter(center);
          });
        } else {
          // Alert if map fails
          alert('Google maps error: ' + status);
        }
      });

      /**
       * Options
       */
      var vcardGmapOptions = {
        //Set zoom within vcard
        'zoom': parseInt($vcardGmap.children('.zoom').text()),
        'mapTypeId': google.maps.MapTypeId.ROADMAP,
        'mapTypeControl': false,
        'scrollwheel': false,
        'disableDefaultUI': false,
        'styles': styles
      };
    });
  });
}
