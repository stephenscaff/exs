/** 
 * Scolling Nav effect
 * Adds classes to body on scroll so
 * we can do fancy css things
 */
(function($) {
 
  var scrollingNav = {
    
    init: function() {     

      // Set a flag
      var scrolledDown;

      $(window).scroll(function(){
        scrolledDown = true;
      });

      // Throttle our on scroll
      setInterval(function() {
        if (scrolledDown) {
          hasScrolled();
          scrolledDown = false;
        }
      }, 350);

      // Our scroll action
      function hasScrolled() {

        // Get height
        var scrollDistance = $('.mast, .folio, .post-mast').height();

        // Get top
        var scrolling = $(window).scrollTop();

        // Toggle class logic
        (scrolling >= scrollDistance) ? $('body').addClass('has-scrolled') : $('body').removeClass('has-scrolled');
      }
    },
  };
scrollingNav.init();

})(jQuery);