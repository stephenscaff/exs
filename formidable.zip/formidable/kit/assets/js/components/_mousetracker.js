/**
 * MouseTracker
 * Tracks mouse coords for the effect on home, work CTA
 */
(function($) {
  var mouseTracker = {
    init: function() { 
      
      $(document).mousemove(
      function(e) {
        // get current mouse position
        var mouseX = Math.round(e.pageX),
            mouseY = Math.round(e.pageY);

        // display the position in the HTML
        $('#js-coords-x').text(mouseX);
        $('#js-coords-y').text(mouseY);
      }
    );  
  },
};
// Let's Go
if($("#js-coords-x").length) {
  mouseTracker.init();
}
})(jQuery);


