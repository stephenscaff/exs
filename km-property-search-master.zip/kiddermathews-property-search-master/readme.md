# KidderMathews Property FrontEnd

## A static build of the property search elements

Had been upgraded to an es6 project using Babel and Browserfy. The `gulpfile.js` and `packages.json` have both been updated. Note that the project is using Gulp v3.9.1. Also not the the dependecy `gulp-uglifyes` is throwing warnings to update to Tracer. However, Tracer was having issues with options, so I rolled back to keep `gulp-uglifyes` for now.


### Dependencies
- [Gulp.js](http://gulp.js.com/) : For css/js compiling, and other task management stuff.
- [Handlebars.js](http://handlebarsjs.com/) : For compiling of partials and client-side templates (static dev purposes only).
- [Google Maps API](http://googlemaps.com/) : For Demo rendering of the property map

### Run

Just Run `npm install --save-dev`

`src` will build into `dist`.

A simple live server is included in the project via `gulp-live-server` serving on port `7777`.

So, you can access the site at [http://127.0.0.1:9991/](http://127.0.0.1:9991/)

### A Static Front-end

This project mainly serves to establish the base front-end styles of the KidderMathews Property Search App.
Primary focus was on visual design and css to support the UI design.

Many of the styles were established during the build of the CMS-based marketing site, and were simply rolled into this project.

It's understood that modifications will have to be made when integrating this into the final React App, so see this project as a jump off point more than a final destination.

Of course, if more css authorship is required by GreenRubino, please don't hesitate to ask.


### Project JS

Project javascript was mainly for dev purposes only. Considering that the final project will be a React build,
I didn't want to make too many options or assumptions or go to far down the path of DOM-dependent js. I'd imagine essentially
none of this projects JS would carry over into the final app.

Additionally, since KidderMathew's internal developer anticipates maintaining the marketing site code after delivery,
this influenced some of the development decisions in an effort to keep things as simple and flat as possible.

For example, all js is in ES5 (no Babel or ES6 flavors), and written in self-contained 'modules' to keep authorship simple.


### Filters and Forms

The actual filters and form elements were left out of the project, as I'd imagine the final app would have
some react-port of some form library (choices.js, etc). However, if that turns out not to be the case, and you'd like
me to write some css/js to handle filters and form elements (checks, range sliders, etc), I'm more than happy to handle.


### Project Organization

The majority of components are housed in Handlebars partials, and compiled via Gulp.
Each component is named after it's UI purpose, with supporting SCSS organized in a similarly named fashion.


```
src/
 |- Assets
    |- JS
       |- app.js : included js files, using gulp-include
       |- components/ : UI components organized as es5-style 'modules'
          |- drawers.js : A resuable drawer component
          |- render-hbs.js : A utility to render hbs template with fake data (for dev)
          |- properties-map.js : google maps js for map views

   |- SCSS
       |- _config.scss : scss variables
       |- app.scss : scss imports
       |- base : base level styles
       |- components : ui components
          |- _app-header.scss
          |- _app-header.scss
          |- base : base level styles
       |- fonts : base64'd font imports
       |- tools : extends and mixins
       |- utils : utility and helpers

  |- Templates  : handlebars template files for client-side rendering of our fake data.
       |- listing-card.hbs : hbs template for the listing card component
       |- listing-marker.hbs : hbs template for the map marker component

 |- Pages
    |- index.hbs
    |- single.hbs

 |- Partials : HBS partials for gulp-based compiling
    |- app-head.hbs : the main head element and content
    |- app-header.hbs : the app's primary header component
    |- app-menu-sm.hbs : mobile menu component
    |- properties-map.hbs : properties map view
    |- properties-sidebar.hbs : properties sidebar of listing cards"
    |- properties-split-view.hbs : the main app split view of sidebar and map
    |- etc...
```

### JS Loading

The project now uses es6 modules and imports/exports. `app.js` is used as the main entry point where all js modules are imported and initialized.


### HBS Partials

As mentioned, views/components are organized into HBS partials. For example,

For example, `single.hbs` is the Property Single View. It's contents of hbs partials includes looks like:
```
<!--
# Single Property View
-->
{{> app-head}}
{{> app-header}}
{{> app-menu-sm}}

<main class="has-header-offset">

{{> property-mast}}
{{> property-header}}

<section class="property-content">
  <div class="grid-lg">
    <div class="property-content__grid">
      <section class="property-content__main">
        {{> property-overview}}
        {{> property-available}}
        {{> property-map}}
      </section>

      <aside class="property-content__sidebar">
        {{> property-sidebar}}
      </aside>
    </div>
  </div>
</section>

</main>

{{> app-footer}}
```

All of the partial includes, ie: `{{> property-map}}`, follow standard Handlebars partials syntax and reference a component found with the `src/partials` directory.


### Professionals API

In the event that the main property search app needs to import professionals-related info/data, that exists in the CMS only, I've opened up the Professional content type via api.

For testing purposes, that endpoint for the staging build is available at:

[http://staging-kiddermathews.kinsta.cloud/wp-json/wp/v2/professionals](http://staging-kiddermathews.kinsta.cloud/wp-json/wp/v2/professionals)

Eventually, the endpoint will be at:

[http://kiddermathews.com/wp-json/wp/v2/professionals](http://kiddermathews.com/wp-json/wp/v2/professionals)

We can discuss this further and integrate any desired fields.


## Filters - Ranges

The Range slider lib [JSR](https://github.com/mm-jsr/jsr) has been introduced.


See `src/js/components/Filters/ranges.js` for how the ranges are initialized and their instance returned.
The actual range elements, are found in `src/partials/control-bar.hbs`

`src/js/components/Filters/index.js` for how the ranges are used to create an object to return the [min,max'] values.

A helper `getRangeVals()` located in `src/js/components/Filters/helpers.js` is used to snag the [min,max] for each range instance.


### Example of object
```
{
  rent: ["500", "2000"],  ([min,max] in dollars)
  size: ["400", "5000"],  ([min,max])
  leaseRate: ["1000", "3000"], ([min,max])
  capRate: ["1000", "3000"],  ([min,max])
}
```

### Calling update method

```
import Filters from './components/Filters/_index.js'

Filters.update();
```

### Potential Caveats with Mobile

The range wants an ID to create each instance it appears. So, not sure how to handle mobile instances. Might have to create separate instances that are initialized and destroyed off of media query listeners?

The plan is to combine all filters into a mobile drawer with accordions.

## Search Mast

The main search page has been added to `pages/search.hbs`.

The plan with this is to eventually hook up autocomplete to the provided endpoints.


## Filter Dropdowns.

Filter Dropdowns are a UI component somewhere between a scrollable modal and an actual dropdown.
They house the various form filters and allow for overflow vertical scrolling.

Focus Support should be implemented.


## Properties List View.

Not sure if this should should be done with css, or if a seperate list view template can be injected on click?
If the later, I can create that template. If the former, I'll write the required styles and use an 'is-list' state class added to the container.
