/**
  * Drawers
  * Handles intro/close of 'Drawers' / full viewport sections
  * via data attribute on link el that refs scene id.
  * Includes Gooey SVG path animation via Anime.js
  *
  * @author stephen scaff
  */
const Drawers = (() => {

   const html =        document.querySelector('html');
   const drawerLinks = document.querySelectorAll('[data-drawer]');
   const closeLinks =  document.querySelectorAll('.js-close-drawer');
 	 let isOpen = 			 false;

   return {

     /**
      * Init
      */
     init() {
       this.bindEvents();
     },

     /**
      * Bind Events
      */
     bindEvents() {
 			Drawers.handleClicks();
     },

     /**
      * Handle Clicks
      */
 		 handleClicks() {

       drawerLinks.forEach((drawerLink) => {

         // Main Click to Open Event
         drawerLink.addEventListener('click', function(e) {
           e.preventDefault();

           let targetDrawer = drawerLink.dataset.drawer;
           let targetDrawerId = document.querySelector('#' + targetDrawer);

           if (isOpen !== true) {
             Drawers.open(drawerLink, targetDrawerId);
           }

           if (isOpen == true) {
             Drawers.close(drawerLink, targetDrawerId);
           }

           // Manual Click close
           closeLinks.forEach((closeLink) => {
             closeLink.addEventListener('click', function(e) {
               e.preventDefault();

               Drawers.close(drawerLink, targetDrawerId);
             });
           });

           // Manual Esc close
           window.onkeydown = function(e) {
             if (e.keyCode === 27) {
               Drawers.close(drawerLink, targetDrawerId);
             }
           }
         });
       });
 		},


     /**
      * Open Drawer
      */
     open(link, id) {
       html.classList.remove('drawer-is-closed');
       id.classList.remove('is-closed');
       html.classList.add('drawer-is-opening');
       id.classList.add('is-opened');
       link.classList.add('is-opened');

       setTimeout(function(){
         html.classList.remove('drawer-is-opening');
         html.classList.add('drawer-is-opened');
         isOpen = true;
       }, 200);
     },

   /**
    * close
    */
   close(link, id) {
     html.classList.add('drawer-is-closing');
     id.classList.add('is-closing');

     setTimeout(function(){
       html.classList.remove('drawer-is-opened');
       id.classList.remove('is-opened');
       html.classList.remove('drawer-is-closing');
       id.classList.remove('is-closing');
       link.classList.remove('is-opened')
       html.classList.add('drawer-is-closed');
       id.classList.add('is-closed');

       isOpen = false;
     }, 200);
   },
 };
})();

export default Drawers;
