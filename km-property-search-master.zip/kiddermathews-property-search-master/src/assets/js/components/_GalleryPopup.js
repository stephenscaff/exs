import Siema from './_Siema.js'

/**
 * Gallery Popup
 * Gallery slider popup featured on single property pages
 */
const GalleryPopUp = (() => {

  return {

    init() {
      this.render();
    },

    render(){

      const trigger = document.querySelector('.js-gallery-trigger');
      const prev = document.querySelector('.js-gallery-prev');
      const next = document.querySelector('.js-gallery-next');

      trigger.addEventListener('click', function(){
        const mySiema = new Siema({
          duration: 150,
        });

        prev.addEventListener('click', () => mySiema.prev());
        next.addEventListener('click', () => mySiema.next());

        document.addEventListener('keydown', (e) => {

          if (e.keyCode === 37) {
            mySiema.prev()
          }

          else if (e.keyCode === 39) {
            mySiema.next()
          }
        })
      });
    }
  }
})();

export default GalleryPopUp;
