/**
 * Get Range Values
 * @param {object} - range element object
 * @return {[number,number]} min, max values of range
 */
export function getRangeVals(range){
  const min = range.inputs[0].value;
  const max = range.inputs[1].value;

  return [min, max]
}

export function setRangeVals(range,values) {
    range.inputs[0].value = values[0];
    range.inputs[1].value = values[1];
    range.refresh();
}

/**
 * GetCheckedVals
 * @param {element} checks - collection of checkboxes
 * @return {array} checked checkboxes
 */
export function getCheckedVals(checks) {

 return Array.from(checks)
 .filter((checkbox) => checkbox.checked)
 .map((checkbox) => checkbox.value);
}

export function withCommas (value) {
    return value  ? value.toLocaleString("en") : '0';
}
