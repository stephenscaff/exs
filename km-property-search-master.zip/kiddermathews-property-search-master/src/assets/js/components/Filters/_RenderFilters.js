
import RenderHBS from '../../components/_RenderHBS.js'

/**
 * Render Properties
 * Render property cards and markers from fake data.
 * Just to help with the static front-end dev
 * Using Handlbars client-side compiling.
 *
 * @see js/components/_render-hbs.js - a little hbs rendering util.
 */
const RenderFilters = {

    propertyTypeFilters(types,callback) {
        const renderEl = document.querySelector('#property-type-filters');
        const template = 'assets/templates/property-type-filter.hbs';
        const dataArray = this.toDataArray(types,'propertyTypes');
        RenderHBS.render(dataArray, renderEl, template,true,callback)

    },

    spaceTypeFilters(types,callback) {
        const renderEl = document.querySelector('#space-type-filters');
        const template = 'assets/templates/space-type-filter.hbs';
        const dataArray = this.toDataArray(types,'spaceTypes');

        RenderHBS.render(dataArray, renderEl, template,true,callback)

    },

    propertyClassFilters(types) {
        const renderEl = document.querySelector('#property-class-filters');
        const template = 'assets/templates/property-type-filter.hbs';
        const dataArray = this.toDataArray(types,'propertyClasses');
        RenderHBS.render(dataArray, renderEl, template,true)

    },

    toDataArray (array,groupName) {
        return Object.keys(array).map((key,i) => {
                return {
                    inputGroup: groupName,
                    value: array[i].value,
                    displayName: array[i].display,
                    checked: array[i].selected ? 'checked' : '',
                    disabled: typeof array[i].disabled === 'boolean' ? array[i].disabled : false
                }
            });
    }
};

export default RenderFilters;
