import JSR from './_JSR.js'
import {withCommas} from "./_helpers";


/**
 * Init Range Slider for rent and sqft
 * Object's methods are used to get and pass [min, max] vals
 * in the primary Filters obj in index.js
 *
 * @see JSR range lib - https://github.com/mm-jsr/jsr
 */

const DEFAULT_PRICE_VALUES = [0, 500000000];
const DEFAULT_SIZE_VALUES = [0, 1000000];
const DEFAULT_LEASE_RATE_VALUES = [0,500];
const DEFAULT_CAP_RATE_VALUES = [0, 5000];//[0, 10000000];

const Ranges = {


  /**
   * Price
   * Inits the range sliders for Rent min/max
   * @return {obj} Rangeslider option
   */
  price() {

    if (!document.querySelector('#js-range-price-1-1')) return;

      const jsr =  new JSR(['#js-range-price-1-1', '#js-range-price-1-2'], {
          sliders: 2,
          step: 1000,
          min: DEFAULT_PRICE_VALUES[0],//0,
          max: DEFAULT_PRICE_VALUES[1],//10000000,
          values: DEFAULT_PRICE_VALUES,//[0, 10000000],
          labels: {
              formatter: (value) => {
                  return '$' + withCommas(value);
              }
          },
          limit: { show: true },
          grid: false
      });
    return jsr;
  },

  /**
   * Size
   * Inits the range sliders for Sqft min/max
   * @return {obj} Rangeslider option
   */
  size() {
    if (!document.querySelector('#js-range-size-1-1') ) return;

    const jsr =  new JSR(['#js-range-size-1-1', '#js-range-size-1-2'], {
      sliders: 2,
      step: 500,
      min: DEFAULT_SIZE_VALUES[0],//0,
      max: DEFAULT_SIZE_VALUES[1],//1000000,
      values: DEFAULT_SIZE_VALUES,//[0, 1000000],
      labels: {
        formatter: (value) => {
          return withCommas(value)+ ' SF';
        }
      },
      limit: { show: true },
      grid: false
    });

    return jsr;
  },

  /**
   * Lease Rate
   * @return {obj} Rangeslider option
   */
  leaseRate() {
    if (!document.querySelector('#js-range-leaserate-1-1') ) return;

    const jsr =  new JSR(['#js-range-leaserate-1-1', '#js-range-leaserate-1-2'], {
      sliders: 2,
      step: 10,
      min: DEFAULT_LEASE_RATE_VALUES[0],//0,
      max: DEFAULT_LEASE_RATE_VALUES[1],//5000,
      values: DEFAULT_LEASE_RATE_VALUES,//[0,5000],//[100, 5000],
      labels: {
        formatter: (value) => {
          return '$' + withCommas(value);
        }
      }, limit: { show: true },
      grid: false
    });

    return jsr;
  },

  /**
   * Cap Rate
   * @return {obj} Rangeslider option
   */
  capRate() {
    if (!document.querySelector('#js-range-caprate-1-1') ) return;

    const jsr =  new JSR(['#js-range-caprate-1-1', '#js-range-caprate-1-2'], {
      sliders: 2,
      step: 10,
      min: DEFAULT_CAP_RATE_VALUES[0],//0,
      max: DEFAULT_CAP_RATE_VALUES[1],//5000,
      values: DEFAULT_CAP_RATE_VALUES,//[0, 5000],
      labels: {
        formatter: (value) => {
          return value.toString();
        }
      },
      limit: { show: true },
      grid: false
    });

      return jsr;
  },
}

export default {
  Ranges,
  DEFAULT_PRICE_VALUES,
  DEFAULT_SIZE_VALUES,
  DEFAULT_LEASE_RATE_VALUES,
  DEFAULT_CAP_RATE_VALUES

};
