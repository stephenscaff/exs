import RangeUtils from './_ranges.js'

import {getRangeVals, getCheckedVals, setRangeVals} from './_helpers.js'


/**
 * Filters
 * Handles returning a object of values for apartment filtering
 */
const Filters = (() => {

  const rent = RangeUtils.Ranges.price();
  const size = RangeUtils.Ranges.size();
  const leaseRate = RangeUtils.Ranges.leaseRate();
  const capRate = RangeUtils.Ranges.capRate();
  //const floors = document.getElementsByName('floor[]');



  return {

    reset () {
        setRangeVals(rent,RangeUtils.DEFAULT_PRICE_VALUES);
        setRangeVals(size,RangeUtils.DEFAULT_SIZE_VALUES);
        setRangeVals(leaseRate,RangeUtils.DEFAULT_LEASE_RATE_VALUES);
        //setRangeVals(capRate,RangeUtils.DEFAULT_CAP_RATE_VALUES);
        Filters.update();

    },
    init() {
      this.update();
      this.listeners();
    },

    /**
     * Primary Update method to create and return
     * the filter object of values for each val.
     * Call Filters.update().
     * see _helpers.js for get vals helpers
     */
    update(){

      const obj = {
        'rent'      : getRangeVals(rent),
        'size'      : getRangeVals(size),
        'leaseRate' : getRangeVals(leaseRate),
        //'capRate'   : getRangeVals(capRate)
        //'space'   : getCheckedVals(space)
      }

      return obj;
    },

    registerUpdateListener(eventListener) {

      rent.addEventListener('update',eventListener);
      size.addEventListener('update',eventListener);
      leaseRate.addEventListener('update',eventListener);
      //capRate.addEventListener('update',eventListener);
    } ,
    /**
     * Collection of listeners that call and update our Filters object.
     */
    listeners() {

      // Rent Range
      rent.addEventListener('update', (input, value) => {
        Filters.update();
      });

      // Size SQft ranges
      size.addEventListener('update', (input, value) => {
        Filters.update();
      });

      leaseRate.addEventListener('update', (input, value) => {
        Filters.update();
      });

      // capRate.addEventListener('update', (input, value) => {
      //   Filters.update();
      // });


      // Space checks
      // floors.forEach((space) => {
      //   floor.addEventListener('change', () => {
      //     Filters.update();
      //   });
      // });
    },
  }
})();

export default Filters;
