/**
  * ResultsControls
  * A grouped collection of Controls and utils for Results
  * @author stephen scaff
  */
const PageTransitions = (() => {

  return {

    settings: {
      html: document.querySelector('html'),
      body: document.querySelector('body'),
      exitDuration: 900,
      classes: {
        loading: 'is-loading',
        loaded: 'is-loaded',
        exiting: 'is-exiting'
      }
    },

    /**
     * Combine our methods here
     * to allow a single init on the default export.
     */
    init() {
      this.entrance();
    },

    exit() {},

    loading() {
      this.settings.html.classList.add(this.settings.classes.loading);
    },

    loaded() {
      this.settings.html.classList.remove(this.settings.classes.loading);
      this.settings.html.classList.add(this.settings.classes.loaded);
    }
  };
})();

export default PageTransitions
