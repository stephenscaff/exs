
import RenderHBS from '../components/_RenderHBS.js'

/**
 * Render professionals
 * Hit the Professionals API to return Broker info and render it as hbs partial
 */
const RenderProfessionals = (() => {

  return {

    /**
     * Init
     * Just an init that passes params to the render function
     * @param brokersData {obj} - Current Brokers Object
     */
    init(brokersData){
      this.render(brokersData);
    },

    /**
     * Get Api Helper
     * @return api url between envs
     */
    getApiUrl() {
      const baseUrl = window.location.origin;

      if (baseUrl == 'http://staging-kiddermathews.kinsta.cloud' ||
          baseUrl ==  'https://staging-kiddermathews.kinsta.cloud') {
        return 'https://staging-kiddermathews.kinsta.cloud/wp-json/wp/v2/professionals';
      }
      else if (baseUrl == 'https://kidder.com' ||
               baseUrl == 'kidder.com') {
        return 'https://kidder.com/wp-json/wp/v2/professionals';
      }
      else if (baseUrl == 'http://localhost:9999' ||
               baseUrl == 'http://127.0.0.1:9999') {
        return 'http://127.0.0.1/kiddermathews/wp-json/wp/v2/professionals';
      }
    },

    /**
     * Get Emails
     * Helper to grab broker email address to complete api request.
     * @param data {obj} - Current Brokers Object
     * @return Broker Emails, comma seperated
     */
    getEmails(data) {
      let brokers = data;
      var arry = new Array();
      brokers.forEach((broker, index) => {
        if (broker == null) return;
        let brokerEmail = broker.brokerAgentKey.person.personContactInfo.emailAddress;

        arry.push(brokerEmail);
      });
      return arry.join(',');
    },

    /**
     * Render
     * Makes our fetch request to professionals api, renders as hbs partial
     * @param brokersData {obj} - Current Brokers Object
     */
    render(brokersData) {

      let brokerEmails  = RenderProfessionals.getEmails(brokersData);
      const prosApi     = RenderProfessionals.getApiUrl();
      const prosRequest = `${prosApi}?meta_key=professional_email&meta_value[]=${brokerEmails},`;
      console.log('prosRequest', prosRequest)

      fetch(prosRequest)
        .then((resp) => resp.json())
        .then(function(data) {
          console.log('fetched pros', data)
          const proTemp ='assets/templates/partials/property-sidebar-pros.hbs';
          const proEl = document.querySelector('#js-pros');
          RenderHBS.render(data, proEl, proTemp);
      });
    }
  };
})();

export default RenderProfessionals;
