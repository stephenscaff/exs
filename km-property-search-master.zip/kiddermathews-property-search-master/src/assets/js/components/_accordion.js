import Utils from '../components/_Utils.js'

/**
 * Accordion
 * Accordion-like UI for the main mobile/sm nav.
 */
const Accordion = (() => {

  const accordion = document.querySelector('.accordion');
  const sub = document.querySelector('.accordion__content');
  const activeClass = 'is-active';
  let isOpen = false;

  return{

    /**
     * Init
     */
    init() {
      if (!accordion) return;
      this.bindEvents();
    },

    /**
     * Bind Events
     */
    bindEvents() {
      let triggers = accordion.querySelectorAll('.js-accordion-trigger');

      Utils.forEach(triggers, function (index, trigger) {

        trigger.addEventListener('click', function (e) {
          e.stopPropagation();

          const activeTrigger = accordion.querySelector('.accordion__item'+'.'+activeClass);
          const triggerParent = trigger.parentElement;
          const clickedContent = trigger.parentElement.querySelector('.accordion__content');
          const targetEl = trigger;
          const clickedElement = e.target.parentElement;

          Accordion.toggle(trigger, activeTrigger, targetEl, triggerParent, clickedElement);
        });
      });
    },

    /**
     * Toggle
     * Main accordiion-like action
     */
    toggle(trigger, activeTrigger, targetEl, triggerParent, clickedElement) {

      let subs = document.querySelectorAll('.accordion__item');

      if (clickedElement.classList.contains('is-active')) {
        clickedElement.classList.remove('is-active');
        return;
      }

      Utils.forEach(subs, function (index, sub) {
        sub.classList.remove(activeClass);
      });

      triggerParent.classList.add(activeClass);
    },
  };
})();

export default Accordion;
