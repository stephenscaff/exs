/**
 * Debug Helper
 * Logs data of current context
 */
 Handlebars.registerHelper('debug', function() {
  console.log('Current Context');
  console.log('====================');
  console.log(this);
});

/**
 * Get Base URL Helper
 * @return string base url
 */
Handlebars.registerHelper('getBaseUrl', function () {
  let base = window.location.origin + '/' + window.location.pathname.split ('/') [1] + '/';
  return new Handlebars.SafeString(base);
});

Handlebars.registerHelper('getPageUrl', function () {
    return encodeURIComponent(window.location.href);
});

Handlebars.registerHelper('ifCond', function(v1, v2, options) {
 if (v1 === v2) {
   return options.fn(this);
 }
 return options.inverse(this);
});

Handlebars.registerHelper('iflt', function (v1, v2, options) {
 if(v1 < v2) {
   return options.fn(this);
 }
 return options.inverse(this);
});

Handlebars.registerHelper('ifgt', function (v1, v2,options) {
    if (typeof v1 !== "undefined"  && v1 > v2) {
        return options.fn(this);
    }
    return options.inverse(this);
});

Handlebars.registerHelper('ifLcIncludes', function (v1, v2, options) {
 if (v1 && v2) {
   const lowercaseV1 = v1.toLowerCase();
   const lowercaseV2 = v2.toLowerCase()

   if (lowercaseV1.includes(lowercaseV2)) {
     return options.fn(this);
   }
 }
 return options.inverse(this);
});

Handlebars.registerHelper('ifNotEmpty', function (v1, options) {
 if (typeof v1 !== "undefined" && v1 !== null) {
   return options.fn(this);
 }
 return options.inverse(this);
});

Handlebars.registerHelper('displayCond', function (v1) {
 if(v1 ) {
   return new Handlebars.SafeString(v1);
 } else {
   return new Handlebars.SafeString("<b>-</b>");
 }
});

Handlebars.registerHelper('displayCondNotZero', function (v1) {
    if(v1 && v1 != 0) {
        return new Handlebars.SafeString(v1);
    } else {
        return new Handlebars.SafeString("<b>-</b>");
    }
});

Handlebars.registerHelper('formatNumber', function (v1) {
 if(v1) {
   return (typeof(v1) === 'number' ? new Handlebars.SafeString(v1.toLocaleString('en')) : new Handlebars.SafeString(Number(v1).toLocaleString('en')))
 } else {
   return new Handlebars.SafeString("<b>-</b>");
 }
});

Handlebars.registerHelper('formatMoney', function (v1) {
    if(v1) {
        return '$'+ (typeof(v1) === 'number' ? new Handlebars.SafeString((Math.round(v1*100)/100).toFixed(2)) : new Handlebars.SafeString((Math.round(Number(v1)*100)/100).toFixed(2)));
    } else {
        return new Handlebars.SafeString("<b>-</b>");
    }
});

Handlebars.registerHelper('displayCapRate', function (v1) {
    if(v1) {
        return (typeof(v1) === 'number' ? new Handlebars.SafeString((Math.round(v1*100)/100).toFixed(2)) : new Handlebars.SafeString((Math.round(Number(v1)*100)/100).toFixed(2))) + '%';
    } else {
        return new Handlebars.SafeString("<b>-</b>");
    }
});

Handlebars.registerHelper('displayBoolYorN', function (v1) {

    if(v1 ) {
        return new Handlebars.SafeString(v1 === true ? 'Y':'N');
    } else {
        return new Handlebars.SafeString("N");
    }
});

Handlebars.registerHelper('formatUrl', function (v1) {
    if(v1) {
        return v1.toLowerCase().startsWith('http') ? new Handlebars.SafeString(v1) : new Handlebars.SafeString('http://'+v1);
    } else {
        return new Handlebars.SafeString("");
    }
});

Handlebars.registerHelper('ifArrayIncludes', function (v1, v2, options) {

    const values = v1.split(',').map(x=> {
        if (x) return x.toLowerCase();
    });

    const lowerV2 = v2 ? v2.toLowerCase() : v2;

    if (values.includes(lowerV2)) {
        return options.fn(this)
    } else {
        return options.inverse(this);
    }
});

Handlebars.registerHelper('trimWhitespace', function (v1) {
    if(v1) {
        return new Handlebars.SafeString(v1.trim());
    } else {
        return new Handlebars.SafeString("");
    }
});

Handlebars.registerHelper('decodeHTMLEntities', function () {

  let entities = [
      ['amp', '&'],
      ['apos', '\''],
      ['#x27', '\''],
      ['#x2F', '/'],
      ['#39', '\''],
      ['#47', '/'],
      ['lt', '<'],
      ['gt', '>'],
      ['nbsp', ' '],
      ['quot', '"']
  ];

  for (let i = 0, max = entities.length; i < max; ++i)  {
    text = text.replace(new RegExp('&'+entities[i][0]+';', 'g'), entities[i][1]);
  }

  return new Handlebars.SafeString(text);
});
