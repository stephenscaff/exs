
import RenderHBS from '../../components/_RenderHBS.js'


/**
 * Render Properties
 * Render property cards and markers from fake data.
 * Just to help with the static front-end dev
 * Using Handlbars client-side compiling.
 *
 * @see js/components/_render-hbs.js - a little hbs rendering util.
 */
const RenderProperties = {


  /**
   * Renders fakie listings cards within hbs partial.
   * @see components/_render-hbs.js
   */
  cards(data) {

    const listingsRenderEl = document.querySelector('#js-listing-cards');
    const listingsTemplate = 'assets/templates/listing-card.hbs';
    RenderHBS.render(data.results, listingsRenderEl, listingsTemplate,true)

    const resultCountEl = document.querySelector('#result-count');
    const resultCountTemplate = 'assets/templates/result-count.hbs';
    RenderHBS.render(data, resultCountEl, resultCountTemplate,true)

    const loadMoreEl = document.querySelector('#load-more-container');
    const loadMoreTemplate = 'assets/templates/load-more-link.hbs';
    RenderHBS.render(data, loadMoreEl, loadMoreTemplate,true)
  },

  /**
   * Renders fakie listings Map Markers within hbs partial.
   * @see components/_render-hbs.js
   */
  markers(data) {

    const markerRenderEl = document.querySelector('#js-listing-markers');
    const markerTemplate ='assets/templates/listing-marker.hbs';
    RenderHBS.render(data, markerRenderEl, markerTemplate,true)
    console.log('Map data', data)
  }
};

export default RenderProperties;
