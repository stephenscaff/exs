import GoogleMapsApi from './_GoogleMapsApi';
import { stylers }   from './_stylers.js';
import MarkerTmpl from './_MarkerTmpl.js';


/**
 * MapInit
 * Initializes google map,
 * creates a series of markers from external data,
 * uses a with a single custom infoWindow instance
 * @requires GoogleMapsApi.js
 * @requires stylers
 * @requires data_listings
 * @requires MarkerTmpl
 */
class MapInit {

  constructor() {
    this.gmapApi = new GoogleMapsApi();
    this.mapEl = document.querySelector('.js-properties-map');
    this.mapMarkers = document.querySelectorAll('.js-marker');
    //this.markerTmpl = this.markerTmpl.bind(this);
  }

  /**
   * Kicks things off on reslove of
   * a promise to gmaps api
   * @requires _GoogleMapsApi.js
   */
  init(data_listings) {
    this.gmapApi.load().then(() => {
      this.renderMap(data_listings)
    });
  }

  /**
   * Render Map
   * Primary creation of map and markers.
   */
  renderMap(data_listings) {

    /**
     * Options
     * @property {LatLng} center - center default
     * @property {mapType} mapType - type of map
     * @property {obj} styles - map styles json
     * @property {number} zoom - intial zoom level
     * @property {boolean} scrollWheel - disable
     */
    const options = {
      center:      google.maps.LatLng(0, 0),
      mapTypeId:   google.maps.MapTypeId.ROADMAP,
      styles:      stylers.styles,
      zoom:        9,
      scrollwheel: true
    }

    /**
     * Custom Icon object
     * @property {string} url - marker image base64
     * @property {Size}
     */
    const icon = {
      url:        stylers.icons.red,
      scaledSize: new google.maps.Size(40, 40)
    }

    /**
     * Infowindow Instance
     * Create a single infoWindow to swap out for each marker.
     * @type {InfoWindow}
     */
    const infowindow = new google.maps.InfoWindow();

    /**
     * Google map instance
     * @type {Map}
     */
    const map = new google.maps.Map(this.mapEl, options);

    /**
     * Markers Array
     * @type {array}
     */
    map.markers = [];

    const latLngs = [];
    /**
     * Create Markers
     * Loop through data and add markers
     * @param {object} data_listings
     * @requires data-listings.js
     */
    data_listings.forEach((data_listing) => {

      if (data_listing.longitude && data_listing.latitude) {
          /**
           * Marker Template
           * @type {function} MarkerTmpl - gets marker template, passes in data.
           * @param {object} data_listing - Marker Data
           * @requires _MarkerTmpl.js
           */
          let tmpl = MarkerTmpl(data_listing);


          const latLng = data_listing.latitude +','+data_listing.longitude;
          var lat = data_listing.latitude;
          var lng = data_listing.longitude;

          if (latLngs.includes(latLng)) {
              let counts = latLngs.reduce((counts, val) => counts.set(val, 1 + (counts.get(val) || 0)), new Map());
              const occurrences = counts.get(latLng);
              lat =  data_listing.latitude  + ((occurrences+1) / 90000);
              lng =  data_listing.longitude  + ((occurrences+1) / 90000);
          }
          latLngs.push(latLng);


          const marker = new google.maps.Marker({
              position: new google.maps.LatLng(
                  lat,//data_listing.latitude,
                  lng,//data_listing.longitude
              ),
              map: map,
              icon: icon,
              title: data_listing.property_name,
              animation: google.maps.Animation.DROP,
              content: tmpl
          });

          map.markers.push(marker);

          this.toggleInfoWindow(map, marker, infowindow);
      }
    });

    this.centerMap(map);
  }

  /**
   * Toggle Info Window
   * Toggle a single info window instance across markers
   * @param {Map}
   * @param {Marker}
   * @param {InfoWindow}
   */
  toggleInfoWindow(map, marker, infowindow) {

    /**
     * Click Event
     * @param {Marker}
     */
    google.maps.event.addListener(marker, 'click', function() {

      /**
       * Pan to marker animation
       * @param {Position}
       */
      map.panTo(marker.getPosition());

      /**
       * Set Content to Infowindow
       * @param {string|blob}
       */
      infowindow.setContent(marker.content);

      /**
       * Open Marker's Infowindow
       * @param {Map}
       * @param {Marker}
       */
      infowindow.open(map, marker);
    });

     /**
      * Close InfoWindow on map click.
      */
     google.maps.event.addListener(map, 'click', function(event) {
       if (infowindow) {
         infowindow.close(map, infowindow);
       }
     });
   }


  /**
   * Center Map
   * Figures out map center for
   * 1 or many markers
   * @param {Map}
   */
  centerMap(map){

    const bounds = new google.maps.LatLngBounds();

    /**
    * Loop over markers
     * @param {Marker}
     */
    map.markers.forEach((marker) => {
      bounds.extend(marker.getPosition());
      // bounds.extend({
      //   lat: marker.position.lat(),
      //   lng: marker.position.lng()
      // });
    });


    if (map.markers.length == 1) {
      map.setCenter(bounds.getCenter());
    } else {
      map.fitBounds(bounds);
      //map.setCenter(bounds.getCenter());
    }
  }
}

export default MapInit;
