
import Utils from '../../components/_Utils.js'
import { stylers }   from './_stylers.js';


 /**
  * Properties Map
  * Map of available properties from external data source.
  * Data should output on page as a collection of html elements to construct markers and infowindows.
  * @see  js/components/_gmaps-config.js -  global google map options
  * @see  scss/components/_locations-map.scss
  */

 const PropertiesMap = (() => {

   /**
    * Bail if no google obj or properties map
    */
    if (!typeof google === 'object' && !typeof google.maps === 'object') return;
    if (!document.querySelector('.js-properties-map')) return;

    /**
     * Selector Elements
     */
    const selectors = {
      mapEl: document.querySelectorAll('.js-properties-map'),
    };

    /**
     * Icon Object
     */
    const icon = {
      url: stylers.icons.red,
      scaledSize: google.maps.Size(40, 40),
      origin: google.maps.Point(0,0),
      anchor: google.maps.Point(0, 0)
    };

    /**
     * Settings
     */
    const options = {
      center:      google.maps.LatLng(0, 0),
      mapTypeId:   google.maps.MapTypeId.ROADMAP,
      styles:      stylers.styles,
      zoom:        12,
      scrollwheel: true
    };


    /**
     * Google Map Instance
     * Map object assigned to an element with options passed in.
     */
    const map = new google.maps.Map(selectors.mapEl[0], options);

    /**
     *  Create single info window instance
     *  will switch out on click
     */
    const infowindow = new google.maps.InfoWindow();


    return{

      /**
       * Init
       */
      init() {
        if (document.querySelector('.js-properties-map')){
          this.bindEvents();
        }
      },

      /**
       * BindEvents
       */
      bindEvents(){
        if (selectors.mapEl) {
          PropertiesMap.loadGMaps(selectors.mapEl);
          PropertiesMap.renderMap();
        }
        //PropertiesMap.renderMapOnClick();
      },

      loadGMaps(el){
        if (el.length > 0 ) {
          const scriptEl = document.createElement('script');
          scriptEl.type = 'text/javascript';
          scriptEl.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyB5H-iWZVunwrRI4Q0EB03-35kLduacABE&callback=initMap';
          document.getElementsByTagName('head')[0].appendChild(scriptEl);
        }
      },
      /**
       * RednerMap
       */
      renderMap(){

        // add a markers reference
        map.markers = [];

        Utils.forEach(selectors.mapMarkers, function(index, marker) {
          console.log('map Markers', selectors.mapMarkers)

          PropertiesMap.addMarkers(marker, map);
        });

        // center map
        PropertiesMap.centerMap(map);

        // center on resize
        PropertiesMap.centerMapResize(map);

      },

      /**
       * Add Markers Function
       */
      addMarkers(el, map){

        const latlng = new google.maps.LatLng(el.dataset.lat, el.dataset.lng);

        // create marker object
        const marker = new google.maps.Marker({
          position: latlng,
          map: map,
          icon: icon,
          animation: google.maps.Animation.DROP,
        });

        // push markers to array
        map.markers.push(marker);
        PropertiesMap.toggleInfoWindow(el, map, marker);
      },

      /**
       * Reset Map
       */
      resetMap() {
        while (map.markers.length) {
          map.markers.pop().setMap(null);
        }
      },

      /**
       * Toggle Info Window
       */
      toggleInfoWindow(el, map, marker) {

        if (el.innerHTML) {

          /**
           * Show info window when marker is clicked,
           * close other marker
           */
          google.maps.event.addListener(marker, 'click', function() {
            PropertiesMap.panToInfoWindow(el, map, marker);
            PropertiesMap.openInfoWindow(el, map, marker)
          });

          /**
           * Close Info Window
           */
          google.maps.event.addListener(map, 'click', function(event) {
            PropertiesMap.closeInfoWindow(map, marker)
          });
        }
      },

      /**
       * Move To InfoWindow
       */
      panToInfoWindow(el, map, marker) {
        map.panTo(marker.getPosition());
        //map.setCenter(marker.getPosition());
      },

      /**
       * Open InfoWindow
       */
      openInfoWindow(el, map, marker) {
        //swap content of that singular info window
        infowindow.setContent(el.innerHTML)
        infowindow.open(map, marker);
      },

      /**
        * Close InfoWindow
        * @param {obj} map - google map obj
        * @param {obj} infowindow - google infowindow obj
        */
       closeInfoWindow(map, infowindow) {

         if (infowindow) {
           infowindow.close(map, infowindow);
         }
       },

       /**
         * Close InfoWindow
         * @param {obj} map - google map obj
         * @param {obj} infowindow - google infowindow obj
         */
      centerMap(map){

        // vars
        const bounds = new google.maps.LatLngBounds();

        Utils.forEach(map.markers, function(index, marker) {
          const latlng = new google.maps.LatLng(marker.position.lat(), marker.position.lng());
          console.log(latlng)
          bounds.extend(latlng);
        });

        // only 1 marker?
        if (map.markers.length == 1) {
          map.setCenter(bounds.getCenter());
          map.setZoom(options.zoom + 3);
        } else {
          //map.fitBounds(bounds);
          map.setCenter(bounds.getCenter());
          map.setZoom(options.zoom);
        }
      },

      /**
       * Center Map on Resize
       */
      centerMapResize(map){
        google.maps.event.addDomListener(window, "resize", function() {
          const center = map.getCenter();
          google.maps.event.trigger(map, "resize");
          map.setCenter(center);
          map.setZoom(selectors.initialZoom);
        });
      },
    };
  })();

export default PropertiesMap;
