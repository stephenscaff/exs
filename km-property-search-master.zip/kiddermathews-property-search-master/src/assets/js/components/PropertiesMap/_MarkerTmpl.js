import Utils from '../../components/_Utils.js'

/**
 * Marker Template
 * @param {obj} data - property data/json
 */
function markerTmpl(data) {
  let conditionalTitle = 'Price';
  let conditionalContent = (data.list_price ? '$' + data.list_price.toLocaleString('en') : '-');
  if (data.listing_type  && data.listing_type.toLowerCase().includes('lease')) {
    conditionalTitle = 'SF Available';
    conditionalContent = (data.sf_avail ? data.sf_avail.toLocaleString('en')  : '-');
  }
  const photo = data.listing_photo ? data.listing_photo : data.property_photo;

  return `<article class="marker-box">
    <div class="marker-box__wrap">
      <div class="marker-box__grid">
        <figure class="marker-box__figure">
          <a target="_blank" href="/properties/single.html?listing=${data.listing_key}&property=${data.property_key}">
            <div class="marker-box__bg" style="background-image:url(${photo})"></div>
          </a>
        </figure>
        <div class="marker-box__main">
          <span class="marker-box__title">${data.property_name}</span>
          <address class="marker-box__address">
            <span class="marker-box__street">${data.property_address}</span>
            <span class="marker-box__city-state">${data.city} ${data.state_code} ${data.zip_postal_code}</span>
          </address>
          <span class="marker-box__info"><strong>Type</strong> ${data.use_type}</span>
          <span class="marker-box__info"><strong>${conditionalTitle}</strong> ${conditionalContent}</span>

          <a target="_blank" class="marker-box__btn btn-line" href="/properties/single.html?listing=${data.listing_key}&property=${data.property_key}">View Details</a>
        </div>
      </div>
    </div>
  </article>`;
}

export default markerTmpl;
