
class SpecialtyTypeCriteria {

    constructor() {
        // Office Specialty Types
        this.medicalDental = false;
        this.government = false;
        this.mixedUse = false;
        this.generalOffice = false;
        this.dataCallCenter = false;

        this.lowRiseOfficeBuilding = false;
        this.midRiseOfficeBuilding = false;
        this.highRiseOfficeBuilding = false;

        // Industrial Specialty Types
        this.highTechOrRaD = false;
        this.manufacturing = false;
        this.warehouseDistribution = false;
        this.warehouseOffice = false;
        this.selfStorage = false;

        // Land Specialty Types
        this.scraped = false;
        this.obsolete = false;
        this.singleFamilyLand = false;
        this.farmlandRanch = false;

        // Retail specialty types
        this.bigBox = false;
        this.neighborhoodCenter = false;
        this.anchored = false;
        this.lifestyleCenter = false;
        this.outdoorMall = false;
        this.padSite = false;
        this.restaurant = false;
        this.retailMixedUse = false;
        this.stripCenter = false;
        this.superRegionalCenter = false;

        // Multifamily types
        this.garden = false;
        this.loft = false;
        this.midrise = false;
        this.hirise = false;
        this.militaryHousing = false;
        this.seniorHousing = false;
        this.studentHousing = false;

        // Hospitality
        this.hotel = false;
        this.motel = false;
        this.resort = false;

        // Other Specialty types
        this.civic = false;
        this.library = false;
        this.museum = false;
        this.commercial = false;
        this.carDealership = false;
        this.education = false;
        this.collegeUniversity = false;
        this.dayCare = false;
        this.school = false;
        this.event = false;
        this.amusementPark = false;
        this.arena = false;
        this.sportsFacility = false;
        this.theater = false;
        this.cityHall = false;
        this.groceryAnchored = false;
        this.duplex = false;
        this.industrialLand = false;
        this.industrialFlex = false;
        this.officeFlex = false;
        this.condo = false;
        this.redevelopment = false;
        this.truckTerminal = false;
        this.mobileHomePark = false;
        this.transportation = false;
        this.misc = false;
        this.parkingStructure = false;
        this.religious = false;
    }
}

SpecialtyTypeCriteria.prototype.reset = SpecialtyTypeCriteria;

class BuildingClassCriteria {
    constructor() {
        this.trophy = false;
        this.a = false;
        this.b = false;
        this.c = false;
        this.d = false;
    }
}

BuildingClassCriteria.prototype.reset = BuildingClassCriteria;

class BuildingTypeCriteria {
    constructor() {
        this.lowRise = false;
        this.midRise = false;
        this.highRise = false;
    }
}

class PriceCriteria {
    constructor() {
        this.minPrice = null;
        this.maxPrice = null;
        this.minLeaseRate = null;
        this.maxLeaseRate = null;
        this.minCapRate = null;
        this.maxCapRate = null;
    }
}

PriceCriteria.prototype.reset = PriceCriteria;

class ListingTypeCriteria {
    constructor() {
        this.forSale = false;
        this.forLease = false;
        this.investmentSaleFlg = false;
        this.nnnInvestmentFlg = false;
    }
}

ListingTypeCriteria.prototype.reset = ListingTypeCriteria;

class PropertyTypeCriteria {
    constructor(type) {
        this.propertyType = type;
        this.selected = false;
        this.specialtyTypeCriteria = new SpecialtyTypeCriteria();
    }
}

class LocationCriteria {
    constructor() {
        this.states = null;
        this.city = null;
        this.address = null;
    }
}

LocationCriteria.prototype.reset = LocationCriteria;

class SearchCriteria {

    constructor() {

        //this.specialtyTypeCriteria = new SpecialtyTypeCriteria();
        this.buildingClassCriteria = new BuildingClassCriteria();
        this.priceCriteria = new PriceCriteria();
        this.listingTypeCriteria = new ListingTypeCriteria();
        this.searchTerm = null;
        this.locationCriteria = new LocationCriteria();

        this.brokerName = null;
        this.buildingName = null;
        this.statusCriteria = {
            existing: false,
            proposed: false,
            underConstruction: false,
            kmManagedOnly: false,
        };
        this.tenancyCriteria = {
            single: false,
            multi: false
        };
        this.sizeCriteria = {
            min: "",
            max: "",
            availableSf: false,
            totalSf: false,
            acreage: false
        };
        this.propertyTypes = {
            Office: new PropertyTypeCriteria('Office'),
            Industrial: new PropertyTypeCriteria('Industrial'),
            Land: new PropertyTypeCriteria('Land'),
            Retail: new PropertyTypeCriteria('Retail'),
            Multifamily: new PropertyTypeCriteria('Multifamily'),
            Hospitality: new PropertyTypeCriteria('Hospitality'),
            'Life Science': new PropertyTypeCriteria('Life Science'),
            Other: new PropertyTypeCriteria('Other'),
        };
    }
}

SearchCriteria.prototype.resetPropertyTypeFilters = function() {
    this.propertyTypes = {
        Office: new PropertyTypeCriteria('Office'),
        Industrial: new PropertyTypeCriteria('Industrial'),
        Land: new PropertyTypeCriteria('Land'),
        Retail: new PropertyTypeCriteria('Retail'),
        Multifamily: new PropertyTypeCriteria('Multifamily'),
        Hospitality: new PropertyTypeCriteria('Hospitality'),
        Other: new PropertyTypeCriteria('Other'),
        'Life Science': new PropertyTypeCriteria('Life Science'),
    };
}

class SearchRequest {
    constructor() {
        this.searchCriteria = new SearchCriteria();
        this.startIndex = 0;
        this.numResults = 5;
        this.includeAggregations = true;
    }
}


SearchRequest.prototype.reset =  SearchRequest;

const BASE_SERVER_URL = "https://services.kidder.com";
//const BASE_SERVER_URL = "http://localhost:8080";

export const ListingsSearch = (function() {
    return {
        search: function (requestData,successCallback,errorCallback) {
            $.ajax({
                url: BASE_SERVER_URL+"/search/public/listing",
                type: "POST",
                data: requestData,
                async: true,
                contentType : "application/json;charset=UTF-8",
                dataType: 'json',
                crossDomain: true,
                // beforeSend: function(xhr) {
                //     xhr.withCredentials = true;
                // },
                success: successCallback,
                error: errorCallback

            });
        },
        findStatesWithAvailableListings: function (successCallback,errorCallback) {
            $.ajax({
                url: BASE_SERVER_URL+"/search/public/listing/states",
                type: "GET",
                //data: requestData,
                async: true,
                contentType : "application/json;charset=UTF-8",
                dataType: 'json',
                crossDomain: true,
                // beforeSend: function(xhr) {
                //     xhr.withCredentials = true;
                // },
                success: successCallback,
                error: errorCallback

            });
        }
    }
})();


export const Property = (function() {
    return {
        fetchWithListings: function (propertyId,successCallback,errorCallback) {
            $.ajax({
                url: BASE_SERVER_URL+"/properties/public/listings/"+propertyId,
                type: "GET",
                async: true,
                contentType : "application/json;charset=UTF-8",
                dataType: 'json',
                crossDomain: true,
                // beforeSend: function(xhr) {
                //     xhr.withCredentials = true;
                // },
                success: successCallback,
                error: errorCallback
            });
        }
    }
})();

export const DEFAULT_SEARCH_REQUEST = new SearchRequest();
export const PROPERTY_TYPES = [
    {display: 'Office',value: 'Office'},
    {display: 'Industrial',value: 'Industrial'},
    {display:'Land',value:'Land'},
    {display:'Retail',value:'Retail'},
    {display:'Multifamily',value:'Multifamily'},
    {display:'Hospitality',value:'Hospitality'},
    {display:'Life Science',value:'Life Science'},
    {display:'Other',value:'Other'}
];

export const BUILDING_CLASSES = [
    {value: 'a', display: 'A'},
    {value: 'b',  display: 'B'},
    {value: 'c', display:  'C'},
    //{value: 'd', display: 'D'}
];
export const SPECIALTY_TYPES = [
    {value: 'amusementPark' , display: 'Amusement Park'},
    {value: 'arena' , display: 'Arena'},
    {value: 'farmlandRanch' , display: 'Agricultural'},
    {value: 'bigBox' , display: 'Big Box'},
    {value: 'carDealership' , display: 'Car Dealership'},
    {value: 'civic' , display: 'Civic'},
    {value: 'cityHall' , display: 'City Hall'},
    {value: 'collegeUniversity' , display: 'College University'},
    {value: 'commercial' , display: 'Commercial'},
    {value: 'condo' , display: 'Condo'},
    {value: 'dataCallCenter' , display: 'Data Center'},
    {value: 'dayCare' , display: 'Day Care'},
    {value: 'warehouseDistribution' , display: 'Distribution'},
    {value: 'duplex' , display: 'Duplex'},
    {value: 'education' , display: 'Education'},
    {value: 'event' , display: 'Event'},
    {value: 'executiveSpace' , display: 'Executive Space'},
    {value: 'obsolete' , display: 'Functionally  Obsolete Structure'},
    {value: 'garden' , display: 'Garden'},
    {value: 'generalOffice' , display: 'General Office'},
    {value: 'government' , display: 'Government'},
    {value: 'groceryAnchored' , display: 'Grocery Anchored'},
    {value: 'highTechOrRaD' , display: 'High Tech/R&D'},
    {value: 'hirise' , display: 'High Rise'},
    {value: 'hotel' , display: 'Hotel'},
    {value: 'industrialFlex' , display: 'Industrial Flex'},
    {value: 'library' , display: 'Library'},
    {value: 'lifestyleCenter' , display: 'Lifestyle Center'},
    {value: 'loft' , display: 'Loft'},
    {value: 'lowRiseOfficeBuilding' , display: 'Low-Rise (Office)'},
    {value: 'manufacturing' , display: 'Manufacturing'},
    {value: 'medicalDental' , display: 'Medical (Office)'},
    {value: 'medical' , display: 'Medical (Other)'},
    {value: 'midrise' , display: 'Mid Rise'},
    {value: 'militaryHousing' , display: 'Military Housing'},
    {value: 'misc' , display: 'Miscellaneous'},
    {value: 'mobileHomePark' , display: 'Mobile Home Park'},
    {value: 'motel' , display: 'Motel'},
    {value: 'museum' , display: 'Museum'},
    {value: 'neighborhoodCenter' , display: 'Neighborhood Center'},
    {value: 'officeFlex' , display: 'Office Flex'},
    {value: 'mixedUse' , display: 'Office Mixed Use'},
    {value: 'outdoorMall' , display: 'Outdoor Mall'},
    {value: 'parkingStructure' , display: 'Parking Structure'},
    {value: 'redevelopment' , display: 'Redevelopment'},
    {value: 'religious' , display: 'Religious'},
    {value: 'retailMixedUse' , display: 'Retail Mixed Use'},
    {value: 'superRegionalCenter' , display: 'Super Regional Center'},
    {value: 'resort' , display: 'Resort'},
    {value: 'restaurant' , display: 'Restuarant'},
    {value: 'anchored' , display: 'Retail Anchored'},
    {value: 'padSite' , display: 'Retail Pad Site'},
    {value: 'scraped' , display: 'Scraped'},
    {value: 'school' , display: 'School'},
    {value: 'selfStorage' , display: 'Self Storage'},
    {value: 'seniorHousing' , display: 'Senior Housing'},
    {value: 'singleFamilyLand' , display: 'Single Family Land'},
    {value: 'sportsFacility' , display: 'Sports Facility'},
    {value: 'stripCenter' , display: 'Strip Center'},
    {value: 'studentHousing' , display: 'Student Housing'},
    {value: 'theater' , display: 'Theater '},
    {value: 'townhouse' , display: 'Townhouse '},
    {value: 'transportation' , display: 'Transportation'},
    {value: 'truckTerminal' , display: 'Truck Terminal'},
    {value: 'warehouseOffice' , display: 'Warehouse '},

];

export const SPACE_USE_BY_PROPERTY_TYPE = {
    'Office' : ['medicalDental','mixedUse','dataCallCenter','government','generalOffice','executiveSpace'],
    'Industrial':['highTechOrRaD','warehouseDistribution','selfStorage','warehouseOffice','manufacturing'],
    'Land':['scraped','singleFamilyLand','farmlandRanch','obsolete'],
    'Retail':['bigBox','anchored','outdoorMall','restaurant','stripCenter','neighborhoodCenter','lifestyleCenter','padSite','retailMixedUse','superRegionalCenter'],
    'Multifamily':['garden','midrise','militaryHousing','studentHousing','loft','hirise','seniorHousing'],
    'Hospitality':['hotel','motel','resort'],
    'Other':['misc','transportation','religious','parkingStructure','mobileHomePark','government','medical','civic','museum','carDealership','collegeUniversity','school','amusementPark','sportsFacility','cityHall','library','commercial','education','dayCare','arena','event','theater'],
    'Life Science': []
}
