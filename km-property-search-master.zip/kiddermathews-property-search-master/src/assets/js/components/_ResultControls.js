/**
  * ResultsControls
  * A grouped collection of Controls and utils for Results
  * @author stephen scaff
  */
const ResultControls = (() => {

  const container = document.querySelector('.properties-split');
  const listingCards = document.querySelector('#js-listing-cards');

  return {

    /**
     * Combine our methods here
     * to allow a single init on the default export.
     */
    init() {
      this.mapToggle();
      this.listToggle();
    },

    /**
     * Map Toggle
     * Toggle map collapsed view on properties split view.
     */
    mapToggle() {

      const toggle = document.querySelector('.js-toggle-map');
      let isCollapsed = false;

      if (!toggle) return;

      toggle.addEventListener('click', function() {

        if (isCollapsed) {
          container.classList.remove('map-is-collapsed');
          isCollapsed = false;
        } else {
          container.classList.add('map-is-collapsed');
          isCollapsed = true;
        }
      });
    },

    listToggle() {
      const listLink = document.querySelector('.js-view-list');
      const gridLink = document.querySelector('.js-view-grid');

      if (!listLink) return;

      listLink.addEventListener('click', function(e) {
        gridLink.classList.remove('is-active');
        listLink.classList.add('is-active');
        listingCards.classList.remove('is-grid');
        listingCards.classList.add('is-list');
      });

      gridLink.addEventListener('click', function(e) {
        listLink.classList.remove('is-active');
        gridLink.classList.add('is-active');
        listingCards.classList.add('is-grid');
        listingCards.classList.remove('is-list');
      });
    }
  };
})();

export default ResultControls
