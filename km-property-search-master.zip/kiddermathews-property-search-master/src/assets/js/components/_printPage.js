/**
 * Print page
 * Helper to trigger print page window
 */
export default function printPage() {

  if ( !document.querySelectorAll('.js-print-page').length ) return;

  let printPageTrigger = document.querySelector('.js-print-page');

  printPageTrigger.addEventListener('click', function() {
    window.print();
  })
}
