import Utils from '../components/_utils.js'
import printPage from '../components/_printPage.js'
import RenderHBS from '../components/_RenderHBS.js'
import * as SearchAPI from '../components/_search.js'
import PopUps from '../components/_PopUps.js'
import GalleryPopUp from '../components/_GalleryPopup.js'
import RenderProfessionals from '../components/_RenderProfessionals.js'
import MapInit from '../components/PropertiesMap/_MapInit.js'
import PageTransitions from '../components/_PageTransitions.js'

// Begin Transition / Preloader
PageTransitions.loading();

let PropertiesMap = null;

$(function() {

  if (/single/.test(window.location.href))  {

    RenderHBS.getTemplate('assets/templates/partials/property-mast.hbs', function (template) {
      Handlebars.registerPartial('property-mast', template);
    });

    RenderHBS.getTemplate('assets/templates/partials/property-header.hbs', function (template) {
      Handlebars.registerPartial('property-header', template);
    });

    RenderHBS.getTemplate('assets/templates/partials/property-overview.hbs', function (template) {
      Handlebars.registerPartial('property-overview', template);
    });

    RenderHBS.getTemplate('assets/templates/partials/property-available.hbs', function (template) {
      Handlebars.registerPartial('property-available', template);
    });

    RenderHBS.getTemplate('assets/templates/partials/property-map.hbs', function (template) {
      Handlebars.registerPartial('property-map', template);
    });

    RenderHBS.getTemplate('assets/templates/partials/property-sidebar.hbs', function (template) {
      Handlebars.registerPartial('property-sidebar', template);
    });

    RenderHBS.getTemplate('assets/templates/partials/listing.hbs', function (template) {
      Handlebars.registerPartial('listing', template);
    });

    RenderHBS.getTemplate('assets/templates/partials/property-info.hbs', function (template) {
      Handlebars.registerPartial('property-info', template);
    });

    let parameters = new URLSearchParams(window.location.search);
    const propertyId = parameters.get('property');
    const listingId = parameters.get('listing');

    if (propertyId && listingId) {
      SearchAPI.Property.fetchWithListings(propertyId, loadPropertyListings, Utils.errorCallback);
    }
  }
});

/**
 * Load Propety Listings
 * Calls RenderHBS.render, Inits PopUps and GalleryPopUp
 * Renders Map
 */
function loadPropertyListings(data, textStatus, jqXHR) {

  var markerRenderEl = document.querySelector('#single-property-view');
  var markerTemplate ='assets/templates/single-property-view.hbs';
  let parameters = new URLSearchParams(window.location.search);

  data.selectedListing = data.listings.find(listing => listing.listingKey == parameters.get('listing'));
  data.brokers = initBrokerList(data.selectedListing.listingBrokers);

  if (data.selectedListing && data.selectedListing.listingType === 'LEASE') {
    const filteredListings = data.listings.filter(element => element && element.attributes && !isNaN(element.attributes.sfAvail));

    const sfAvail = filteredListings.map((listing) => {
      return listing.attributes.sfAvail;
    });

    data.sfAvailMin = Math.min(...sfAvail);
    data.sfAvailMax = Math.max(...sfAvail);
    console.log(data);


  }

  /**
   * Render HBS: Render
   * RenderHBS, Popus, GalleryPopups, PrintPage, etc
   */
  RenderHBS.render(data, markerRenderEl, markerTemplate, true, function (dummy) {
    renderMap(data);
    PageTransitions.loaded();
    PopUps.init();
    GalleryPopUp.init();
    RenderProfessionals.init(data.selectedListing.listingBrokers)
    printPage();
  });
}

/**
 * Render Map
 */
function renderMap(data) {

  let parcel = null;

  if (data.property && data.property.propertyAttributes && data.property.propertyAttributes.parcels) {
    parcel = data.property.propertyAttributes.parcels.find(item => item && item.longitude && item.latitude);
  }

  if (parcel && data.selectedListing) {
    PropertiesMap = new MapInit();
    const listing = data.selectedListing;
    console.log('data from selected listing');
    console.log(listing);
    const listingData = [{
          listing_key: listing.listingKey,
          property_key: data.property.propertyKey,
          listing_name: listing.listingName,
          property_name: data.property && data.property.propertyAttributes && data.property.propertyAttributes.propertyName ? data.property.propertyAttributes.propertyName : '',
          list_price: listing.listPrice,
          sf_avail: listing.sfAvail,
          listing_type: listing.listingType && listing.listingType.toLowerCase().includes('lease') ? 'For Lease' : 'For Sale',
          asking_rent_min: listing.askingRentMin,
          asking_rent_max: listing.askingRentMax,
          latitude: parcel.latitude,
          longitude: parcel.longitude,
          listing_address: listing.attributes && listing.attributes.address ? listing.attributes.address.address1 : '',
          property_address: data.property && data.property.primaryAddress ? data.property.primaryAddress.address1 : '',
          city: data.property && data.property.primaryAddress && data.property.primaryAddress.city ? data.property.primaryAddress.city.city : '',
          state_code: data.property && data.property.primaryAddress && data.property.primaryAddress.city && data.property.primaryAddress.city.state ? data.property.primaryAddress.city.state.stateCode: '' ,
          zip_postal_code: data.property && data.property.primaryAddress && data.property.primaryAddress.zipCode ? data.property.primaryAddress.zipCode.zipCode: '',
          property_photo: listing.primaryPhotoUrl ? listing.primaryPhotoUrl : data.property.primaryPhotoUrl,
          use_type: listing.attributes && listing.attributes.specialityType ? listing.attributes.specialityType : listing.attributes && listing.attributes.useType ? listing.attributes.useType : '',
          property_type: listing.attributes && listing.attributes.specialityType ? listing.attributes.specialityType : listing.attributes && listing.attributes.useType ? listing.attributes.useType : ''
    }];

    if (listingData) {
      PropertiesMap.init(listingData);
    }
  }
}

/**
 * Initialize Broker List
 * @return brokers
 */
function initBrokerList(agents) {
  let brokers = [];

  if (agents) {

    agents.map((value, index, array) => {

        if (value && value.brokerAgentKey && value.brokerAgentKey.person) {
            const license = value.brokerAgentKey.licenses.find((element) => {
              return element && element.licenseNumber
            })
            const email = value.brokerAgentKey.person.personContactInfo ? value.brokerAgentKey.person.personContactInfo.emailAddress : null;

            const address = value.brokerAgentKey.person.addressList.find((element) => {
              return element && element.city
            })
            const phoneNumber = value.brokerAgentKey.person.personContactInfo && value.brokerAgentKey.person.personContactInfo.phoneNumber ? value.brokerAgentKey.person.personContactInfo.phoneNumber.phoneNumber : null;
            const person = value.brokerAgentKey.person;
            const broker = {
                firstName:      person ? person.firstName : null,
                lastName:       person ? person.lastName : null,
                emailAddress:   email ? email.emailAddress : null,
                phoneNumber:   phoneNumber,
                licenseNumber:  license ? license.licenseNumber : null,
                city:           address ? address.city : null,
            }

            brokers.push(broker);
      }
    });
  }
  return brokers;
}
