/**
 * SEARCH PAGE JS
 */
//if (window.location.pathname === '/search.html') {
if (window.location.pathname.indexOf('/search.html') === 0) {
  $('#js-search-input').on("keypress", function (event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      forwardToSearchResults();
    }
  });
}

/**
 * Forward Search Results
 */
function forwardToSearchResults() {
  const searchTerm = $('#js-search-input').val();
  const listingType = $("input[name='search-toggle[]']:checked").val();
  let url = '/index.html?listType='+listingType;
  if (searchTerm) {
    url += '&term='+searchTerm;
  }

  window.location.href = url;
}
