import Utils from '../components/_utils.js'
import * as SearchAPI from '../components/_search.js'
import PageTransitions from '../components/_PageTransitions.js'
import ResultControls from '../components/_ResultControls.js'
import RenderProperties from '../components/PropertiesMap/_RenderProperties.js'
import MapInit from '../components/PropertiesMap/_MapInit.js'
import Filters from '../components/Filters/_index.js'
import RenderFilters from '../components/Filters/_RenderFilters.js'
import RenderHBS from '../components/_RenderHBS.js'
import PopUps from '../components/_PopUps.js'
import GalleryPopUp from '../components/_GalleryPopUp.js'
import '../components/_HBSHelpers.js'

ResultControls.init();

const searchState = {
  searchRequest: SearchAPI.DEFAULT_SEARCH_REQUEST,
  searchResponse : null
};

let PropertiesMap = null;

if (!/single/.test(window.location.href)) {

  if (document.querySelectorAll('.js-filters').length) {
    Filters.init();
    Filters.registerUpdateListener(rangeUpdateListener);
  }

  RenderFilters.propertyTypeFilters(SearchAPI.PROPERTY_TYPES,loadSpaceTypeFilters);
  RenderFilters.propertyClassFilters(SearchAPI.BUILDING_CLASSES);
  //RenderFilters.spaceTypeFilters(buildSpaceTypeFilterDisplayArray());

  // Init google map
  PropertiesMap = new MapInit();
}

function loadSpaceTypeFilters() {
    RenderFilters.spaceTypeFilters(buildSpaceTypeFilterDisplayArray(),processUrlParams);
}

/**
 * App Home/Index DOM Ready
 */
function processUrlParams() {
  if (!/single/.test(window.location.href)  && (!/search/.test(window.location.href)) ) {

    const parameters = new URLSearchParams(window.location.search);
    const propertyType = parameters.get('propertyType');
    const listingType = parameters.get('listType');
    const searchTerm = parameters.get('term');
    const spaceTypes = parameters.get('spaceTypes');
    const investment = parameters.get('investment');
    const nnn_lease = parameters.get('nnn_lease');

    if (propertyType) {
      searchState.searchRequest.searchCriteria.propertyTypes[propertyType].selected = true;
      $("#property-type-filters input[value='"+propertyType+"']").prop('checked',true);

      if (spaceTypes) {
        const parsedSpaceTypes = spaceTypes.split(',');
          parsedSpaceTypes.forEach(spaceType => {
            searchState.searchRequest.searchCriteria.propertyTypes[propertyType].specialtyTypeCriteria[spaceType] = true;
        })
      }

      RenderFilters.spaceTypeFilters(buildSpaceTypeFilterDisplayArray(),initSelectedSpaceTypes);
    }

    if (listingType) {
      $(".js-listing-type-filters input[value='"+listingType+"']").prop('checked',true);
    }

    if (searchTerm) {
      $('#search-box-input').val(searchTerm);
    }


    Utils.throttle(performSearch,200);

    if (propertyType || listingType || searchTerm || investment === 'true' || nnn_lease === 'true') {
      performSearch();
    }

    loadStates();
    PageTransitions.loaded();
  }
}

function initSelectedSpaceTypes(data) {

    const parameters = new URLSearchParams(window.location.search);
    const spaceTypes = parameters.get('spaceTypes');
    if (spaceTypes) {
        let parsedSpaceTypes = spaceTypes.split(',');
        parsedSpaceTypes.forEach(spaceType => {
             $("#space-type-filters input[value='"+spaceType+"']").prop('checked',true);
        })
    }
}


/**
 * Number of Results to Show
 */
const NUM_RESULTS = 50;

/**
 * Process Search response
 */
function processSearchResponse(data, textStatus, jqXHR) {

  if (data.requestId == searchState.searchRequest.requestId) {
      searchState.searchResponse = data;
      displayResults(searchState.searchResponse);
  }
}

/**
 * Display Results
 */
function displayResults(response) {
  RenderProperties.cards(response);
  PropertiesMap.init(response.results);
}

/**
 * Perform Search
 */
function performSearch(loadMore) {
  const ranges = Filters.update();
  const searchTerm = $('#search-box-input').val();
  const brokerName = $('#broker-name-input').val();
  const buildingName = $('#building-name-input').val();
  const city = $('#city-input').val();
  const address = $('#location-address-input').val();


  if (loadMore) {
    searchState.searchRequest.numResults += NUM_RESULTS;
  } else {
    searchState.searchRequest.numResults = NUM_RESULTS
  }

  if (searchTerm) {
    searchState.searchRequest.searchCriteria.searchTerm = searchTerm;
  } else {
    searchState.searchRequest.searchCriteria.searchTerm = null;
  }

  if (brokerName) {
    searchState.searchRequest.searchCriteria.brokerName = brokerName;
  } else {
    searchState.searchRequest.searchCriteria.brokerName = null;
  }

  if (buildingName) {
    searchState.searchRequest.searchCriteria.buildingName = buildingName;
  } else {
    searchState.searchRequest.searchCriteria.buildingName = null;
  }

  if (address) {
    searchState.searchRequest.searchCriteria.locationCriteria.address = address;
  } else {
    searchState.searchRequest.searchCriteria.locationCriteria.address = null;
  }

  if (city) {
    searchState.searchRequest.searchCriteria.locationCriteria.city = city;
  } else {
    searchState.searchRequest.searchCriteria.locationCriteria.city = null;
  }

  // Set List Type Criteria
  setListTypeCriteria();

  searchState.searchRequest.requestId =  performance.now();
  console.log('Search Request', searchState.searchRequest);

  SearchAPI.ListingsSearch.search(
    JSON.stringify(searchState.searchRequest),
    processSearchResponse,
    Utils.errorCallback
  );
}

/**
 * Set Size Search Critera
 */
function setSizeSearchCriteria(sizeRange) {
  if (sizeRange) {
    searchState.searchRequest.searchCriteria.sizeCriteria.availableSf = true;
    searchState.searchRequest.searchCriteria.sizeCriteria.min = sizeRange[0] ? sizeRange[0] : null;
    searchState.searchRequest.searchCriteria.sizeCriteria.max = sizeRange[1] ? sizeRange[1] : null;
  } else {
    searchState.searchRequest.searchCriteria.sizeCriteria.availableSf = false;
    searchState.searchRequest.searchCriteria.sizeCriteria.totalSf = false;
    searchState.searchRequest.searchCriteria.sizeCriteria.acreage = false;
  }
}

/**
 * Set Price Search Critera
 * @param number
 */
function setPriceSearchCriteria(priceRange) {
  if (priceRange  ) {
    searchState.searchRequest.searchCriteria.priceCriteria.minPrice = priceRange[0] ? priceRange[0] : null;
    searchState.searchRequest.searchCriteria.priceCriteria.maxPrice = priceRange[1] ? priceRange[1] : null;
  } else {
    searchState.searchRequest.searchCriteria.priceCriteria.minPrice = null;
    searchState.searchRequest.searchCriteria.priceCriteria.maxPrice = null;
  }
}

/**
 * Set Leads Search Critera
 */
function setLeaseRateSearchCriteria(leaseRange) {
  if (leaseRange) {
    searchState.searchRequest.searchCriteria.priceCriteria.minLeaseRate = leaseRange[0] ? leaseRange[0] : null;
    searchState.searchRequest.searchCriteria.priceCriteria.maxLeaseRate = leaseRange[1] ? leaseRange[1] : null;
  } else {
    searchState.searchRequest.searchCriteria.priceCriteria.minLeaseRate = null;
    searchState.searchRequest.searchCriteria.priceCriteria.maxLeaseRate = null;
  }
}

/**
 * Set Cap Rate Search Critera
 */
function setCapRateSearchCriteria(capRange) {
  if (capRange) {
    searchState.searchRequest.searchCriteria.priceCriteria.minCapRate = capRange[0] ? capRange[0] : null;
    searchState.searchRequest.searchCriteria.priceCriteria.maxCapRate = capRange[1] ? capRange[1] : null;
  } else {
    searchState.searchRequest.searchCriteria.priceCriteria.minCapRate = null;
    searchState.searchRequest.searchCriteria.priceCriteria.maxCapRate = null;
  }
}

/**
 * Range Update Listener
 * Calls the performSearch() function
 */
function rangeUpdateListener(element,value) {
  const id = element.id;

  if (id.includes('price')) {
    setPriceSearchCriteria(Filters.update().rent);
  } else if (id.includes('size')) {
    setSizeSearchCriteria(Filters.update().size);
  } else if (id.includes('cap')) {
    setCapRateSearchCriteria(Filters.update().capRate);
  } else if (id.includes('lease')) {
    setLeaseRateSearchCriteria(Filters.update().leaseRate);
  }
  performSearch();
}

/**
 * Apply filters
 * Calls displayReults()
 */
function applyFilters() {
  const size = Filters.update().size;
  let results = searchState.searchResponse.results;
  const totalResultCount = searchState.searchResponse.totalResultCount;
  const currentResultCount = searchState.searchResponse.results.length;

  results = results.filter(priceFilter);

  const data = {
    totalResultCount: totalResultCount - (currentResultCount-results.length),
    results: results
  }

  // searchState.searchResponse = data;
  displayResults(data);
}

/**
 * Size Filter
 * @return boolean
 */
function sizeFilter(item) {
  const size = Filters.update().size;
  if (!size || !item.sf_avail) {
    return true;
  }
  if (size[0] && item.sf_avail < size[0]) {
    return false;
  }
  if (size[1] && item.sf_avail > size[1]) {
    return false;
  }
  return true;
}

/**
 * Price Filter
 * @return boolean
 */
function priceFilter(item,index,array) {
  const price = Filters.update().rent;

  if (!price || !item.list_price) {
    return true;
  }
  if (price[0] && item.list_price < price[0]) {
    return false;
  }
  if (price[1] && item.list_price > price[1]) {
    return false;
  }

  return true;
}

/**
 * Handle Seach Box Input
 * Calls performSearch()
 */
function handleSearchBoxInput(event) {
  if (event.keyCode === 13) {
    event.preventDefault();
  }

  const searchTerm = $('#search-box-input').val();
  if (searchTerm !== searchState.searchRequest.searchCriteria.searchTerm) {
    performSearch();
  }
}

/**
 * Handle Filter Input
 * Calls performSearch()
 */
function handleFilterInputText(event) {
  console.log('handleFilterInputText invoked');
  console.log(event);
  performSearch();
}

/**
 * Set List Type Critera
 */
function setListTypeCriteria() {
  searchState.searchRequest.searchCriteria.listingTypeCriteria.reset();

  const listingType = $("input[name='search-toggle[]']:checked").val();

  if (listingType === 'For Sale') {
    searchState.searchRequest.searchCriteria.listingTypeCriteria.forSale = true;
  } else if (listingType == 'For Lease') {
    searchState.searchRequest.searchCriteria.listingTypeCriteria.forLease = true;
  }

    const parameters = new URLSearchParams(window.location.search);
    const investment = parameters.get('investment');
    const nnn_lease = parameters.get('nnn_lease');
    if (investment === 'true') {
        searchState.searchRequest.searchCriteria.listingTypeCriteria.investmentSaleFlg = true;
    }
    if (nnn_lease === 'true') {
        searchState.searchRequest.searchCriteria.listingTypeCriteria.nnnInvestmentFlg = true;
    }
}

/**
 * Event Listeners
 */
$("input[name='search-toggle[]']").on("click", function() {
   performSearch();
});

//$('#search-box-input').on('paste keyup change input keypress keydown search submit', handleSearchBoxInput);
$('#search-box-input').on('paste keyup change input keypress search submit', handleSearchBoxInput);

$('.filter-input-text-box').on('change', handleFilterInputText);

$('#load-more-container').on('click','a', function() {performSearch(true);});

$('#property-type-filters').on('click','input', function(event) {
 searchState.searchRequest.searchCriteria.propertyTypes[event.target.value].selected = $(event.target).prop('checked');

 if (searchState.searchRequest.searchCriteria.propertyTypes[event.target.value].selected === false) {
   clearPropertyTypeSpaceFilters(event.target.value);
 }

 RenderFilters.spaceTypeFilters(buildSpaceTypeFilterDisplayArray());
 performSearch();
});

$('#property-types .js-filter-reset').on('click', function(event) {
 resetPropertyTypeFilters();
 performSearch();
});

function resetPropertyTypeFilters() {
 searchState.searchRequest.searchCriteria.resetPropertyTypeFilters();
 RenderFilters.propertyTypeFilters(SearchAPI.PROPERTY_TYPES);
 RenderFilters.spaceTypeFilters(buildSpaceTypeFilterDisplayArray());
}

$('#property-class-filters').on('click','input', function(event) {
 searchState.searchRequest.searchCriteria.buildingClassCriteria[event.target.value] = $(event.target).prop('checked');
 performSearch();
});

$('#property-classes .js-filter-reset').on('click', function(event) {
 resetPropertyClassFilters();
 performSearch();
});

function resetPropertyClassFilters() {
 searchState.searchRequest.searchCriteria.buildingClassCriteria.reset();
 RenderFilters.propertyClassFilters(SearchAPI.BUILDING_CLASSES);
}

$('#size-price-filters .js-filter-reset').on('click', function(event) {
 resetSizePriceFilters();
 performSearch();
});

function resetSizePriceFilters() {
  Filters.reset();
  setSizeSearchCriteria();
  setPriceSearchCriteria();
  setLeaseRateSearchCriteria();
  setCapRateSearchCriteria();
}

$('#space-type-filters').on('click','.checkbox__input.js-filter-space', function(event) {
   const propertyType = getAssociatedPropertyType(event.target.value);
   searchState.searchRequest.searchCriteria.propertyTypes[propertyType].specialtyTypeCriteria[event.target.value] = $(event.target).prop('checked');
   RenderFilters.spaceTypeFilters(buildSpaceTypeFilterDisplayArray());
   performSearch();
});

$('#space-types .js-filter-reset').on('click', function(event) {
 resetSpaceTypeFilters();
 performSearch();
});

function resetSpaceTypeFilters() {
 for (var propertyType in searchState.searchRequest.searchCriteria.propertyTypes) {
   clearPropertyTypeSpaceFilters(propertyType);
 }
 RenderFilters.spaceTypeFilters(buildSpaceTypeFilterDisplayArray());
}


/**
 * Build Space Type Filter Display Array
 */
function buildSpaceTypeFilterDisplayArray() {

  // First get the property types that are selected
  const selectedPropertyTypes = getSelectedPropertyTypes();
  let spaceUses = [];
  let spaceUseDisplay = [];

  for (const propertyType in selectedPropertyTypes) {
    spaceUses.push(...SearchAPI.SPACE_USE_BY_PROPERTY_TYPE[selectedPropertyTypes[propertyType]]);
  }

  for (const spaceUse in spaceUses) {
    let displayInfo = SearchAPI.SPECIALTY_TYPES.find(function(element) {
      return element.value === spaceUses[spaceUse];
    })
    displayInfo.selected = searchState.searchRequest.searchCriteria.propertyTypes[getAssociatedPropertyType(displayInfo.value)].specialtyTypeCriteria[displayInfo.value];
    spaceUseDisplay.push(displayInfo);
  }

  spaceUseDisplay.sort((a, b) => a.display.localeCompare(b.display));

  return spaceUseDisplay;
}

/**
 * Get Selected Property Types
 */
function getSelectedPropertyTypes() {
  let selectedTypes = [];
  for (var type in searchState.searchRequest.searchCriteria.propertyTypes) {
    const propertyType = searchState.searchRequest.searchCriteria.propertyTypes[type];
    if (propertyType.selected === true) {
      selectedTypes.push(propertyType.propertyType);
    }
  }
  return selectedTypes;
}

/*
 * Clear Propety Type Space Filters
 */
function clearPropertyTypeSpaceFilters(propertyType) {
  searchState.searchRequest.searchCriteria.propertyTypes[propertyType].specialtyTypeCriteria.reset();
}

/**
 * Get Associated Property Type
 */
function getAssociatedPropertyType(spaceUse) {
  let propertyType = null;
  const keys = Object.keys(SearchAPI.SPACE_USE_BY_PROPERTY_TYPE);

  for (var key in SearchAPI.SPACE_USE_BY_PROPERTY_TYPE) {
    if (SearchAPI.SPACE_USE_BY_PROPERTY_TYPE[key].includes(spaceUse)) {
      propertyType = key;
      break;
    }
  }
  return propertyType;
}


/**
 * LoadStates
 */
var stateOptions = null;
var stateSelect = null;

function loadStates() {
  SearchAPI.ListingsSearch.findStatesWithAvailableListings(
    function(response) {
      console.log(response);
      stateSelect =
        new SlimSelect({
            select: '#state-filters-select',
            showSearch: false,
            searchPlaceholder: null
        })

        stateOptions = response.map((state) => {
          return {text: state.stateName,value: state.stateCode}
        });
        stateOptions =
            [
                {'placeholder': true, 'text': 'Select State(s)'},
                ...stateOptions
            ]

        stateSelect.setData(stateOptions);

        const selectElement = document.querySelector('#state-filters-select');

        selectElement.addEventListener('change', (event) => {
          setStateSearchCriteria(stateSelect.selected());
          performSearch();
        });
      },
      Utils.errorCallback
    );
  }

$('#location-filters .js-filter-reset').on('click', function(event) {
  resetLocationFilters();
  performSearch();
});

function resetLocationFilters() {
  searchState.searchRequest.searchCriteria.locationCriteria.reset();
  $('#broker-name-input').val(null);
  $('#building-name-input').val(null);
  $('#city-input').val(null);
  $('#location-address-input').val(null);
  stateSelect.close();
  stateSelect.setData(stateOptions);
}

function setStateSearchCriteria(states) {
  searchState.searchRequest.searchCriteria.locationCriteria.states = states;
}

$('#reset-all .js-filter-reset').on('click', function(event) {
  resetPropertyTypeFilters();
  resetLocationFilters()
  resetSizePriceFilters();
  resetSpaceTypeFilters();
  resetPropertyClassFilters();
  performSearch();
});
