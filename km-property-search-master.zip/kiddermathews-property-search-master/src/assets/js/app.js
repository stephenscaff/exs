/**
 * App JS
 * Primary entry point.
 * Compiles to app.min.js
 * Cleaning efforts moved property views specific stuff to js/views
 */
import "@babel/polyfill";
import './components/_polys.js'
import './components/_Sniffers.js'
import MenuSmall from './components/_MenuSmall.js'
import Drawers from './components/_Drawers.js'
import Dropdowns from './components/_Dropdowns.js'
import './views/_index.js'

MenuSmall.init();
Drawers.init();
Dropdowns.init();
