<?php
/**
 * Template Name: Market Research
 *
 * @author    Stephen Scaff
 * @package   page
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>
<main class="has-header-offset">

<?php get_template_part( 'views/shared/mast' ); ?>

<section class="modules">
  <?php get_template_part( 'views/shared/modules' );?>
</section>
<?php get_template_part( 'views/shared/bottom-nav' ); ?>
</main>

<?php get_footer(); ?>
