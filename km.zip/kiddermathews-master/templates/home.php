<?php
/**
 * Template Name: Home
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header(); ?>

<main>

<?php get_template_part( 'views/shared/mast-promo' ); ?>

<section class="modules">
<?php get_template_part( 'views/shared/modules' );?>
</section>

</main>

<?php get_footer(); ?>
