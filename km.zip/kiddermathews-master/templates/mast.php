<?php
/**
 * Template Name: Mast
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  template
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header(); ?>

<main class="has-header-offset">

<?php get_template_part( 'views/shared/mast' ); ?>

<section class="post-content is-page">
  <div class="grid-sm">
    <?php
    while (have_posts()) : the_post();
      the_content();
   endwhile; ?>
  </div>
</section>

</main>

<?php get_footer(); ?>
