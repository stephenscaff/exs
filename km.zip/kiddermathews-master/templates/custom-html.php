<?php
/**
 * Template Name: Custom HTML
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  template
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$grid = get_field('grid');
$custom_html = get_field('custom_html');

?>

<main class="has-header-offset">
  <section class="custom-html">
    <div class="<?php echo $grid; ?>">
      <?php echo $custom_html; ?>
    </div>
  </section>
</main>
<?php get_template_part( 'views/shared/bottom-nav' ); ?>
<?php get_footer(); ?>
