<?php
/**
 * Template Name: Property Search
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  template
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header(); ?>

<main>

<?php
get_template_part( 'views/properties/_search-mast' );
get_template_part( 'views/properties/_property-types' );
?>
<?php get_template_part( 'views/shared/bottom-nav' ); ?>
</main>

<?php get_footer(); ?>
