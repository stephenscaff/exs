<?php
/**
 * Template Name: Form
 * Creates a 2 col layout with a form (CF7) include and optional contacts
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  template
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$title = get_field('mast_pretitle');
$page_title = $title ? $title : get_the_title();
$page_subtitle = get_field('mast_title');
$company_phone_tollfree = get_field('company_phone_local', 'options');
$company_phone_tollfree = get_field('company_phone_tollfree', 'options');
$company_email = get_field('company_email', 'options');
$company_phone_property_mgmt = get_field('company_phone_property_management', 'options');
$company_email_property_mgmt = get_field('company_email_property_management', 'options');
$company_email = get_field('company_email', 'options');
$company_facebook = get_field('company_facebook', 'options');
$company_twitter = get_field('company_twitter', 'options');
$company_linkedin = get_field('company_linkedin', 'options');
$show_tollfree_phone = get_field('show_tollfree_phone');
$show_email = get_field('show_email');
$show_property_management_phone = get_field('show_property_management_phone');
$show_property_management_email = get_field('show_property_management_email');
$show_socials = get_field('show_socials');
$show_custom_contacts = get_field('show_custom_contacts');
$custom_contacts = get_field('custom_contacts');
$form_title = get_field('form_title');
$form_text = get_field('form_text');
$form_shortcode = get_field('form_shortcode');
$iframe_url = get_field('iframe_url');


?>

<main class="has-header-offset">

<section class="page-content">
  <div class="grid-lg">
    <div class="page-content__grid">
      <div class="page-content__half">

        <header class="page-content__header">
          <h1 class="page-content__header-pretitle"><?php echo $page_title; ?></h1>
          <h3 class="page-content__header-title"><?php echo $page_subtitle; ?></h3>
        </header>

        <?php if ($show_tollfree_phone && $company_phone_tollfree): ?>
        <div class="page-content__block has-contacts">
          <h5 class="page-content__heading">Contact</h5>
          <?php if ($company_phone_tollfree) : ?>
          <a class="link-tel" href="tel:<?php echo $company_phone_tollfree; ?>"><?php echo $company_phone_tollfree; ?></a> <br/>
          <?php endif; ?>
          <?php if ($show_email && $company_email): ?>
          <a class="link-email" href="mailto:<?php echo $company_email; ?>"><?php echo $company_email; ?></a>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($show_socials) : ?>
        <div class="page-content__block has-socials">
          <nav class="list-socials">
            <?php if ($company_facebook): ?><a class="list-socials__link" href="<?php echo $company_facebook; ?>"><i class="icon-facebook"></i></a><?php endif; ?>
            <?php if ($company_twitter): ?><a class="list-socials__link" href="<?php echo $company_twitter; ?>"><i class="icon-twitter"></i></a><?php endif; ?>
            <?php if ($company_linkedin): ?><a class="list-socials__link" href="<?php echo $company_linkedin; ?>"><i class="icon-linkedin"></i></a><?php endif; ?>
          </nav>
        </div>
        <?php endif; ?>

        <?php if ($show_property_management_email OR $show_property_management_phone) : ?>
        <div class="page-content__block has-contacts">
          <h5 class="page-content__heading">Property Management</h5>
          <span class="page-content__label">Customer Service Center</span>
          <?php if ($show_property_management_phone) : ?>
            <a class="link-tel" href="tel:<?php echo $company_phone_property_mgmt; ?>"><?php echo $company_phone_property_mgmt; ?></a> <br/>
          <?php endif; if ($show_property_management_phone) : ?>
          <a class="link-email" href="mailto:<?php echo $company_email_property_mgmt; ?>"><?php echo $company_email_property_mgmt; ?></a>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($show_custom_contacts) : ?>
        <div class="page-content__block has-contacts">
        <?php
        foreach ($custom_contacts as $custom_contacts) :
          $title = $custom_contacts['title'];
          $value = $custom_contacts['value']; ?>
          <h5 class="page-content__heading"><?php echo $title; ?></h5>
          <div><?php echo $value; ?></div>
        <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <div class="page-content__half">
        <section class="contact-form">
          <?php if ($form_title) : ?><h3 class="contact-form__title"><?php echo $form_title; ?></h3><?php endif; ?>
          <?php if ($form_text) : ?><p class="contact-form__subtitle"><?php echo $form_text; ?></p><?php endif; ?>
          <?php if ($form_shortcode) : ?><?php echo do_shortcode($form_shortcode); ?><?php endif; ?>
          <?php if (!$form_shortcode && $iframe_url) : ?><iframe frameborder="0" width="100%" class="iframe is-form" src="<?php echo $iframe_url; ?>" scrolling="no" ></iframe><?php endif; ?>
        </section>
      </div>
    </div>
  </div>
</section>

<section class="modules">
  <?php get_template_part( 'views/shared/modules' ); ?>
</section>

</main>

<?php get_footer(); ?>
