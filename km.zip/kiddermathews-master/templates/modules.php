<?php
/**
 * Template Name: Modules
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  template
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header(); ?>

<main class="has-header-offset">

<?php get_template_part( 'views/shared/mast' ); ?>

<section class="modules">
<?php get_template_part( 'views/shared/modules' ); ?>
</section>
<?php get_template_part( 'views/shared/bottom-nav' ); ?>
</main>

<?php get_footer(); ?>
