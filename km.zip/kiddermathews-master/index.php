<?php
/**
 * The News and Press Index
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$page_title = get_field('mast_title', 'news-index');

if (!$page_title) $page_title = 'In the news';

?>

<main role="main" class="has-header-offset">

<section class="heading is-centered is-title">
  <div class="grid">
    <h1 class="heading__title"><?php echo $page_title; ?></h1>
  </div>
</section>

<?php
include(locate_template('views/post/_featured-recent.php'));
include(locate_template('views/post/_search-filters-bar.php'));
include(locate_template('views/post/_featured-cats.php'));
include(locate_template('views/post/_press-contact.php'));
?>


<?php get_footer(); ?>
