# Kidder Mathews

## A custom build for KM.

Kidder Mathews is a custom wp build using a self-authored wp framework called The Jumpoff.

This repo is for the CMS / Wordpress build. If you're looking for the Project Search App

[Kiddermathews Property Search App](https://github.com/GreenRubino/kiddermathews-property-search)

### Features

- Gulp for task running
- Organization by partials and components of scss, js and php views.
- Custom drag and drop modules for content authorship
- A php approach to field management via ACF and Stout Logic's ACF Builder
- Custom Admin theme (styles and functionality)
- A library of useful utilities/helpers

### Dependencies
- [Node](https://nodejs.org/en/download/) : to run `gulp`.
- [NPM](https://www.npmjs.com/get-npm) : also to run `gulp`.
- [Gulp](https://gulpjs.com/) : for compiling, minimizing and linting scss, js, svgs, images, etc.
- [SCSS/SASS](https://sass-lang.com/) : for css authorship.
- [WordPress](https://wordpress.org/) : This is a custom Wordpress build
- [ACF](https://www.advancedcustomfields.com/pro/) : For managing fields, metas, options, etc.
- [StoutLogic ACF Builder](https://github.com/StoutLogic/acf-builder) : A more sane way to register ACF fields within PHP utils


## Deployments.

Currently, the site is hosted on Kinsta and features staging and production builds:

**Staging**  

[staging-kiddermathews.kinsta.cloud](http://staging-kiddermathews.kinsta.cloud)

**Production**  

[kidder.com](https://kidder.com)

This Repo is connected to the staging instance, so to deploy new code, your ssh key must first be added to the Kinsta Admin so you can access the servers. ([more on ssh keys](https://kinsta.com/knowledgebase/connect-to-ssh/))

Once added, deploying code the staging server follows this process:


**1. Add your local updates to the repo**

```
# Add changes
git add .

# Commit
git commit -m "some message about updates"

# Push updates to repo
git push
```

**2. ssh onto the staging server**

```
ssh kiddermathews@35.199.174.117 -p 52799
```

**3. cd to the theme directory**

```
cd public/wp-content/themes/kiddermathews
```

**4 Do a git pull to add your updates to staging**  

```
git pull
```

That deploys new code to the staging server.

When ready, to deploy to production, you currently have to go through the Kinsta admin.

1. Login to Kinsta
2. Go to Sites->Kiddermathews
3. Select Staging from the the Change Environment select.
4. When in the Staging Env, you will see a Deploy to production button. Click it.
5. Write the site name into the provided text field. The Deploy button will become active.
6. Click the Deploy button to deploy the staging site to prod.

Note that the Kinsta deploy script copies over all staging code, settings, and database, doing a search and replace for the site url.



## Run Project

Make sure Gulp and Node are globally installed on your system. Then:

**Install Gulp dependencies**

```
npm install --save-dev
```

**Install Composer dependencies**

Currently Composer is just installing StoutLogic's ACF Builder.
Make sure to run composer first, or the theme can't locate autoload and you'll see a custom error.

```
composer install
```


## Project Organization - Front-end


### Gulp / Task running

As mentioned, this project uses **Gulp** as the task runner, handling a variety of responsibilities like css/js compiling and minifing.

Reference tasks and packages at `gulpfile.js`.


### CSS / JS

As much as possible, css and js is organized by component, named after it's usage / BEM naming convention.

**JS**  

This is an ES6 build, leveraging **browserfy** (to support js modules) and **babel** (for ES6 to ES5 transpiling).

`src/assets/js/app.js` serves as the entry point and compiles to `assets/js/app.min.js`, which is loaded via Wp's enqueue system.

**SCSS/CSS**  

`src/assets/scss/app.scss` compiles to `assets/css/css.min.css` which is loaded via Wp's enqueue.
`src/assets/scss/fonts.scss` compiles to `assets/css/fonts.min.css` which is loaded via Wp's enqueue system.


## Project Organization - Wp

### Setup/Kickoff
`inc/app/*` houses a setup singleton class to kick things off.
`inc/admin/admin-setup` houses a setup singleton class related to the admin.


### Better Folder Org

**Views**  

`inc/Setup/loader.php` contains a template loader filter to reorg how wp loads template files.
Now, are components and single/archive/search files are housed in the `views` directory, and organized by content type.

For example:

- `single.php` code is housed `views/post/single.php`
- `archive.php` code is housed `views/post/archive.php`
-  Single view code for the `Professional` post type is housed in `views/professional/archive.php`, etc.
- Partials and scoped to their post type folder as well, using using the underscore naming convention to indicate their included nature - ie, `inc/professional/_page-nav.php`.
- Globally shared files are housed in `views/shared/*`

Note that default files like `archive.php` are left in place currently as a failsafe and just direct towards `views/post/archive.php` (etc).


### Fields

The Jumpoff uses ACF for Fields, but actual field authorship is enhanced with [Stout Logic's ACF Builder](https://github.com/StoutLogic/acf-builder).

Stout Logic provides a fluent API for rapidly creating and configuring ACF Fields in PHP, using a really nice builder pattern.

Here's an example of creating fields for SEO metas:

```
/**
 * Fields - SEO
 * Location: Pages, posts, Team post type.
 */
$seo_fields = new StoutLogic\AcfBuilder\FieldsBuilder('seo', [
  'key' => 'seo',
  'position' => 'normal',
]);

$seo_fields
  ->addText('seo_title')
  ->addTextArea('seo_description',  [
    'rows' =>  '2'
  ])
  ->addImage('seo_image')
  ->setLocation('post_type', '==', 'page')
    ->or('post_type', '==', 'post')
    ->or('post_type', '==', 'team');

add_action('acf/init', function() use ($seo_fields) {
   acf_add_local_field_group($seo_fields->build());
});
```

All Fields are registered in `inc/fields/*`, generally in their own clearly named file. Variables for reuse are housed in `inc/fields/vars.php`.


## Modules

The Jumpoff uses ACF's Flexible content fields to create a drag-and-drop module system and are defined at `inc/fields/modules/*`

The Modules are then included and added to a modules template (or whatever) at `inc/fields/modules.php`.

A custom module loader class (`inc/acf/acf-modules.php`) further enhances flexible content fields by mapping them by name to files within the `views/modules` directory. So, when used, a module field named `content-module` will load and scope it's fields to a module file at `views/modules/content-module.php`.

For Example:

**Define Content Module**  


```
// inc/fields/modules/content

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Content Module
 * Creates an content / wysi section
 * @see scss/components/_content (post-content)
 */
$content_module = new FieldsBuilder('content_module');
$content_module
  ->addMessage('', 'The Content Module creates an all purpose content/wysi region.')
  ->addWysiwyg('content');

```

**Define Content Module**  


```
// inc/fields/modules.php

use StoutLogic\AcfBuilder\FieldsBuilder;


require_once('modules/content.php');
...

$modules= new FieldsBuilder('modules');

$modules
  ->addFlexibleContent('modules',
    ['button_label'=> 'Add Module']
  )
  ->addLayout($cards_module,
    ['name'=> 'cards_module']
  )
  ...
  ->setLocation('page_template', '==', 'templates/modules.php');

  add_action('acf/init', function() use ($modules) {
     acf_add_local_field_group($modules->build());
  });
```

**Content Module View**  


```
// views/modules/content-module.php

$content = get_sub_field('content');

?>

<section class="content module">
  <div class="grid-sm">
    <?php echo $content; ?>
  </div>
</section>

```

**Calling the Modules in a template**  


```

// views/shared/modules.php

while (has_sub_field('modules')) :
  ACF_Modules::render(get_row_layout());
endwhile;
```


### INC

Site functionality is added in the `inc` folder, with the goal of self authoring most theme/site functionality (as oppose to leveraging 3rd party plugins).

`inc` is broken up into a collection of folders to organize related functionality:

**App**  

Houses the main theme setup class, and the custom template loader.

**Admin**  

A custom admin theme and various admin-based functionality and utilities are housed in `inc/admin`. `admin-theme` includes the scss for our, eh, admin theme. `admin.scss` compiles out via gulp into `admin.css`.

**ACF**  

Houses ACF related functionality, including the modules system.

**Api**  

Houses stuff related to leveraging the WP Rest API

**Post Types**  

Custom Post Types are registered in `inc/post-types` and follow a simple file naming convention.

**Fields**  

Where Fields are defined (see above for more)

**Media**  

Houses functionality related to Images and media.

**Search and Filtering**  

Houses functionality related to the extensive customization of wp search

**Utils**  

Houses general utilities, helpers, conditionals, hooks, debuggers, post funcs, etc.
