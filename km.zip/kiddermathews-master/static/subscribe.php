<?php
/**
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

$title = get_field('mast_pretitle');
$page_title = $title ? $title : get_the_title();
$page_subtitle = get_field('mast_title');
$company_phone_tollfree = get_field('company_phone_local', 'options');
$company_phone_tollfree = get_field('company_phone_tollfree', 'options');
$company_email = get_field('company_email', 'options');
$company_phone_property_mgmt = get_field('company_phone_property_management', 'options');
$company_email_property_mgmt = get_field('company_email_property_management', 'options');
$company_email = get_field('company_email', 'options');
$company_facebook = get_field('company_facebook', 'options');
$company_twitter = get_field('company_twitter', 'options');
$company_linkedin = get_field('company_linkedin', 'options');
$form_title = get_field('form_title');
$form_text = get_field('form_text');
$form_id = get_field('form_id');
$form_id = 1834;

?>

<main class="has-header-offset">

<section class="page-content">
  <div class="grid-lg">
    <div class="page-content__grid">
      <div class="page-content__half">

        <header class="page-content__header">
          <h1 class="page-content__header-pretitle"><?php $page_title; ?></h1>
          <h3 class="page-content__header-title"><?php echo $page_subtitle; ?></h3>
        </header>

        <div class="page-content__block">
          <h5 class="page-content__heading">Contact</h5>
          <?php if ($company_phone_tollfree): ?>
            <a class="link-tel" href="tel:<?php echo $company_phone_tollfree; ?>"><?php echo $company_phone_tollfree; ?></a> <br/>
          <?php endif; ?>
          <?php if ($company_email): ?>
            <a class="link-email" href="mailto:<?php echo $company_email; ?>"><?php echo $company_email; ?></a>
          <?php endif; ?>
          <br/><br/>
          <nav class="list-socials">
            <?php if ($company_facebook) : ?><a class="list-socials__link" href="<?php echo $company_facebook; ?>"><i class="icon-facebook"></i></a><?php endif; ?>
            <?php if ($company_twitter) : ?><a class="list-socials__link" href="<?php echo $company_twitter; ?>"><i class="icon-twitter"></i></a><?php endif; ?>
            <?php if ($company_linkedin): ?><a class="list-socials__link" href="<?php echo $company_linkedin; ?>"><i class="icon-linkedin"></i></a><?php endif; ?>
          </nav>
        </div>
        <div class="page-content__block">
          <h5 class="page-content__heading">Property Management</h5>
          <span class="page-content__label">Customer Service Center</span>
          <a class="link-tel" href="tel:<?php echo $company_phone_property_mgmt; ?>"><?php echo $company_phone_property_mgmt; ?></a> <br/>
          <a class="link-email" href="mailto:<?php echo $company_email_property_mgmt; ?>"><?php echo $company_email_property_mgmt; ?></a>
        </div>
      </div>

      <div class="page-content__half">
        <section class="contact-form">
          <?php if ($form_title) : ?><h3 class="contact-form__title"><?php echo $form_title; ?></h3><?php endif; ?>
          <?php if ($form_text) : ?><p class="contact-form__subtitle"><?php echo $form_text; ?></p><?php endif; ?>

          <?php echo do_shortcode('[contact-form-7 id="'.$form_id.'" title="Contact Form"]'); ?>
        </section>
      </div>
    </div>
  </div>
</section>

<section class="modules">
  <?php get_template_part( 'partials/partial', 'modules' ); ?>
</section>

</main>

<?php get_footer(); ?>
