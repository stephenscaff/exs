<?php
/**
* The default template for single blog posts.
*
* @author    Stephen Scaff
* @package   jumpoff
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

while (have_posts()) : the_post();

$mast_title = get_the_title();

?>

<main role="main" class="has-header-offset">

<article>

<section class="mast-pro">
  <figure class="mast-pro__lines">
    <?php echo jumpoff_get_svg('lines-for-pro'); ?>
  </figure>
  <figure class="mast-pro__headshot">
    <img class="mast-pro__headshot-img" src="<?php echo jumpoff_get_img_dir(); ?>/tmp/tmp-jason-r.png"/>
  </figure>
  <header class="mast-pro__header grid-lg">
    <span class="mast-pro__city-state">Seattle, WA</span>
    <h1 class="mast-pro__title"><?php echo $mast_title; ?></h1>
    <span class="mast-pro__position">Senior Vice President | Partner</span>
  </header>
</section>


<section class="intro-pro">
  <div class="grid-lg">
    <div class="intro-pro__grid">

      <div class="intro-pro__info">
        <div class="intro-pro__info-grid">
          <div class="intro-pro__info-col">
            <h5 class="intro-pro__heading">Contact</h5>
            <span class="intro-pro__value is-tel">T <a href="tel:">206.296.9608</a></span>
            <span class="intro-pro__value is-tel">F <a href="tel:">206.296.9608</a></span>

            <a class="intro-pro__value is-email">jrosaure@kiddermathes.com</a>

            <address class="intro-pro__address">
              601 Union Street, Ste 4720 <br/>
              Seattle, WA 98101
            </address>
          </div>

          <div class="intro-pro__info-col">

            <h5 class="intro-pro__heading">License No.</h5>
            <span class="intro-pro__value">1321474-98</span>

            <h5 class="intro-pro__heading">Downloads</h5>
            <a class="intro-pro__value is-download">vCard</a>
            <a class="intro-pro__value is-download">Bio</a>

            <nav class="intro-pro__socials">
              <a class=""><i class="icon-facebook"></i></a>
              <a class=""><i class="icon-twitter"></i></a>
              <a class=""><i class="icon-linkedin"></i></a>
            </nav>

          </div>
        </div>
      </div>

      <div class="intro-pro__main">
        <h5 class="intro-pro__heading is-sm-only">About Jason</h5>
        <div class="js-read-more" data-rm-words="100">
          <p>Jason Rosauer joined Kidder Mathews in 2002. Jason’s career experience is the basis for qualified focus in real estate investment brokerage, as well as grocery specific, complex lease negotiations and arbitration. In 2012, Jason joined with Rob Anderson to form an investment team. Jason handles complex transactions and is the team’s primary client interface. Jason is a strategic deal maker and skilled negotiator and brings expertise and experience from a broad range of markets to service the client.</p>

          <p>Previously, Jason was the Director of Real Estate Investment for a privately held investment company based out of Seattle, Washington. This position encompassed strategic management of capital through acquisition, development, and sale of assets in six geographic locations throughout Washington, Idaho, and Montana. Jason has established quality working relationships with senior key real estate professionals in virtually every major and sub-tier market located throughout the West Coast.</p>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="list-items">
  <div class="grid-lg">
    <div class="list-items__bg bg-grey-light">
    <header class="heading">
      <h2 class="heading_title">Client List</h2>
    </header>
    <ul class="list-items__list grid-1-2-3">
      <li>AAA Washington</li>
      <li>Albertson’s</li>
      <li>Associated Grocers</li>
      <li>Bank of America</li>
      <li>Carlile Transportation Systems</li>
      <li>City of Monroe</li>
      <li>City of Seattle</li>
      <li>Cohen Financial</li>
      <li>Elks Club</li>
      <li>Energy Northwest-Washington State</li>
      <li>HNA Airlines</li>
      <li>Kauri Investment</li>
      <li>Key Bank</li>
      <li>King County</li>
      <li>NW Marine Trade Association</li>
      <li>Red Lion Hotels</li>
      <li>Sabey Corporation</li>
      <li>Safeway-PDA</li>
      <li>Schnitzer Steel</li>
      <li>Seattle Housing Authority</li>
      <li>Services Group of America (SGA)</li>
      <li>Silver Cloud Hotel</li>
      <li>State of Washington</li>
      <li>Talon Private Capital</li>
      <li>Volunteers of America</li>
      <li>Wards Cove</li>
      <li>As well as multiple privately held investment companies throughout the U.S.</li>
    </ul>
  </div>
</div>
</section>


<section class="properties  pad">
  <div class="grid-lg">
    <div class="properties__grid grid-1-2-4">
      <?php loop_content(8, 'property'); ?>
    </div>
    <footer class="ending">
      <a class="ending__btn btn" href="">View All</a>
    </footer>
  </div>
</section>


<!-- Team CTA -->
<section class="team-cta-pro">
  <figure class="team-cta-pro__headshot">
    <img class="team-cta-pro__headshot-img" src="<?php echo jumpoff_get_img_dir(); ?>/tmp/tmp-team-jason-rob.png"/>
  </figure>
  <header class="team-cta-pro__header grid-lg">
    <span class="team-cta-pro__meta">Investment Team</span>
    <h1 class="team-cta-pro__title"><?php echo $mast_title; ?></h1>
    <span class="team-cta-pro__text">Client Interface / Deal Flow & Transaction Coordinator / Project Marketing Lead / Deal Strategy & Negotiations</span>
    <a class="team-cta-pro__btn btn-line is-white" href="#">View Team Profile</a>
  </header>
</section>



<section class="stats module pad">
  <div class="grid-lg">
    <div class="stats__bg">

      <header class="stats__header">
        <h3 class="stats__title">Company Overview</h3>
      </header>

      <div class="stats__grid grid-2-3-5">
        <article class="stat">
          <div class="stat__numb">20</div>
          <h5 class="stat__title">Office Location</h5>
          <p class="stat__text">In Washington, Oregon, California, Nevada & Arizona</p>
        </article>

        <article class="stat">
          <div class="stat__numb">36</div>
          <h5 class="stat__title">Appraisers</h5>
          <p class="stat__text">22 MAI Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">700+</div>
          <h5 class="stat__title">Employees</h5>
          <p class="stat__text">Brokers, Staff & Professionals</p>
        </article>

        <article class="stat">
          <div class="stat__numb">360+</div>
          <h5 class="stat__title">Brokers</h5>
          <p class="stat__text">39 SIOR & 24 CCIM Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">46</div>
          <h5 class="stat__title">Property Managers</h5>
          <p class="stat__text">Including Construction & Development Management</p>
        </article>

        <article class="stat">
          <div class="stat__numb">20</div>
          <h5 class="stat__title">Office Location</h5>
          <p class="stat__text">In Washington, Oregon, California, Nevada & Arizona</p>
        </article>

        <article class="stat">
          <div class="stat__numb">36</div>
          <h5 class="stat__title">Appraisers</h5>
          <p class="stat__text">22 MAI Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">700+</div>
          <h5 class="stat__title">Employees</h5>
          <p class="stat__text">Brokers, Staff & Professionals</p>
        </article>

        <article class="stat">
          <div class="stat__numb">360+</div>
          <h5 class="stat__title">Brokers</h5>
          <p class="stat__text">39 SIOR & 24 CCIM Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">46</div>
          <h5 class="stat__title">Property Managers</h5>
          <p class="stat__text">Including Construction & Development Management</p>
        </article>

        <article class="stat">
          <div class="stat__numb">36</div>
          <h5 class="stat__title">Appraisers</h5>
          <p class="stat__text">22 MAI Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">700+</div>
          <h5 class="stat__title">Employees</h5>
          <p class="stat__text">Brokers, Staff & Professionals</p>
        </article>

        <article class="stat">
          <div class="stat__numb">360+</div>
          <h5 class="stat__title">Brokers</h5>
          <p class="stat__text">39 SIOR & 24 CCIM Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">46</div>
          <h5 class="stat__title">Property Managers</h5>
          <p class="stat__text">Including Construction & Development Management</p>
        </article>
      </div>
    </div>
  </div>
</section>



<!-- Banners -->
<section class="banner-block">
  <div class="banner__wrap">
    <figure class="banner__figure" style="background-image: url(http://127.0.0.1/kiddermathews/wp-content/uploads/2018/10/about-mast.jpg)"></figure>
    <header class="banner__header">
      <div class="grid-lg">
        <div>
          <h3 class="banner__title">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias.</h3>
        </div>
      </div>
    </header>
  </div>
</section>




<!-- Card Blocks : Success Stories -->
<section class="card-blocks is-stories module">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title">Success Stories</h2>
    </header>

    <div class="card-blocks__grid">

      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(<?php echo jumpoff_get_img_dir(); ?>/masts/professional-search-mast.jpg)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Where We All Think Like Owners</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(<?php echo jumpoff_get_img_dir(); ?>/masts/properties-search-mast.jpg)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Professionals</h3>
            </div>
          </header>
        </a>
      </article>


      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(https://source.unsplash.com/AqY6268yL3o/1250x750)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Where We All Think Like Owners</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(https://source.unsplash.com/ABKvlwjFT68/1250x750)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Professionals</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(https://source.unsplash.com/AqY6268yL3o/1250x750)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Where We All Think Like Owners</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block is-story is-story-all">
        <a class="card-block__link js-svg-trigger" href="">
          <figure class="car-block__svg">
            <?php echo jumpoff_get_svg('lines-for-story'); ?>
          </figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__btn">View All Success Stories</span>
            </div>
          </header>
        </a>
      </article>
    </div>
  </div>
</section>


<section class="testimonials pad bg-grey-light has-show-more">
  <div class="grid-lg">

    <header class="heading">
      <h2 class="heading__title">Testimonials</h2>
    </header>
    <div class="testimonails__items js-show-more">

      <article class="testimonial show-more__item ">
        <div class="testimonial__grid">
          <header class="testimonial__header">
            <h4 class="testimonial__author">Ching-Mang Chang</h4>
            <span class="testimonial__byline">Owner, iDream Summit, LLC and iDream Properties, LLC</span>
          </header>

          <div class="testimonial__quote">
            <div class="js-read-more" data-rm-words="50">
              <p>During the transaction, you were readily available, listened patiently, responded quickly and provided thorough and thoughtful feedback, suggestions and guidance on all aspects of the transaction.</p>
              <p>Your knowledge of the buildings, conditions and market trends of the immediate and surrounding marketplace provided an accurate and able sense for underwriting that is rare for the typical sales professional. Your initial underwriting was an essential component in directing and facilitating the transaction into a successful closing.</p>
            </div>
          </div>
        </div>
      </article>

      <article class="testimonial show-more__item ">
        <div class="testimonial__grid">
          <header class="testimonial__header">
            <h4 class="testimonial__author">Ching-Mang Chang</h4>
            <span class="testimonial__byline">Owner, iDream Summit, LLC and iDream Properties, LLC</span>
          </header>

          <div class="testimonial__quote">
            <div class="js-read-more" data-rm-words="50">
              <p>During the transaction, you were readily available, listened patiently, responded quickly and provided thorough and thoughtful feedback, suggestions and guidance on all aspects of the transaction.</p>
              <p>Your knowledge of the buildings, conditions and market trends of the immediate and surrounding marketplace provided an accurate and able sense for underwriting that is rare for the typical sales professional. Your initial underwriting was an essential component in directing and facilitating the transaction into a successful closing.</p>
            </div>
          </div>
        </div>
      </article>


      <article class="testimonial show-more__item ">
        <div class="testimonial__grid">
          <header class="testimonial__header">
            <h4 class="testimonial__author">Ching-Mang Chang</h4>
            <span class="testimonial__byline">Owner, iDream Summit, LLC and iDream Properties, LLC</span>
          </header>

          <div class="testimonial__quote">
            <div class="js-read-more" data-rm-words="50">
              <p>Your knowledge of the buildings, conditions and market trends of the immediate and surrounding marketplace provided an accurate and able sense for underwriting that is rare for the typical sales professional. Your initial underwriting was an essential component in directing and facilitating the transaction into a successful closing.</p>
              <p>During the transaction, you were readily available, listened patiently, responded quickly and provided thorough and thoughtful feedback, suggestions and guidance on all aspects of the transaction. Your initial underwriting was an essential component in directing and facilitating the transaction</p>
            </div>
          </div>
        </div>
      </article>


      <article class="testimonial show-more__item ">
        <div class="testimonial__grid">
          <header class="testimonial__header">
            <h4 class="testimonial__author">Ching-Mang Chang</h4>
            <span class="testimonial__byline">Owner, iDream Summit, LLC and iDream Properties, LLC</span>
          </header>

          <div class="testimonial__quote">
            <div class="js-read-more" data-rm-words="50">
              <p>During the transaction, you were readily available, listened patiently, responded quickly and provided thorough and thoughtful feedback, suggestions and guidance on all aspects of the transaction.</p>
              <p>Your knowledge of the buildings, conditions and market trends of the immediate and surrounding marketplace provided an accurate and able sense for underwriting that is rare for the typical sales professional. Your initial underwriting was an essential component in directing and facilitating the transaction into a successful closing.</p>
            </div>
          </div>
        </div>
      </article>


      <article class="testimonial show-more__item ">
        <div class="testimonial__grid">
          <header class="testimonial__header">
            <h4 class="testimonial__author">Ching-Mang Chang</h4>
            <span class="testimonial__byline">Owner, iDream Summit, LLC and iDream Properties, LLC</span>
          </header>

          <div class="testimonial__quote">
            <div class="js-read-more" data-rm-words="50">
              <p>During the transaction, you were readily available, listened patiently, responded quickly and provided thorough and thoughtful feedback, suggestions and guidance on all aspects of the transaction.</p>
              <p>Your knowledge of the buildings, conditions and market trends of the immediate and surrounding marketplace provided an accurate and able sense for underwriting that is rare for the typical sales professional. Your initial underwriting was an essential component in directing and facilitating the transaction into a successful closing.</p>
            </div>
          </div>
        </div>
      </article>

    </div>

    <footer class="ending no-pad">
      <a class="btn js-show-more-btn">Show More</a>
    </footer>


  </div>
</section>

<section class="intro has-drawing is-inset module pad">
  <div class="intro__bg bg-grey-dark">
    <div class="intro__lines">
      <?php echo jumpoff_get_svg('lines-for-dark'); ?>
    </div>
    <div class="grid-lg">
      <div class="intro__grid">
        <header class="intro__header">
          <h5 class="intro__pretitle">Jason's Blog</h5>
          <h2 class="intro__title">Seattle/Tacoma Industrial Commerical Real Estate</h2>
        </header>

        <div class="intro__main">
          <p class="intro__text">Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nullam id dolor id nibh ultricies.</p>

          <div class="btns">
            <a class="btn-line" href="">Learn More</a>
            <span class="sep-vert is-white"></span>
            <a class="btn-line" href="">Subscribe</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="research pad">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title">Market Research</h2>
    </header>
    <div class="research__grid grid-1-3">
      <?php loop_content(3, 'text-post'); ?>
    </div>
    <footer class="ending">
      <a class="ending__btn btn" href="">View All</a>
    </footer>
  </div>
</section>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCdI3zqWx343t6RK4D13GvX8Cnn66oWX9E"></script>

<section class="properties-map">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title">Available Properties</h2>
    </header>
    <div class="properties-map__controls">
      <nav class="properties-map__nav">
        <a class="is-active">For Sale</a>
        <span class="sep-vert"></span>
        <a class="">For Lease</a>
      </nav>
      <a class="">View All Properties</a>
    </div>
    <div class="properties-map__map-wrap">
      <div class="properties-map__map js-properties-map">

        <article class="marker js-marker" data-lat="47.606701" data-lng="-122.332501">
          <div class="marker__wrap">
            <div class="marker__grid">
              <figure class="marker__figure">
                <img class="marker__img" src="https://source.unsplash.com/fIywSGHYLYM/500x700"/>
              </figure>
              <div class="marker__main">
                <span class="marker__title">Captial Hill Office</span>
                <address class="marker__address">
                  <span class="marker__street">601 Union Street, Suite 4720</span>
                  <span class="marker__city-state">Seattle, WA 98202</span>
                </address>
                <span class="marker__tel">206.299.1245</span>

                <a class="marker__btn btn-line">View Location</a>
              </div>
            </div>
          </div>
        </article>

        <article class="marker js-marker" data-lat="47.605024" data-lng="-122.334371">
          <div class="marker__wrap">
            <div class="marker__grid">
              <figure class="marker__figure">
                <img class="marker__img" src="https://source.unsplash.com/fIywSGHYLYM/500x700"/>
              </figure>
              <div class="marker__main">
                <span class="marker__title">Seattle Office Headquarthers</span>
                <address class="marker__address">
                  <span class="marker__street">601 Union Street, Suite 4720</span>
                  <span class="marker__city-state">Seattle, WA 98202</span>
                </address>
                <span class="marker__tel">206.299.1245</span>

                <a class="marker__btn btn-line">View Location</a>
              </div>
            </div>
          </div>
        </article>

        <article class="marker js-marker"  data-lat="47.600506" data-lng="-122.333225">
          <div class="marker__wrap">
            <div class="marker__grid">
              <figure class="marker__figure">
                <img class="marker__img" src="https://source.unsplash.com/fIywSGHYLYM/500x700"/>
              </figure>
              <div class="marker__main">
                <span class="marker__title">Seattle Office Headquarthers</span>
                <address class="marker__address">
                  <span class="marker__street">601 Union Street, Suite 4720</span>
                  <span class="marker__city-state">Seattle, WA 98202</span>
                </address>
                <span class="marker__tel">206.299.1245</span>

                <a class="marker__btn btn-line">View Location</a>
              </div>
            </div>
          </div>
        </article>


      </div>
    </div>
  </div>
</section>

</main>

<?php endwhile; ?>

<!-- Footer-->
<?php get_footer(); ?>
