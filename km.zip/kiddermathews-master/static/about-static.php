<?php
/**
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<main class="has-header-offset modules">

<?php get_template_part( 'views/shared', 'mast ); ?>

<?php

$service_location = jumpoff_term('service_location');
$service_link = get_field('service_link');
$service_title = get_the_title();
$service_excerpt = get_field('service_excerpt');
?>

<article class="services-listing">
  <div class="services-listing__wrap">
    <div class="services-listing__meta">
      <h3 class="services-listing__meta-location"><?php echo $service_location->name; ?></h3>
    </div>
    <div class="services-listing__main">
      <h3 class="services-listing__title"><?php echo $service_title; ?></h3>
      <p class="services-listing__excerpt"><?php echo $service_excerpt; ?></p>
    </div>
  </div>
</article>



<!-- <section class="split-cta module">
  <div class="split-cta__bg">
    <div class="grid-lg">
      <div class="split-cta__grid">

        <header class="split-cta__header">
          <h5 class="split-cta__pretitle">About Us</h5>
          <h2 class="split-cta__title">Kidder Mathews is the largest independent commercial real estate firm on the West Coast.</h2>
        </header>

        <div class="split-cta__main">
          <p class="split-cta__text">With more than 700 real estate professionals and staff in 20 offices in Washington, Oregon, California, Nevada, and Arizona, we offer a complete range of brokerage, appraisal, property management, consulting, project and construction management, and debt equity finance services for all property types.</p>
          <a class="btn-line" href="">Learn More</a>
        </div>

      </div>
    </div>
  </div>
</section> -->


<!-- <section class="stats module">
  <div class="grid-lg">
    <div class="stats__bg">

      <header class="stats__header">
        <h3 class="stats__title">Company Overview</h3>
      </header>

      <div class="stats__grid grid-2-3-5">
        <article class="stat">
          <div class="stat__numb">20</div>
          <h5 class="stat__title">Office Location</h5>
          <p class="stat__text">In Washington, Oregon, California, Nevada & Arizona</p>
        </article>

        <article class="stat">
          <div class="stat__numb">36</div>
          <h5 class="stat__title">Appraisers</h5>
          <p class="stat__text">22 MAI Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">700+</div>
          <h5 class="stat__title">Employees</h5>
          <p class="stat__text">Brokers, Staff & Professionals</p>
        </article>

        <article class="stat">
          <div class="stat__numb">360+</div>
          <h5 class="stat__title">Brokers</h5>
          <p class="stat__text">39 SIOR & 24 CCIM Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">46</div>
          <h5 class="stat__title">Property Managers</h5>
          <p class="stat__text">Including Construction & Development Management</p>
        </article>

        <article class="stat">
          <div class="stat__numb">20</div>
          <h5 class="stat__title">Office Location</h5>
          <p class="stat__text">In Washington, Oregon, California, Nevada & Arizona</p>
        </article>

        <article class="stat">
          <div class="stat__numb">36</div>
          <h5 class="stat__title">Appraisers</h5>
          <p class="stat__text">22 MAI Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">700+</div>
          <h5 class="stat__title">Employees</h5>
          <p class="stat__text">Brokers, Staff & Professionals</p>
        </article>

        <article class="stat">
          <div class="stat__numb">360+</div>
          <h5 class="stat__title">Brokers</h5>
          <p class="stat__text">39 SIOR & 24 CCIM Designations</p>
        </article>

        <article class="stat">
          <div class="stat__numb">46</div>
          <h5 class="stat__title">Property Managers</h5>
          <p class="stat__text">Including Construction & Development Management</p>
        </article>
      </div>
    </div>
  </div>
</section> -->


<!-- <section class="split-cta has-drawing module">
  <div class="split-cta__bg bg-alpha ">
  <div class="split-cta__lines">
    <?php echo jumpoff_get_svg('lines-for-alpha'); ?>
  </div>

  <div class="grid-lg">
    <div class="split-cta__grid">
      <header class="split-cta__header">
        <h5 class="split-cta__pretitle">Our Services</h5>
        <h2 class="split-cta__title">We have built a comprehensive list of services in response to our clients’ varied commercial real estate needs.</h2>
      </header>

      <div class="split-cta__main">
        <p class="split-cta__text">Our professionals perform an extensive needs analysis process to ensure the appropriate services provided are in alignment with your business objectives.</p>

        <a class="btn-line" href="">Learn More</a>
      </div>
    </div>
  </div>
</div>
</section> -->

<section class="card-blocks is-full module">
  <div class="grid-lg">

      <article class="card-block">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(<?php echo jumpoff_get_img_dir(); ?>/masts/professional-search-mast.jpg)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__pretitle">Office Locations</span>
              <h3 class="card-block__title">Benefit from Twenty West Coast Offices Delivering their Local Expertise</h3>
            </div>
          </header>
        </a>
      </article>
  </div>
</section>


<section class="card-blocks module">
  <div class="grid-lg">
    <div class="card-blocks__grid grid-1-2">

      <article class="card-block">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(<?php echo jumpoff_get_img_dir(); ?>/masts/professional-search-mast.jpg)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__pretitle">Search for</span>
              <h3 class="card-block__title">Where We All Think Like Owners</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(<?php echo jumpoff_get_img_dir(); ?>/masts/properties-search-mast.jpg)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__pretitle">Search for</span>
              <h3 class="card-block__title">Professionals</h3>
            </div>
          </header>
        </a>
      </article>
    </div>
  </div>
</section>



<section class="card-blocks is-stories module">
  <div class="grid-lg">
    <div class="card-blocks__grid">

      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(<?php echo jumpoff_get_img_dir(); ?>/masts/professional-search-mast.jpg)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Where We All Think Like Owners</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(<?php echo jumpoff_get_img_dir(); ?>/masts/properties-search-mast.jpg)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Professionals</h3>
            </div>
          </header>
        </a>
      </article>


      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(https://source.unsplash.com/AqY6268yL3o/1250x750)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Where We All Think Like Owners</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(https://source.unsplash.com/ABKvlwjFT68/1250x750)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Professionals</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block is-story">
        <a class="card-block__link" href="">
          <figure class="card-block__figure" style="background-image: url(https://source.unsplash.com/AqY6268yL3o/1250x750)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">Brokerage | Office | Seattle, WA</span>
              <h3 class="card-block__title">Where We All Think Like Owners</h3>
            </div>
          </header>
        </a>
      </article>

      <article class="card-block is-story is-story-all">
        <a class="card-block__link js-svg-trigger" href="">
          <figure class="car-block__svg">
            <?php echo jumpoff_get_svg('lines-for-story'); ?>
          </figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__btn">View All Success Stories</span>
            </div>
          </header>
        </a>
      </article>
    </div>
  </div>
</section>


<section class="logos module">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title">Awards and Rankings</h2>
    </header>
    <div class="logos__grid">
      <figure class="logo">
        <img class="logo__img" src="<?php echo jumpoff_get_img_dir(); ?>/awards/award-bptw.png" alt="">
      </figure>

      <figure class="logo">
        <img class="logo__img" src="<?php echo jumpoff_get_img_dir(); ?>/awards/award-top-work-places.png" alt="">
      </figure>

      <figure class="logo">
        <img class="logo__img" src="<?php echo jumpoff_get_img_dir(); ?>/awards/award-costar-group.png" alt="">
      </figure>

      <figure class="logo">
        <img class="logo__img" src="<?php echo jumpoff_get_img_dir(); ?>/awards/award-bptw.png" alt="">
      </figure>

      <figure class="logo">
        <img class="logo__img" src="<?php echo jumpoff_get_img_dir(); ?>/awards/award-top-work-places.png" alt="">
      </figure>

      <figure class="logo">
        <img class="logo__img" src="<?php echo jumpoff_get_img_dir(); ?>/awards/award-costar-group.png" alt="">
      </figure>

    </div>
  </div>
</section>

<section class="card-posts module">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title">In The News</h2>
    </header>

    <div class="card-posts__grid grid-1-3">

      <article class="card-post">
        <a class="card-post__link" href="">
          <figure class="card-post__figure">
            <img class="card-post__img" src="https://source.unsplash.com/CpSEtJOcYRI/1250x750" alt=""/>
          </figure>
          <div class="card-post__main">
            <span class="card-post__meta">
              News | Seattle, WA | 09.16.18
            </span>

            <h4 class="card-post__title">Largest Office Occupiers in the Puget Sound Region</h4>
            <p class="card-post__excerpt">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis…</p>
            <span class="card-post__btn btn-line">Read More</span>
          </div>
        </a>
      </article>

      <article class="card-post">
        <a class="card-post__link" href="">
          <figure class="card-post__figure">
            <img class="card-post__img" src="https://source.unsplash.com/ABKvlwjFT68/1250x750" alt=""/>
          </figure>
          <div class="card-post__main">
            <span class="card-post__meta">
              News | Seattle, WA | 09.16.18
            </span>

            <h4 class="card-post__title">Largest Office Occupiers in the Puget Sound Region</h4>
            <p class="card-post__excerpt">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis…</p>
            <span class="card-post__btn btn-line">Read More</span>
          </div>
        </a>
      </article>

      <article class="card-post">
        <a class="card-post__link" href="">
          <figure class="card-post__figure">
            <img class="card-post__img" src="https://source.unsplash.com/AqY6268yL3o/1250x750" alt=""/>
          </figure>
          <div class="card-post__main">
            <span class="card-post__meta">
              News | Seattle, WA | 09.16.18
            </span>

            <h4 class="card-post__title">Largest Office Occupiers in the Puget Sound Region</h4>
            <p class="card-post__excerpt">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis…</p>
            <span class="card-post__btn btn-line">Read More</span>
          </div>
        </a>
      </article>

    </div>

    <footer class="ending">
      <a class="btn" href="">View All</a>
    </footer>
  </div>
</section>

<section class="split-cta has-drawing is-inset pad">
  <div class="split-cta__bg bg-grey-dark">
    <div class="split-cta__lines">
      <?php echo jumpoff_get_svg('lines-for-dark'); ?>
    </div>
    <div class="grid-lg">
      <div class="split-cta__grid">
        <header class="split-cta__header">
          <h5 class="split-cta__pretitle">Our Services</h5>
          <h2 class="split-cta__title">We have built a comprehensive list of services in response to our clients’ varied commercial real estate needs.</h2>
        </header>

        <div class="split-cta__main">
          <p class="split-cta__text">Our professionals perform an extensive needs analysis process to ensure the appropriate services provided are in alignment with your business objectives.</p>

          <a class="btn-line" href="">Learn More</a>
        </div>
      </div>
    </div>
  </div>
</section>


<section class="list-block">
  <div class="grid-lg">
    <div class="list-block__grid">


    </div>
  </div>
</section>

</main>

<?php get_footer(); ?>
