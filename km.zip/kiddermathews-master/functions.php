<?php

if ( ! defined( 'ABSPATH' ) ) exit;


# APP
require_once( 'inc/app/setup.php'  );
require_once( 'inc/app/loaders.php'  );

# Additional Functionality
array_map(
	function( $folder ) {
		require_once( "inc/{$folder}/includes.php"  );
	},
	[
		'utils',
		'acf',
    'admin',
    'fetch-more',
    'fields',
    'media',
    'post-types',
    'taxonomies',
		'api',
		'search-and-filtering'
	]
);
