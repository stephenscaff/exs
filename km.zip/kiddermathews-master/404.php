<?php
/**
 * Four Oh Four Template
 *
 * @author    Stephen Scaff
 * @package   404
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- MAIN -->
<main class="has-header-offset bg-white">

<section class="fourohfour">
  <div class="grid">
    <div class="fourohfour__grid">
      <figure class="fourohfour__figure">
        <img src="<?php echo jumpoff_get_img_dir(); ?>/404/404-1.gif">
      </figure>

      <div class="fourohfour__content">
        <h1 class="fourohfour__title">Four Oh Four</h1>
        <p class="fourohfour__text">Sorry. We can't find what you're looking for.</p>

        <nav class="fourohfour__nav">
          <div><a class="fourhofour__link btn-line" href="<?php echo jumpoff_get_page_url('home') ?>">Take Me Home</a></div>
          <div><a class="fourhofour__link btn-line" href="<?php echo jumpoff_get_page_url('professional', 1) ?>">Find a Professional</a></div>
          <div><a class="fourhofour__link btn-line" href="<?php echo jumpoff_get_page_url('news') ?>">Read Some News</a></div>
          <div><a class="fourhofour__link btn-line" href="<?php echo jumpoff_get_page_url('contact') ?>">Contact Us</a></div>
        </nav>
      </div>
    </div>
  </div>
</section>

</main>

<!-- Footer  -->
<?php get_footer(); ?>
