<?php
/**
 * Default Page Template
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

/**
 * Mast Title / Page Title
 */
$mast_title = get_field('mast_title');

if (!$mast_title) $title = get_the_title();

/**
 * Mast Pretitle
 */
$mast_pretitle = get_field('mast_pretitle');

/**
 * Mast Subtitle
 */
$mast_subtitle = get_field('post_subtitle');

/**
 * Mast Image / Ft Image Logic
 */
$mast_img = get_field('mast_image');
$mast_img_url = $mast_img['url'];
$mast_img_alt = $mast_img['alt'];
$mast_img_caption = $mast_img['caption'];
$ft_img = jumpoff_ft_img('full');

if (!$mast_img) {
  $mast_img = $ft_img;
  $mast_img_url = $ft_img->url;
  $mast_img_caption = $mast_img->caption;
  $mast_img_alt = $mast_img->alt;
}

$has_img = false;
if ($mast_img_url != NULL) {
  $has_img = true;
}
?>

<main>
  <section class="post-mast is-page <?php if ($has_img) { echo "has-img"; } else { echo "no-img"; }; ?>">
    <header class="post-mast__header grid-sm ">
      <?php if ($mast_pretitle ) : ?>
        <span class="post-mast__meta"><?php echo $mast_pretitle; ?></span>
      <?php endif; ?>

      <h1 class="post-mast__title"><?php echo $mast_title; ?></h1>

      <?php if ($mast_subtitle): ?>
        <p class="post-mast__subtitle"><?php echo $mast_subtitle; ?> </p>
      <?php endif; ?>
    </header>

    <?php
    if ($has_img) : ?>
    <figure class="post-mast__figure grid">
      <img class="post-mast__img" src="<?php echo $mast_img_url; ?>" alt="<?php echo $mast_img_alt; ?>">
      <?php if ($mast_img_caption) : ?>
        <figcaption class="post-mast__img-caption"><?php echo $mast_img_caption ?></figcaption>
      <?php endif; ?>
    </figure>
    <?php endif; ?>
  </section>

  <section class="post-content is-page">
    <div class="grid-sm">
      <?php
      while (have_posts()) : the_post();
        the_content();
     endwhile; ?>
    </div>
  </section>
</main>

<?php get_footer(); ?>
