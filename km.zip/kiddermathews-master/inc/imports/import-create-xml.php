
<?php
/**
 * SImple Sitemap XML Class generator
 * Just a simple singleton, as no need for reuse.
 */
class CreateWpImport{

	/**
	 * GetXML
	 * Get the xml from the provided file
	 * @param string $inputFile
	 * @return xml
	 */
	function getXML($inputFile) {
		$xmlFile =  get_template_directory() . "/inc/imports/dumps/{$inputFile}.xml";
		$xml = simplexml_load_file($xmlFile);

		return $xml;
	}

  /**
   * Build Sitemap XML
   * @return {xmlBlob} $sitemap - sitemap xml from post types
   */
  function build($inputFile) {

		$xml = $this->getXML($inputFile);

			$xml_import = '<?xml version="1.0" encoding="UTF-8" ?>' . "\n";
			$xml_import = '<rss version="2.0"
				xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/"
				xmlns:content="http://purl.org/rss/1.0/modules/content/"
				xmlns:wfw="http://wellformedweb.org/CommentAPI/"
				xmlns:dc="http://purl.org/dc/elements/1.1/"
				xmlns:wp="http://wordpress.org/export/1.2/"
			>' . "\n";

			$xml_import .= '<channel>';
			$xml_import .= '<title>Kidder Mathews</title>' . "\n";
			$xml_import .= '<link>http://127.0.0.1/kiddermathews</link>' . "\n";
			$xml_import .= '<description></description>' . "\n";
			$xml_import .= '<pubDate>Fri, 15 Mar 2019 10:01:25 +0000</pubDate>' . "\n";
			$xml_import .= '<language>en-US</language>' . "\n";
			$xml_import .= '<wp:wxr_version>1.2</wp:wxr_version>' . "\n";
			$xml_import .= '<wp:base_site_url>http://127.0.0.1/kiddermathews</wp:base_site_url>' . "\n";
			$xml_import .= '<wp:base_blog_url>http://127.0.0.1/kiddermathews</wp:base_blog_url>' . "\n";
			$xml_import .= '	<wp:category>' . "\n";
			$xml_import .= '	<wp:term_id>1</wp:term_id>' . "\n";
			$xml_import .= '	<wp:category_nicename><![CDATA[news]]></wp:category_nicename>' . "\n";
			$xml_import .= '	<wp:category_parent><![CDATA[]]></wp:category_parent>' . "\n";
			$xml_import .= '	<wp:cat_name><![CDATA[In the News]]></wp:cat_name>' . "\n";
			$xml_import .= '</wp:category>' . "\n";
			$xml_import .= '<generator>https://wordpress.org/?v=5.1.1</generator>' . "\n";

			foreach($xml->database->table as $item) {
				$post_title = $item->column[1];
				$story_services = $item->column[4];
				$story_quote = $item->column[5];
				$story_outline = $item->column[6];
				$story_challange = $item->column[7];
				$story_approach = $item->column[8];
				$story_results = $item->column[9];

				$xml_import .= '<item>' . "\n";
					$xml_import .= "<wp:post_type><![CDATA[success_story]]></wp:post_type>" . "\n";
		  		$xml_import .= "<title>{$post_title}</title>" . "\n";
		  		$xml_import .= "<pubDate></pubDate>" . "\n";
		  		$xml_import .= '<dc:creator><![CDATA[admin]]></dc:creator>' . "\n";
		  		$xml_import .= "<content:encoded></content:encoded>" . "\n";
					$xml_import .= "<wp:post_date></wp:post_date>" . "\n";
		  		$xml_import .= "<wp:post_date_gmt></wp:post_date_gmt>" . "\n";

		  		$xml_import .= '<wp:status><![CDATA[publish]]></wp:status>' . "\n";
		  		$xml_import .= '<wp:post_type><![CDATA[post]]></wp:post_type>' . "\n";

		      $xml_import .= '<wp:postmeta>' . "\n";
		        $xml_import .= '<wp:meta_key><![CDATA[story_services]]></wp:meta_key>' . "\n";
		        $xml_import .= "<wp:meta_value><![CDATA[{$story_services}]]></wp:meta_value>" . "\n";
		      $xml_import .= '</wp:postmeta>' . "\n";

					$xml_import .= '<wp:postmeta>' . "\n";
		        $xml_import .= '<wp:meta_key><![CDATA[story_quote]]></wp:meta_key>' . "\n";
		        $xml_import .= "<wp:meta_value><![CDATA[{$story_quote}]]></wp:meta_value>" . "\n";
		      $xml_import .= '</wp:postmeta>' . "\n";

					$xml_import .= '<wp:postmeta>' . "\n";
		        $xml_import .= '<wp:meta_key><![CDATA[story_outline]]></wp:meta_key>' . "\n";
		        $xml_import .= "<wp:meta_value><![CDATA[{$story_outline}]]></wp:meta_value>" . "\n";
		      $xml_import .= '</wp:postmeta>' . "\n";

					$xml_import .= '<wp:postmeta>' . "\n";
		        $xml_import .= '<wp:meta_key><![CDATA[story_challange]]></wp:meta_key>' . "\n";
		        $xml_import .= "<wp:meta_value><![CDATA[{$story_challange}]]></wp:meta_value>" . "\n";
		      $xml_import .= '</wp:postmeta>' . "\n";

					$xml_import .= '<wp:postmeta>' . "\n";
		        $xml_import .= '<wp:meta_key><![CDATA[story_approach]]></wp:meta_key>' . "\n";
		        $xml_import .= "<wp:meta_value><![CDATA[{$story_approach}]]></wp:meta_value>" . "\n";
		      $xml_import .= '</wp:postmeta>' . "\n";

					$xml_import .= '<wp:postmeta>' . "\n";
		        $xml_import .= '<wp:meta_key><![CDATA[story_results]]></wp:meta_key>' . "\n";
		        $xml_import .= "<wp:meta_value><![CDATA[{$story_results}]]></wp:meta_value>" . "\n";
		      $xml_import .= '</wp:postmeta>' . "\n";


					$xml_import .= '</item>' . "\n";
			}

			$xml_import .= '</channel>' . "\n";
			$xml_import .= '</rss>' . "\n";

	    return $xml_import;
		}

		/**
		 * DumpXML
		 * Dumps the XML to identity required nodes to map
		 * @return xml
		 */
		function dump($inputFile) {
			$xml = $this->getXML($inputFile);
			return var_dump($xml);
		}

		/**
		 * Loop
		 * Dumps the XML to identity required nodes to map
		 * @return xml
		 */
		function loop($inputFile) {
			$xml = $this->getXML($inputFile);
			foreach($xml->database->table as $item) {

				//jumpoff_dump($item);
				echo $item->column[1] . "\n"; // title
				echo $item->column[4] . "\n"; // services
				echo $item->column[5] . "\n"; // quote
				echo $item->column[6] . "\n"; // outline
				echo $item->column[7] . "\n"; // challange
				echo $item->column[8] . "\n"; // approach
				echo $item->column[9] . "\n"; // approach
				// echo $item->column[4];
				// echo $item->column[6];
			}
		}

	/**
	 * Create
	 * Creates the xml file of imported data
	 * @param string $inputFile - input file name.
	 * @param string $outputFile output file name
	 */
	 function create($inputFile, $outputFile) {
	  $xml = $this->build($inputFile);
		$file = $outputFile.'.xml';
	  $fp = fopen( ABSPATH . $file, 'w' );
	  fwrite( $fp, $xml );
	  fclose( $fp );
	}
}



// $in = 'import-success-stories';
// $out = 'success-stories-xml';
//
// $export = new CreateWpImport();
// $export->loop($in);

// $export = new CreateWpImport();
// $export->create($in, $out);
