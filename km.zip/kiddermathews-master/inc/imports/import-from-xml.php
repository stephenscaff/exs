<?php


function NOPEimport_xml_to_posts() {
	$file =  get_template_directory() . '/inc/imports/in_the_news_test.xml';
	$xml = simplexml_load_file($file);

	foreach($xml->database->table as $item) {

		$title = $item->column[1];

		if (!get_page_by_title($title, 'OBJECT', 'post') ){
			$postCreated = array(
			    'post_title'    => $title,
					'post_date'    	=> $item->column[2],
					'post_content'  => $item->column[6],
			    'post_status'   => 'publish',
			    'post_type'     => 'post',
					'post_category' => array(1),
			);


			$post_id = wp_insert_post( $postCreated, true );
			$field_key = "field_in_the_news_article_source";
			$field_key_2 = "article_source";
			$value = $item->column[4];
			echo $value;
			update_field( $field_key, $value, $post_id );
			update_field( $field_key_2, $value, $post_id );

			//update_post_meta($post_id,$field_key,$value);

		}
	}
}
