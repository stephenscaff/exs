<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Success Stories Query
 * Exclude Broker Term from Success Stories main query
 */
add_action('pre_get_posts', function($query) {

  if (!isset($query->query_vars['post_type'])) return;

  if (! is_admin() &&
    $query->query_vars['post_type'] == 'success_story' &&
    is_post_type_archive('success_story') &&
    !isset($_GET['pro_id'])){

    $term_by = get_term_by('name', 'broker', 'success_story_cat');
    $broker_id = $term_by->term_id;

    $query->set( 'tax_query',
      array(
        array(
         'taxonomy' => 'success_story_cat',
         'field' => 'id',
         'terms' => array( $broker_id),
         'operator' => 'NOT IN'
        )
      )
   );
  }

  return $query;
});
