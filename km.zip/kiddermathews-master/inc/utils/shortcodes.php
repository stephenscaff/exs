<?php

if ( ! defined( 'ABSPATH' ) ) exit; 

/**
 *  Post Type Labels
 *  Utility to handle singular / plural labels of register_post_type();
 *  $labels = jumpoff_post_type_labels('Project', 'Projects');
 */
 add_shortcode('get_part', 'get_part_func');

 function get_part_func($template) {
   ob_start();
   include(locate_template($template));
   return ob_get_clean();
 }

/**
 * Vimeo Popup
 * Creates a Vimeo Popup vid.
 * @param id - vimeo id
 * @param btn - button class name {btn-line | btn}
 * @param icon - show icon or not {fake boolean}
 * @example [vimeo_popup id="333916706" btn="btn-line"]Heyç Popup[/vimeo_popup]
 */
add_shortcode('vimeo_popup', 'vimeo_popup_shortcode');

function vimeo_popup_shortcode( $atts, $content = null ) {
   $atts = shortcode_atts( array(
    'id'  => '',
    'btn'   => '',
    'icon'  => '',
	), $atts, 'vimeo_popup' );

  $has_icon = (!empty($atts['icon'])) ? '<i class="icon-play-o"></i>' : '';

  return
    "<a class='popup-link {$atts['btn']}' data-vimeo-popup='{$atts['id']}'>
      $has_icon
      <span class='popup-link__text'>{$content}</span>
    </a>";
}




/**
 * Button (btn) Shortcode
 */
add_shortcode( 'button', 'button_shortcode' );

function button_shortcode( $atts, $content = null ) {

	// Extract shortcode attributes
	extract( shortcode_atts( array(
		'url'    => '',
		'title'  => '',
		'target' => '',
		'text'   => '',
		'color'  => 'alpha',
	), $atts ) );

	// Use text value for items without content
	$content = $text ? $text : $content;

	// Return button with link
	if ( $url ) {
    $content = $text ? $text : $content;
		$link_attr = array(
			'href'   => esc_url( $url ),
			'title'  => esc_attr( $title ),
			'target' => ( 'blank' == $target ) ? '_blank' : '',
			'class'  => 'btn is-sc is-' . esc_attr( $color ),
		);

		$link_attrs_str = '';

		foreach ( $link_attr as $key => $val ) {
			if ( $val ) {
				$link_attrs_str .= ' ' . $key . '="' . $val . '"';
			}
		}

		return '<a' . $link_attrs_str . '><span>' . do_shortcode( $content ) . '</span></a>';
	}

	// No link defined so return button as a span
	else {
		return '<span class="btn"><span>' . do_shortcode( $content ) . '</span></span>';
	}
}


/**
 * Button Line (btn-line) Shortcode
 */
add_shortcode( 'button_text', 'button_text_shortcode' );

function button_text_shortcode( $atts, $content = null ) {

	// Extract shortcode attributes
	extract( shortcode_atts( array(
		'url'    => '',
		'title'  => '',
		'target' => '',
		'text'   => '',
		'color'  => 'alpha',
	), $atts ) );

	// Use text value for items without content
	$content = $text ? $text : $content;

	// Return button with link
	if ( $url ) {
    $content = $text ? $text : $content;

		$link_attr = array(
			'href'   => esc_url( $url ),
			'title'  => esc_attr( $title ),
			'target' => ( 'blank' == $target ) ? '_blank' : '',
			'class'  => 'btn-line is-sc is-' . esc_attr( $color ),
		);

		$link_attrs_str = '';

		foreach ( $link_attr as $key => $val ) {
			if ( $val ) {
				$link_attrs_str .= ' ' . $key . '="' . $val . '"';
			}
		}

		return '<a' . $link_attrs_str . '><span>' . do_shortcode( $content ) . '</span></a>';
	}

	// No link defined so return button as a span
	else {
		return '<span class="btn-line"><span>' . do_shortcode( $content ) . '</span></span>';
	}
}

/**
 * Download Button
 */
add_shortcode( 'button_download', 'button_download_shortcode' );

function button_download_shortcode( $atts, $content = null ) {

  // Extract shortcode attributes
  extract( shortcode_atts( array(
    'url'    => '',
    'title'  => '',
    'target' => '',
    'text'   => '',
    'color'  => 'alpha',
  ), $atts ) );

  // Use text value for items without content
  $content = $text ? $text : $content;

  // Return button with link
  if ( $url ) {
    $content = $text ? $text : $content;
    $link_attr = array(
      'href'   => esc_url( $url ),
      'title'  => esc_attr( $title ),
      'target' => ( 'blank' == $target ) ? '_blank' : '',
      'class'  => 'btn is-download is-' . esc_attr( $color ),
    );

    $link_attrs_str = '';

    foreach ( $link_attr as $key => $val ) {
      if ( $val ) {
        $link_attrs_str .= ' ' . $key . '="' . $val . '"';
      }
    }

    return '<a' . $link_attrs_str . '><i class="icon-download-file"></i> <span>' . do_shortcode( $content ) . '</span></a>';
  }

  // No link defined so return button as a span
  else {
    return '<span class="btn"><span>' . do_shortcode( $content ) . '</span></span>';
  }
}
