<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly



/**
 * Join Fields
 * Coverts an array of style (class name) Fields
 * to a space seperated grouping.
 *
 * @example jumpoff_add_class($class, 'module')
 * @return string $group - space seperated sting of class names
 */
function jumpoff_add_classes($fields){
  $group = join(' ', $fields);

  return $group;
}



/**
 * Remove Wp's Auto P
 */
function jumpoff_unautop($str) {
  $str = str_replace("\n", "", $str);
  $str = str_replace("<p>", "", $str);
  $str = str_replace(array("<br />", "<br>", "<br/>"), "\n", $s);
  $str = str_replace("</p>", "\n\n", $s);

  return $str;
}



/**
 *  Make Hash ID
 *  Builds id friedly string by replacing whitespace with dashes
 *  and converting to lowercase
 *  @return: $classes (string)
 */
function jumpoff_make_hash($str) {
  # Lower case everything
  $str = strtolower($str);

  # Make alphanumeric (removes all other characters)
  $str = preg_replace("/[^a-z0-9_\s-]/", "", $str);

  # Clean up multiple dashes or whitespaces
  $str = preg_replace("/[\s-]+/", " ", $str);

  # Convert whitespaces and underscore to dash
  $str = preg_replace("/[\s_]/", "-", $str);

  return $str;
}


/**
 *  Line Wrapper
 *  Detects line breaks in string and wraps them
 *  in a list or span.
 *
 *  @param    string $str The string / field
 *  @param    string $type Markup wrapping lines
 *  @return   string $output
 *  @example  jumpoff_format_lines( $fieldname,  'span' )
 */
function jumpoff_format_lines ( $str, $type='list' ){

  $lines = explode("\n", $str);

  $output = '';

  if ( !empty($lines) ) {
    foreach ( $lines as $line ) {
      if ($type == 'list'){
        $output .= '<li>'. trim( $line ) .'</li>';
      }
      elseif ($type == 'span'){
        $output .= '<span>'. trim( $line ) .' ' . '</span>';
      }
    }
  }
  return $output;
}

/**
 *  Covert to Words
 *  Converts _ to space and capitalizes words.
 *
 *  @param    string $str The string / field
 *  @return   string $output
 */
function convert_to_words($str, $replacer = "_") {
  return ucwords(str_replace($replacer, " ", $str));
}

/**
 *  Format Tel Link
 *  Covert human readable / cms entered
 *
 *  @param    string $str The string / field of the number
 *  @return   string $output
 */
function format_tel_link($str) {
  return str_replace(['.', '-'], '', $str);
}


/**
 * Pluralizes a word if quantity is not one.
 *
 * @param array $count_arry  Array to count
 * @param string $singular   Singular form of word
 * @param string $plural     Plural form of word; function will attempt to deduce plural form from singular if not provided
 * @return string pluralized of singular word.
 */
function pluralize($count_arry, $singular, $plural = null) {

  $quantity = sizeof($count_arry);

  if ( $quantity == 1 || !strlen($singular) ) return $singular;
  if ( $plural !== null ) return $plural;

  $last_letter = strtolower($singular[strlen($singular)-1]);

  switch($last_letter) {
    case 'y':
      return substr($singular,0,-1).'ies';
    case 's':
      return $singular.'es';
    default:
      return $singular.'s';
  }
}

/**
 * Pluralizes a word if quantity is not one.
 *
 * @param string $singular   Singular form of word
 * @return string pluralized of singular word.
 */
function pluralizer($singular) {

  $last_letter = strtolower($singular[strlen($singular)-1]);

  switch($last_letter) {
    case 'y':
      return substr($singular,0,-1).'ies';
    case 's':
      return $singular.'es';
    default:
      return $singular.'s';
  }
}


/**
 * Convert to USD
 * Converts a string (of number) to USD
 * without the decimal.
 * @param string $num - price as string
 * @return string usd money format
 */
function convert_to_usd($num) {
  setlocale(LC_MONETARY, 'en_US.UTF-8');

  return money_format('%.0n', $num);
}

function format_number($num) {
  return number_format($num);
}
