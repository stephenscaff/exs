<?php
/**
 * Get id by page name
 * @return int $id - id of the returned page
 */
function get_id_by_name($page) {
  $slug = get_page_by_path($page);
  $id = $slug->ID;

  return $id;
}

/**
 * Get Post ID by Meta Values (metea_key/meta_value)
 */
function get_post_id_by_metas($key, $value) {
	global $wpdb;

  $meta = $wpdb->get_results( $wpdb->prepare(
    "SELECT * FROM ".$wpdb->postmeta." WHERE meta_key=%s AND meta_value=%s", $key, $value )
  );

  if (is_array($meta) && !empty($meta) && isset($meta[0])) {
		$meta = $meta[0];
	}

  if (is_object($meta)) {
		return $meta->post_id;
	}

  else {
		return false;
	}
}

/**
 *  jumpoff_get_id()
 *  Retrieves IDs to use in calling fields.
 *  @return integar $id - the id of the post
 *  @example $id = jumpoff_get_id();
 */
function jumpoff_get_id() {
  global $post;
  $term_obj = get_queried_object();
  $page_for_posts = get_option( 'page_for_posts' );
  //
  // if( !is_object( $post ) )
  //    return;

  // if (is_post_type('market_report') && (isset($_GET)) OR is_search() && is_post_type_archive('market_report-index')){
  //   return 'market_report-index';
  // }

  if (is_search() && is_post_type_archive('post')) {
    return'news-index';
  }
  elseif (is_search() && is_post_type_archive('professional')) {
    return 'professional-index';
  }
  elseif (is_search() && is_post_type_archive('team')) {
    return 'team-index';
  }
  elseif (is_search() && is_post_type_archive('market_report')) {
    return 'market_report-index';
  }
  elseif (is_search() && is_post_type_archive('success_story')) {
    return 'success_story-index';
  }
  elseif (is_search() && is_post_type_archive('trend_article')) {
    return 'trend_article-index';
  }
  elseif (is_post_type_archive()){
    $post_type = get_queried_object();
    //$post_type = get_post_type( $post->ID );
    $cpt = $post_type->name;
    return $cpt . '-index';
  }
  elseif (is_home() OR is_search()){
    return 'news-index';
  }
  elseif (is_front_page()) {
    return get_option('page_on_front');
  }
  elseif (is_tax('activity_type') OR is_tax('activity_location')) {
    return $term_obj->taxonomy . '_' . $term_obj->term_id;
  }

  else{
    return get_the_ID();
  }
}


/**
 * Custom Field Fallback
 * Defines a string fallback for custom fields.
 *
 * @param mixed $field - Custom Field
 * @param mixed fallback - probably a string
 * @return mixed Custom field or fallback
 */
function jumpoff_field_fallback ($field, $fallback) {

  $output = '';

  if ($field) {
    $output = $field;
  } else {
    $output = $fallback;
  }
  return $output;
}


/**
 *  jumpoff_mod_class
 *  For creating BEM style modifiers
 *  @return string $class - BEM style modifier class name
 */
function jumpoff_get_mod_class() {
  global $post;
  $page_for_posts = get_option( 'page_for_posts' );
  $class='';

  if (is_home()){
    $class ='news';
  }
  elseif (is_search()) {
    $class = 'search';
  }
  elseif (get_query_var('location') ||
          get_query_var('product_type') ||
          get_query_var('state')) {
    $class = 'query';
  }
  elseif (is_post_type_archive()) {
    $class = get_post_type(get_the_ID()) . '-index';
  }
  elseif (is_singular()) {
    $class = get_post_type($post->ID);
  }
  elseif (is_front_page()) {
    $class ='home';
  }
  elseif (is_tax()){
    $class = 'tax';
  }
  elseif (is_archive()){
    $class = 'archive';
  }
  elseif (is_post_type('activity')){
    $class = 'activity';
  }
  else {
    $class = basename(get_permalink());
  }
  return $class;
}


/**
 * Chain Module Classes
 * Coverts an array of style (class name) Fields
 * to a space seperated grouping.
 *
 * @example jumpoff_add_class($class, 'module')
 * @return string $group - space seperated sting of class names
 */
function chain_module_classes($fields){
  $group = join(' ', $fields);

  return $group;
}



/**
 * Get BG Mod
 * Gets a stateful modifier class for styling rules,
 * based on bg color class to add to a module, since
 * our bg classes are mostly nested.
 *
 * @return string $output - class name
 */
function get_bg_mod($field){
  switch($field) {
    case 'bg-white':
    $output = 'has-bg-white';
      break;
    case 'bg-grey-light':
    $output = 'has-bg-grey';
      break;
    case 'bg-grey-dark':
    $output = 'has-bg-grey';
      break;
    case 'bg-alpha':
    $output = 'has-bg-alpha';
      break;
  }

  return $output;
}

/**
 * Add Character Count Class
 * outputs a css class if character count exceeds f
 * defined amount.
 * @param string $str - string to count chars
 * @param number $num - Character count
 * @return string $klass - css output class
 */
function add_char_class($str, $num, $klass) {
  if ( strlen($str) > $num ) {
    return $klass;
  }
}
