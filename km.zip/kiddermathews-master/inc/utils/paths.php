<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *  jumpoff_get_img_dir()
 *  An image path helper that gets template path of images
 */
function jumpoff_get_img_dir(){
  $template_path = get_bloginfo( 'template_directory' );
  $img_path = $template_path . '/assets/images';
  return $img_path;
}


/**
 *  jumpoff_get_path()
 *  An asset path helper that gets template path.
 *  @example : <video src="<?php jumpoff_get_path()(); ?>/videos/vide.mp4">
 */
function jumpoff_get_path(){
  $template_path = get_bloginfo( 'template_directory' );
  $path = $template_path . '/assets';
  return $path;
}


/**
 *  jumpoff_get_svg
 *  An asset path helper that gets template path.
 *  @example : <video src="<?php jumpoff_get_path()(); ?>/videos/vide.mp4">
 */
function jumpoff_get_svg( $file ){
  $svg = get_template_part( 'assets/images/svgs/' . $file, 'svg' );
  return $svg;
}
