<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *  Get Tax Posts
 *
 *  Gets posts by post type and tax/term with some options
 *
 * @see      partials-content-products.php For useage
 * @param    string  $post_type The post type
 * @param    string  $tax   The taxonomy
 * @param    string  $term  The taxonomy's term
 * @param    int     $num_posts  Number of posts
 * @param    string  $grid_size Determines grid layout via css grid helper class
 * @return   $posts
 */
function get_term_posts($opts){
  global $post ;

  $defaults = array(
  	'post_type'       => 'post',
  	'tax'        => null,
  	'terms'       => null,
  	'num_posts'  => 3,
    'template'   => 'post',
    'grid_cols'  => '1-3',
    'excluded'   => ''
  );

  $args = wp_parse_args( $opts, $defaults );

  $post_args = array(
    'post_type'        => $args['post_type'],
    'posts_per_page'   => $args['num_posts'],
    'orderby'          => 'date',
    'order'            => 'DESC',
    'no_found_rows'    => true,
    'post__not_in'     =>  array($args['excluded']),
    'tax_query' 			 => array(
      array(
        'taxonomy' 	=> $args['tax'],
        'terms' 		=> array($args['terms']),
        'field' 		=> 'slug',
        'operator' 	=> 'IN',
      ),
    ),
  );


  $heading_title = get_post_type($args['post_type']);

  ?>
<section class="posts">
  <div class="grid-lg">
    <header class="heading">
      <h3 class="heading__title"><?php echo $heading_title; ?></h3>
    </header>
    <div class="posts__grid grid-1-3">
    <?php
    $posts = get_posts( $post_args );
        // jumpoff_dump($args);

    foreach ( $posts as $post ) : setup_postdata( $post );
      get_template_part( 'views/content/post' );
    endforeach;
    wp_reset_postdata(); ?>
    </div>
  </div>
</section> <?php
}



/**
 *  Get Tax Posts
 *
 *  Gets posts by post type and tax/term with some options
 *
 * @see      partials-content-products.php For useage
 * @param    string  $post_type The post type
 * @param    string  $tax   The taxonomy
 * @param    string  $term  The taxonomy's term
 * @param    int     $num_posts  Number of posts
 * @param    string  $grid_size Determines grid layout via css grid helper class
 * @return   $posts
 */

function get_posts_by_term($opts){
  global $post ;


  $defaults = array(
  	'post_type'  => 'post',
  	'tax'        => null,
  	'terms'      => null,
  	'num_posts'  => 3,
    'template'   => 'post',
    'grid_cols'  => '1-3',
    'show_archive_link' => false,
    'excluded'   => null,
  );

  $args = wp_parse_args( $opts, $defaults );


  $post_args = array(
    'posts_per_page'   => $args['num_posts'],
    'post_type'        => $args['post_type'],
    'orderby'          => 'date',
    'order'            => 'DESC',
    'no_found_rows'    => true,
    'post__not_in'     => array($args['excluded']),
    'tax_query' 			 => array(
			array(
        'taxonomy' 	=> $args['tax'],
        'terms' 		=> array($args['terms']),
				'field' 		=> 'slug',
        'operator' 	=> 'IN',
      ),
    ),
  );

  $term_obj  = get_term_by( 'slug', $args['terms'], $args['tax']);

?>
<section class="post-cards">
  <div class="grid-lg">
    <heading class="heading">
      <h2 class="title__title"><?php echo $term_obj->name; ?></h2>
    </heading>

    <div class="post-cards__grid grid-1-2-3">
    <?php
    $posts = get_posts( $post_args );
    foreach ( $posts as $post ) : setup_postdata( $post );
      include(locate_template( "views/content/{$args['template']}.php" ) );
    endforeach;
    wp_reset_postdata(); ?>
    </div>
    <?php if ($args['show_archive_link']) : ?>
    <footer class="ending">
      <a class="btn" href="<?php echo get_category_link($term_obj->term_id); ?>">View All</a>
    </footer>
    <?php endif; ?>
  </div>
</section> <?php
}

/**
 *  Get all posts by term
 *  Loops through given terms and applies our
 *  posts/card template grid.
 */
function get_posts_by_all_terms($post_type, $tax, $num_posts, $exclude = null, $has_footer = false){
  global $post;

  $name = '';
  $slug = '';
  $desc = '';

  $args = array(
    'taxonomy' => $tax,
    'exclude' => $exclude,
		'posts_per_page'   => 3,
		'orderby'          => 'date',
		'order'            => 'DESC',
  );

  $terms = get_terms( $args);

  foreach ( $terms as $term ) {

    if ($term) {
      $name = $term->name;
      $slug = $term->slug;
      $desc = $term->description;

      include(locate_template("partials/partial-posts-title.php"));

      get_tax_posts($post_type, $tax, $term->name, $num_posts);

      if ($has_footer) {
        //include(locate_template("partials/partial-ending.php"));
      }
    }
  }
}
