<?php

if ( ! defined( 'ABSPATH' ) ) exit;

require_once('conditionals.php');
require_once('debuggers.php');
//require_once('dev-helpers.php');
require_once('hooks.php');
require_once('hooks-head.php');
require_once('hooks-footer.php');
require_once('helpers.php');
require_once('post-funcs.php');
require_once('formating.php');
require_once('nav.php');
require_once('paths.php');
require_once('post-type-labels.php');
require_once('post-filters.php');
require_once('locations.php');
require_once('loops.php');
require_once('shortcodes.php');
require_once('queries.php');
