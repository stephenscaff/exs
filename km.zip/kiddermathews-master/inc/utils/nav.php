<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 *   Nav Active Class.
 *   Adds active class, since we're not using native wp menus
 *
 *   @param    string $page_name
 *   @return   string 'is-active';
 */
function jumpoff_active_class( $page_name ){
  if (is_page( $page_name ) || is_post_type_archive( $page_name )) {
    return 'is-active';
  }
}


/**
 *   Gets page link.
 *   For use with our custom navigations
 *
 *   @param    string $page_name
 *   @return   string 'is-active';
 */
function jumpoff_get_page_url( $page_name, $cpt='' ){
  if ( $cpt == true ) {
    $page_url = esc_url( get_post_type_archive_link( $page_name ) );
  } else {
    $page_url = esc_url( get_permalink( get_page_by_title( $page_name ) ) );
  }
  return $page_url;
}


/**
 * Get Subpage Links
 * Outputs a post types subpages as nav items
 * @var $post_type sring - The desired post type
 * @var $klass string - class name for link
 * @return string
 */
function jumpoff_get_subpage_links( $post_type, $klass ){
  global $post ;

  $args = array(
   'posts_per_page'   => -1,
   'post_type'        => $post_type,
  );
  $links  = get_posts( $args );
  $output = '';

  foreach ( $links as $post ) : setup_postdata( $post );
    $url     = get_the_permalink();
    $title   = get_the_title();
    $output .= '<a class="'. $klass . '" href="' . $url . '">' . $title . '</a>';
  endforeach;
  wp_reset_postdata();

  return $output;
}




/**
 * Render Menu
 * Renders Simple Menus with options for class name and menu title.
 *
 * @var string $menu_name
 * @var string $menu_class - Nav element class name
 * @var string $menu_title - optional menu title
 * @return $output html blob
 */
 function render_menu($menu_name, $menu_class = null, $extra = null) {
   global $post;
   $locations = get_nav_menu_locations();
   $menu_id = $locations[$menu_name];
   $menu_items = wp_get_nav_menu_items($menu_id);
   $output = '';
   $output .= '
    <nav class="'.$menu_class.'__nav">';
    if ($menu_items) :
      foreach($menu_items as $menu_item  => $item) :
          $output .= '
           <a class="'.$menu_class.'__link" href="'.$item->url.'" role="menuitem">'.$item->title.'</a>';
      endforeach;
    endif;
    if ($extra) :
    $output .= $extra;
    endif;
    $output .= '
    </nav>';

  return $output;
}


/**
 * Render Dropdown
 * Renders dropdowns for the main header/nav from Wordpress Menus
 * @var string $menu_name
 * @return $output html blob
 */
function render_nav_dropdown($menu_name, $title = null, $class = null) {
  global $post;
  $locations = get_nav_menu_locations();
  $menu_id = $locations[$menu_name];
  $menu_items = wp_get_nav_menu_items($menu_id);
  $parent_item  = $menu_items[0];
  if (!$menu_items) return;
  $output = '';
  $output .= '
  <div class="nav-dropdown '.$class.'">
    <div class="nav-dropdown__target">';
      if ($title != null) :
      $output .= '<a class="app-header__link has-dd" aria-expanded="false">'.$title.'</a>';
      else :
      $output .= '<a class="app-header__link has-dd" href="'.$parent_item->url.'" aria-expanded="false">'.$parent_item->title.'</a>';
      endif;
      $output.= '
      <nav class="nav-dropdown__menu" role="menubar">';

      foreach($menu_items as $menu_item  => $item) :
        if ($menu_item >= 0 ) :
          $output .= '<a class="nav-dropdown__link" href="'.$item->url.'" role="menuitem">'.$item->title.'</a>';
        endif;
      endforeach;
      $output .= '
      </nav>
    </div>
  </div>';

  return $output;
}




/**
 * Get Post Breadcrumbs
 *
 * Builds breadcrumb-like element for post mast
 * on single post templates. Kinda grimey I know, but it
 * works i think
 */
function get_post_breadcrumbs() {

  $post_type = get_post_type(get_the_ID());
  $base_url = get_post_type_archive_link($post_type);
  $base_name = 'News & Press';

  if (is_post_type('post')) {

    $base_url = get_post_type_archive_link($post_type);
    $base_name = 'News & Press';
    $cat = get_the_category(get_the_ID());
    $cat_url = get_category_link( $cat[0]->term_id );
    $cat_name = $cat[0]->name;

  }

  elseif (is_post_type('trend_article') OR is_post_type('market_report')) {

    $base_url = jumpoff_get_page_url('markert_research');
    $base_name = 'Market Research';
    $cat_url = get_post_type_archive_link($post_type);
    $cat_name = ucwords(str_replace("_", " ", $post_type));

  }

  elseif (is_post_type('success_story')) {

    $base_url = jumpoff_get_page_url('success_story', 1);
    $base_name = 'Success Stories';
    $cat_url = '';
    $cat_name = '';

  }

  $output = '';
  $output .= '
  <div class="post-cats">
    <span class="post-cats__label">Posted In — </span>
    <a class="post-cats__link" href="'.$base_url.'">'.$base_name.'</a>
    <span class="post-cats__sep"> | </span>
    <a class="post-cats__link" href="'.$cat_url.'">'.$cat_name.'</a>
  </div>';

  return $output;
}
