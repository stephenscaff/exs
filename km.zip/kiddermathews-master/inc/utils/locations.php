<?php

if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Locations Object
 */
function Locations() {
  global $post;

  $locs = get_terms( array(
    'taxonomy' => 'location',
    'hide_empty' => false,
  ));

  if ($locs && !is_wp_error($locs)) {
    foreach ($locs as $loc) {
      $city_state = explode(',', $loc->name);
      $city = $city_state[0];
      $state = $city_state[1];

      $obj[] = array(
        'city'  => $city,
        'state' => $state
      );
    }
    return $obj;
  }
}


/**
 * Get City/State from Title
 *
 * Uses current post title to obtain various city, state strings.
 *
 * @return object $obj - city state
 */
function get_location_from_title() {
  $title = get_the_title();
  $city_state = explode(',', $title);
  $city =  $city_state[0];
  $state =  trim($city_state[1]);
  $city_state = $city .', ' . $state;
  $hyphen = preg_replace("/[\s_]/", "-", $city) .'-'. $state;

  $obj = array(
    'filter'     => strtolower($hyphen),
    'city_state' => $city_state,
    'city'       => $city,
    'state'      => $state
  );
  return (object)$obj;
}

/**
 * Get Location Filters
 *
 * Gets available location terms as query var filters
 *
 * @param string $type - option for output.
 * @return html $out - html link with data-filter populated
 */
function get_locations_filters($type) {

  $out = "";

  $locs = get_terms( array(
    'taxonomy' => 'location',
    'hide_empty' => true,
  ));

  if (!$locs) return;

  if ($locs && !is_wp_error($locs)) {
    foreach ($locs as $loc) {

      $city_state = explode(',', $loc->name);
      $city = $city_state[0];
      $state = $city_state[1];

      if ($type == 'city') {
        $out .= '<a class="dropdown__link js-filter" data-filter="'.strtolower($city).'">'.$city.'</a>';
      }
      if ($type == 'state') {
        $out .= '<a class="dropdown__link js-filter" data-filter='.strtolower($state).'>'.$state.'</a>';
      }
    }

    return $out;
  }
}

/**
 * Get Location City/State
 *
 * Gets city or state from current term via get_the_terms();
 *
 * @return object $obj - object with city, state props.
 */
function get_location_form_term() {
  global $post;
  $loc = get_the_terms($post->ID, 'location');
  $city_state = explode(',', $loc[0]->name);
  $city =  $city_state[0];
  $state =  trim($city_state[1]);

  $obj = array(
    'city'  => $city,
    'state' => $state
  );
  return (object)$obj;
}
