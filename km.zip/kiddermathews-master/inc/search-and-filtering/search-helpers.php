<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Has Search Results
 * @return boolean
 */
function has_search_results(){
  if ( is_search()) {
    global $wp_query;
    $result = ( 0 != $wp_query->found_posts ) ? true : false;

    return $result;
  }
}


/**
 * Get Filter Info
 * @param string $filter - tax slug
 */
function get_filter_info($filters) {
  global $wp_query;
  $res = $wp_query->query_vars;

  foreach($filters as $filter) {
    $term_obj = get_term_by('slug', $filter);
  }
}

/**
 * Get Filter URL
 * @param string $type - post type name
 * @param string $Filter - fitler name
 * @param string $value - fitler value
 */
function get_filter_url($type, $filter, $value) {
  $base = get_post_type_archive_link($type);
  $url = "{$base}?{$filter}={$value}";

  return $url;
}

/**
 * Get Current Query
 * @param string $query
 */
function get_current_query($query) {

  $q = get_query_var($query);
  $title = $query;

  foreach($_GET as $key => $value) {
    $filter_key = $key;
    $filter_value = $value;
    $term_to_transform = get_term_by('slug', $filter_value, $filter_key);
  }

  if ($q) {
    return $term_to_transform;
  } else {
    return $title;
  }
}


/**
 * Get Search Queries
 */
function get_search_queries() {
  global $wp_query;

  foreach($_GET as $key => $value) {

    if ($key != 'post_type') {
      $val = $wp_query->query_vars[$key];
      $key_val = get_query_var($key);

      return $key_val;
    }
  }
}

/**
 * Get Request Params
 */
function get_request_params( $key, $default = '' ) {

  if ( ! isset( $_REQUEST[ $key ] ) || empty( $_REQUEST[ $key ] ) ) {
    return $default;
  }

  return strip_tags( (string) wp_unslash( $_REQUEST[ $key ] ) );
}
