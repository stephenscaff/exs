<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once('search-helpers.php');
require_once('search-controls.php');
require_once('search-infos.php');
require_once('hooks.php');
require_once('search-post-meta.php');
require_once('search-autocomplete.php');
