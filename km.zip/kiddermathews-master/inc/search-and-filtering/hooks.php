<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Add Query Vars
 *
 * Adds custom query vars to list of public
 * query variables available to WP_Query
 *
 * @param array $vars - array of filters
 */
add_filter( 'query_vars', 'add_query_vars' );

function add_query_vars($vars) {
  $vars[] .= 'product_type';
  $vars[] .= 'location';
  $vars[] .= 'state';
  $vars[] .= 'specialty';

  return $vars;
}

/*
 * Set Search Results PPP
 * Set to 24 (divisable by 2,3,4)
 */
add_action( 'pre_get_posts',  'set_search_ppp'  );

function set_search_ppp( $query ) {

  global $wp_query;

  if ( ( ! is_admin() ) && ( $query === $wp_query ) && ( $query->is_search() ) ) {
    $query->set( 'posts_per_page', 20 );
  }

  elseif ( ( ! is_admin() ) && ( $query === $wp_query ) && is_post_type('post')) {
    $query->set( 'posts_per_page', 12 );
  }

  return $query;
}

/**
 * Filter By Last Word
 * Gets last word in post type and uses that to filter.
 * Creates new oderby value of pros_last_word
 */
add_filter( 'posts_orderby', function( $orderby, \WP_Query $q ) {
  if ( 'pros_last_word' === $q->get( 'orderby' ) && $get_order =  $q->get( 'order' ) ) {
    if ( in_array( strtoupper( $get_order ), ['ASC', 'DESC'] ) ) {
      global $wpdb;
      $orderby = " SUBSTRING_INDEX( {$wpdb->posts}.post_title, ' ', -1 ) " . $get_order;
    }
  }

  return $orderby;

}, PHP_INT_MAX, 2 );

/**
 * Professional Search Filter
 * Alphatize by last word (last name)
 */
add_action('pre_get_posts', function($query){

  if (!is_search('professional')) return;

  $query->set( 'order', 'ASC' );
  $query->set( 'orderby', 'pros_last_word' );
});

/**
 * Professional Filter
 * Alphatize by last word (last name)
 */
add_action('pre_get_posts', function($query){
  if (is_post_type_archive('professional')) {
    $query->set( 'order', 'ASC' );
    $query->set( 'orderby', 'pros_last_word' );
  }
});

/**
 * Market Research
 * Use menu order if empty search
 * This is why we can't have nice things
 */
add_action('pre_get_posts', function($query){
  if (is_post_type_archive('market_report')) {
    if (is_search('market_report')) {
      // if ($_GET['s'] == '') {
        $query->set( 'orderby', 'menu_order' );
        $query->set( 'order', 'ASC' );
     // }
    }
  }
});


 /**
  * Search SQL filter for matching against post title only.

  * To use this, also have to exlude post type from search-post-meta class
  * ie !is_search('professional')
  *
  * @link    http://wordpress.stackexchange.com/a/11826/1685
  *
  * @param   string      $search
  * @param   WP_Query    $wp_query
  */
//add_filter( 'posts_search', 'pro_search_by_title', 10, 2 );

// function pro_search_by_title( $search, $wp_query ) {
//  if ( empty( $search ) && empty( $wp_query->query_vars['search_terms'] ) ) return;
//  if (!is_seach('professional')) return;
//
//  global $wpdb;
//
//  $q = $wp_query->query_vars;
//  $n = ! empty( $q['exact'] ) ? '' : '%';
//
//  $search = array();
//
//  foreach ( ( array ) $q['search_terms'] as $term )
//     $search[] = $wpdb->prepare( "$wpdb->posts.post_title LIKE %s", $n . $wpdb->esc_like( $term ) . $n );
//
//  if ( ! is_user_logged_in() )
//   $search[] = "$wpdb->posts.post_password = ''";
//
//  $search = ' AND ' . implode( ' AND ', $search );
//
//  return $search;
// }
