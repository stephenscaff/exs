/**
 * Autocomplete Init
 */
$('#js-search-pros').autoComplete({
  source: function(name, response) {
    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: `${appGlobals.admin_ajax}`,
      data: 'action=get_professional_names&name='+name,
      success: function(data) {
        response(data);
        console.log(data);
      }
    });
  }
});
