<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *  Get Market Reports Search Info
 *  Retuns info on the search and filtered queries for market research/reports
 * @return html
 */
function get_market_reports_search_info() {
  global $wp_query;

  $res = $wp_query->query_vars;
  $output = "";
  $query_search = "Market Reports ";
  $output_state = "";
  $output_product_type = "";

  if ($res['s']) {
    $query_search = "<span>{$res['s']}</span>";
  }

  if (isset($res['state'])) {
    $query_state = convert_to_words($res['state'], "-");
    $output_state = " in the state of <span>{$query_state}</span>";
  }

  if (isset($res['product_type'])) {
    $query_product_type = convert_to_words($res['product_type'], "-");
    $output_product_type = " in the product type of <span>{$query_product_type}</span>";
  }

  return $query_search . $output_state . $output_product_type;
}

/**
 * Get Professionals Search Info
 * Returns info on the searched and filtered queries for Professionals
 * @return html
 */
function get_pro_search_info() {
  global $wp_query;

  $query_search = "";
  $res = $wp_query->query_vars;
  $output = "";
  $output_location = "";
  $output_specialty = "";
  $maybe_comma = "";

  if ($res['s']) {
    $query_search = "<span>{$res['s']}</span>";
  }

  if (isset($res['location']) && !empty($res['location'])) {
    $location_term = get_term_by('slug', $res['location'], 'location');
    $output_location = " <span>{$location_term->name}</span>";
  }

  if (isset($res['specialty']) && !empty($res['specialty'])) {
    $specialty_term = get_term_by('slug', $res['specialty'], 'specialty');
    $output_specialty = " <span>{$specialty_term->name}</span>";
  }

  if (isset($res['specialty']) && !empty($res['specialty']) &&
      isset($res['location']) && !empty($res['location'])) {
        $maybe_comma = ', ';
  }

  return $query_search . $output_location . $maybe_comma . $output_specialty;
}


/**
 * Get Professionals Search Info
 * Returns info on the searched and filtered queries for Professionals
 * @return html
 */
function get_success_story_info() {
  global $wp_query;

  $res = $wp_query->query_vars;
  $output = "";
  $query_search = "Stories ";
  $output_location = "";
  $output_specialty = "";

  if ($res['s']) {
    $query_search = "<span>{$res['s']}</span>";
  }

  if (isset($res['specialty'])) {
    $query_specialty = convert_to_words($res['specialty'], "-");
    $output_specialty = " in <span>{$query_specialty}</span>";
  }

  return $query_search . $output_location . $output_specialty;
}
