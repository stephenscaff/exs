<?php

/**
 * Is Professional Search
 * Determins if we're querying for pros
 * @return boolean
 */
function is_professional_search() {

  $location = get_query_var('location');
  $product_type = get_query_var('product_type');
  if ($location OR $product_type or is_post_type_archive('professional')) {
    return true;
  } else {
    return false;
  }
}

/**
 * Search Autocomplete Loader
 * Load up cdns for our search autocomplete libs
 */
add_action('wp_enqueue_scripts', 'search_autocomplete');

function search_autocomplete() {

  if ( is_professional_search() ) {

    // Jquery
    wp_enqueue_script(
       'jquery',
       'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js',
       '',
       true,
       true
     );

    // jquery autocomplete
   	wp_enqueue_script(
   		'search_autocomplete',
   		'https://cdnjs.cloudflare.com/ajax/libs/jquery-autocomplete/1.0.7/jquery.auto-complete.min.js',
   		array( 'jquery' ),
   		'',
   		true,
      true
   	);

    // Init autocomplete
    wp_enqueue_script(
   		'search_autocomplete-init',
   		get_template_directory_uri() . '/inc/search-and-filtering/search-autocomplete-init.js',
   		array( 'search_autocomplete' ),
   		'',
   		true,
      true
   	);
  }
}


/**
 * Autocomplete Search for Test (post type)
 * Querys for professionals by name
 */
add_action('wp_ajax_nopriv_get_professional_names', 'ajax_listings');
add_action('wp_ajax_get_professional_names', 'ajax_listings');

function ajax_listings() {
	global $wpdb; //get access to the WordPress database object variable

	//get names of all businesses
	$name = $wpdb->esc_like(stripslashes($_POST['name'])).'%'; //escape for use in LIKE statement
	$sql = "select post_title
		from $wpdb->posts
		where post_title like %s
		and post_type='professional' and post_status='publish'";

	$sql = $wpdb->prepare($sql, $name);

	$results = $wpdb->get_results($sql);

	//copy names to array
	$titles = array();

  foreach( $results as $r )

    $titles[] = $r->post_title;

  //encode into JSON format and output
	echo json_encode($titles);

  //stop "0" from being output
	die();
}
