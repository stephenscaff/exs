<?php

if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Jumpoff Query Filters
 * Builds out term links using query var
 * @param string $tax - taxonomy slug
 * @param string $type - post type
 * @param string $class - css class name
 * @return html
 */
function jumpoff_query_filters($tax, $type, $class) {

  $output = "";

  $args = array(
   'taxonomy'   => $tax,
   'hide_empty' => true,
   'post_type'  => array($type),
  );

  $link = get_post_type_archive_link($type);

  $terms = get_terms( $args);

  # wp_error object check
  if (is_wp_error( $terms )) return;

  if (!$terms) return;

  //$current_query = $_SERVER['QUERY_STRING'];
  foreach ($terms as $term)  {
   $url = $link .'?'.$tax . '=' . $term->slug;
   $title = $term->name;
   $output .= '<a class="' . $class . '" href="' . $url . '">' . convert_to_words($title) . '</a>';
 }

 return $output;
}


/**
 * Jumpoff Query Select
 * Builds Select elements for term search filtering.
 * @param string $tax taxonomy name
 * @param string $id Unique html id
 * @return html select
 */
function jumpoff_query_select($tax, $type, $id = '') {

  $output = "";

  $args = array(
     'taxonomy'   => $tax,
     'hide_empty' => true,
     'post_type'  => array($type)
  );

  $terms = get_terms( $args);

  # wp_error object check
  if (is_wp_error( $terms )) return;

  if (!$terms) return;

  $query_term       = '';
  $query            = get_query_var($tax);
  $tax_label        = convert_to_words($tax);
  $tax_label_plural = pluralizer($tax_label);
  $selected_value   = '';
  $selected_label   = "Select {$tax_label}";

  if ($query) {
    $query_term     = get_term_by( 'slug', $query, $tax, object);
    $selected_value = $query;
    $selected_label = $query_term->name;
  }

  $output .= "<select name='{$tax}' class='js-select' id='{$id}' style='width: 100%'>";
  $output .= "<option value='{$selected_value}' selected='selected'>{$selected_label}</option>";
  $output .= "<option value=''>All {$tax_label_plural}</option>";

  foreach ($terms as $term)  {

   $title   = $term->name;
   $output .= "<option value='{$term->slug}'>{$term->name}</option>";
 }
 $output .= "</select>"  . "\n";

 return $output;
}

/**
 * Specialty Select
 * Builds a select of specialty terms, for avvanced search.
 * @param string $type name of post type
 * @param string $label select label val
 * @param string $id select id (for js)
 * @param string $class select class name (for css and js)
 */
function jumpoff_specialty_select($type, $label, $id, $class) {

  $query = get_query_var('specialty');
  $select_label = "Select ${label}";
  $selected_value = '';
  $label_plural = pluralizer($label);

  if ($query) {
    $selected_value = $query;
    $select_term = get_term_by('slug', $query, 'specialty');
    $select_label = $select_term->name;
    //$select_label = convert_to_words($query, '-');
  }

  $output = "";
  $output .= "<select name='specialty' class='{$class}' id='{$id}'>";
  $output .= "<option value='{$selected_value}' selected='selected'>{$select_label}</option>";
  $output .= "<option value=''>All {$label_plural}</option>";

  foreach(
    get_terms(
      'specialty', array(
        'hide_empty' => true,
        'parent'     => 0,
        'post_type'  => $type
      )
    ) as $parent_term ) {

    $output .= "<option data-parent='parent' value='{$parent_term->slug}'>{$parent_term->name}</option>";

    foreach(
      get_terms(
        'specialty', array(
          'hide_empty' => false,
          'parent'     => $parent_term->term_id,
          'post_type'  => $type
        )
      ) as $child_term ) {
      $output .= "<option value='{$child_term->slug}'>{$child_term->name}</option>";
    }
  }

  $output .= "</select>"  . "\n";

  return $output;
}
