<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Fields - SEO
 * Location: all pages, posts and post types. Edit as needed.
 */

$careers_fields = new StoutLogic\AcfBuilder\FieldsBuilder('careers');

$careers_fields
  ->addText('career_subtitle')
  ->addText('career_address')
  ->addTextArea('career_intro', [
    'rows' => '3'
  ])
  ->addRepeater('career_list_block', [
    'layout' => 'block'
  ])
    ->addText('title')
    ->addTextarea('items', [
      'label' => 'List Items <br/><span style="font-weight: 400">New lines create list items</span>'
    ])
  ->endRepeater()
  ->addTextArea('career_disclaimer', [
    'rows' => '3'
  ])
  ->addText('career_apply_url')
  ->setLocation('post_type', '==', 'career');

add_action('acf/init', function() use ($careers_fields) {
   acf_add_local_field_group($careers_fields->build());
});
