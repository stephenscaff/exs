<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;

$post_location = new StoutLogic\AcfBuilder\FieldsBuilder('post_location', [
  'position'    => 'acf_after_title',
  'menu_order'  => '3',
]);

$post_location
  ->addText('post_location')
  ->setLocation('post_type', '==', 'success_story');

add_action('acf/init', function() use ($post_location) {
   acf_add_local_field_group($post_location->build());
});

/**
 * Subtitles
 */
$subtitle_field = new StoutLogic\AcfBuilder\FieldsBuilder('post_subtitle', [
  'position'    => 'acf_after_title',
  'menu_order'  => '2',
]);

$subtitle_field
  ->addText('post_subtitle')
  ->setLocation('post_type', '==', 'page')
          ->and('page_template', '!=', 'templates/form.php')
          ->and('page_template', '!=', 'templates/modules.php')
          ->and('page_template', '!=', 'templates/professionals-search.php')
           ->or('post_type', '==', 'success_story')
           ->or('post_type', '==', 'market_report')
           ->or('post_type', '==', 'trend_article');

add_action('acf/init', function() use ($subtitle_field) {
   acf_add_local_field_group($subtitle_field->build());
});
