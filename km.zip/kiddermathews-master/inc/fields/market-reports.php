<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Market Research
 */
$market_reports_fields = new StoutLogic\AcfBuilder\FieldsBuilder('market_reports_fields');

$market_reports_fields
  ->addText('reports_title')
  ->addFile('current_report')
  ->addRepeater('prior_reports')
    ->addFile('report')
  ->endRepeater()
  ->setLocation( 'post_type', '==', 'market_report' );

add_action('acf/init', function() use ($market_reports_fields) {
   acf_add_local_field_group($market_reports_fields->build());
});
