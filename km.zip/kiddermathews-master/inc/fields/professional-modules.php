<?php

if ( ! defined( 'ABSPATH' ) ) exit;


use StoutLogic\AcfBuilder\FieldsBuilder;

$professional_modules = new FieldsBuilder('professional_modules', [
  'key' => 'group_professional_modules',
  'position' => 'normal',
]);

$professional_modules
  ->addFlexibleContent('modules', [
    'button_label'=> "Add Module",
  ])
  ->addLayout($banner_module, [
    'name'=> "banner_module",
  ])
  ->addLayout($completed_transactions_module, [
    'name'=> "completed_transactions_module",
  ])
  ->addLayout($content_module, [
    'name'=> "content_module",
  ])
  ->addLayout($featured_properties_module, [
    'name'=> "featured_properties_module",
  ])
  ->addLayout($list_module, [
    'name'=> "list_module",
  ])
  ->addLayout($logos_module, [
    'name'=> "logos_module",
  ])
  ->addLayout($reports_trends_module, [
    'name'=> "reports_trends_module",
  ])
  ->addLayout($news_module, [
    'name'=> "news_module",
  ])
  ->addLayout($property_map_module, [
    'name'=> "property_map_module",
  ])
  ->addLayout($stats_module, [
    'name'=> "stats_module",
  ])
  ->addLayout($success_stories_module, [
    'name'=> "success_stories_module",
  ])
  ->addLayout($team_cta_module, [
    'name'=> "team_cta_module",
  ])
  ->addLayout($testimonials_module, [
    'name'=> "testimonials_module",
  ])
  ->addLayout($split_cta_module, [
    'name'=> "split_cta_module",
  ])
  ->setLocation('post_type', '==', 'professional')
  ->or('post_type', '==', 'team');

  add_action('acf/init', function() use ($professional_modules) {
     acf_add_local_field_group($professional_modules->build());
  });
