<?php

if ( ! defined( 'ABSPATH' ) ) exit;


use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Fields - Team mast
 * Location: Professional Post Type, singles
 */
$team_mast_fields = new StoutLogic\AcfBuilder\FieldsBuilder('team_mast', [
  'key' => 'team_mast',
  'position' => 'acf_after_title',
  'menu_order' => '1',
]);

$team_mast_fields
  ->addText( 'team_mast_pretitle' )
  ->addTextArea( 'team_mast_title', [
    'rows' => 2,
  ])
  ->addText( 'team_mast_subtitle' )
  ->addImage( 'team_mast_image' )
  ->addFields($bg_color_dark)
  ->setLocation('post_type', '==', 'team');

add_action('acf/init', function() use ($team_mast_fields) {
   acf_add_local_field_group($team_mast_fields->build());
});



/**
 * Fields - Professional Details
 * Location: Professional Post Type, singles
 */
$team_info_fields = new StoutLogic\AcfBuilder\FieldsBuilder('team_info', [
  'key' => 'team_info',
  'position' => 'acf_after_title',
  'menu_order' => '2',
]);

$team_info_fields
  ->addRelationship('professional_select', [
    'post_type'	=> 'professional',
    'return_format' => 'id',
    'max'   => 4,
    'filters' => array('search', '', ''),
    'label' => 'Select Team\'s Professionals'
  ])
  ->addWysiwyg ('professional_summary', [
    'media_upload' => 0
  ])

  ->setLocation('post_type', '==', 'team');

add_action('acf/init', function() use ($team_info_fields) {
   acf_add_local_field_group($team_info_fields->build());
});
