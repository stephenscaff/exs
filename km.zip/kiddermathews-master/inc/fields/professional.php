<?php

if ( ! defined( 'ABSPATH' ) ) exit;


use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Fields - Professional Details
 * Location: Professional Post Type, singles
 */
$professional_info_fields = new StoutLogic\AcfBuilder\FieldsBuilder('professional_info', [
  'key' => 'professional_info',
  'position' => 'acf_after_title',
]);

$professional_info_fields
  ->addText('professional_pretitle', [
  'label'   => 'Pretitle',
  ])
  ->addText('professional_designation', [
    'label'   => 'Designation',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addText('professional_position', [
    'label'   => 'Title',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addText('professional_license_no', [
    'label'   => 'License Number',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addText('professional_phone', [
    'label'   => 'Phone',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addText('professional_mobile', [
    'label'   => 'Mobile Phone',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addText('professional_fax',  [
    'label'   => 'Fax',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addText('professional_email', [
    'label'   => 'Email',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addText('professional_twitter', [
    'label'   => 'Twitter',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addText('professional_linkedin', [
    'label'   => 'LinkedIn',
    'wrapper' =>  ['width' => '33.333%']
  ])
  ->addTextArea('professional_address', [
    'label'   => 'Address',
    'rows'    => 3,
    'new_lines'	 => 'br',
  ])
  ->addFile('professional_vcard', [
    'label'   => 'vCard',
    'wrapper' =>  ['width' => '50%']

  ])
  ->addFile('professional_bio_pdf', [
    'label'   => 'Bio PDF',
    'wrapper' =>  ['width' => '50%']

  ])
  ->addTextArea('professional_recognition', [
    'label'   => 'Recognition <br/><span style="font-weight: 400">Add each item on a new line</span>',
    'wrapper' =>  ['width' => '50%'],
    'rows'    => 3,
  ])
  ->addTextArea('professional_education', [
    'label'   => 'Education <br/><span style="font-weight: 400">Add each item on a new line</span>',
    'wrapper' =>  ['width' => '50%'],
    'rows'    => 3,
  ])
  ->addWysiwyg ('professional_summary', [
    'media_upload' => 0
  ])

  ->setLocation('post_type',    '==', 'professional');

add_action('acf/init', function() use ($professional_info_fields) {
   acf_add_local_field_group($professional_info_fields->build());
});
