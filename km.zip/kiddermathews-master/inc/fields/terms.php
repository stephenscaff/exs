<?php

/**
 * Term Fields
 */
$term_fields = new StoutLogic\AcfBuilder\FieldsBuilder('term_fields', [
 'key' => 'term_fields',
 'position' => 'normal',
 'menu_order' => '1',
]);

$term_fields
 ->addImage('term_image', [
   'label' => '<strong>Image</strong> <br/><span>Displays on Term pages in Masts and cards. Size to 2000x1200</span>',
   'return_format' => 'array',
 ])
 ->setLocation('taxonomy', '==', 'specialty')
          ->or('taxonomy', '==', 'location')
          ->or('taxonomy', '==', 'product_type');

add_action('acf/init', function() use ($term_fields) {
  acf_add_local_field_group($term_fields->build());
});
