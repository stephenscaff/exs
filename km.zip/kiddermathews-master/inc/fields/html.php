<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *  Html Template
 */
$cf7_url = admin_url( 'admin.php?page=wpcf7' );

$html_fields = new StoutLogic\AcfBuilder\FieldsBuilder('custom_html', [
  'position' => 'acf_after_title',
  'name' => 'HTML'
]);;

$html_fields
->addTab('HTML')
->addSelect('grid')
  ->addChoice('grid-full')
  ->addChoice('grid-lg')
  ->addChoice('grid')
  ->addChoice('grid-sm')
  ->addTextArea('custom_html', [
    'rows' => '30',
  ])
->addTab('CSS')
->addTextArea('custom_css', [
  'rows' => '30',
])
->setLocation('page_template', '==', 'templates/custom-html.php');

add_action('acf/init', function() use ($html_fields) {
   acf_add_local_field_group($html_fields->build());
});
