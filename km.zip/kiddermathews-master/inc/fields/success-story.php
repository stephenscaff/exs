<?php

if ( ! defined( 'ABSPATH' ) ) exit;

$story_stats = new StoutLogic\AcfBuilder\FieldsBuilder('success_story_stats', [
 'position' => 'acf_after_title',
 'menu_order' => '1',
]);
$story_stats
->addMessage('', 'This creates the stats section under the mast.')

->addRepeater('story_stat', [
  'button_label' => 'Add Stat',
  'layout' => 'block'
])
  ->addText('number', [
    'wrapper' =>  ['width' => '15%']
  ])
  ->addText('title', [
    'wrapper' =>  ['width' => '35%']
  ])
  ->addText('text', [
    'wrapper' =>  ['width' => '50%']
  ])
  ->endRepeater()

  ->setLocation('post_type', '==', 'success_story');

add_action('acf/init', function() use ($story_stats) {
  acf_add_local_field_group($story_stats->build());
});
