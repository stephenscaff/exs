<?php

if ( ! defined( 'ABSPATH' ) ) exit;


$show_contacts = new StoutLogic\AcfBuilder\FieldsBuilder('contacts_aside', [
  'key' => 'group_contacts_aside',
  'position' => 'acf_after_title',
  'menu_order' => '2',
  'name' => 'Show Contacts'
]);;


$contacts_url = admin_url( 'admin.php?page=wpcf7' );

$show_contacts
  ->addText( 'form_title' )
  ->addTextArea( 'form_text', [
    'rows' => 2,
    'label' => 'Form Intro Text'
  ])
  ->addTrueFalse('show_tollfree_phone', [
      'default_value'  => 0,
      'message'        => '<br/><br/>Show Tollfree phone.',
      'ui'             => 1,
      'ui_on_text'     => 'Show',
      'ui_off_text'    => 'Hide',
      'wrapper'    =>  ['width' => '50%']
  ])
  ->addTrueFalse('show_email', [
      'default_value'  => 0,
      'message'        => '<br/><br/>Show Company Email.',
      'ui'             => 1,
      'ui_on_text'     => 'Show',
      'ui_off_text'    => 'Hide',
      'wrapper'    =>  ['width' => '50%']
  ])
  ->addTrueFalse('show_property_management_phone', [
      'default_value'  => 0,
      'message'        => '<br/><br/>Switch on Property Management Phone Number.',
      'ui'             => 1,
      'ui_on_text'     => 'Show',
      'ui_off_text'    => 'Hide',
      'wrapper'    =>  ['width' => '50%']
  ])
  ->addTrueFalse('show_property_management_email', [
      'default_value'  => 0,
      'message'        => '<br/><br/>Switch on Property Management Phone Email.',
      'ui'             => 1,
      'ui_on_text'     => 'Show',
      'ui_off_text'    => 'Hide',
      'wrapper'    =>  ['width' => '50%']
  ])
  ->addTrueFalse('show_socials', [
      'default_value'  => 0,
      'message'        => '<br/><br/>Switch on Social Links.',
      'ui'             => 1,
      'ui_on_text'     => 'Show',
      'ui_off_text'    => 'Hide',
      'wrapper'    =>  ['width' => '50%']
  ])
  ->addTrueFalse('show_custom_contacts', [
      'default_value'  => 0,
      'message'        => '<br/><br/>Switch on Custom Contacts.',
      'ui'             => 1,
      'ui_on_text'     => 'Show',
      'ui_off_text'    => 'Hide',
      'wrapper'    =>  ['width' => '50%']
  ])
  ->addRepeater('custom_contacts', [
    'layout' => 'block',
    'button_label' => 'Add Contact',
  ])
    ->addText('title', [
      'wrapper'    =>  ['width' => '40%'],
    ])
    ->addText('value', [
      'wrapper'    =>  ['width' => '60%'],
    ])
  ->endRepeater()


->setLocation('page_template', '==', 'templates/form.php');

add_action('acf/init', function() use ($show_contacts) {
   acf_add_local_field_group($show_contacts->build());
});
