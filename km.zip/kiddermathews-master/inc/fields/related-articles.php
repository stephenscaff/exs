<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *   Related Market Reports.
 */
$related_market_reports = new StoutLogic\AcfBuilder\FieldsBuilder('related_market_reports', [
  'menu_order' => '4'
]);

$related_market_reports
  ->addRelationship('markert_reports',  [
    'label'      => 'Select market reports',
    'post_type'  =>  'market_report',
    'filters'    => array('search', 'market_report', 'market_location'),
    'max'        => 3,
    'wrapper'    =>  ['width' => '100%'],
  ])
  ->addText('market_reports_archive_link', [
    'label' => 'Prefiltered View All Link <br/><span>If you want a prefiltered list of market reports, provide relative link <br/> ie:<code>/market-reports/?product_type=brokerage</code></span>'
  ])
  ->setLocation( 'post_type', '==', 'office_location' );

add_action('acf/init', function() use ($related_market_reports) {
   acf_add_local_field_group($related_market_reports->build());
});

/**
 * Related News
 */
$related_news = new StoutLogic\AcfBuilder\FieldsBuilder('related_news', [
  'menu_order' => '5',
]);
$related_news
  ->addRelationship('news',  [
    'label'      => 'Select News Articles or let the 3 latest related articles display ',
    'post_type'  =>  'post',
    'taxonomy'   => '',
    'filters'    => array('search', '', ''),
    'max'        =>  3,
    'wrapper'    =>  ['width' => '100%'],
  ])
  ->addText('news_archive_link', [
    'label' => 'Prefiltered View All Link <br/><span>If you want a prefiltered list of News Articles, provide relative categorey link <br/> ie:<code>/news/category/press-releases</code></span>'
  ])
  ->setLocation( 'post_type', '==', 'office_location' )
  ->or( 'post_type', '==', 'service' );

add_action('acf/init', function() use ($related_news) {
   acf_add_local_field_group($related_news->build());
});


/**
 * Related Succes Stories
 */
$related_success_stories = new StoutLogic\AcfBuilder\FieldsBuilder('related_success_stories', [
  'menu_order' => '6',
]);
$related_success_stories
  ->addRelationship('success_stories',  [
    'label'      => 'Select Success Stories or let the 3 latest related articles display ',
    'post_type'  =>  'success_story',
    'taxonomy'   => '',
    'filters'    => array('search', '', ''),
    'max'        =>  5,
    'wrapper'    =>  ['width' => '100%'],
  ])
  ->addText('success_stories_archive_link', [
    'label' => 'Prefiltered View All Link <br/><span>If you want a prefiltered list of market reports, provide relative link <br/> ie:<code>/success-stories/?product_type=brokerage</code></span>'
  ])
  ->setLocation( 'post_type', '==', 'office_location' )
  ->or( 'post_type', '==', 'service' );

add_action('acf/init', function() use ($related_success_stories) {
   acf_add_local_field_group($related_success_stories->build());
});
