<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;

$bottom_nav = new StoutLogic\AcfBuilder\FieldsBuilder('bottom_navigation', [
  'key'        => 'bottom_nav',
  'position'   => 'normal',
  'menu_order' => '12',
]);

$bottom_nav
# Left Button
->addText('left_btn_title', [
  'wrapper' =>  ['width' => '50%'],
  'label'   =>  'Left Button Text'
])
->addPageLink('left_btn_link', [
  'allow_null'  => 'true',
  'wrapper'     =>  ['width' => '50%'],
  'label'       =>  'Left Button Link (internal)',
  'post_type'	  => array('page', 'service', 'professional'),
])

# Right Button
->addText('right_btn_title', [
  'wrapper' =>  ['width' => '50%'],
  'label'   =>   'Right Button Text'
])
->addPageLink('right_btn_link', [
  'allow_null'  => 'true',
  'wrapper'     =>  ['width' => '50%'],
  'label'       =>   'Right Button Link (internal)',
  'post_type'	  => array('page', 'service'),
])

->setLocation('post_type', '==', 'success_story')
  ->or('post_type',     '==', 'service')
  ->or('page_template', '==', 'templates/custom-html.php')
  ->or('page_template', '==', 'templates/modules.php')
  ->or('page_template', '==', 'templates/careers.php')
  ->or('page_template', '==', 'templates/home.php')
  ->or('page_template', '==', 'templates/market-research.php');


add_action('acf/init', function() use ($bottom_nav) {
   acf_add_local_field_group($bottom_nav->build());
});
