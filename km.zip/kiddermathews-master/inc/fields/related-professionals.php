<?php

if ( ! defined( 'ABSPATH' ) ) exit;

$related_professional = new StoutLogic\AcfBuilder\FieldsBuilder('related_professional');

$related_professional
  ->addRelationship('related_professional', [
    'post_type'	    => array('professional', 'team'),
    'return_format' => 'id',
    'label'         => 'Related Professional / Team <br/><span style="font-weight: 400">Select a Professional / Team to relate this post to</span>'
  ])
  ->setLocation('post_type', '==', 'post')
           ->or('post_type', '==', 'success_story')
           ->or('post_type', '==', 'market_report');

add_action('acf/init', function() use ($related_professional ) {
   acf_add_local_field_group($related_professional->build());
});
