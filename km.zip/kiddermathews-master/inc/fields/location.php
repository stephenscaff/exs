<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Location
 * Post Type: Office Location
 */
$location_fields = new StoutLogic\AcfBuilder\FieldsBuilder('location');

$location_fields
  ->addRepeater('location_contact_numbers', [
    'min' => 1,
    'layout' => 'block',
    'button_label' => 'Add Number',
  ])
    ->addText('label', [
      'wrapper'    =>  ['width' => '20%']
    ])
    ->addText('number', [
      'wrapper'    =>  ['width' => '80%']
    ])
  ->endRepeater()
  ->addTextArea('location_address', [
    'rows' => '3',
    'new_lines' => 'br',
    'wrapper'    =>  ['width' => '50%'],
  ])
  ->addGoogleMap('location_map', [
    'height' => '200',
    'center_lat' => '48.745961',
    'center_lng' => '-122.474071',
    'zoom' => '10',
    'wrapper'    =>  ['width' => '50%'],
    'required'  => true
  ])
  ->addRelationship('location_evp',  [
   'label'      => 'Select the Office Location\'s Managing Director',
   'post_type'  =>  array('professional'),
   'filters' => array('search', '', ''),
   'max'        => 1,
   'wrapper'    =>  ['width' => '50%']
  ])
  ->addRelationship('location_rp',  [
   'label'      => 'Select the Office Location\'s Regional President',
   'post_type'  =>  array('professional'),
   'filters' => array('search', '', ''),
   'max'        => 1,
   'wrapper'    =>  ['width' => '50%']
  ])
  ->addFile('location_brochure', [
    'wrapper'    =>  ['width' => '50%']
  ])
  ->addFile('property_management_brochure', [
    'wrapper'    =>  ['width' => '50%']
  ])
  ->setLocation( 'post_type', '==', 'office_location' );

add_action('acf/init', function() use ($location_fields) {
   acf_add_local_field_group($location_fields->build());
});
