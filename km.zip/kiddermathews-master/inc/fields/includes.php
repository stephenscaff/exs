<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Require Composer Autoload for StoutLogic ACF Builder
 * @see https://github.com/StoutLogic/acf-builder
 * @see https://github.com/StoutLogic/acf-builder/wiki
 */
$autoload = get_template_directory().'/vendor/autoload.php';

# Autoload warning
if ( is_file($autoload) ) {
  require_once( $autoload );
} else {
  trigger_error("Whoops! Make sure to run `composer install` first, so vendor/autoload.php exists for our ACF Fields Builder. Included in: ", E_USER_WARNING);
  die();
}


require_once('vars.php');
require_once('modules/includes.php');
require_once('bottom-nav.php');
require_once('careers.php');
require_once('contacts.php');
require_once('show-contacts.php');
require_once('featured.php');
require_once('forms.php');
require_once('global-content.php');
require_once('tracking.php');
require_once('home.php');
require_once('html.php');
require_once('location.php');
require_once('mast.php');
require_once('market-reports.php');
require_once('modules-template.php');
require_once('news.php');
require_once('professional.php');
require_once('professional-modules.php');
require_once('related-professionals.php');
require_once('seo.php');
require_once('service.php');
require_once('success-story.php');
require_once('page-titles.php');
require_once('post-fields.php');
require_once('professionals-search.php');
require_once('team.php');
require_once('terms.php');
require_once('user.php');
require_once('properties.php');
