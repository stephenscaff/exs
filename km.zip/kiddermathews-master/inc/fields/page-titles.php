<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

$title_field = new StoutLogic\AcfBuilder\FieldsBuilder('page_title', [
  'position' => 'acf_after_title',
]);

$title_field
  ->addText('page_title')
  ->setLocation('options_page', '==', 'posts-index');

add_action('acf/init', function() use ($title_field) {
   acf_add_local_field_group($title_field->build());
});
