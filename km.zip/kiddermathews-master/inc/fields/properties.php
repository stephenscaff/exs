<?php
/**
 * Property Listings
 * Location: Property Listings
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *   Related Market Reports.
 */
$property_listings = new StoutLogic\AcfBuilder\FieldsBuilder('property_listings');


$property_listings
  ->addText('heading_title')
  ->addRepeater('property_types', [
    'button_label'  => 'Add New Type',
    'layout'        => 'block',
  ])
    ->addText('title')
    ->addImage('image')
    ->addText('url_for_sale')
    ->addText('url_for_lease')
  ->setLocation( 'page_template', '==', 'templates/property-search.php' );

add_action('acf/init', function() use ($property_listings) {
   acf_add_local_field_group($property_listings->build());
});
