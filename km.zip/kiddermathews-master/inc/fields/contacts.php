<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Contacts Fields
 */
$contacts_fields = new StoutLogic\AcfBuilder\FieldsBuilder('contacts');

$contacts_fields
    ->addTextArea('company_address', [
      'wrapper' =>  ['width' => '100%'],
      'rows' =>  '4',
    ])
    ->addMessage('Phone Numbers', '')
    ->addText('company_phone_local', [
      'wrapper' =>  ['width' => '33.33%']
    ])
    ->addText('company_phone_tollfree', [
      'wrapper' =>  ['width' => '33.33%']
    ])
    ->addText('company_phone_property_management', [
      'label' => 'Property Manament Phone',
      'wrapper' =>  ['width' => '33.33%']
    ])
    ->addMessage('Emails', '')
    ->addText('company_email', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('company_email_property_management', [
      'label' => 'Property Manament Email',
      'wrapper' =>  ['width' => '50%']
    ])
    ->addMessage('Socials', '')
    ->addText('company_youtube', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('company_instagram', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('company_twitter', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('company_linkedin', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('company_facebook', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addMessage('Press Contact', '')
    ->addFields($bg_color)
    ->addTrueFalse('is_inside_container', [
      'label'  => 'Is Inside Container <br/><span style="font-weight: 400">Checking this box will place the module within the container, instead of being full width',
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('press_name', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('press_title', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('press_number', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('press_email', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addTextArea('press_excerpt', [
      'rows' => '3',
      'new_lines' => 'br',
    ])
    ->setLocation('options_page', '==', 'contacts');

add_action('acf/init', function() use ($contacts_fields) {
   acf_add_local_field_group($contacts_fields->build());
});
