<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Footer Content Fields
 */
$global_fields = new StoutLogic\AcfBuilder\FieldsBuilder('global_content');

$global_fields
  ->addTextArea('footer_message', [
    'wrapper' =>  ['width' => '100%'],
    'rows'    =>  '4',
  ])
  ->setLocation('options_page', '==', 'global_content');

add_action('acf/init', function() use ($global_fields) {
   acf_add_local_field_group($global_fields->build());
});
