<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Mast Promo
 * Homepage mast interaction to promote services or whatevers
 */
 $mast_promo_fields = new StoutLogic\AcfBuilder\FieldsBuilder('mast_promo', [
     'key' => 'group_mast_promo',
     'position' => 'acf_after_title',
     'menu_order' => '1',
 ]);;

 $mast_promo_fields
 ->addMessage(
   '',
   'The Mast Promo Component allows you to promote Kidder Mathews services via slides/layers that appear on hover of a subnav element.'
  )
 ->addTextArea('mast_promo_title', [
   'label'      => 'Mast Title ',
   'rows'       => 3,
   'new_lines'  => 'br'
 ])
 ->addFile('mast_promo_video', [
   'label' => 'Featured Background Video'
 ])
 ->addImage('mast_promo_image', [
   'label' => 'Featured Background Image. Size to 2000x1200'
 ])
 ->addRepeater('mast_promo_layers', [
   'label'        => 'Layers <br/><br/><span style="font-weight: 400">Build each layer with a background image and subnav link</span>',
   'button_label' => 'Add Layers',
   'layout'       => 'block',
   'min'          => 1,
 ])
   ->addTextArea('title', [
     'label'      => 'Layer Title ',
     'rows'       => 3,
     'new_lines'  => 'br'
   ])
   ->addImage('image', [
     'label' => 'Background Image. Size to 2000x1250'
   ])
   ->addPageLink('page_link', [
     'allow_null'   => 'true',
     'wrapper'      =>  ['width' => '33.333%'],
     'label'        =>   'Page Link (internal)',
   ])
   ->addText('url', [
     'wrapper'  =>  ['width' => '33.333%'],
     'label'    =>   'URL (external)'
   ])
   ->addText('link_text', [
     'wrapper'  =>  ['width' => '33.333%'],
   ])
 ->endRepeater()
 ->setLocation('page_template', '==', 'templates/home.php');

 add_action('acf/init', function() use ($mast_promo_fields) {
    acf_add_local_field_group($mast_promo_fields->build());
 });
