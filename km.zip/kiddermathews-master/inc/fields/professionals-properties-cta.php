<?php

if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Professional / Properties CTAs
 * Post Type: Office Location
 */
$professional_properties_cta = new StoutLogic\AcfBuilder\FieldsBuilder('professional_properties_cta');

$professional_properties_cta
  ->addTrueFalse('show_pro_prop_ctas', [
      'default_value'  => 1,
      'message'        => 'Toggle CTAs on/off',
      'ui'             => 1,
      'ui_on_text'     => 'Show',
      'ui_off_text'    => 'Hide',
  ])
  ->addImage('professionals_search_image', [
    'label' => 'Professionals Image <span style="font-weight:400;">Size to 1500x900</span>',
    'wrapper'    =>  ['width' => '50%']
  ])
  ->addText('professionals_search_url')
  ->addImage('properties_search_image', [
    'label' => 'Properties Image <span style="font-weight:400;">Size to 1500x900</span>',
    'wrapper'    =>  ['width' => '50%']
  ])
  ->addText('properties_search_url')
  ->setLocation( 'post_type', '==', 'office_location' )
  ->or( 'post_type', '==', 'service');

add_action('acf/init', function() use ($professional_properties_cta) {
   acf_add_local_field_group($professional_properties_cta->build());
});
