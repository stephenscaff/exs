<?php

/**
 * Term Fields
 */
$in_the_news = new StoutLogic\AcfBuilder\FieldsBuilder('in_the_news', [
 'position'   => 'acf_after_title',
 'menu_order' => '1',
]);

$in_the_news
 ->addText('article_source', [
   'label'          => 'Article Source',
   'return_format'  => 'array',
   'wrapper'        =>  ['width' => '50%']
 ])
 ->addText('article_author', [
   'label'          => 'Article Author',
   'return_format'  => 'array',
   'wrapper'        =>  ['width' => '50%']
 ])
 ->setLocation('post_type', '==', 'post')
   ->and('post_category', '==', array(1));

add_action('acf/init', function() use ($in_the_news) {
  acf_add_local_field_group($in_the_news->build());
});
