<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Tracking Fields
 */
$tracking_fields = new StoutLogic\AcfBuilder\FieldsBuilder('tracking');

$tracking_fields
    # GTM ID
    ->addText('gtm_id', [
      'label' => 'Provide GTM Id <span>(ie: GTM-ABCDEFG)</span>',
    ])

    ->setLocation('options_page', '==', 'tracking');

add_action('acf/init', function() use ($tracking_fields) {
   acf_add_local_field_group($tracking_fields->build());
});
