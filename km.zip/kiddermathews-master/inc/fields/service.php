<?php

if ( ! defined( 'ABSPATH' ) ) exit;


use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Fields -  Services
 * Location: Single Service
 */
$servcie_fields = new StoutLogic\AcfBuilder\FieldsBuilder('service', [
  'position' => 'acf_after_title'
]);

$servcie_fields
  ->addRelationship('service_professional',  [
   'label'      => 'Select the Service\'s professional contact',
   'post_type'  =>  array('professional'),
   'filters'    => array('search', '', ''),
   'wrapper'    =>  ['width' => '100%']
  ])

  ->addFile('service_capabilities_brocure', [
    'label'   => 'Capabilities Brochure',
    'wrapper' =>  ['width' => '50%']
  ])
  ->addRepeater('service_additional_downloads', [
    'label'         => 'Additional Downloads',
    'button_label'  => 'Add Download',
    'wrapper'       =>  ['width' => '50%']
  ])
    ->addFile('file', [
      'label'   => 'File',
    ])
  ->endRepeater()
  ->addRepeater('service_stats', [
    'label'         => 'Stats',
    'button_label'  => 'Add Stat',
    'wrapper'       =>  ['width' => '100%']
  ])
    ->addText('number')
    ->addText('title')
    ->addText('text')
  ->endRepeater()

  ->setLocation('post_type',    '==', 'service');

add_action('acf/init', function() use ($servcie_fields) {
   acf_add_local_field_group($servcie_fields->build());
});
