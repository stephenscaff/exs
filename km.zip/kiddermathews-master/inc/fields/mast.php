<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *   Mast Fields
 *   For mastheads and stuff.
 */

$mast_fields = new StoutLogic\AcfBuilder\FieldsBuilder('mast', [
  'key' => 'group_mast',
  'position' => 'acf_after_title',
  'menu_order' => '1',
]);

$mast_fields
  ->addText( 'mast_pretitle' )
  ->addTextArea( 'mast_title', [
    'rows' => 2,
  ])
->addImage( 'mast_image' )
->setLocation( 'post_type', '==', 'page' )
        ->and('page_template', '!=', 'templates/home.php')
        ->and('page_template', '!=', 'templates/professionals-search.php')
         ->or('post_type', '==', 'service')
         ->or('options_page', '==', 'news-index')
         ->or('options_page', '==', 'service-index')
         ->or('options_page', '==', 'career-index')
         ->or('options_page', '==', 'market_report-index')
         ->or('options_page', '==', 'trend_article-index');

add_action('acf/init', function() use ($mast_fields) {
   acf_add_local_field_group($mast_fields->build());
});
