<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Buttons
 */
$button_field = new FieldsBuilder('button');
$button_field
 # Button Page link
 ->addPageLink('button_link', [
   'allow_null' => 'true',
   'wrapper'    =>  ['width' => '33.333%'],
   'label'      =>   'Button Page Link (internal)',
 ])
 # Button URL
 ->addText('button_url', [
   'wrapper' =>  ['width' => '33.333%'],
   'label'   =>   'Button URL (external)'
 ])
 # Button Text
 ->addText('button_text', [
   'wrapper' =>  ['width' => '33.333%'],
 ]);


 /**
  * Headings
  */
 $heading_field = new FieldsBuilder('heading');
 $heading_field
  ->addText('heading_title', [
    'label'   =>  'Section Title <br><span>Apply a title to module/section.</span>',
    'wrapper' => ['width' => '50%']
  ]);

/**
 * Section Name / Anchor
 */
$section_name = new FieldsBuilder('section_name');
$section_name
  ->addText('section_name',  [
    'label'   => 'Section Name <br><span>Used for creating page navigation and anchors. Keep it as short.</span>',
    'wrapper' => ['width' => '50%']
  ]);

/**
 * Background Color Selector
 */
$bg_color = new FieldsBuilder('background_color');
$bg_color
  ->addSelect('bg_color',  [
    'placeholder' => 'Select an Background Color',
    'default'     =>  'white',
    'wrapper'     =>  ['width' => '50%']
  ])
  ->addChoice('bg-white', 'White')
  ->addChoice('bg-grey-light', 'Light Grey')
  ->addChoice('bg-grey', 'Grey')
  ->addChoice('bg-grey-mid', 'Grey Mid')
  ->addChoice('bg-grey-dark', 'Dark Grey')
  ->addChoice('bg-alpha', 'Orange');

/**
 * Background Color Selector
 */
$bg_color_dark = new FieldsBuilder('background_color_dark');
$bg_color_dark
  ->addSelect('bg_color',  [
    'placeholder'   => 'Select an Background Color',
    'default_value' =>  'bg-alpha',
  ])
  ->addChoice('bg-grey', 'Grey')
  ->addChoice('bg-grey-dark', 'Dark Grey')
  ->addChoice('bg-alpha', 'Orange');


/**
 * Background Color Selector
 */
$bg_color_light = new FieldsBuilder('background_color_light');
$bg_color_light
  ->addSelect('bg_color',  [
    'placeholder'   => 'Select an Background Color',
    'default_value' =>  'bg-white',
  ])
  ->addChoice('bg-white', 'White')
  ->addChoice('bg-grey-light', 'Light Grey')
  ->addChoice('bg-grey-dark', 'Dark Grey');
