<?php

if ( ! defined( 'ABSPATH' ) ) exit;


use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Fields - Professional Details
 * Location: Professional Post Type, singles
 */
$professional_search_fields = new StoutLogic\AcfBuilder\FieldsBuilder('professional_search');

$professional_search_fields
  ->addMessage('Search Mast', '')
  ->addText('pro_search_pretitle', [
    'label' => 'Search Mast Pretitle',
  ])
  ->addImage('pro_search_mast_img', [
    'label' => 'Search Mast Image',
  ])
  ->addText('pro_search_mast_title', [
    'label' => 'Search Mast Title',
  ])
  ->addMessage('Search Intro', '')
  ->addText('pro_search_intro_pretitle')
  ->addText('pro_search_intro_title')
  ->addTextArea('pro_search_intro_excerpt')
  ->setLocation('options_page', '==', 'professional-index');

add_action('acf/init', function() use ($professional_search_fields) {
   acf_add_local_field_group($professional_search_fields->build());
});
