<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *   Mast Fields
 *   For mastheads and stuff.
 */

$cf7_url = admin_url( 'admin.php?page=wpcf7' );

$form_fields = new StoutLogic\AcfBuilder\FieldsBuilder('form', [
  'key' => 'group_forms',
  'position' => 'acf_after_title',
  'menu_order' => '3',
  'name' => 'Contact Form'
]);


$form_fields
  ->addText( 'form_title' )
  ->addTextArea( 'form_text', [
    'rows' => 2,
    'label' => 'Form Intro Text'
  ])
->addText( 'form_shortcode',     [
    'label'   =>  'Provide Contact Form Shortcode <br/><span style="font-weight: 400">Forms are built within the  <a href="'.$cf7_url.'">Contact Form Section</a>. Otherwise use the iframe URL from your third party provider, below.</span>'
])
->addText( 'iframe_url')

->setLocation('page_template', '==', 'templates/form.php');

add_action('acf/init', function() use ($form_fields) {
   acf_add_local_field_group($form_fields->build());
});
