<?php
/**
 * Fields - Modules for our Modules Template
 * Location: templates/modules.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;

$modules_template = new FieldsBuilder('modules_template', [
  'key' => 'group_modules_template',
  'menu_order' => '2',
]);

$modules_template
  ->addFlexibleContent('modules', [
    'button_label'=> "Add Module",
  ])
  ->addLayout($banner_module, [
    'name'=> "banner_module",
  ])
  ->addLayout($cards_module, [
    'name'=> "cards_module",
  ])
  ->addLayout($card_blocks_module, [
    'name'=> "card_blocks_module",
  ])
  ->addLayout($content_module, [
    'name'=> "content_module",
  ])
  ->addLayout($featured_properties_module, [
    'name'=> "featured_properties_module",
  ])
  ->addLayout($gallery_module , [
    'name'=> "gallery_module",
  ])
  ->addLayout($list_module, [
    'name'=> "list_module",
  ])
  ->addLayout($logos_module, [
    'name'=> "logos_module",
  ])
  ->addLayout($news_module, [
    'name'=> "news_module",
  ])
  ->addLayout($property_map_module, [
    'name'=> "property_map_module",
  ])
  ->addLayout($reports_trends_module, [
    'name'=> "reports_trends_module",
  ])
  ->addLayout($research_module, [
    'name'=> "research_module",
  ])
  ->addLayout($services_module, [
    'name'=> "services_module",
  ])
  ->addLayout($split_cta_module , [
    'name'=> "split_cta_module",
  ])
  ->addLayout($stats_module, [
    'name'=> "stats_module",
  ])
  ->addLayout($success_stories_module, [
    'name'=> "success_stories_module",
  ])
  ->addLayout($testimonials_module , [
    'name'=> "testimonials_module",
  ])
  ->addLayout($team_cta_module, [
    'name'=> "team_cta_module",
  ])
  ->addLayout($team_selector_module, [
    'name'=> "team_selector_module",
  ])
  ->addLayout($quote_module, [
    'name'=> "quote_module",
  ])
  ->setLocation('page_template', '==', 'templates/modules.php')
    ->or('page_template', '==', 'templates/careers.php')
    ->or('page_template', '==', 'templates/home.php')
    ->or('page_template', '==', 'templates/market-research.php')
    ->or('page_template', '==', 'templates/form.php')
    ->or('post_type',     '==', 'office_location')
    ->or('post_type',     '==', 'service')
    ->or('options_page',  '==', 'service-index')
    ->or('post_type',     '==', 'success_story');

  add_action('acf/init', function() use ($modules_template) {
     acf_add_local_field_group($modules_template->build());
  });
