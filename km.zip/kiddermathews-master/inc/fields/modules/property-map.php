<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Property Map Module
 * @see views/modules/team-cta-module.php
 * @see scss/components/_t.scss
 */
$property_map_module = new FieldsBuilder('property_map_module');
$property_map_module
->addMessage('', 'The Property Map Module adds an interactive map of properties and info markers by connecting to the property api.')
->addFields($section_name)
->addFields($heading_field)
->addTrueFalse('lease_or_sale', [
  'label'         => 'Lease or Sale',
  'message'       => 'Lease -OR- Sale',
  'instructions'  => 'Toggle View All Link for List Type Lease or Sale ',
  'default_value' => 0,
  'ui'            => 1,
  'ui_on_text'    => 'Sale',
  'ui_off_text'   => 'Lease'
])
->addText('api_endpoint_email', [
  'label' => 'API Endpoint Email <br/><span style="font-weight: 400">Provide the Broker email address to make the map request</span>',
  'wrapper' =>  ['width' => '50%']
])
->addText('api_endpoint_display_name', [
  'label' => 'API Endpoint Display Name <br/><span style="font-weight: 400">Provide the Broker Name used in the API endpoint</span>',
  'wrapper' =>  ['width' => '50%']
]);
