<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Cards Module
 * @see views/modules/cards-module.php
 * @see scss/components/_card.scss
 */
$cards_module = new FieldsBuilder('cards_module');
$cards_module
  ->addMessage('', 'The Cards Module enables you to add a collection of ui cards offering image, title, text and link.')
  ->addFields($section_name)
  ->addFields($heading_field)
  ->addRepeater('cards', [
    'button_label' => 'Add Card',
    'layout' => 'block',
  ])
    ->addImage('image', [
      'label' => 'Image <br/><span style="font-weight:400">Ensure all images are the same size. 800x480 is good size.</span>',
      'max_size'  => '300 KB',
      'return_format' => 'id'
    ])
    ->addText('title', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addTextArea('content', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addFields($button_field)
  ->endRepeater()
  ->addText('view_more_url', [
    'label' => 'View More url',
    'wrapper' =>  ['width' => '50%']
  ])
  ->addText('view_more_btn_text', [
    'label' => 'View More Button Text',
    'wrapper' =>  ['width' => '50%']
  ]);
