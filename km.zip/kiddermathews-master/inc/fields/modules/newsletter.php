<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


 /**
  * Newsletter Module
  * @see views/modules/team-module
  */
 $newsletter_module = new FieldsBuilder('newsletter_module');
 $newsletter_module
   ->addMessage('', 'The Newsletter Module allows you to include newsletter entires in a 3 column grid with the ability to provide an external link or pdf download.')
   ->addFields($section_name)
   ->addFields($heading_field)
   ->addRepeater('newsletters', [
     'button_label' => 'Add Newsletter',
     'layout' => 'block'
   ])
   ->addDatePicker('date', [
     'display_format' => 'F j Y',
     'return_format'  => 'F j Y',
     'wrapper' =>  ['width' => '100%'],
     'label'   =>  'Date Picker (optional)'
   ])
   ->addText('title')
   ->addUrl('url')
   ->addFile('newsletter_pdf');
