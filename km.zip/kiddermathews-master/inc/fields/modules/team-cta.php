<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Team CTA Module
 * @see views/modules/team-cta-module.php
 * @see scss/components/_t.scss
 */
$team_cta_module = new FieldsBuilder('team_cta_module');
$team_cta_module
  ->addMessage('', 'The Team CTA Module promotes a related professional team. ')
  ->addFields($bg_color_dark)
  ->addFields($section_name)
  ->addText('pretitle')
  ->addText('title', [
    'label' => 'Names of Team Members'
  ])
  ->addText('specialties')
  ->addImage('image', [
    'label' => 'Team Image',
    'max_size'  => '300 KB',
    'return_format' => 'id'
  ])
  ->addPageLink('link', [
    'post_type'	=> array('team'),
  ]);
