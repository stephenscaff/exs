<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Logos Module
 * @see views/modules/team-module
 */

$logos_module = new FieldsBuilder('logos_module');
$logos_module
->addFields($section_name)
->addFields($heading_field)
->addTrueFalse('is_grayscale', [
  'label'         => 'Grayscale Images',
  'instructions'  => 'Toggle to enable grayscale imagds',
  'default_value' => 1,
  'ui'            => 1,
  'ui_on_text'    => 'On',
  'ui_off_text'   => 'Off',
])
  ->addRepeater('logos', [
  'min' => 1,
  'layout' => 'block',
  'button_label' => 'Add Block',
])
  ->addImage('image', [
    'label' => 'Block Image <br/><span style="font-weight:400">Ensure all images are the same size. 500x500 is good size.</span>',
    'max_size'  => '300 KB',
    'return_format' => 'id',
  ])
->endRepeater()

->addFields($button_field);
