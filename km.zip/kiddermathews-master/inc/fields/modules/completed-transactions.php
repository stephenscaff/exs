<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Completed Transactions Module
 * @see views/modules/team-cta-module.php
 * @see scss/components/_t.scss
 */
$completed_transactions_module = new FieldsBuilder('completed_transactions_module');
$completed_transactions_module
->addMessage('', 'The Completed Transactions Module adds a collection of property cards pulled in from a specified property api endpoint.')
->addFields($section_name)
->addFields($heading_field)
->addText('api_endpoint_email', [
  'label' => 'API Endpoint Email <br/><span style="font-weight: 400">Provide the Broker email address to make the request for broker transactions</span>'
]);
