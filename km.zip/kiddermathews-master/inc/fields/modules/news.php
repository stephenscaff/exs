<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * News Module
 * @see views/modules/team-module
 */
$news_module = new FieldsBuilder('news_module');
$news_module
  ->addMessage('', 'The News Module will display 3 latest news posts, unless you select to show by a selected filter or manually select specific posts.')
  ->addFields($bg_color_light)
  ->addFields($section_name)
  ->addFields($heading_field)
  ->addTaxonomy('posts_cat', [
   'label'      => 'By Category',
   'taxonomy'   => 'category',
   'return_format' => 'object',
   'field_type'     => 'select',
   'allow_null'     => 1,
   'wrapper'    =>  ['width' => '33.333%'],
  ])
  ->addTaxonomy('posts_location', [
   'label'      => 'By Location ',
   'taxonomy'   => 'location',
   'return_format' => 'object',
   'field_type'     => 'select',
   'allow_null'     => 1,
   'wrapper'    =>  ['width' => '33.333%'],
  ])
  ->addTaxonomy('posts_specialty', [
   'label'      => 'By Specialty ',
   'taxonomy'   => 'specialty',
   'return_format' => 'object',
   'field_type'     => 'select',
   'allow_null'     => 1,
   'wrapper'    =>  ['width' => '33.333%'],
  ])
  ->addRelationship('posts_selector',  [
   'label'      => 'Or, Show Posts by Selection (overrides category and latest )',
   'post_type'  =>  array('post'),
   'filters' => array('search', '', ''),
   'max'        => 3,
   'wrapper'    =>  ['width' => '100%'],
  ]);
