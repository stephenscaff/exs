<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * News Module
 * @see views/modules/team-module
 */

 $research_module = new FieldsBuilder('research_module');
 $research_module

   ->addRepeater('research_cards', [
     'button_label' => 'Add new card',
     'layout' => 'block',
   ])
   ->addImage('image', [
     'label' => 'Product Type Image',
     'max_size'  => '300 KB',
     'return_format' => 'id'
   ])
   ->addText('title')
   ->addSelect('market_report')
     ->addChoice('office')
     ->addChoice('industrial' )
     ->addChoice('retail' )
     ->addChoice('multifamily' )
     ->addChoice('life-science' )
     ->addChoice('rd' )
     ->addChoice('medical' )
     ->addChoice('hotel' )

   ->addFile('summary', [
     'mime_types' => 'pdf',
     'wrapper'  =>  ['width' => '50%']
   ])
   ->addFile('inventory_map', [
     'mime_types' => 'pdf',
     'wrapper'  =>  ['width' => '50%']
   ])
   ->endRepeater();
