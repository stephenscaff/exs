<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Service Module
 * @see views/modules/services.php
 * @see scss/components/_services.scss
 */
$services_module = new FieldsBuilder('services_module');
$services_module

  ->addMessage('', 'The Services module will show the title to the left and description to the right')
  ->addFields($section_name)
  ->addText('title')
  ->addTextArea('text')
  ->addRepeater('links', [
    'button_label' => 'Add Link',
    'layout' => 'block',
  ])
    ->addPageLink('item_link', [
      'allow_null'  => 'true',
      'wrapper' =>  ['width' => '33.333%'],
      'label'  =>   'Button Page Link (internal)',
    ])
    # Button URL
    ->addText('item_url', [
      'wrapper' =>  ['width' => '33.333%'],
      'label'  =>   'Button URL (external)'
    ])
    # Button Text
    ->addText('item_title', [
      'wrapper' =>  ['width' => '33.333%'],
    ])
  ->endRepeater();
