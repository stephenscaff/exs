<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Testimonials Module
 * @see views/modules/testimonials-module.php
 * @see scss/components/_testimonials-items.scss
 */
$testimonials_module = new FieldsBuilder('testimonials_module');
$testimonials_module
  ->addMessage('', 'The Testimonials Module allows you to create a collection of testimonials. It displays 3 at a time with a Show More button.  ')
  ->addFields($section_name)
  ->addRepeater('quotes', [
    'button_label' => 'Add Testimonial',
    'layout' => 'block'
  ])
    ->addTextArea('quote', [
      'new_lines' => 'wpautop'
    ])
    ->addText('author', [
      'wrapper' =>  ['width' => '40%']
    ])
    ->addText('byline', [
      'wrapper' =>  ['width' => '60%']
    ])
  ->endRepeater();
