<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Success Stories Module
 */
$success_stories_module = new FieldsBuilder('success_story_module');
$success_stories_module
  ->addMessage('', 'The Success Stories Module allows you to select Success Stories to display.')
  ->addFields($section_name)
  ->addFields($heading_field)
  ->addTaxonomy('success_story_location', [
   'label'          => 'By Location ',
   'taxonomy'       => 'location',
   'return_format'  => 'object',
   'field_type'     => 'select',
   'allow_null'     => 1,
   'wrapper'        =>  ['width' => '50%'],
  ])
  ->addTaxonomy('success_story_specialty', [
   'label'          => 'By Specialty ',
   'taxonomy'       => 'specialty',
   'return_format'  => 'object',
   'field_type'     => 'select',
   'allow_null'     => 1,
   'wrapper'        =>  ['width' => '50%'],
  ])
  ->addRelationship('success_story_selector',  [
   'label'      => 'Select Success Stories <br/><span style="font-weight: 400">Select either 2 or 5 entries</span>',
   'post_type'  =>  'success_story',
   'filters'    => array('search', '', ''),
   'max'        => 5,
  ]);
