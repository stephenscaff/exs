<?php

if ( ! defined( 'ABSPATH' ) ) exit;

require_once('banner.php');
require_once('cards.php');
require_once('card-blocks.php');
require_once('completed-transactions.php');
require_once('content.php');
require_once('featured-properties.php');
require_once('gallery.php');
require_once('list.php');
require_once('logos.php');
require_once('news.php');
require_once('newsletter.php');
require_once('property-map.php');
require_once('reports-trends.php');
require_once('research.php');
require_once('services.php');
require_once('split-cta.php');
require_once('stats.php');
require_once('success-stories.php');
require_once('team-cta.php');
require_once('team-selector.php');
require_once('testimonials.php');
require_once('quote.php');
