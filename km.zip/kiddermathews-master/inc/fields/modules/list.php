<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * List Module
 * @see views/modules/list-module.php
 * @see scss/components/_list-items.scss
 */
$list_module = new FieldsBuilder('list_module');

$list_module
  ->addMessage('', 'The Lists Module enables you to add a list of items via a simple list builder, or columns of lists that expand/collapse on mobile ')

  ->addFields($section_name)
  ->addFields($heading_field)

  ->addFields($bg_color_light)

  ->addTrueFalse('is_columns', [
    'label'         => 'Use Columns',
    'message'       => 'Single -OR- Columns',
    'default_value' => 0,
    'ui'            => 1,
    'ui_on_text'    => 'Columns',
    'ui_off_text'   => 'Single'
  ])
    ->setInstructions("Use multiple list block columns that convert to accordions on mobile, instead of a single list block.")

  ->addTextArea('list', [
    'label' => 'List Items <br/><span>Add each item on a new line</span>',
    'rows'  => '10'
  ])
    ->conditional('is_columns', '==', 0)
  ->addSelect('max_columns', [
    'default_value' => 'grid-1-2-3'
  ])
    ->addChoice('grid-1-2', '2')
    ->addChoice('grid-1-2-3', '3')
    ->conditional('is_columns', '==', 0)

  ->addRepeater('columns', ['min' => 1, 'max' => 3, 'layout' => 'block'])
    ->conditional('is_columns', '==', 1)
    ->addText('title')
    ->addTextArea('list', [
      'label' => 'List Items <br/>
                  <span>Add each item on a new line</span>',
      'rows'  => '10'
  ])
  ->endRepeater();
