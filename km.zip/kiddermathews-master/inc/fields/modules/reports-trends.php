<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * News Module
 * @see views/modules/team-module
 */
 $reports_trends_module = new FieldsBuilder('reports_trends_module');
 $reports_trends_module
   ->addMessage('', 'The Market Reports Module allows you to select up to 6 market reports to display with a link to view all.')
   ->addFields($bg_color_light)
   ->addFields($section_name)
   ->addFields($heading_field)

   ->addRadio('reports_or_trends', [
     'label'    => "Select to Show Market Reports or Trend Article",
     'default_value' => '',
     'wrapper'  =>  ['width' => '20%']
   ])
    ->addChoice('trend_article', 'Trend Articles')
    ->addChoice('market_report', 'Market Reports')

   ->addRelationship('reports_selector',  [
    'label'      => 'Manually Select Market Reports to Display',
    'post_type'  =>  array('market_report'),
    'filters'    => array('search', '', ''),
    'max'        => 6,
    'wrapper'    =>  ['width' => '80%']
   ])
   ->conditional('reports_or_trends', '==', 'market_report')


   ->addRelationship('trends_selector',  [
    'label'      => 'Manually Select Trend Articles to Display',
    'post_type'  =>  array('trend_article'),
    'filters'    => array('search', '', ''),
    'max'        => 6,
    'wrapper'    =>  ['width' => '80%']
   ])
   ->conditional('reports_or_trends', '==', 'trend_article')
   ->addText('view_all_url');
