<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Two Column CTA Module (Split CTA)
 * @see views/modules/two-col-cta-module.php
 * @see scss/components/_split-ctas.scss
 */
$split_cta_module = new FieldsBuilder('split_cta_module');
$split_cta_module
  ->addMessage('', 'The Two Column CTA Module adds a two columna CTA element with up to two button')
  ->addFields($bg_color)
  ->addFields($section_name)
  ->addTrueFalse('is_inside_container', [
    'label'  => 'Is Inside Container <br/><span style="font-weight: 400">Checking this box will place the module within the container, instead of being full width',
    'wrapper' =>  ['width' => '50%']
  ])
  ->addText('pretitle')
  ->addText('title')
  ->addTextArea('text')
  ->addRepeater('buttons', [
    'button_label' => 'Add Button',
    'layout' => 'block',
    'max'   => 2,
  ])
    ->addFields($button_field)
  ->endRepeater();
