<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Stats Module
 * @see views/modules/stats-module.php
 * @see scss/components/_stats-items.scss
 */
$stats_module = new FieldsBuilder('stats_module');
$stats_module
  ->addMessage('', 'The Stats Module creates columns of stats / figures ')

  ->addFields($section_name)
  ->addFields($heading_field)

  ->addSelect('max_columns', [
    'default_value' => 'grid-2-3'
  ])
    ->addChoice('grid-2-3', '3')
    ->addChoice('grid-2-3-5', '5' )

  ->addRepeater('stats', [
    'button_label' => 'Add Stat',
    'layout' => 'block'
  ])
    ->addText('number', [
      'wrapper' =>  ['width' => '15%']
    ])
    ->addText('title', [
      'wrapper' =>  ['width' => '35%']
    ])
    ->addText('text', [
      'wrapper' =>  ['width' => '50%']
    ])
  ->endRepeater();
