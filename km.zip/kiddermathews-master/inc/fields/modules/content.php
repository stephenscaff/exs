<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Content Module
 * @see views/modules/content-module.php
 * @see scss/components/_content-block.scss
 */
$content_module = new FieldsBuilder('content_module');
$content_module
  ->addMessage('', 'The Content Module provides an all purpose content region and wysi editor. You can select 1 to 2 columns ')

  ->addFields($section_name)
  ->addFields($heading_field)
  ->addFields($bg_color_light)

  ->addSelect('number_cols', [
    'label' => 'Number of Columnns? <br><span style="font-weight: 400">By selecting more than 1 column, you will be given additional content editors for each column</span>',
    'wrapper' =>  ['width' => '50%']
  ])
    ->addChoice('1', '1')
    ->addChoice('2', '2')

  ->addNumber('read_more_length', [
    'label' => 'Read More Length <br><span style="font-weight: 400">You can truncate long content blocks by providing a character count here.</span>',
    'wrapper' =>  ['width' => '50%']
  ])

  ->addWysiwyg('content_block')

  ->addSelect('col_alignment', [
    'label' => 'Single Column Alignment<br><span style="font-weight: 400;>Align a single column left or center',
    'default_value' => 'is-center'
  ])
    ->addChoice('is-center', 'Center')
    ->addChoice('is-left', 'Left')
    ->conditional('number_cols', '==', '1')

  ->addWysiwyg('content_block_2')
    ->conditional('number_cols', '==', '2');
