<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * News Module
 * @see views/modules/team-module
 */

$card_blocks_module = new FieldsBuilder('card_blocks_module');
$card_blocks_module
  ->addMessage('', 'The Card Blocks Module adds a section displaying 1 100% block or 2 50% blocks.')
  ->addRepeater('card_blocks', [
    'min' => 1,
    'max' => 2,
    'layout' => 'block',
    'button_label' => 'Add Block',
  ])
    ->addImage('image', [
      'label' => 'Block Image <br/><span style="font-weight:400">Ensure all images are the same size. 2000x1200 is good size.</span>',
      'max_size'  => '300 KB',
      'return_format' => 'id'
    ])
    ->addText('pretitle', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('title', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addPageLink('button_link', [
      'allow_null'  => 'true',
      'wrapper' =>  ['width' => '50%'],
      'label'  =>   'CTA Page Link (internal)',
    ])
    # Button URL
    ->addText('button_url', [
      'wrapper' =>  ['width' => '50%'],
      'label'  =>   'CTA URL (external)'
    ])
->endRepeater();
