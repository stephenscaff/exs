<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;
/**
 * Gallery Module
 * @see partials/modules/gallery-module.php
 * @see scss/components/gals.scss
 */
$gallery_module = new FieldsBuilder('gallery_module');
$gallery_module
  ->addMessage('', 'The Gallery Module creates a gallery of images. You can select the size of each image. <br/>Image Combos inlcude 100%, 50/50, 33/33/33 ')
  ->addRepeater('images', [
    'min' => 1,
    'button_label' => 'Add Image',
    'layout' => 'block',
  ])
    ->addImage('image', [
      'wrapper'    =>  ['width' => '25%'],
    ])
    ->addSelect('image_width', [
      'wrapper'    =>  ['width' => '75%'],
    ])
      ->addChoice('is-100', '100%')
      ->addChoice('is-50', '50%')
      ->addChoice('is-33', '33%')
  ->endRepeater();
