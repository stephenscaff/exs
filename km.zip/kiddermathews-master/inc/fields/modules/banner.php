<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Banner Module
 * @see views/modules/banner-module.php
 * @see scss/components/_banner.scss
 */
$banner_module = new FieldsBuilder('banner_module');
$banner_module
  ->addMessage('', 'The Banner Module creates a section with a background image, text and an optional link/button. Good for large quotes or CTA element ')
  ->addFields($section_name)
  ->addImage('image', [
    'label' => 'Background Image <br/><span style="font-weight:400">Size to 2000x1200</span>',
    'max_size'  => '300 KB',
    'return_format' => 'id'
  ])
  ->addText('pretitle', [
    'label' => 'Pretitle <span style="font-weight:400">(optional)</span>'
  ])
  ->addText('title')
  ->addFields($button_field);
