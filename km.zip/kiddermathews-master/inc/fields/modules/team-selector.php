<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Team Selector Module
 * @see views/modules/team-selector-module
 */

$team_selector_module = new FieldsBuilder('team_selector_module');
$team_selector_module
->addRelationship('team_selector',  [
 'label'      => 'Select Team members to show',
 'post_type'  =>  array('professional'),
 'filters'    => array('search', '', ''),
 'max'        => -1,
 'wrapper'    =>  ['width' => '100%']
]);
