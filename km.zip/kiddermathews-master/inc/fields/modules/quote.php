<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Content Module
 * @see views/modules/content-module.php
 * @see scss/components/_content-block.scss
 */
$quote_module = new FieldsBuilder('quote_module');
$quote_module
  ->addMessage('', 'The Quote Module provides adds a centered quote with optional background image/color ')
  ->addTextArea('quote_quote')
  ->addText('quote_cite')
  ->addSelect('quote_bg_color',  [
    'placeholder'   => 'Select an Background Color',
    'default_value' =>  'bg-white',
  ])
    ->addChoice('bg-white', 'White')
    ->addChoice('bg-grey-light', 'Light Grey')
    ->addChoice('bg-grey-dark', 'Dark Grey')
  ->addImage('quote_bg_image');
