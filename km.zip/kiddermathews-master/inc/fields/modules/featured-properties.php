<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Featured Properties Module
 * @see views/modules/featured-property.php
 * @see scss/components/_card-property.scss
 */
$featured_properties_module = new FieldsBuilder('featured_properties_module');
$featured_properties_module
  ->addMessage('', 'The Featured Properties Module enables you to add a collection of Featured Properties cards, with the ability to customize the presented info.')
  ->addFields($section_name)
  ->addFields($heading_field)
  ->addRepeater('properties', [
    'button_label' => 'Add Card',
    'layout' => 'block',
  ])
    ->addImage('image', [
      'label' => 'Property Image <br/><span style="font-weight:400">Ensure all images are the same size. 800x480 is good size.</span>',
      'max_size'  => '300 KB',
      'return_format' => 'id'
    ])
    ->addText('title', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('url', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addRepeater('info', [
      'min' => 2,
      'max' => 4,
      'button_label' => 'Add Item',
      'layout' => 'table',
    ])
      ->addText('label')
      ->addText('value')
    ->endRepeater()
  ->endRepeater()
  ->addText('view_all_url');
