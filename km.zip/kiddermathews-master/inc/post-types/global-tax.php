<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Global Tax: Location
 * @see utils/post-type-labels
 */

add_action( 'init', function() {

  $tax = 'location';

  $labels = jumpoff_post_type_labels('Location', 'Locations');

  $type = array(
            'professional',
            'team',
            'success_story',
            'post',
            'news',
            'career',
            'trend_article',
            'office_location'
          );

  $args = [
      'description'         => 'Location',
      'labels'              => $labels,
      'hierarchical'        => true,
      'show_ui'             => true,
      'show_admin_column'   => true,
      'show_in_quick_edit'  => true,
      'rewrite'             => array('slug' => 'location', 'with_front' => false),
  ];

  register_taxonomy( $tax, $type, $args);
});


/**
 * Global Tax: Specialty
 * @see utils/post-type-labels
 */
add_action( 'init', function() {
  $tax = 'specialty';
  $labels = jumpoff_post_type_labels('Specialty', 'Specialties');
  $type = array(
            'professional',
            'team',
            'service',
            'success_story',
            'post',
            'market_report',
            'trend_article'
          );
  $args = [
      'description'         => 'Specialty',
      'labels'              => $labels,
      'hierarchical'        => true,
      'show_ui'             => true,
      'show_admin_column'   => true,
      'show_in_quick_edit'  => true,
      'rewrite'             => array('slug' => 'specialty', 'with_front' => false),
  ];
  register_taxonomy( $tax, $type, $args);
});
