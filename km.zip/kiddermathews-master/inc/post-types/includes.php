<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Flush Rewrites
 */
add_action( 'after_switch_theme', 'jumpoff_flush_rewrite_rules' );

function jumpoff_flush_rewrite_rules() {
  flush_rewrite_rules();
}

require_once('news.php');
require_once('professionals.php');
require_once('teams.php');
require_once('services.php');
require_once('market-reports.php');
require_once('trend-articles.php');
require_once('office-location.php');
// require_once('post-type-careers.php');
require_once('success-stories.php');
require_once('global-tax.php');
