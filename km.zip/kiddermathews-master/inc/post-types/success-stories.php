<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type:Success Stories
 *
 *  Slug :      success-stories
 *  Supports : 'title','thumbnail', 'editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'success_story';

 $labels = jumpoff_post_type_labels('Success Story', 'Success Stories');

 $args = [
   'public'             => true,
   'description'        => 'KidderMathews Press Releases.',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_dashicon'      => 'dashicons-flag',
   'menu_icon'          => 'dashicons-flag',
   'query_var'          => true,
   'supports'           => array( 'title','thumbnail'),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'rewrite'            => array(
     'slug' => 'success-stories',
     'with_front' => false
   ),
 ];
 register_post_type( $type, $args);
});


/**
 *  Taxonomy:  Service Filters
 *
 *  @author     Stephen Scaff
 *  @version    1.0
 */

add_action( 'init', function() {
  $tax = 'success_story_cat';
  $type = 'success_story';

  // Call the function and save it to $labels
  $labels = jumpoff_post_type_labels('Success Story Category', 'Success Story Categories');

  $args = [
      'description'        => 'Success Story Categories',
      'labels'             => $labels,
      'hierarchical'        => true,
      'show_ui'             => true,
      'show_admin_column'   => true,
      'show_in_quick_edit'  => true,
      'rewrite'            => array('slug' => 'service', 'with_front' => false),
  ];
  register_taxonomy( $tax, $type, $args);
});



/**
  *  Success Story Tax Souting
  *
  *  Allows our activities taxonomies to share
  *  '/success-stories' base url.
  *
  */
add_action('generate_rewrite_rules', function($wp_rewrite) {

  $rules = array();

  $success_stories = get_post_types(
    array(
      'name'     => 'success_story',
      'public'   => true,
      '_builtin' => false
    ), 'objects' );


  $success_story_cats = get_taxonomies(
    array(
      'name'      => 'success_story_cat',
      'public'    => true,
      '_builtin'  => false
    ), 'objects'
  );

  foreach ( $success_stories as $post_type ) {
    $post_type_name = $post_type->name;
    $post_type_slug = $post_type->rewrite['slug'];
    /**
     * Activity Type Tax
     */
    foreach ( $success_story_cats as $taxonomy ) {
      if ( $taxonomy->object_type[0] == $post_type_name ) {
        $terms = get_categories( array( 'type' => $post_type_name, 'taxonomy' => $taxonomy->name, 'hide_empty' => 0 ) );
        foreach ( $terms as $term ) {
          $rules[$post_type_slug . '/' . $term->slug . '/?$'] = 'index.php?' . $term->taxonomy . '=' . $term->slug;
        }
      }
    }
  }

  $wp_rewrite->rules = $rules + $wp_rewrite->rules;
});
