<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Location
 *
 *  Slug :    locations
 *  Fields : 'fields/location.php'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'office_location';

 // Call the function and save it to $labels
 $labels = jumpoff_post_type_labels('Office Location', 'Office Locations');

 $args = [
   'public'             => true,
   'description'        => 'KidderMathews Offices.',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 2,
   'menu_dashicon'      => 'dashicons-location',
   'menu_icon'          => 'dashicons-location',
   'query_var'          => true,
   'supports'           => array( 'title','thumbnail', 'editor'),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'show_in_rest'       => true,
   'rest_base'          => 'office_locations',
   'rest_controller_class' => 'WP_REST_Posts_Controller',
   'rewrite'            => array(
     'slug' => 'office-locations',
     'with_front' => false
   ),
 ];
 register_post_type( $type, $args);
});


/**
 * office_location_params
 * Adds support for Menu_order to locations api
 * @example ${appGlobals.locations_api}?orderby=menu_order&order=asc&per_page=100&_embed=1
 */
add_filter( 'rest_office_location_collection_params', 'office_location_params', 10, 1 );

function office_location_params( $params ) {
	$params['orderby']['enum'][] = 'menu_order';
	return $params;
}


/**
 * Add ACF Fields to Products Endpoint
 */
add_filter("rest_prepare_office_location", 'office_location_rest_prepare_post', 10, 3);

function office_location_rest_prepare_post($data, $post, $request) {
  $_data = $data->data;
  $fields = get_fields($post->ID);

  foreach ($fields as $key => $value){
    $_data[$key] = get_field($key, $post->ID);
  }
  $data->data = $_data;

  return $data;
}
