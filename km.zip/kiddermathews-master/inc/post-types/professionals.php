<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Team
 *
 *  Slug :      Team
 *  Supports : 'title','thumbnail','editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'professional';

 // Call the function and save it to $labels
 $labels = jumpoff_post_type_labels('Professional', 'Professionals');

 $args = [
   'public'             => true,
   'description'        => 'KidderMathews Professionals.',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 2,
   'menu_dashicon'      => 'dashicons-businessman',
   'menu_icon'          => 'dashicons-businessman',
   'query_var'          => true,
   'supports'           => array( 'title','thumbnail'),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'show_in_rest'       => true,
   'rest_base'          => 'professionals',
   'rest_controller_class' => 'WP_REST_Posts_Controller',
   'rewrite'            => array(
     'slug' => 'professionals',
     'with_front' => false
   ),
 ];
 register_post_type( $type, $args);
});



  /**
   * Add ACF Fields to Products Endpoint
   */

  add_filter("rest_prepare_professional", 'professionals_rest_prepare_post', 10, 3);

  function professionals_rest_prepare_post($data, $post, $request) {
      $_data = $data->data;

      $fields = get_fields($post->ID);

      foreach ($fields as $key => $value){
          $_data[$key] = get_field($key, $post->ID);
      }

      $data->data = $_data;
      return $data;
  }
