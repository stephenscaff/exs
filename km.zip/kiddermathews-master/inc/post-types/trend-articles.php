<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Trend Articles (part of Research)
 *
 *  Slug :      Releases
 *  Supports : 'title','thumbnail', 'editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'trend_article';

 $labels = jumpoff_post_type_labels('Trend Article', 'Trend Articles');

 $args = [
   'public'             => true,
   'description'        => 'KidderMathews Research Trend Articles.',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_dashicon'      => 'dashicons-chart-area',
   'menu_icon'          => 'dashicons-chart-area',
   'query_var'          => true,
   'supports'           => array( 'title','thumbnail', 'editor'),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'rewrite'            => array(
     'slug' => 'trend-articles',
     'with_front' => false
   ),
 ];
 register_post_type( $type, $args);
});
