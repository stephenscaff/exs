<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Servcies
 *
 *  Slug :      Servcies
 *  Supports : 'title','thumbnail'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'service';

 // Call the function and save it to $labels
 $labels = jumpoff_post_type_labels('Service', 'Services');

 $args = [
   'public'             => true,
   'description'        => 'KidderMathews Services.',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 2,
   'menu_dashicon'      => 'dashicons-portfolio',
   'menu_icon'          => 'dashicons-portfolio',
   'query_var'          => true,
   'supports'           => array( 'title','thumbnail', 'editor'),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'rewrite'            => array(
     'slug' => 'services',
     'with_front' => false
   ),
 ];
 register_post_type( $type, $args);
});



// add_action( 'init', function() {
//   $tax = 'service_type';
//   $type = array('service');
//
//   // Call the function and save it to $labels
//   $labels = jumpoff_post_type_labels('Sevice Type', 'Service Types');
//
//   $args = [
//       'description'        => 'Service Types',
//       'labels'             => $labels,
//       'hierarchical'        => true,
//       'show_ui'             => true,
//       'show_admin_column'   => true,
//       'show_in_quick_edit'  => true,
//       'rewrite'            => array('slug' => 'service_types', 'with_front' => false),
//   ];
//   register_taxonomy( $tax, $type, $args);
// });
