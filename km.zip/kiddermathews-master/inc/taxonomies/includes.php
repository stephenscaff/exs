<?php

if ( ! defined( 'ABSPATH' ) ) exit;

require_once('term-clause-types.php');
require_once('taxonomies.php');
