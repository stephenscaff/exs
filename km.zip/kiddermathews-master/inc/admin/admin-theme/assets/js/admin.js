
/**
 * Check Parent Term if child is checked.
 */
$(".children :input").change(function() {
	if (this.checked) {
    $(this).parents('li').children('label').children('input').prop("checked", true);
  }
});
