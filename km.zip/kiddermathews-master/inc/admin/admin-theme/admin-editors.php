<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 * Editor Toolbars
 * Class for customizing Wp Editor Toolbars, for
 * Visual (TinyMCE), Text (Qtags) and ACF toolbars
 */
class AdminEditors {

  /**
   * @var AdminEditors
   */
  public static $instance;

  /**
   * @return AdminEditors
   */
  public static function init() {
   if ( is_null( self::$instance ) )
     self::$instance = new AdminEditors();
   return self::$instance;
  }


  private function __construct(){
    add_action( 'admin_print_footer_scripts', array( $this, 'text_editor_toolbar' ), 999 );
    add_filter( 'tiny_mce_before_init', array( $this, 'visual_editor_toolbar' ));
    add_filter('acf/fields/wysiwyg/toolbars' , array( $this, 'acf_toolbar') );
    add_action('admin_head', array($this, 'hide_editor' ));
  }

  /**
   * Text Editor Toolbar
   * Used qtags editor
   */
  function text_editor_toolbar(){
    ?>
    <script type="text/javascript">
      QTags.addButton( 'h3-title', 'Title', '<h3>', '</h3>', '3', 'Title', 1 );
      QTags.addButton( 'h4-subtitle', 'Subtitle', '<h4>', '</h4>', '4', 'Subtitle', 1 );
      QTags.addButton( 'p-small', 'Small', '<p class="font-sm">', '</p>', '7', 'Small', 1 );
      QTags.addButton( 'hr-sep', 'Seperator', '<hr class="sep is-centered"/>', '', 's', 'Seperator', 202 );
    </script>
    <?php
  }

  /**
   * Visual Editor Toolbar
   * Used Tiny MCE
   */
  function visual_editor_toolbar($toolbar){
    $toolbar['block_formats'] = "Title=h3; Subtitle=h4; Paragraph=p; Small=small";
    $toolbar['toolbar1'] = 'formatselect,bold,italic,small,bullist,numlist,tiny_blockquote,hr,alignleft,link,unlink,spellchecker,pastetext,removeformat,plyr,wp_fullscreen';
    $toolbar['toolbar2'] = '';

    return $toolbar;
  }

  /**
   * ACF Toolbars
   * For the ACF editor field.
   */
  function acf_toolbar( $toolbar ){
    $toolbar['Full'] = array();
    $toolbar['Full'][1] = array('formatselect', 'bold', 'italic', 'underline', 'alignleft', 'aligncenter', 'tiny_blockquote', 'hr', 'bullist', 'numlist', 'removeformat', );
    $toolbar['Full'][2] = array();

    // remove the 'Basic' toolbar completely (if you want)
    unset( $toolbar['Basic' ] );

    return $toolbar;
  }

  /**
   * Hide Content Editors
   */
  function hide_editor() {
    if (
      is_template('templates/modules.php') OR
      is_template('templates/market-research.php') OR
      is_template('templates/property-search.php') OR
      is_template('templates/form.php') OR
      is_template('templates/professionals-search.php') OR
      is_template('templates/resources.php')

    ) {
      remove_post_type_support('page', 'editor');
    }
  }
}

AdminEditors::init();
