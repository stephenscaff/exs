<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


require_once('admin-theme/admin-setup.php');
require_once('admin-dash/dash-admin.php');
require_once('admin-theme/admin-ft-image-col.php');
require_once('admin-theme/admin-post-duplicator.php');
require_once('admin-theme/admin-editors.php');
require_once('post-ordering/post-ordering.php');
require_once('blockquotes/blockquotes.php');
