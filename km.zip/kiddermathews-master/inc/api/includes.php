<?php

if ( ! defined( 'ABSPATH' ) ) exit;

# Add Featured Images to API
require_once('api-ft-image.php');

# Add Featured Images to API
require_once('requests.php');
