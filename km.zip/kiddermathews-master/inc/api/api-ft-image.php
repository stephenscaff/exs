<?php
/**
 *  ApiMods Singleton Class
 *
 *  Collection of methods to add new nodes to the api api
 *
 *  @author     stephen scaff
 *  @version    1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $post;

class ApiMods {

  /**
   * @var ApiMods
   */
  public static $instance;

  /**
   * API Enpoints to target
   */
  public $target_endpoints = '';

  /**
   * @return ApiMods
   */
  public static function init() {
   if ( is_null( self::$instance ) ) self::$instance = new ApiMods();
   return self::$instance;
  }

   /**
    * Constructor
    * @uses rest_api_init
    */
   private function __construct() {
     $this->target_endpoints = array('professional', 'office_location');
     add_action( 'rest_api_init', array( $this, 'add_nodes' ));
   }

  /**
   * Add new nodes via register_rest_fields
   */
  function add_nodes() {

    /**
     * Featured Image
     */
   register_rest_field( $this->target_endpoints, 'featured_image',
      array(
        'get_callback'    => array( $this, 'get_image_url_full'),
        'update_callback' => null,
        'schema'          => null,
        )
      );

    /**
     * Featured Image Thumb
     */
    register_rest_field( $this->target_endpoints, 'featured_image_thumb',
      array(
       'get_callback'    => array( $this, 'get_image_url_thumb'),
       'update_callback' => null,
       'schema'          => null,
     )
   );

   /**
    * Location Tax
    */
   register_rest_field( $this->target_endpoints, 'location',
    array(
      'get_callback'    => array( $this, 'get_location'),
      'update_callback' => null,
      'schema'          => null,
      )
    );
   }

   /**
    * Get Location
    */
   function get_location() {
     global $post;
     $loc = get_the_terms($post->ID, 'location');
     $loc_name = $loc[0]->name;

     if (strpos($loc_name, ',') == false) return;

     $city_state = explode(',',trim($loc[0]->name));
     $city = $city_state[0];
     $state = $city_state[1];

     return array(
       'city' => $city,
       'state' => $state
     );
   }

  /**
   * Get Image Helper
   */
  function get_image($size) {
    $id = get_the_ID();

    if ( has_post_thumbnail( $id ) ){
      $img_arr = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), $size );
      return $img_arr[0];
    } else {
      return false;
    }
  }

  /**
   * Get Image: Thumb
   */
  function get_image_url_thumb(){
    return $this->get_image('thumbnail');
  }

  /**
   * Get Image: Full
   */
  function get_image_url_full(){
    return $this->get_image('full');
  }
}

ApiMods::init();








//
//
//
//  add_action( 'rest_api_init', function() {
//
//    register_rest_field( 'locations', 'location',
//       array(
//         'get_callback'    => 'get_location',
//         'update_callback' => null,
//         'schema'          => null,
//       )
//     );
// });
// //
// function get_location() {
//   global $post;
//   $loc = get_the_terms($post->ID, 'location');
//   $loc_name = $loc[0]->name;
//   $city_state = explode(' ',trim($loc[0]->name));
//   $city = $city_state[0];
//   $state = $city_state[1];
//
//   return array(
//     'city' => $city,
//     'state' => $state
//   );
// }
