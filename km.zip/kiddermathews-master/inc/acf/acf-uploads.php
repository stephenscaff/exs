<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Check and disable real mime
 * Gets around wp 5.1 upload issue. Should be a tmp thing
 * as v5.3 is suppose to correct.
 * @see https://codex.wordpress.org/Function_Reference/wp_check_filetype_and_ext
 */
add_filter( 'wp_check_filetype_and_ext', 'disable_real_mime_check', 10, 4 );

function disable_real_mime_check( $data, $file, $filename, $mimes ) {
	$wp_filetype = wp_check_filetype( $filename, $mimes );

	$ext = $wp_filetype['ext'];
	$type = $wp_filetype['type'];
	$proper_filename = $data['proper_filename'];

	return compact( 'ext', 'type', 'proper_filename' );
}

/**
 * Allow VCard (VCF) uploads
 * Adds the 'vcf' mime type to WP's approved upload
 * formats using wp's upload_mimes filter.
 */
add_filter('upload_mimes', 'allow_vcard_uploads');

function allow_vcard_uploads( $mime_types ){
  $mime_types['vcf'] = 'text/x-vcard';
  return $mime_types;
}

/**
 * vCard Directory
 * Save Professional vCard uploads to their own directory
 * Field: professional_vcard
 * Dir:  '/professionals/vcards'
 */
add_filter('acf/upload_prefilter/name=professional_vcard',

  function($errors, $file, $field) {
    add_filter('upload_dir', 'vcf_upload_dir');
  }, 10, 3
);

function vcf_upload_dir( $param ){
  $dir = '/professionals/vcards';
  $param['path'] = $param['basedir'] . $dir;
  $param['url'] = $param['baseurl'] . $dir;

  return $param;
}

/**
 * Professional BIO PDFs
 * Save Professional BIO PDF uploads to their own directory
 * Field: professional_bio_pdf
 * Dir:  '/professionals/vcards'
 */
add_filter('acf/upload_prefilter/name=professional_bio_pdf',

  function($errors, $file, $field) {
    add_filter('upload_dir', 'bio_upload_dir');
  }, 10, 3
);

function bio_upload_dir( $param ){
  $dir = '/professionals/bio_pdfs';
  $param['path'] = $param['basedir'] . $dir;
  $param['url'] = $param['baseurl'] . $dir;

  return $param;
}


/**
 * Capabilities Brochures
 * Save Service Capabilities Brochure uploads to their own directory
 * Field: service_capabilities_brocure
 * Dir:  /brochures/capabilities'
 */
add_filter('acf/upload_prefilter/name=service_capabilities_brocure',

  function($errors, $file, $field) {
    add_filter('upload_dir', 'capabilities_upload_dir');
  }, 10, 3
);

function capabilities_upload_dir( $param ){
  $dir = '/brochures/capabilities';
  $param['path'] = $param['basedir'] . $dir;
  $param['url'] = $param['baseurl'] . $dir;

  return $param;
}
