<?php
/**
 * Views/Shared/Mast-Promo
 *
 * Displays the homepage mast promo interaction to highlight services.
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$mast_title = get_field('mast_promo_title');
$mast_image = get_field('mast_promo_image');
$mast_vid = get_field('mast_promo_video');

?>

<section class="mast-promo js-mast-promo">
  <?php if ($mast_vid) : ?>
  <div class="mast-promo__vid bg-vid">
    <span class="bg-vid__cover"></span>
    <video class="bg-vid__vid" autoplay="" loop="" muted poster="">
      <source type="video/mp4" src="<?php echo $mast_vid['url']; ?>">
    </video>
  </div>
  <?php endif; ?>

  <figure class="mast-promo__figure" style="background-image: url(<?php echo $mast_image['url']; ?>)"></figure>

  <section class="mast-promo__bgs">
    <?php
    while( have_rows('mast_promo_layers') ): the_row();
      $image = get_sub_field('image'); ?>

    <figure class="mast-promo__bg js-mast-promo-bg" style="background-image: url(<?php echo $image['url']; ?>)"></figure>
    <?php endwhile; ?>
  </section>

  <header class="mast-promo__header grid-lg">
    <div class="mast-promo__brand"><?php echo jumpoff_get_svg('brand-logo'); ?></div>
    <h1 class="mast-promo__titles">
      <div class="mast-promo__page-fade">
        <div class="mast-promo__title is-first is-active"><?php echo $mast_title; ?></div>
      </div>
      <?php
      while( have_rows('mast_promo_layers') ): the_row();
        $title = get_sub_field('title');
      ?>
      <div class="mast-promo__title js-mast-promo-title"><?php echo $title; ?></div>
      <?php endwhile; ?>
    </h1>
  </header>

  <section class="mast-promo__links">
    <nav class="mast-promo__nav grid-lg">
      <span class="mast-promo__label">Our Services</span>
      <?php
      while( have_rows('mast_promo_layers') ): the_row();
        $link_text = get_sub_field('link_text');
        $link = get_sub_field('page_link');
        $url = get_sub_field('url');
        $link_or_url = jumpoff_field_fallback($link, $url);
      ?>
      <a class="mast-promo__link js-mast-promo-link" href="<?php echo $link_or_url; ?>"><?php echo $link_text; ?></a>
      <?php endwhile; ?>
      <a class="mast-promo__scroll-link js-scroll-down" href="#intro"><i class="icon-down-arrow"></i></a>
    </nav>
  </section>
</section>
