<?php
/**
 * Views/Shared/Header
 *
 * Main site/app header and nav section.
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>


<header class="app-header">
  <div class="grid-lg">
    <div class="app-header__grid">

      <div class="app-header__group is-left">
        <a class="app-header__brand is-logo-bug" href="<?php echo jumpoff_get_page_url('home'); ?>">
          <?php echo jumpoff_get_svg('brand-bug'); ?>
        </a>

        <nav class="app-header__nav is-secondary-nav">
          <span class="app-header__label">Search For</span>
          <a class="app-header__link is-profs" href="<?php echo jumpoff_get_page_url('professional', 1); ?>">Professionals</a>
          <!-- <span class="sep-vert"></span> -->
          <a class="app-header__link is-props" href="<?php echo jumpoff_get_page_url('property search'); ?>">Properties</a>
        </nav>
      </div>

      <div class="app-header__group is-right">
        <nav class="app-header__nav is-main-nav">
          <a class="app-header__link" href="<?php echo jumpoff_get_page_url('about'); ?>">About</a>
          <a class="app-header__link" href="<?php echo jumpoff_get_page_url('service', 1); ?>">Services</a>
          <a class="app-header__link" href="<?php echo jumpoff_get_page_url('research'); ?>">Research</a>
          <a class="app-header__link" href="<?php echo jumpoff_get_page_url('office_location', 1); ?>">Locations</a>
        </nav>

        <!-- <nav class="app-header__nav is-lang-nav">
          <a class="app-header__link" href="">ENG</a>
          <span class="sep-nav"></span>
        <a class="app-header__link" href="">简体中文</a>
        </nav> -->

        <!-- <a class="app-header__link is-login-link" href="">Log In</a> -->
        <?php echo render_nav_dropdown('login_menu', 'Login', 'app-header__nav is-login-link'); ?>
      </div>

    <button class="menu-toggle js-menu-toggle is-mobile-only" arial-label="Menu"><div class="menu-toggle__bars"></div></button>
  </div>
</div>
</header>
