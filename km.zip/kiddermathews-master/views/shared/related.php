<?php
/**
 * Views/Shares/Related
 *
 * The section for Related Posts.
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$post_type = get_post_type( get_the_ID() );
$template_part = 'post';
$ppp = 3;
$grid_class = 'grid-1-3';

if (is_post_type('trend_article') OR is_post_type('market_report')) {
  $template_part = 'text-post';
}

if (is_post_type('success_story')) {
  $template_part = 'success-story';
  $ppp = 4;
  $grid_class = 'grid-1-2-4';
}

?>

<section class="related pad has-border-top">
  <div class="grid-lg">
    <header class="heading is-text-center">
      <h3 class="heading__title">Keep Reading</h3>
    </header>
    <div class="related__grid <?php echo $grid_class; ?>">
    <?php
    // $cat = jumpoff_get_cat_slug();
    // 'category_name'    => $cat,
    $args = array(
      'post_type'        => $post_type,
      'posts_per_page'   => $ppp,
      'orderby'          => 'date',
      'order'            => 'DESC',
      'post__not_in'     => array($post->ID),
      'tax_query' => array()
    );

    $related = get_posts( $args );
    foreach ( $related as $post ) : setup_postdata( $post );
      get_template_part( "views/content/$template_part" );
    endforeach;
    wp_reset_postdata();
    ?>
    </div>
  </div>
</section>
