<?php
/**
 * Views/Shared/Search-Info
 *
 * Section to display info on search results
 *
 * @author    Stephen Scaff
 * @package   jumpoff/kidder
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $wp_query;

$left_text  = get_field('left_btn_title');
$left_url   = get_field('left_btn_link');
$right_text = get_field('right_btn_title');
$right_url  = get_field('right_btn_link');

?>
<?php if ($left_url OR $right_url) : ?>
<section class="bottom-nav has-border-top">
  <div class="grid-lg">
    <div class="bottom-nav__container">
      <div class="bottom-nav__left">
        <?php if ($left_url) : ?>
        <a class="bottom-nav__link" href="<?php echo $left_url; ?>">
          <i class="icon-arrow-left"></i>
          <span class="btn-line"><?php echo $left_text; ?></span>
        </a>
        <?php endif; ?>
      </div>
      <div class="bottom-nav__right">
        <?php if ($right_url) : ?>
        <a class="bottom-nav__link" href="<?php echo $right_url; ?>">
          <span class="btn-line"><?php echo $right_text; ?></span>
          <i class="icon-arrow-right"></i>
        </a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>
