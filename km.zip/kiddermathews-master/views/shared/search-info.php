<?php
/**
 * Views/Shared/Search-Info
 *
 * Section to display info on search results
 *
 * @author    Stephen Scaff
 * @package   jumpoff/kidder
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $wp_query;

$search_query = get_search_query();
$search_count = $wp_query->found_posts;
$search_terms = $wp_query->search_terms;

$title = 'Search results for';

$results_plural = 'results';
if ($search_count == 1) $results_plural = 'result';

if (is_market_reports()) {
  $search_query = get_market_reports_search_info();
}
elseif (is_professionals()) {
  $title = 'Professional results for ';
  $search_query = get_pro_search_info();
}
elseif (is_success_story()) {
  $title = 'Results for ';
  $search_query = get_success_story_info();
}

# Bail if pro_id query
if (isset($_GET['pro_id'])) return;

?>

<section class="search-info">
  <div class="grid-lg">
    <div class="search-info__grid">
      <header class="search-info__header">
        <h5 class="search-info__title">
          <span class="search-info__label"><?php echo $title; ?></span>
          <span class="search-info__term"><?php echo $search_query ?></span>
        </h5>
        <span class="search-info__count">
          <span class="search-info__numb"><?php echo $search_count; ?></span>
          <span class="search-info__text">Results</span>
        </span>
      </header>

      <?php if (is_professionals()) : ?>
      <nav class="search-info__controls controls-toggle">
        <a class="controls-toggle__link js-toggle-grid is-active"><i class="icon-grid"></i></a>
        <a class="controls-toggle__link js-toggle-list"><i class="icon-list"></i></a>
      </nav>
      <?php endif; ?>

    </div>
  </div>
</section>
