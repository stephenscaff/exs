<?php
/**
 * Views/Shared/Menu-Small
 *
 * App mobile menu
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) exit;

# Login Nav
$menu_locations = get_nav_menu_locations();
$menu_id = $menu_locations['login_menu'];
$menu_items = wp_get_nav_menu_items($menu_id);

?>

<section class="app-menu-sm">
  <nav class="app-menu-sm__nav">
    <a class="app-menu-sm__link" href="/"><span>Home</span></a>
    <hr class="app-menu-sm__sep"/>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('professional', 1); ?>"><span>Professionals</span></a>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('property search'); ?>"><span>Properties</span></a>
    <hr class="app-menu-sm__sep"/>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('about'); ?>"><span>About</span></a>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('service', 1); ?>"><span>Services</span></a>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('research'); ?>"><span>Research</span></a>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('news'); ?>"><span>News</span></a>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('office_location', 1); ?>"><span>Locations</span></a>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('careers'); ?>"><span>Careers</span></a>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('contact'); ?>"><span>Contact</span></a>
    <a class="app-menu-sm__link" href="<?php echo jumpoff_get_page_url('subscribe'); ?>"><span>Subscribe</span></a>
  </nav>

    <hr class="app-menu-sm__sep"/>
    <!-- <div class="app-menu-sm__langs">
    <a class="app-menu-sm__link" href=""><span>ENG</span></a>
      <span class="sep-nav"></span>
    <a class="app-menu-sm__link" href=""><span>简体中文</span></a>
    </div>
    <hr class="app-menu-sm__sep"/> -->
    <?php

    if ($menu_items) : ?>
    <div class="app-menu-sm__login">
      <div class="app-menu-sm__label">Login</div>
      <nav class="app-menu-sm__login-nav">
      <?php foreach($menu_items as $menu_item  => $item) : ?>
      <a class="app-menu-sm__login-link" href="<?php echo $item->url; ?>" role="menuitem"><span><?php echo $item->title; ?></span></a>
      <?php endforeach; ?>
      </nav>
    </div>
    <?php endif; ?>

</section>
