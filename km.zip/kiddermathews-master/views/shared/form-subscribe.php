<?php
/**
 * Views/Shared/Search-Info
 *
 * Section to display info on search results
 *
 * @author    Stephen Scaff
 * @package   jumpoff | kidder
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="contact-form">
  <form id="js-form" class="contact-form__form">
    <input type="hidden" name="userid" value="46760371"/>
    <input type="hidden" name="hostId" value="102" />
    <input type="hidden" name="refId" value="0" />
    <input type="hidden" name="databaseId" value="328"/>
    <input type="hidden" name="databaseId" value="328"/>
    <input type="hidden" name="howUnsubbed" value="0"/>
    <input type="hidden" name="unsubbed" value="0"/>
    <input type="hidden" name="authorizationKey" value="27:1szaor7e59"/>
	  <input type="hidden" name="prop7" id="prop7" value=""/>

    <div class="contact-form__grid">
      <div class="contact-form__item">
        <label class="contact-form__label">First Name</label>
        <input class="contact-form__input js-input" name="firstName" type="text" required>
        <div class="input-error-msg">Please provide you First Name</div>
      </div>

      <div class="contact-form__item">
        <label class="contact-form__label">Last Name</label>
        <input class="contact-form__input js-input" name="lastName" type="text" required>
        <div class="input-error-msg">Please provide a Last Name</div>
      </div>

      <div class="contact-form__item is-full">
        <label class="contact-form__label">Company</label>
        <input class="contact-form__input js-input" name="comp" type="text">
      </div>

      <div class="contact-form__item">
        <label class="contact-form__label">Email</label>
        <input class="contact-form__input js-input" name="email" type="text" required>
        <div class="input-error-msg">Please provide a proper email address</div>
      </div>

      <div class="contact-form__item">
        <label class="contact-form__label">Phone</label>
        <input class="contact-form__input js-input" name="phone" type="text">
      </div>

      <div class="contact-form__item">
        <label class="contact-form__label">Address</label>
        <input class="contact-form__input js-input" type="text" name="address">
      </div>


      <div class="contact-form__item">
        <label class="contact-form__label">City</label>
        <input class="contact-form__input js-input" type="text" name="city">
      </div>

      <div class="contact-form__item">
        <label class="contact-form__label">State</label>
        <input class="contact-form__input js-input" type="text" name="state">
      </div>

      <div class="contact-form__item">
        <label class="contact-form__label">Zip</label>
        <input class="contact-form__input js-input" type="text" name="zip">
      </div>
    </div>

    <fieldset class="checks-group">
      <div class="contact-form__header">
        <span class="contact-form__label">Select a Region</span>
      </div>
      <div class="grid-2">
        <label class="checkbox is-flex">
          <input class="checkbox__input" type="checkbox" name="prop7" value="Washington">
          <span class="checkbox__text">Washington</span>
        </label>
        <label class="checkbox is-flex">
          <input class="checkbox__input check-prop7" type="checkbox" name="prop7" value="Oregon">
          <span class="checkbox__text">Oregon</span>
        </label>
        <label class="checkbox is-flex">
          <input class="checkbox__input check-prop7" type="checkbox" name="prop7" value="Northern California">
          <span class="checkbox__text">Northern California</span>
        </label>
        <label class="checkbox is-flex">
          <input class="checkbox__input check-prop7" type="checkbox" name="prop7" value="Southern California">
          <span class="checkbox__text">Southern California</span>
        </label>
        <label class="checkbox is-flex">
          <input class="checkbox__input check-prop7" type="checkbox" name="prop7" value="Arizona">
          <span class="checkbox__text">Arizona</span>
        </label>
        <label class="checkbox is-flex">
          <input class="checkbox__input check-prop7" type="checkbox" name="prop7" value="Nevada">
          <span class="checkbox__text">Nevada</span>
        </label>
      </div>
    </fieldset>

    <div class="contact-form__submit">
      <div class="btn-with-loader">
        <button class="contract-form__btn btn" type="submit">Submit</button>

        <div class="form-loader js-form-loader is-hidden">
          <div class="form-loader__spinner">
            <svg><circle cx="20" cy="20" r="15" fill="none" stroke-width="2" stroke-miterlimit="10"/></svg>
          </div>
        </div>
      </div>
    </div>
  </form>

  <section class="form-messages">
    <div class="form-message is-success js-success-message is-hidden">
      Thank you for subscribing to our Market Research!
    </div>

    <div class="form-message is-error js-error-message is-hidden">
      We're sorry. We were unable to add you to our Market Research reports. Please Try again later.
    </div>
  </section>
</section>


<script>

/**
 * TM Form
 * Form sends submission to Tailor Mail api
 * @author Stephen Scaff
 */
var TMForm  = (() => {

  var apiURL = 'https://m2.tm00.com/TMPartnerService/Services/SubscriberService.svc/AddSubscriber';
  var formEl = document.querySelector('#js-form');
  var inputs = document.querySelectorAll('.js-input[required]');
  var loader = document.querySelector('.js-form-loader');
  var successMessage = document.querySelector('.js-success-message');
  var errorMessage = document.querySelector('.js-error-message');
  var errorClass = 'is-invalid';
  var isValid = false, isValidEmail = false;

  return {

    init: function() {
      if (!formEl) return;
      this.bindEvents();
    },

    /**
     * BindEVents
     * Kicks things off
     */
    bindEvents: function() {

      formEl.addEventListener('submit', function (e) {
        e.preventDefault();

        TMForm.validateForm();
      });
    },

    /**
     * ForEach Utility
     * Ensure we can loop over a object or nodelist
     * @see https://toddmotto.com/ditch-the-array-foreach-call-nodelist-hack/
     */
    forEach: function(array, callback, scope) {
      for (var i = 0; i < array.length; i++) {
        callback.call(scope, i, array[i]);
      }
    },

    /**
     * Validate Form
     */
    validateForm: function() {
      var emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
      var emailField = formEl["email"];
      var requiredInputs = document.querySelectorAll('[required]');

      inputs.forEach((input) => {

        if (input.value == "") {
          input.classList.add('is-invalid');
          isValid = false;
          window.scroll({top: 0, left: 0, behavior: 'smooth' });
          return;
        }
        else {
          input.classList.remove('is-invalid')
          isValid = true;
        }
      });

      // Validate Email
      if (!emailField.value.match(emailFormat)) {
        emailField.classList.add('is-invalid');
        isValidEmail = false;
      }
      else {
        emailField.classList.remove('is-invalid');
        isValidEmail = true;
      }

      if (isValid && isValidEmail) {
        TMForm.startSubmit();
      }
    },

    /**
     * Get Form Data
     * Process formData for post request as Tailor Mail API
     * is super finicky about formating.
     * @param object formData - formData object
     * @return object json
     */
    getFormData: function(formData) {
      var json = {};
      for (item of formData.keys()){
        json[item] = formData.get(item);
      }

      return json;
    },

    /**
     * Get Checks
     * Returns prop7 checks as comma seperated string
     * @return string
     */
  	getChecks: function(){
  		var array = []
      var checkboxes = document.querySelectorAll('input.check-prop7:checked')

      for (var i = 0; i < checkboxes.length; i++) {
        array.push(checkboxes[i].value)
		  }

      return array.join(',')
    },

    /**
     * Set Value
     * Helper to set value on a field
     * Calls HandleRequest()
     * @param element key
     * @param string val
     */
  	setValue: function(key, val) {
      key.value = val;
      TMForm.handleRequest()
    },

    /**
     * Start Submit Process
     * Assigns prop7 checks to hidden field
     * Begins submit animation
     */
    startSubmit: function() {
      var checks = TMForm.getChecks();
      var prop7 = document.querySelector('#prop7');

      TMForm.isSubmitting();
      TMForm.setValue(prop7, checks);
    },

    /**
     * Handle Request
     * Collected formData and posts to api via Fetch.
     */
    handleRequest: function() {

      var data = new FormData(formEl);
      var json = TMForm.getFormData(data);
      console.log(json);

      fetch(apiURL, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic Mjc6MXN6YW9yN2U1OQ==',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(json),
      })
      .then(function (response) {
        console.log('response', response.ok)

        if (response.ok == true) {
          return TMForm.onSuccess();
        }
        else {
          return TMForm.onError(error);
        }
      }).catch(function (error) {
        return TMForm.onError(error);
      });
    },

    /**
     * Show Loader UI
     */
    isSubmitting: function() {
      formEl.classList.add('is-submitting');
      loader.classList.remove('is-hidden');
    },

    /**
     * Handle Success State
     */
    onSuccess: function(response) {
      setTimeout(() => {
        successMessage.classList.remove('is-hidden');
        loader.classList.add('is-hidden');
        formEl.reset();
        console.log('success!');
      }, 900);
    },

    /**
     * Handle Error State
     */
    onError: function(error) {
      setTimeout(() => {
        errorMessage.classList.remove('is-hidden');
        loader.classList.add('is-hidden');
        console.log('error!!!')
      }, 900);
    },
  }
})();

TMForm.init();
</script>
