<?php
/**
 *  Views/Shared/Mast
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff
 *  @see       inc/utils/conditions.php for jumpoff_id()
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$located_id     = jumpoff_get_id();
$mast_pretitle  = get_field('mast_pretitle', $located_id);
if (is_post_type('office_location')) $mast_pretitle = 'Commercial Real Estate';
$mast_title     = get_field('mast_title', $located_id);
$mast_text      = get_field('mast_text', $located_id);
$mast_img       = get_field('mast_image', $located_id);
$ft_img         = jumpoff_ft_img('full');
$mod_class      = 'is-'.jumpoff_get_mod_class();

$term_obj = "";
$term_img = "";

if (is_tax()){
  $term_obj = get_queried_object();
  $term_img = get_field('term_image', $term_obj->taxonomy . '_' . $term_obj->term_id);
  $mast_img['url'] = $term_img['url'];
}

?>

<section class="mast <?php echo $mod_class; ?>">
  <?php if ($mast_img) : ?>
    <figure class="mast__figure" style="background-image:url(<?php echo $mast_img['url']; ?>)"></figure>
  <?php else : ?>
    <figure class="mast__figure" style="background-image:url(<?php echo $ft_img->url ?>)"></figure>
  <?php endif; ?>
    <header class="mast__header grid-lg">
      <h1 class="mast__h1">
      <?php if ($mast_pretitle) : ?>
        <span class="mast__pretitle"><?php echo $mast_pretitle; ?></span>
      <?php endif; ?>
      <?php if ($mast_title) : ?>
        <span class="mast__title"><?php echo $mast_title; ?></span>
      <?php elseif (is_tax()) : ?>
        <span class="mast__title"><?php single_cat_title('', true); ?></span>
      <?php else : ?>
        <span class="mast__title"><?php the_title(); ?></span>
      <?php endif;?>
      </h1>
  </header>
</section>
