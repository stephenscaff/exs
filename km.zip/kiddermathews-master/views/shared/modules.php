<?php
/**
 *  Views/Shared/Modules
 *
 *  Modules Loading partials.
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff
 *  @version   1.0
 *  @see       inc/acf-utils/acf-modules.php - Modules class
 *  @see       inc/fields - Defined fields and modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$ids = jumpoff_get_id();

while (has_sub_field('modules', $ids)) :
  ACF_Modules::render(get_row_layout());
endwhile;
