<?php
/**
 * Views/Shared/Footer
 *
 * Global footer element, inlcuding wp_footer().
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$phone_tollfree = get_field('company_phone_tollfree', 'options');
$tel_link = '<a class="app-footer__tel is-desktop-only" href="tel:'.format_tel_link($phone_tollfree).'">'.$phone_tollfree.'</a>';
$footer_message = get_field('footer_message', 'options');
$facebook = get_field('company_facebook', 'options');
$twitter = get_field('company_twitter', 'options');
$linkedin = get_field('company_linkedin', 'options');
?>

<footer class="app-footer">
  <div class="grid-lg">
    <div class="app-footer__grid">
      <div class="app-footer__group is-left">
        <div class="app-footer__byline">
          <a class="app-footer__brand" href="/">
            <?php echo jumpoff_get_svg('brand-bug'); ?>
          </a>
          <?php if ($footer_message) : ?><p class="app-footer__bio"><?php echo $footer_message; ?>
          </p><?php endif; ?>

        </div>
      </div>

      <div class="app-footer__group is-right">
        <?php echo render_menu('footer_menu_1', 'app-footer'); ?>
        <?php echo render_menu('footer_menu_2', 'app-footer'); ?>
        <?php echo render_menu('footer_menu_3', 'app-footer'); ?>

        <div class="app-footer__extras">
          <div>
            <nav class="app-footer__socials is-desktop-only">
              <?php if ($facebook) : ?><a class="app-footer__social" href="<?php echo $facebook; ?>"><i class="icon-facebook"></i></a><?php endif; ?>
              <?php if ($twitter) : ?><a class="app-footer__social" href="<?php echo $twitter; ?>"><i class="icon-twitter"></i></a><?php endif; ?>
              <?php if ($linkedin) : ?><a class="app-footer__social" href="<?php echo $linkedin; ?>"><i class="icon-linkedin"></i></a><?php endif; ?>
            </nav>
            <?php echo $tel_link; ?>
          </div>
        </div>
      </div>

      <div class="app-footer__group is-mobile-only">
        <?php if ($phone_tollfree) : ?><span class="btn-tel" data-nested-link="tel:<?php echo format_tel_link($phone_tollfree); ?>"><?php echo $phone_tollfree; ?></span><?php endif; ?>
        <nav class="app-footer__socials is-centered">
          <?php if ($facebook) : ?><a class="app-footer__social" href="<?php echo $facebook; ?>"><i class="icon-facebook"></i></a><?php endif; ?>
          <?php if ($twitter) : ?><a class="app-footer__social" href="<?php echo $twitter; ?>"><i class="icon-twitter"></i></a><?php endif; ?>
          <?php if ($linkedin) : ?><a class="app-footer__social" href="<?php echo $linkedin; ?>"><i class="icon-linkedin"></i></a><?php endif; ?>
        </nav>
      </div>
    </div>

    <aside class="app-footer__colophon">
      <p class="app-footer__copyright">&copy; <?php echo date("Y"); ?> Kidder Mathews.</p>
      <a class="app-footer__legal" href="<?php echo jumpoff_get_page_url('privacy policy'); ?>">Privacy Policy</a>
    </aside>
  </div>
</footer>

<script>if(!(window.fetch&&window.Promise&&[].includes&&Object.assign&&window.Map)){document.write('<script src="https://cdn.polyfill.io/v2/polyfill.min.js?features=default,fetch"></scr'+'ipt>')}</script>
<?php wp_footer(); ?>

</body>
</html>
