<?php
/**
 * Views/trend_article/Archive
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="filter-bar">
  <div class="grid-lg">
    <div class="filter-bar__grid">

      <div class="filter-bar__items is-right">
        <div class="filter-bar__dropdown dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger"><div>Location</div> <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php echo jumpoff_get_page_url('trend_article', 1); ?>">All Locations</a>
            <?php echo jumpoff_query_filters('location', 'trend_article', 'dropdown__link', 'trend_article'); ?>
          </nav>
        </div>

        <div class="filter-bar__dropdown dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger"><div>Product Type</div> <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php echo jumpoff_get_page_url('trend_article', 1); ?>">All Product Types</a>
            <?php echo jumpoff_query_filters('product_type', 'trend_article', 'dropdown__link', 'trend_article'); ?>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>
