<?php
/**
 * Views/Shared/Professionals/Search-Bar
 *
 * @author      Stephen Scaff
 * @package     jumpoff/kidder
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$search_query = get_search_query();
$res = $wp_query->query_vars;

if ($res['s']) $search_query = $res['s'];

?>

<div id="search-anchor"></div>

<section id="search-bar" class="search-bar has-search">
  <div class="grid-lg">
    <form class="search-bar__form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>#search-anchor">
      <div class="search-bar__grid">
        <div class="search-bar__search">
          <div class="search-box">
            <i class="search-box__icon icon-search"></i>
            <input type="hidden" name="post_type" value="trend_article">
  		      <input
              id="js-search-pros"
              class="search-box__input js-search-advanced"
              name="s"
              type="search"
              placeholder="Search for Trend Articles"
              value="<?php echo $search_query; ?>">
          </div>
        </div>
        <div class="search-bar__filter has-border-bottom">
          <?php echo jumpoff_query_select('location',  'trend_article', 'js-select-location'); ?>
        </div>
        <div class="search-bar__filter has-border-bottom">
          <?php echo jumpoff_specialty_select(
              $type  ='trend_article',
              $label ='Product Type',
              $id    ='js-select-specialty',
              $class ='select-nested'); ?>
        </div>
        <div class="search-bar__submit">
          <button class="search-bar__btn btn" type="submit">Search</button>
        </div>
      </div>
    </div>
  </div>
</section>
