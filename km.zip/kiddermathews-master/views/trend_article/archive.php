<?php
/**
 * Views/trend_article/Archive
 *
 * @author    Stephen Scaff
 * @package   jumpoff/kidder
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header(); ?>

<main class="has-header-offset">

<?php get_template_part( 'views/shared/mast' ); ?>

<?php include(locate_template('views/trend_article/_search-bar.php')); ?>

<section class="posts-cards has-fetch-more pad">
  <div class="grid-lg">
    <div id="js-posts" class="posts-cards__grid grid-1-2-3">
      <?php
      if ( have_posts() ): while ( have_posts() ) : the_post();
        get_template_part( 'views/content/post'  );
      endwhile; else:
        get_template_part( 'views/content/none' );
      endif;
      ?>
    </div>
  </div>
</section>

<?php get_template_part( 'views/shared/fetch-more' );?>

</main>

<?php get_footer(); ?>
