<?php
/**
 * Service - Single View
 * views/service/single
 *
 * @author    Stephen Scaff
 * @package   jumpoff / kidder
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>

<main class="has-header-offset">
  <?php get_template_part( 'views/shared/mast' ); ?>

  <section class="page-content is-service">
    <div class="grid-lg">
      <div class="page-content__grid has-lg-col-pad">

        <!-- Main -->
        <section class="page-content__main">
          <section class="page-content__content post-content">
          <?php
          while (have_posts()) : the_post();
            the_content();
          endwhile; ?>
          </section>
        </section>

        <!-- Sidebar -->
        <aside class="page-content__sidebar sidebar">
          <?php include(locate_template('views/service/_sidebar.php')); ?>
        </aside>
      </div>
    </div>

    <!-- Modules -->
    <section class="modules">
    <?php include(locate_template('views/shared/modules.php')); ?>
    </section>
  </section>
  <?php get_template_part( 'views/shared/bottom-nav' ); ?>
</main>

<?php get_footer(); ?>
