<?php
/**
 * Views/Service                                                                                                         n
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header(); ?>

<main class="has-header-offset">

<?php get_template_part( 'views/shared/mast' ); ?>

<section class="modules">
  <?php get_template_part( 'views/shared/modules' );?>
</section>

</main>

<?php get_footer(); ?>
