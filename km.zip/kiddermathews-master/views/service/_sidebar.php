<?php
/**
 * Service - Sidebar Content
 *
 * @author    Stephen Scaff
 * @package   jumpoff / kidder
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$service_pros = get_field('service_professional');
$service_brocure = get_field('service_capabilities_brocure');
$downloads = get_field('service_additional_downloads');
$stats = get_field('service_stats');

if ($service_brocure) : ?>
<div class="sidebar__download">
  <a class="link-download"
    href="<?php echo $service_brocure['url']; ?>"
    target="_blank"
    title="Download Capabilities Brochure">
    <i class="icon-download-file"></i>
    <span class="btn-line">Capabilities Brochure</span>
  </a>
</div>
<?php endif;
if ($downloads) :
foreach ($downloads as $download) :
  $file = $download['file'];
?>
<div class="sidebar__download">
  <a class="link-download"
    href="<?php echo $file['url']; ?>"
    target="_blank"
    title="Download <?php echo $file['title']; ?>">
    <i class="icon-download-file"></i>
    <span class="btn-line"><?php echo $file['title']; ?></span>
  </a>
</div>
<?php endforeach; endif;
if ($stats) : ?>

<section class="sidebar__stats">
<?php foreach ($stats as $stat) :
  $number = $stat['number'];
  $title = $stat['title'];
  $text = $stat['text']; ?>

  <div class="stat">
    <div class="stat__numb"><?php echo $number; ?></div>
    <?php if ($title) : ?><h5 class="stat__title"><?php echo $title; ?></h5><?php endif; ?>
    <?php if ($text) : ?><p class="stat__text"><?php echo $text; ?></p><?php endif; ?>
  </div>
<?php endforeach; ?>
</section>

<?php endif;

if ($service_pros) : ?>

<h5 class="sidebar__title"><?php echo pluralize($service_pros, 'Contact'); ?></h5>

<?php foreach ($service_pros as $service_pro) :
  $pro_name = get_the_title($service_pro->ID);
  $pro_url = get_the_permalink($service_pro->ID);
  $pro_address = get_field('professional_address', $service_pro->ID);
  $pro_email = get_field('professional_email', $service_pro->ID);
  $pro_position = get_field('professional_position', $service_pro->ID);
  $pro_phone = get_field('professional_phone', $service_pro->ID);
  ?>
  <div class="sidebar__contact">
    <a class="link-invert" href="<?php echo $pro_url; ?>">
      <h5 class="sidebar__name"><?php echo $pro_name; ?></h5>
      <span class="sidebar__position"><?php echo $pro_position; ?></span>
    </a>

    <a class="sidebar__tel link-invert" href="tel:<?php echo format_tel_link($pro_phone); ?>">
      <?php echo $pro_phone; ?>
    </a>

    <a class="sidebar__email link-underline" href="mailto:<?php echo $pro_email; ?>">
      <?php echo $pro_email; ?>
    </a>
  </div>
  <?php endforeach; ?>
<?php endif; ?>

<?php
# If Property Management
# Get links from dropdown menu
$locations = get_nav_menu_locations();
$menu_id = $locations['login_menu'];
$menu_items = wp_get_nav_menu_items($menu_id);

if (is_single(2389) ): ?>

<div class="sidebar__item">
  <a class="btn" href="<?php echo $menu_items[0]->url; ?>"><?php echo $menu_items[0]->title; ?></a>
</div>
<div class="sidebar__item">
  <a class="btn" href="<?php echo $menu_items[1]->url; ?>"><?php echo $menu_items[1]->title; ?></a>
</div>

<?php endif; ?>
