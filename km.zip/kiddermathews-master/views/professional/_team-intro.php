<?php
/**
 * Views/Shared/Professionals/Team-Intro
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$pro_summary = get_field('professional_summary');
$pros = get_field('professional_select');

?>

<section class="intro-pro is-team module">
  <div class="grid-lg">
    <div class="intro-pro__grid">
      <div class="intro-pro__info">
        <h5 class="intro-pro__heading">Contact</h5>

        <div class="intro-pro__team-grid">

          <?php
          // jumpoff_dump($pros);
          foreach ($pros as $pro) :
            $pro_title = get_the_title($pro);
            $pro_position = get_field('professional_position', $pro);
            $pro_url = get_the_permalink($pro);
            $pro_license_no = get_field('professional_license_no', $pro);
            $pro_tel = get_field('professional_phone', $pro);
            $pro_fax = get_field('professional_fax', $pro);
            $pro_email = get_field('professional_email', $pro);
            $pro_vcard = get_field('professional_vcard', $pro);
          ?>

          <div class="intro-pro__team-item">
            <h4 class="intro-pro__team-name"><?php echo $pro_title; ?></h4>
            <span class="intro-pro__team-position"><?php echo $pro_position; ?></span>
            <span class="intro-pro__value is-tel">T <a class="link-invert" href="tel:<?php echo format_tel_link($pro_tel); ?>"><?php echo $pro_tel; ?></a></span>
            <?php if ($pro_license_no) : ?>
            <span class="intro-pro__value is-licno"><span>LIC N°</span> <span class="no-tel"><?php echo $pro_license_no; ?></span></span>
            <?php endif; ?>
            <a class="intro-pro__value is-email " href="mailto:<?php echo $pro_email; ?>"><?php echo $pro_email; ?></a>
            <a class="intro-pro__value is-download no-trans" href="<?php echo $pro_vcard['url']; ?>" download>vCard</a>
            <a class="intro-pro__bio-link btn-line" href="<?php echo $pro_url; ?>">View Profile</a>
          </div>

        <?php endforeach; ?>

        </div>
      </div>

      <div class="intro-pro__main">
        <div class="read-more js-read-more" data-rm-words="150">
          <?php echo $pro_summary; ?>
        </div>
      </div>
    </div>
  </div>
</section>
