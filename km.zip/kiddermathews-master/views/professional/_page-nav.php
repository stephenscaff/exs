<?php
/**
 * Views/Shared/Professionals/PageNav
 *
 * Page Nav element for anchor scrolling.
 * Loops through modules to build nav, grabbing the section_name field
 *
 * @author      Stephen Scaff
 * @package     jumpoff/kidder
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$pro_mods = get_field('modules');

if (has_page_nav($pro_mods)):

?>

<section class="page-nav">
  <div class="grid-lg">
    <nav class="page-nav__nav js-page-nav">
    <?php
    foreach ($pro_mods as $pro_mod) :
      if (isset($pro_mod['section_name']) ) $name = $pro_mod['section_name'];
      if ($name) : $hash = jumpoff_make_hash($name);
      ?>
      <a class="page-nav__link" href="#<?php echo $hash; ?>"><?php echo $name; ?></a>
    <?php endif; endforeach; ?>
    </nav>
  </div>
</section>

<?php endif;
