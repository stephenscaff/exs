<?php
/**
 * Views/Shared/Professionals/Search-Intro
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$pretitle = get_field('pro_search_intro_pretitle', 'professional-index');
$title = get_field('pro_search_intro_title', 'professional-index');
$excerpt = get_field('pro_search_intro_excerpt', 'professional-index');

?>

<section class="split-cta is-professionals">
  <div class="split-cta__bg bg-white">
    <div class="grid-lg">
      <div class="split-cta__grid">
        <header class="split-cta__header">
          <h5 class="split-cta__pretitle"><?php echo $pretitle; ?></h5>
          <h2 class="split-cta__title"><?php echo $title; ?></h2>
        </header>

        <div class="split-cta__main">
          <p class="split-cta__text"><?php echo $excerpt; ?></p>
        </div>
      </div>
    </div>
  </div>
</section>
