<?php
/**
 *  Partial: Professional Mast
 *
 *  Displays the Professional Mast containing headshot image, name|title, location, position
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff
 *  @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$pro_name = get_the_title();
$pro_position = get_field('professional_position');
$pro_specialty = jumpoff_term('specialty');
$ft_img = jumpoff_ft_img('full');
$pro_designation = get_field('professional_designation');

$pro_location = jumpoff_term('location');
$pro_pretitle = get_field('professional_pretitle');
if (!$pro_pretitle) $pro_pretitle = $pro_location->name;

?>

<section class="mast-pro is-professional">
  <figure class="mast-pro__lines">
    <?php echo jumpoff_get_svg('lines-for-pro'); ?>
  </figure>
  <figure class="mast-pro__headshot">
    <img class="mast-pro__headshot-img" src="<?php echo $ft_img->url; ?>" alt="<?php echo $ft_img->alt; ?>"/>
  </figure>
  <header class="mast-pro__header grid-lg">
    <span class="mast-pro__city-state"><?php echo $pro_pretitle; ?></span>
    <h1 class="mast-pro__title">
    <?php
      echo $pro_name;
      if ($pro_designation) echo ", <span class='mast-pro__designation'>{$pro_designation}</span>";
    ?>
    </h1>
    <span class="mast-pro__subtitle">
    <?php echo $pro_position; ?>
    </span>
  </header>
</section>
