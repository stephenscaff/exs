<?php
/**
 * Views/Professionals/Education-and-Recognition
 *
 * @author      Stephen Scaff
 * @package     jumpoff/kidder
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$pro_education        = get_field('professional_education');
$pro_education_list   = jumpoff_format_lines($pro_education, 'list');
$pro_recognition      = get_field('professional_recognition');
$pro_recognition_list = jumpoff_format_lines($pro_recognition, 'list');


if ($pro_education OR $pro_recognition) :

?>

<section class="flex-cols has-border module">
  <div class="grid-lg">
    <div class="flex-cols__grid">

      <?php if ($pro_recognition) : ?>
      <div class="flex-cols__item">
        <header class="heading">
          <h3 class="heading__title">Professional Recognition</h3>
        </header>
        <ul class="flex-cols__list list-dot">
        <?php echo $pro_recognition_list; ?>
        </ul>
      </div>
      <?php endif; ?>

      <?php if ($pro_education) : ?>
      <div class="flex-cols__item">
        <header class="heading">
          <h3 class="heading__title">Education</h3>
        </header>
        <ul class="flex-cols__list list-dot">
        <?php echo $pro_education_list; ?>
        </ul>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php endif; ?>
