<?php
/**
 * Professionals Archive -
 * Serves as professionals search / filtering by checking for get_query_var
 * to determine if a filter has been triggered. Actual Search queries are routed to
 * the search-professionals.php template using a custom controler.
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$location = get_query_var('location');
$specialty = get_query_var('specialty');

?>

<main class="has-header-offset">

<?php

get_template_part( 'views/professional/_search-mast' );

if ($location OR $specialty) {
  include(locate_template('views/shared/search-info.php'));
  include(locate_template('views/professional/_query-results.php'));
  include(locate_template('views/shared/fetch-more.php'));
}
else {
  include(locate_template('views/professional/_search-intro.php'));
}

?>

</main>

<?php get_footer(); ?>
