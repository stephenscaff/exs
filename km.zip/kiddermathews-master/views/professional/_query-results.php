<?php
/**
 * Views/Shared/Professionals/Query
 *
 * Basic Query Var Results
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="pro-cards has-fetch-more is-results js-results-container">
  <div class="grid-lg">
    <div id="js-posts" class="pro-cards__grid">
    <?php
    if (have_posts()) :
      while ( have_posts() ) : the_post();
        get_template_part( 'views/content/professional' );
      endwhile;
    else :
      get_template_part( 'views/content/none' );
    endif;
     ?>
    </div>
  </div>
</section>
