<?php
/**
 * Views/Shared/Professionals/Search-Mast
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;


$pro_id = 'professional-index';
$mast_pretitle = get_field('pro_search_mast_pretitle', $pro_id) ;
$mast_title = get_field('pro_search_mast_title', $pro_id) ;
$mast_img = get_field('pro_search_mast_img', $pro_id);
$ft_img = jumpoff_ft_img('full', $pro_id);
$mod_class = 'is-'.jumpoff_get_mod_class();
$pro_url = get_post_type_archive_link('professional');
?>

<section class="mast <?php echo $mod_class; ?>">
  <?php if ($mast_img) : ?>
    <figure class="mast__figure" style="background-image:url(<?php echo $mast_img['url']; ?>)"></figure>
  <?php else : ?>
    <figure class="mast__figure" style="background-image:url(<?php echo $ft_img->url ?>)"></figure>
  <?php endif; ?>
    <header class="mast__header grid-lg">
    <?php if ($mast_pretitle) : ?>
      <span class="mast__pretitle"><?php echo $mast_pretitle; ?></span>
    <?php endif; ?>
    <?php if ($mast_title) : ?>
      <h1 class="mast__title"><?php echo $mast_title; ?></h1>
    <?php else : ?>
      <h1 class="mast__title">Locate market specialists personally invested in every relationship</h1>
    <?php endif;?>
  </header>
</section>

<?php include(locate_template('views/professional/_search-bar.php'));
