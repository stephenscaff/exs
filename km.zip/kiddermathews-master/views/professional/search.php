<?php
/**
 * Views/Shared/Professionals/Search
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

global $wp_query;

$search_query = get_search_query();
$search_count = $wp_query->found_posts;
$search_terms = $wp_query->search_terms;

?>

<main class="has-header-offset">

<?php

include(locate_template('views/professional/_search-mast.php'));
include(locate_template('views/shared/search-info.php'));
include(locate_template('views/professional/_query-results.php'));
include(locate_template('views/shared/fetch-more.php' ));

?>

</main>

<?php get_footer(); ?>
