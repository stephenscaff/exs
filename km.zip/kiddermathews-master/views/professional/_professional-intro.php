<?php
/**
 *  Views/Professional/_Intro
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff/kidder
 *  @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$pro_license_no = get_field('professional_license_no');
$pro_tel        = get_field('professional_phone');
$pro_mobile     = get_field('professional_mobile');
$pro_fax        = get_field('professional_fax');
$pro_email      = get_field('professional_email');
$pro_address    = get_field('professional_address');
$pro_vcard      = get_field('professional_vcard');
$pro_bio_pdf    = get_field('professional_bio_pdf');
$pro_twitter    = get_field('professional_twitter');
$pro_linkedin   = get_field('professional_linkedin');
$pro_summary    = get_field('professional_summary');

?>

<section class="intro-pro module">
  <div class="grid-lg">
    <div class="intro-pro__grid">
      <div class="intro-pro__info">
        <div class="intro-pro__info-grid">
          <div class="intro-pro__info-col">
            <h5 class="intro-pro__heading">Contact</h5>

            <?php if ($pro_tel): ?>
              <span class="intro-pro__value is-tel">T <a class="link-invert" href="tel:<?php echo format_tel_link($pro_tel); ?>"><?php echo $pro_tel; ?></a></span>
            <?php endif; ?>

            <?php if ($pro_mobile) : ?>
            <span class="intro-pro__value is-tel">M <a class="link-invert" href="tel:<?php echo format_tel_link($pro_mobile); ?>"><?php echo $pro_mobile; ?></a></span>
            <?php endif; ?>

            <?php if ($pro_fax) : ?>
            <span class="intro-pro__value is-tel">F <?php echo $pro_fax; ?></span>
            <?php endif; ?>

            <?php if ($pro_email) : ?>
            <a class="intro-pro__value is-email" href="mailto:<?php echo $pro_email; ?>"><?php echo $pro_email; ?></a>
            <?php endif; ?>

            <?php if ($pro_address) : ?>
            <address class="intro-pro__address">
              <?php echo $pro_address; ?>
            </address>
            <?php endif; ?>
          </div>

          <div class="intro-pro__info-col">
            <?php if ($pro_license_no) : ?>
            <h5 class="intro-pro__heading">LIC N°</h5>
            <span class="intro-pro__value no-tel"><?php echo $pro_license_no; ?></span>
            <?php endif; ?>

            <?php if ($pro_vcard || $pro_bio_pdf) : ?>
            <h5 class="intro-pro__heading">Downloads</h5>
            <a class="intro-pro__value is-download no-trans" href="<?php echo $pro_vcard['url']; ?>" download>vCard</a>
            <a class="intro-pro__value is-download" href="<?php echo $pro_bio_pdf['url']; ?>">Bio</a>
            <?php endif; ?>

            <?php if ($pro_linkedin || $pro_twitter) : ?>
            <nav class="intro-pro__socials">
              <?php if ($pro_twitter)  : ?><a href="<?php echo $pro_twitter; ?>"><i class="icon-twitter"></i></a><?php endif; ?>
              <?php if ($pro_linkedin) : ?><a href="<?php echo $pro_linkedin; ?>"><i class="icon-linkedin"></i></a><?php endif; ?>
            </nav>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="intro-pro__main">
        <h5 class="intro-pro__heading is-sm-only">About</h5>
        <div class="read-more js-read-more" data-rm-words="100">
          <?php echo $pro_summary; ?>
        </div>
      </div>
    </div>
  </div>
</section>
