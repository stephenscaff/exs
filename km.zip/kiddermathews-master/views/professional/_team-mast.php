<?php
/**
 * Views/Shared/Professionals/Team-Mast
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$mast_pretitle = get_field('team_mast_pretitle');
$mast_title = get_field('team_mast_title');
if (!$mast_title) $mast_title = get_the_title();
$mast_subtitle = get_field('team_mast_subtitle');
$bg_color = get_field('bg_color');
$mast_img = get_field('team_mast_image');
$ft_img = jumpoff_ft_img('full', get_the_ID());
?>

<section class="mast-pro is-team <?php if ($bg_color) { echo $bg_color; }; ?>">

  <?php if ($mast_img) : ?>
    <?php if (!has_ft_img(get_the_ID())) : ?>
  <figure class="mast-pro__figure" style="background-image: url(<?php echo $mast_img['url'] ?>)"></figure>
    <?php endif; ?>
  <?php endif; ?>

  <?php if (!$mast_img) : ?>
  <figure class="mast-pro__lines">
    <?php echo jumpoff_get_svg('lines-for-pro'); ?>
  </figure>
  <?php endif; ?>

  <?php if ($ft_img->url) : ?>
  <figure class="mast-pro__headshot">
    <img class="mast-pro__headshot-img" src="<?php echo $ft_img->url; ?>" alt="<?php echo $ft_img->alt; ?>"/>
  </figure>
  <?php endif; ?>
  <header class="mast-pro__header grid-lg">
    <?php if ($mast_pretitle) : ?><span class="mast-pro__pretitle"><?php echo $mast_pretitle; ?></span><?php endif; ?>
    <h1 class="mast-pro__title"><?php echo $mast_title; ?></span></h1>
    <span class="mast-pro__subtitle"><?php echo $mast_subtitle; ?></span>
  </header>
</section>
