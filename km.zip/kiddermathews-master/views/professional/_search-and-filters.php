<?php
/**
 * Views/Shared/Professionals/Search-Mast
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;


$pro_id = 'professional-index';
$mast_pretitle = get_field('pro_search_mast_pretitle', $pro_id) ;
$mast_title = get_field('pro_search_mast_title', $pro_id) ;
$mast_img = get_field('pro_search_mast_img', $pro_id);
$ft_img = jumpoff_ft_img('full', $pro_id);
$mod_class = 'is-'.jumpoff_get_mod_class();
$pro_url = get_post_type_archive_link('professional');
?>

<section class="mast <?php echo $mod_class; ?>">
  <?php if ($mast_img) : ?>
    <figure class="mast__figure" style="background-image:url(<?php echo $mast_img['url']; ?>)"></figure>
  <?php else : ?>
    <figure class="mast__figure" style="background-image:url(<?php echo $ft_img->url ?>)"></figure>
  <?php endif; ?>
    <header class="mast__header grid-lg">
    <?php if ($mast_pretitle) : ?>
      <span class="mast__pretitle"><?php echo $mast_pretitle; ?></span>
    <?php endif; ?>
    <?php if ($mast_title) : ?>
      <h1 class="mast__title js-words"><?php echo $mast_title; ?></h1>
    <?php else : ?>
      <h1 class="mast__title js-words">Locate market specialists personally invested in every relationship</h1>
    <?php endif;?>
  </header>
</section>


<section class="filter-bar has-search">
  <div class="grid-lg">
    <div class="filter-bar__grid">
      <div class="filter-bar__search">
        <form class="search-box" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <i class="search-box__icon icon-search"></i>
        <input type="hidden" name="post_type" value="professional">

		    <input id="js-search-pros" name="s" type="search" class="search-box__input  js-search-pros" placeholder="Search for professional by name, specialty, or location">
      </form>
      </div>

      <div class="filter-bar__items is-right">
        <div class="filter-bar__dropdown dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger"><div>Location</div> <span></span></button>
          <nav class="dropdown__nav">
            <?php if (get_query_var('location')) : ?>
              <?php echo get_query_var('location'); ?>
            <?php else : ?>
            <a class="dropdown__link is-heading" href="#">All Locations</a>
            <?php endif; ?>
            <?php echo jumpoff_query_filters('location', 'professional', 'dropdown__link'); ?>
          </nav>
        </div>

        <div class="filter-bar__dropdown dropdown js-dropdown has-subtitles">
          <button class="dropdown__label js-dropdown-trigger"><div>Specialty</div> <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php // echo jumpoff_get_page_url('activity', 1); ?>">All Specialties</a>
            <span class="dropdown__subtitle">Brokerage</span>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=china-services">China Services</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=corporate-services">Corporate Services</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=debt-equity-finance">Debt & Equity Finance</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=healthcare">Healthcare</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=industrial">Industrial</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=investment">Investment</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=life-science">Life Science/Technology</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=No description	multifamily-investments">Multifamily Investments</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=office">Office</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=religious-educational-facilities">Religious & Educational facilities</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=retail">Retail</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=office-tenant-advisory">Tenant Advisory</a>
            <span class="dropdown__sep"></span>
            <span class="dropdown__subtitle">Property Management</span>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=asset-management-services">Asset Management Services</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=development-management">Development Management</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=distressed-assets">Distressed Assets</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=project-and-construction-management">Project & Construction Management</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=property-management">Property Management</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=sustainability-practices">Sustainability Practices</a>
            <span class="dropdown__sep"></span>
            <span class="dropdown__subtitle">Valuation Advisory</span>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=consulting">Consulting</a>
            <a class="dropdown__link" href="<?php echo $pro_url; ?>/?specialty=valuation-advisory">Valuation Advisory</a>
          </nav>
        </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>
