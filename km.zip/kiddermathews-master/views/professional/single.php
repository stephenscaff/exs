<?php
/**
 * Views/Shared/Professionals/Single
 *
 * @author      Stephen Scaff
 * @package     jumpoff
 * @subpackage  Professionals
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while (have_posts()) : the_post();

$post_type = get_post_type(get_the_ID());
$team_or_professional = $post_type;
$mast_title = get_the_title();

?>

<main class="has-header-offset">

<article>

<?php

get_template_part("views/professional/_{$team_or_professional}-mast");

get_template_part('views/professional/_page-nav');

echo '<section class="modules">';

get_template_part("views/professional/_{$team_or_professional}-intro");

get_template_part('views/professional/_edu-recognition');

get_template_part('views/shared/modules');

echo '</section>';

?>

</article>

</main>

<?php endwhile; ?>

<?php get_footer(); ?>
