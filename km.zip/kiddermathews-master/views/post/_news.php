<?php
/**
 * News
 *
 * Outputs default posts loop. #js-posts is the handler for fetch-more
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="posts-cards pad has-fetch-more">

  <div class="grid-lg">

    <header class="heading">
      <h3 class="heading__title">Recent News</h3>
    </header>

    <div id="js-posts" class="posts-cards__grid grid-1-2-3">
      <?php
      /**
       * Filter our query for fetch more
       * @see inc/post-helpers/query-filters
       */
      add_filter('post_limits', 'jumpoff_limit_posts');
      $ppp = get_option('posts_per_page');
      $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

      $post_args = array(
        'post_type'        => 'post',
        'posts_per_page'   => $ppp,
        'paged'            => $paged,
        'post__not_in'     => array($featured_or_latest[0]->ID)
      );

      $posts = new WP_Query($post_args);

      if ($posts) :
        while ( $posts->have_posts() ) : $posts->the_post();
          setup_postdata( $post );
          include(locate_template('views/content/post.php' ));
          wp_reset_postdata();
        endwhile;
      endif;

      remove_filter('post_limits', 'jumpoff_limit_posts');
      ?>
    </div>
  </div>
</section>
