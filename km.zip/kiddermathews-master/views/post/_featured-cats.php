<?php
/**
 * Views/Posts/Featured Cats
 *
 * Displays 2 Post Collections by selected category.
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$featured_cat_1 = get_field('featured_cat_1', 'posts-index');
$featured_cat_2 = get_field('featured_cat_2', 'posts-index');

if ($featured_cat_1) {
  /**
   * Featured Cat 1
   */
  $args_1 = array(
    'post_type'           => 'post',
    'tax'                 => 'category',
    'terms'               => jumpoff_get_cat_slug($featured_cat_1),
    'num_posts'           => 3,
    'template'            => 'post',
    'show_archive_link'   => true,
    'excluded'            => array($featured_or_latest[0]->ID),
  );

  get_posts_by_term($args_1);
}

if ($featured_cat_2) {
  /**
   * Featured Cat 2
   */
  $args_2 = array(
    'post_type'           => 'post',
    'tax'                 => 'category',
    'terms'               => jumpoff_get_cat_slug($featured_cat_2),
    'num_posts'           => 3,
    'template'            => 'post',
    'show_archive_link'   => true,
    'excluded'            => array($featured_or_latest[0]->ID),
  );

  get_posts_by_term($args_2);
}
