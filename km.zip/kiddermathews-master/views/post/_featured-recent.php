<?php
/**
 * Views/Posts/Featured-Recent
 *
 * Recent or Featured Article for the posts/news index
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
$featured_or_latest = "";
$featured = get_field('featured_post_select', 'posts-index');

if ($featured) :
  $featured_or_latest = $featured;
else :
  # Get Posts: Latest
  $latest_args = array(
    'post_type'        => 'post',
    'posts_per_page'   => 1,
  );
  $latest = get_posts( $latest_args );
  $featured_or_latest = $latest;
endif;

# Featured or latest logic
if ($featured_or_latest) :
  foreach( $featured_or_latest as $post) :
    setup_postdata( $post );
      include(locate_template('views/content/featured.php' ));
    wp_reset_postdata();
  endforeach;
endif;
