<?php
/**
 * Split CTA Module
 *
 * The module for adding the Split CTA element.
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$press_name = get_field('press_name', 'options');
$press_title = get_field('press_title', 'options');
$press_number = get_field('press_number', 'options');
$press_email = get_field('press_email', 'options');
$press_excerpt = get_field('press_excerpt', 'options');

$bg_color = get_field('bg_color', 'options');
$is_inside_container = get_field('is_inside_container', 'options');


/**
 * Logic for Inset Modifier
 * Determines if module is inside grid-lg container
 * or full width.
 */
$is_inset = "";

if ($is_inside_container) {
  $is_inset = 'is-inset';
}

/**
 * Logic for SVG Lines selection.
 * If white bg, no lines.
 * If light bg, dark svg,
 * If dark bg, light svg
 */
$lines_for = '';
$has_drawing = '';

if ($bg_color !== 'bg-white') {
  $has_drawing = 'has-drawing';
}

if ( $bg_color == 'bg-grey' || 'bg-grey-mid' || 'bg-grey-dark' ) {
  $lines_for = 'lines-for-dark';
} elseif ( $bg_color == 'bg-alpha' || 'bg-grey-light' ) {
  $lines_for = 'lines-for-alpha';
}

$module_classes = jumpoff_add_classes([$is_inset, $has_drawing, 'module']);

?>

<section class="split-cta is-inset pad-b has-drawing">
  <div class="split-cta__bg bg-grey-dark">

    <div class="split-cta__lines">
      <?php echo jumpoff_get_svg($lines_for); ?>
    </div>

    <div class="grid-lg">
      <div class="split-cta__grid">
        <header class="split-cta__header">
          <h5 class="split-cta__pretitle"></h5>
          <h2 class="split-cta__title">Press inquiries</h2>
          <p class="press__excerpt"><?php echo $press_excerpt; ?></p>
        </header>

        <div class="split-cta__main">
        <h4 class="press__name"><?php echo $press_name; ?></h4>
        <span class="press__title"><?php echo $press_title; ?></span>
        <a href="tel:<?php echo $press_number; ?>" class="press__number"><?php echo $press_number; ?></a>
        <a href="mailto:<?php echo $press_email; ?>" class="press__email"><?php echo $press_email; ?></a>
        </div>
      </div>
    </div>
  </div>
</section>
