<?php
/**
 * Views/Posts/_footer
 *
 * Displays Post Shares and whatever else belongs at the end of a post
 * or post-like post type.
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name = 'Post';

if (is_post_type('market_report')) {
  $name = 'Report';
} elseif (is_post_type('success_story')) {
  $name = 'Story';
}

?>

<section class="post-shares">
  <div class="post-shares__wrap grid-sm">
    <header class="post-shares__header">
      <h4 class="post-shares__title">Share This <?php echo $name; ?></h4>
    </header>
    <nav class="post-shares__nav">
      <a class="post-shares__link" href="https://twitter.com/share?url=<?php echo get_permalink() ?>&text=<?php echo substr(rawurlencode(get_the_title()), 0, 75) ?>&via=" target="_blank">Twitter</a>
      -
      <a class="post-shares__link" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_permalink() ?>" target="_blank">Facebook</a>
      -
      <a class="post-shares__link" href="https://www.linkedin.com/shareArticle?url=<?php echo get_permalink() ?>&title=<?php the_title(); ?>&summary=<?php echo jumpoff_excerpt(250); ?>&source=<?php get_home_url(); ?>" target="_blank">LinkedIn</a>
    </nav>
  </div>
</section>
