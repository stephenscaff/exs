<?php
/**
 *  Views/Posts/_Post-Mast
 *
 *  Post Mast for Single Posts and post-like post types
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff
 *  @version    1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

# Post Mast
$post_title       = get_the_title();
$post_subtitle    = get_field('post_subtitle');
$post_img         = jumpoff_ft_img('full');
$post_img_url     = $post_img->url;
$post_random_img  = jumpoff_random_img();
$post_date        = get_the_time('F j, Y');
$article_source   = get_field('article_source');
$article_author   = get_field('article_author');

# Featured Image or Fallback logic
$has_img = false;

if ($post_img->url) {
  $has_img = true;
}

if (is_post_type('post') && !$post_img->url) {
  $has_img      = true;
  $post_img_url = jumpoff_random_img();
}

$breadcrumbs = get_post_breadcrumbs();

?>

<section class="post-mast <?php if ($has_img) { echo 'has-img'; } else { echo 'no-img'; }; ?>">
  <header class="post-mast__header grid-sm ">

  <?php if (is_post_type('success_story') && jumpoff_term('location')) : ?>
    <span class="post-mast__meta">
      <?php echo jumpoff_term('location')->name; ?>
    </span>
  <?php endif; ?>

  <?php if (is_post_type('post') OR is_post_type('trend_article') ) : ?>
    <time class="post-mast__meta">
      <?php echo $post_date; ?>
    </time>
  <?php endif; ?>

  <h1 class="post-mast__title"><?php echo $post_title; ?></h1>

  <?php if ($article_source OR $article_author) :  ?>
    <p class="post-mast__subtitle">
      <?php echo $article_source; ?> <?php if ($article_author) { echo '&nbsp; | &nbsp; ' . $article_author; }; ?>
    </p>
  <?php endif; ?>

  <?php if ($post_subtitle && !is_post_type('post')) : ?>
    <p class="post-mast__subtitle">
      <?php echo $post_subtitle; ?>
    </p>
  <?php endif; ?>

  <?php echo $breadcrumbs; ?>
  </header>

  <?php if ($has_img) : ?>
  <figure class="post-mast__figure grid">
    <img class="post-mast__img" src="<?php echo $post_img_url; ?>" alt="<?php echo $post_img->alt; ?>">
    <?php if ($post_img->caption) : ?>
      <figcaption class="post-mast__img-caption"><?php echo $post_img->caption; ?></figcaption>
    <?php endif; ?>
  </figure>
  <?php endif; ?>
</section>
