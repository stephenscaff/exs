<?php
/**
 * Views/Posts/_Search-and-Filters
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;


$post_type = get_post_type( get_the_ID() );

?>

<section class="filter-bar has-search has-top-border">
  <div class="grid-lg">
    <div class="filter-bar__grid">
      <div class="filter-bar__search">
        <form class="search-box" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <i class="search-box__icon icon-search"></i>
        <input type="hidden" name="post_type" value="<?php echo $post_type; ?>">
		    <input id="s" name="s" type="search" class="search-box__input  js-search" placeholder="Search for news, articles and press releases">
      </form>
      </div>

      <div class="filter-bar__items is-right">
        <div class="filter-bar__dropdown dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger"><div>News Categories</div> <span></span></button>
          <nav class="dropdown__nav">
            <?php echo jumpoff_tax_filters('category', 'dropdown__link'); ?>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>
