<?php
/**
 * Views/Posts/_Post-Content
 *
 * Displays main post content from the_content (editor).
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="post-content content">
  <div class="grid-sm">
    <?php the_content(); ?>
  </div>
</section>
