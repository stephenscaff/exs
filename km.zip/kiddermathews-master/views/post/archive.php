<?php
/**
 * New Archive
 * @author    Stephen Scaff
 * @package   jumpoff/Kidder
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$current_obj = get_queried_object();
$ppp = get_option('posts_per_page');
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$pro_id = "";

if (has_get('pro_id')) {
  $pro_id = htmlspecialchars($_GET['pro_id']);
  $title = 'News related to ' . get_the_title($pro_id);
}
elseif (is_tax() OR (is_category())) {
  $title = $current_obj->name;
}
elseif ($index_title) {
  $title = get_field('mast_title', 'posts-index');
}
else {
  $title = "News & press";
}

?>

<main class="has-header-offset">

  <section class="mast-title">
    <div class="grid">
      <h1 class="mast-title__title"><?php echo $title; ?></h1>
    </div>
  </section>

  <?php
  // if (is_category() OR is_tax()) :
  //   get_template_part( 'views/post/_search-filters-bar' );
  // endif;
  ?>

  <section class="posts-cards">
    <div class="grid-lg">
      <div id="js-posts" class="posts-cards__grid grid-1-2-3">
        <?php
        /**
         * If is a Taxonomy Archive
         */
         if ($pro_id) {
           $args = array (
             'post_type'      => 'post',
             'posts_per_page' => $ppp,
             'paged'          => $paged,
             'meta_query'     => array(
              array(
               'key'     => 'related_professional',
               'value'   => $pro_id,
               'compare' => 'LIKE'
              )
             )
           );
         }
        elseif (is_category() OR is_tax()) {
          $queried_object = get_queried_object();
          $tax = $queried_object->taxonomy;
          $term_slug = $queried_object->slug;
          $term_name = $queried_object->name;

          $args = array (
            'post_type'       => 'post',
            'posts_per_page' => $ppp,
            'paged'          => $paged,
            'tax_query'       => array(
              array(
                'taxonomy'    => 'category',
                'field'       => 'slug',
                'terms'       => $term_slug,
                'operator'    => 'IN',
              )
            )
          );
        }

        /**
         * Okay, then just an archive
         */
        else {
          $ppp = get_option('posts_per_page');
          $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
          $args = array (
            'post_type'        => 'post',
            'posts_per_page'   => $ppp,
            'paged'            => $paged
          );
        }

      $posts = new WP_Query($args);

      if (have_posts()) :
        while ( $posts->have_posts() ) : $posts->the_post();
          include(locate_template('views/content/post.php'));
        endwhile;
      else :
        include(locate_template('views/content/none.php'));
      endif;
      wp_reset_postdata();
      ?>
    </div>
  </div>
</section>

<?php get_template_part( 'views/shared/fetch-more' ); ?>

</main>

<?php get_footer(); ?>
