<?php
/**
 * List Module
 *
 * The module for creating a list of items
 *
 * @author       Stephen Scaff
 * @package      views/modules
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name          = get_sub_field('section_name');
$hash          = jumpoff_make_hash($name);
$heading_title = get_sub_field('heading_title');
$bg_color      = get_sub_field('bg_color');
$has_bg_color  = get_bg_mod($bg_color);
$is_columns    = get_sub_field('is_columns');
$list          = get_sub_field('list');
$list_item     = jumpoff_format_lines($list, 'list');
$max_cols      = get_sub_field('max_columns');
$cols          = get_sub_field('columns');
$cols_count    = sizeof($cols);
$grid          = "grid-1-{$cols_count}";

$module_classes = chain_module_classes([
  'list-block',
  'module',
  $has_bg_color
]);


?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="<?php echo $module_classes; ?>">
  <div class="grid-lg">
    <div class="list-block__bg <?php echo $bg_color; ?>">
      <?php if ($heading_title) : ?>
      <header class="heading">
        <h2 class="heading_title"><?php echo $heading_title; ?></h2>
      </header>
      <?php endif; ?>

      <?php if ($is_columns == 0) : ?>

      <ul class="list-block__list <?php echo $max_cols; ?>">
        <?php echo $list_item; ?>
      </ul>

      <?php else : ?>

      <div
        class="list-block__grid accordion is-mobile-accordion <?php echo $grid; ?>"
        data-accordion-init="mobile-only">

        <?php foreach ($cols as $col) :
          $title = $col['title'];
          $list = $col['list'];
          $list_formated = jumpoff_format_lines($list, 'list');
        ?>
        <article class="accordion__item list-block__col">
          <div class="accordion__trigger js-accordion-trigger"  aria-expanded="true">
            <h5 class="list-block__heading"><?php echo $title; ?></h5>
          </div>
          <div class="accordion__content">
            <ul class="list-block__list">
            <?php echo $list_formated; ?>
            </ul>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>
