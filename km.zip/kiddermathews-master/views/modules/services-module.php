<?php
/**
 * Views/Modules/Services Module
 *
 * @author    Karlie Watts
 * @package   jumpoff/kidder
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title = get_sub_field('title');
$text  = get_sub_field('text');
$links = get_sub_field('links');
$name  = get_sub_field('section_name');
$hash  = jumpoff_make_hash($name);

?>

<article id="<?php if ($name) { echo $hash; }; ?>" class="services">
  <div class="grid">
    <div class="services__grid">
      <header class="services__header">
        <h3 class="services__header-title"><?php echo $title; ?></h3>
      </header>
      <div class="services__main">
          <p class="services__excerpt"><?php echo $text; ?></p>
          <?php if ($links) : ?>
          <ul class="services__list">
            <?php
            foreach ($links as $link) :
              $item_title  = $link['item_title'];
              $item_link   = $link['item_link'];
              $item_url    = $link['item_url'];
              $link_or_url = jumpoff_field_fallback($item_link, $item_url);
              ?>
              <li><a class="btn-line link-invert" href="<?php echo $link_or_url; ?>"><?php echo $item_title; ?></a></li>
            <?php endforeach; ?>
          </ul>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</article>
