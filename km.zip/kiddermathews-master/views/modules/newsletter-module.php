<?php
/**
 * Views/Modules/Newsletter
 *
 * The module for displaying posts/news
 *
 * @author       Stephen Scaff
 * @package      jumpoff/kidder
 * @see          scss/components/_posts
 * @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit;

global $post ;

$name           = get_sub_field('section_name');
$hash           = jumpoff_make_hash($name);
$heading_title  = get_sub_field('heading_title');
$bg_color       = get_sub_field('bg_color');
$has_bg_color   = get_bg_mod($bg_color);

$module_classes = chain_module_classes([
  'card-posts',
  'module',
  $has_bg_color
]);

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="<?php echo $module_classes; ?>">
  <div class="card-posts__bg <?php echo $bg_color; ?>">
    <div class="grid-lg">
    <?php if ($heading_title) : ?>
      <header class="heading">
        <h2 class="heading__title"><?php echo $heading_title; ?></h2>
      </header>
    <?php endif; ?>

      <div class="card-posts__grid grid-1-3">
       <?php
       foreach ( $newsletters as $newsletter ) :
         $date  = $newsletter['date'];
         $title = $newsletter['title'];
         $url   = $newsletter['url'];
         $pdf   = $newsletter['newsletter_pdf'];

         include(locate_template('views/content/post.php' ));

       endforeach;
       wp_reset_postdata(); ?>
      </div>

     <footer class="ending">
       <a class="btn" href="<?php echo $archive_link; ?>">All Posts</a>
     </footer>
   </div>
 </div>
</section>
