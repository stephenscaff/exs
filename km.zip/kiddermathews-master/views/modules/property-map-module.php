<?php
/**
 * Property Map Module
 *
 * Renders a map of broker properties via property search api.
 * API uses broker email address as primary id.
 *
 * @author       Stephen Scaff
 * @package      jumpoff/kidder
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name           = get_sub_field('section_name');
$hash           = jumpoff_make_hash($name);
$heading_title  = get_sub_field('heading_title');
$api_email      = get_sub_field('api_endpoint_email');

$broker_name    = '';
$pro_title      = get_the_title();
$display_name   = get_sub_field('api_endpoint_display_name');
if ($display_name) {
  $broker_name = $display_name;
} elseif ($pro_title) {
  $broker_name = $pro_title;
}

# List Type Toggle
$lease_or_sale  = get_sub_field('lease_or_sale');
$list_type      = 'For Lease';
if ($lease_or_sale) $list_type = 'For Sale';

$all_props_url = get_site_url() . '/properties?listType=' .rawurlencode($list_type) . '&term='. rawurlencode($broker_name);

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="properties-map module">

  <script>
  var propertiesData = 'https://services.kidder.com/search/public/listing/broker/<?php echo $api_email; ?>';
  </script>

  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title"><?php echo $heading_title; ?></h2>
    </header>
    <div class="properties-map__controls">
      <nav class="properties-map__nav">
        <a class="js-filter is-forsale" data-filter="sale">For Sale</a>
        <span class="sep-vert"></span>
        <a class="js-filter is-forlease" data-filter="lease">For Lease</a>
      </nav>
      <a class="btn-line" href="<?php echo $all_props_url; ?>">View All Properties</a>
    </div>
    <div class="properties-map__map-wrap">
      <div class="properties-map__map js-property-map"></div>
    </div>
  </div>
</section>
