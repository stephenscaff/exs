<?php
/**
 * Split CTA Module
 *
 * The module for adding the Split CTA element.
 *
 * @author       Stephen Scaff
 * @package      views/modules
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name     = get_sub_field('section_name');
$hash     = jumpoff_make_hash($name);
$pretitle = get_sub_field('pretitle');
$title    = get_sub_field('title');
$text     = get_sub_field('text');
$buttons  = get_sub_field('buttons');
$bg_color = get_sub_field('bg_color');
$is_inside_container = get_sub_field('is_inside_container');

# No Pretilte
$has_pretitle = "";

if (!$pretitle) {
  $has_pretitle = 'no-pretitle';
}

# Logic for Inset Modifier
# Determines if module is inside grid-lg container
# or full width.
$is_inset = "";

if ($is_inside_container) {
  $is_inset = 'is-inset';
}

# Logic for SVG Lines selection.
# If white bg, no lines.
# If light bg, dark svg,
# If dark bg, light svg
$lines_for = '';
$has_drawing = '';

if ($bg_color !== 'bg-white') $has_drawing = 'has-drawing';

if ( $bg_color == 'bg-grey' || 'bg-grey-mid' || 'bg-grey-dark' ) {
  $lines_for = 'lines-for-dark';
} elseif ( $bg_color == 'bg-alpha' || 'bg-grey-light' ) {
  $lines_for = 'lines-for-alpha';
}

$module_classes = chain_module_classes([
  $is_inset,
  $has_drawing,
  $has_pretitle,
  'module'
]);

$class_if_extended = add_char_class($text, 350, 'is-extended');

?>

<section id="<?php if ($name) { echo $hash; }; ?>"  class="split-cta <?php echo $module_classes; ?>">
  <div class="split-cta__bg <?php echo $bg_color; ?>">

    <?php if ($bg_color !== 'bg-white') : ?>
    <div class="split-cta__lines">
      <?php echo jumpoff_get_svg($lines_for); ?>
    </div>
    <?php endif; ?>

    <div class="grid-lg">
      <div class="split-cta__grid">
        <header class="split-cta__header">
          <?php if ($pretitle) : ?><h5 class="split-cta__pretitle"><?php echo $pretitle; ?></h5><?php endif; ?>
          <h2 class="split-cta__title"><?php echo $title; ?></h2>
        </header>

        <div class="split-cta__main">
          <p class="split-cta__text <?php echo $class_if_extended; ?>"><?php echo $text; ?></p>

          <?php if (have_rows('buttons')) : ?>
          <div class="btns">
            <?php
              $btn_count = 1;

              while( have_rows('buttons') ): the_row();
                $link = get_sub_field('button_link');
                $url = get_sub_field('button_url');
                $link_or_url = jumpoff_field_fallback($link, $url);
                $btn_text = get_sub_field('button_text');
                $btn_count++;
            ?>

            <?php if ($btn_count % 2) : ?>
              <span class="sep-vert is-white"></span>
            <?php endif; ?>

            <a class="btn is-clear is-sm" href="<?php echo $link_or_url; ?>"><?php echo $btn_text; ?></a>

          <?php endwhile; ?>
          </div>
        <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>
