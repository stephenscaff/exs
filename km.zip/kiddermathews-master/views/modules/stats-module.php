<?php
/**
 * Stats Module
 *
 * Module for creating a collection of stat based info.
 *
 * The module for creating a Team CTA.
 *
 * @author       Stephen Scaff
 * @package      jumpoff/kidder
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name           = get_sub_field('section_name');
$hash           = jumpoff_make_hash($name);
$heading_title  = get_sub_field('heading_title');
$bg_color       = get_sub_field('bg_color');
$max_columns    = get_sub_field('max_columns');
$module_classes = jumpoff_add_classes(['module', $bg_color]);

?>
<section id="<?php if ($name) { echo $hash; }; ?>" class="stats module">
  <div class="grid-lg">
    <div class="stats__bg">
      <?php if ($heading_title ) : ?>
      <header class="stats__header">
        <h2 class="stats__title"><?php echo $heading_title; ?></h2>
      </header>
    <?php endif; ?>

      <div class="stats__grid <?php echo $max_columns; ?>">
        <?php while( have_rows('stats') ): the_row();
          $number = get_sub_field('number');
          $title = get_sub_field('title');
          $text = get_sub_field('text');
        ?>
        <article class="stat">
          <div class="stat__numb"><?php echo $number; ?></div>
          <?php if ($title) : ?><h5 class="stat__title"><?php echo $title; ?></h5><?php endif; ?>
          <?php if ($text) : ?><p class="stat__text"><?php echo $text; ?></p><?php endif; ?>
        </article>
      <?php endwhile; ?>
      </div>
    </div>
  </div>
</section>
