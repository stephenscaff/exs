<?php
/**
 * Card Blocks Module
 *
 * The module for creating CTA Card Blocks
 *
 * @author       Karlie Watts
 * @package      jumpoff/kidder
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name = get_sub_field('section_name');
$hash = jumpoff_make_hash($name);
$card_blocks = get_sub_field('card_blocks');

?>

<section id="<?php if ($name) { echo $hash; }; ?>"  class="card-blocks is-full module">
  <div class="grid-lg">
    <div class="card-blocks__grid">
      <?php foreach ( $card_blocks as $card_block ) :
        $pretitle     = $card_block['pretitle'];
        $title        = $card_block['title'];
        $button_link  = $card_block['button_link'];
        $button_url   = $card_block['button_url'];
        $img_id       = $card_block['image'];
        $img          = jumpoff_ft_img('full', $img_id);
        $link_or_url = jumpoff_field_fallback($button_link, $button_url);
      ?>
    <div>
      <article class="card-block">
        <a class="card-block__link" href="<?php echo $link_or_url; ?>">
          <figure class="card-block__figure" style="background-image: url(<?php echo $img->url;  ?>)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__pretitle"><?php echo $pretitle; ?></span>
              <h2 class="card-block__title"><?php echo $title; ?></h2>
            </div>
          </header>
        </a>
      </article>
    </div>
  <?php endforeach; ?>
  </div>
</section>
