<?php
/**
 * Views/Modules/Team Selector
 *
 * The module for adding selected team members (from professionals).
 *
 * @author       Stephen Scaff
 * @package      jumpoff/team
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $post;

$teams = get_sub_field('team_selector');

?>

<section class="pro-cards module pad">
  <div class="grid-lg">
    <div class="pro-cards__grid grid-1-2-3-4">
    <?php
      foreach ($teams as $post) : setup_postdata( $post );
        include(locate_template('views/content/professional.php' ));
      endforeach;
     ?>
    </div>
  </div>
</section>
