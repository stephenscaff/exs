<?php
/**
* Content Module
* views/modules/content-module
*
* The module for creating content (headers, paragraphs, blockquotes, etc) regions.
*
* @author       Stephen Scaff
* @package      views/modules
* @version      1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit;

$name             = get_sub_field('section_name');
$hash             = jumpoff_make_hash($name);
$heading_title    = get_sub_field('heading_title');
$bg_color         = get_sub_field('bg_color');
$has_bg_color     = get_bg_mod($bg_color);
$read_more_length = get_sub_field('read_more_length');
$num_cols         = get_sub_field('number_cols');
$grid_cols        = "has-{$num_cols}";
$content_block_1  = get_sub_field('content_block');
$content_block_2  = get_sub_field('content_block_2');

# Col Align Logic
$col_align = get_sub_field('col_alignment');

if ($num_cols == 1) {
  $col_align = $col_align;
} elseif ($num_cols == 2) {
  $col_align = 'is-left';
}

$module_classes = chain_module_classes([
  'content-block',
  'module',
  $col_align,
  $has_bg_color
]);

?>

<section id="<?php if ($name) { echo $hash; }; ?>"  class="<?php echo $module_classes; ?>">
  <div class="content-block__bg <?php echo $bg_color; ?>">
    <div class="grid-lg">

      <?php if ($heading_title) : ?>
      <header class="heading ">
        <h2 class="heading__title"><?php echo $heading_title; ?></h2>
      </header>
      <?php endif; ?>

      <div class="content-block__grid <?php echo $grid_cols; ?>">
        <div class="content-block__item post-content">
          <?php if ($read_more_length ) : ?>
          <div class="js-read-more read-more" data-rm-words="<?php echo $read_more_length; ?>">
          <?php endif; ?>
            <?php echo $content_block_1; ?>
          <?php if ($read_more_length) : ?>
          </div>
          <?php endif; ?>
        </div>

        <?php if ($num_cols == 2 && $content_block_2) : ?>
        <div class="content-block__item post-content">
          <?php if ($read_more_length ) : ?>
          <div class="js-read-more read-more" data-rm-words="<?php echo $read_more_length; ?>">
          <?php endif; ?>
            <?php echo $content_block_2 ?>
          <?php if ($read_more_length) : ?>
          </div>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
