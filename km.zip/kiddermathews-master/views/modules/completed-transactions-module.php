<?php
/**
 * Completed Transactions Module
 *
 * The module for adding a brokers completed transactions.
 * A request is made to the search api via broker email.
 *
 * @author       Stephen Scaff
 * @package      views/modules
 * @version      1.0
 * @todo         Test again against a while loop to determine performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name           = get_sub_field('section_name');
$hash           = jumpoff_make_hash($name);
$heading_title  = get_sub_field('heading_title');
$api_email      = get_sub_field('api_endpoint_email');
$api_url        = 'https://services.kidder.com/search/public/transactions/broker';
$response       = wp_remote_get( esc_url_raw("{$api_url}/{$api_email}"));
$response_body  = json_decode( wp_remote_retrieve_body( $response ), true );
$properties     = $response_body['results'];

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="properties module has-show-more">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title"><?php echo $heading_title; ?></h2>
    </header>
    <div class="properties__grid grid-1-to-5 js-completed-trans">
      <?php
      foreach ( $properties as $property ) :
        $img        = $property['property_photo'];
        $title      = $property['property_name'];
        $city       = $property['city'];
        $state      = $property['state_code'];
        $location   = "{$city}, {$state}";
        $sale_price = $property['sale_price'];
        $sq_ft      = $property['square_feet'];
        $type       = $property['transaction_type'];

        $label_price_or_sqft = "Price";
        $price_or_sqft = convert_to_usd($sale_price);

        if ($type == 'For Lease') {
          $label_price_or_sqft = "SQ FT";
          $price_or_sqft = format_number($sq_ft);
        }
      ?>
      <article class="card-property completed-trans__item">
        <div class="card-property__wrap">
          <figure class="card-property__figure">
            <div class="card-property__bg-img" style="background-image: url(<?php echo $img; ?>)"></div>
          </figure>
          <div class="card-property__main">
            <h4 class="card-property__title"><?php echo $title; ?></h4>

            <div class="card-property__item">
              <span class="card-property__label"><span>Location</span></span>
              <span class="card-property__value"><span><?php echo $location; ?></span></span>
            </div>

            <div class="card-property__item">
              <span class="card-property__label"><span><?php echo $label_price_or_sqft; ?></span></span>
              <span class="card-property__value"><span><?php echo $price_or_sqft; ?></span></span>
            </div>
          </div>
        </a>
      </article>
    <?php endforeach; ?>
    </div>
    <footer class="ending">
      <a class="btn js-completed-trans-btn">View All</a>
    </footer>
  </div>
</section>
