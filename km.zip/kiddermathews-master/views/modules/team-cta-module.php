<?php
/**
 * Team CTA Module
 *
 * The module for creating a Team CTA.
 *
 * @author       Stephen Scaff
 * @package      jumpoff/kidder
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name         = get_sub_field('section_name');
$hash         = jumpoff_make_hash($name);
$title        = get_sub_field('title');
$pretitle     = get_sub_field('pretitle');
$specialties  = get_sub_field('specialties');
$image_id     = get_sub_field('image');
$image        = jumpoff_ft_img('full', $image_id);
$link         = get_sub_field('link');
$bg_color     = get_sub_field('bg_color');
$has_bg_color = get_bg_mod($bg_color);

$module_classes = chain_module_classes([
  'team-cta-pro',
  'module',
  $has_bg_color
]);

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="<?php echo $module_classes; ?>">
  <div class="team-cta-pro__bg  <?php echo $bg_color; ?>">
    <figure class="team-cta-pro__headshot">
      <img class="team-cta-pro__headshot-img" src="<?php echo $image->url; ?>" alt="<?php echo $image->alt; ?>"/>
    </figure>
    <header class="team-cta-pro__header grid-lg">
      <?php if ($pretitle) : ?>
        <span class="team-cta-pro__meta"><?php echo $pretitle; ?></span>
      <?php endif; ?>
      <h1 class="team-cta-pro__title"><?php echo $title; ?></h1>
      <span class="team-cta-pro__text">
        <?php echo $specialties; ?></span>
      <a class="team-cta-pro__btn btn-line is-white" href="<?php echo $link; ?>">View Team Profile</a>
    </header>
  </div>
</section>
