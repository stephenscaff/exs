<?php
/**
 * Market Reports or Trend Articles Modules
 * Views/Modules/Reports-Trends-Modules
 *
 * Displays simple text posts for Reseach-based content (market reports and/or trend articles),
 *
 * @author       Stephen Scaff
 * @package      jumpoff
 * @version      1.2
 * @see          scss/components/_text-post.scss | _posts.scss
 */
if ( ! defined( 'ABSPATH' ) ) exit;

global $post;

$name             = get_sub_field('section_name');
$hash             = jumpoff_make_hash($name);
$heading_title    = get_sub_field('heading_title');
$report_or_trends = get_sub_field('reports_or_trends');
$reports_selector = get_sub_field('reports_selector');
$trends_selector  = get_sub_field('trends_selector');
$view_all_url     = get_sub_field('view_all_url');

$title = "Trend Articles";
if ($report_or_trends == 'market_report') $title = 'Market Reports';

# Selected or Latest Logic
$selected_or_latest = "";

if ($report_or_trends == 'market_report' && $reports_selector) {
  $selected_or_latest = $reports_selector;
}
elseif ($report_or_trends == 'trend_article' && $trends_selector) {
  $selected_or_latest = $trends_selector;
}
else {
  $latest_posts_args = array(
    'post_type'        => $report_or_trends,
    'posts_per_page'   => 3,
  );

  $selected_or_latest = get_posts( $latest_posts_args );
}

if ($selected_or_latest) :

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="text-posts module">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title"><?php echo $title; ?></h2>
    </header>
    <div class="text-posts__grid grid-1-2-3">
      <?php
      foreach ( $selected_or_latest as $post ) : setup_postdata( $post);
        if ($report_or_trends == 'market_report') {
          include(locate_template('views/market_report/_post.php' ));
        }
        elseif ($report_or_trends == 'trend_article') {
          include(locate_template('views/content/post.php' ));
        }
      endforeach; wp_reset_postdata(); ?>
    </div>
    <?php if ($view_all_url) : ?>
      <footer class="ending">
        <a class="ending__btn btn" href="<?php echo $view_all_url; ?>">View All</a>
      </footer>
    <?php endif; ?>
  </div>
</section>

<?php endif; ?>
