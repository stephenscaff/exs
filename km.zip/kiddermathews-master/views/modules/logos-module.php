<?php
/**
 * Card BlocksLogos
 * The module for creating Logo stream
 *
 * @author       Karlie Watts
 * @package      views/modules
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name           = get_sub_field('section_name');
$hash           = jumpoff_make_hash($name);
$heading_title  = get_sub_field('heading_title');
$is_grayscale   = get_sub_field('is_grayscale');
$logos          = get_sub_field('logos');
$link           = get_sub_field('button_link');
$url            = get_sub_field('button_url');
$link_or_url    = jumpoff_field_fallback($link, $url);
$btn_text       = get_sub_field('button_text');

if ($is_grayscale) {
  $is_grayscale = 'is-grayscale';
}

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="logos module <?php echo $is_grayscale; ?>">
  <div class="grid-lg">
    <?php if ($heading_title) : ?>
    <header class="heading">
      <h2 class="heading__title"><?php echo $heading_title ?></h2>
    </header>
    <?php endif; ?>

    <div class="logos__grid">
      <?php foreach ( $logos as $logo ) :
        $img_id      = $logo['image'];
        $img = jumpoff_ft_img('full', $img_id);
      ?>
      <div>
        <figure class="logo">
          <img class="logo__img" src="<?php echo $img->url;  ?>" alt="<?php echo $img->alt;  ?>">
          <?php if ($img->caption) : ?>
          <figcaption class="logo__caption"><?php echo $img->caption; ?></figcaption>
          <?php endif; ?>
        </figure>
      </div>
    <?php endforeach; ?>
  </div>
  <?php if ($link_or_url) : ?>
  <div class="logos__btn">
    <a class="btn" href="<?php echo $link_or_url; ?>"><?php echo $btn_text; ?></a>
  </div>
<?php endif; ?>
</section>
