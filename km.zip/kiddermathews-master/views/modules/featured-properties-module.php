<?php
/**
 * Featured Properties Module
 *
 * The module for creating a collection of Featured Properties
 * with a card builder repeater field.
 *
 * @author       Stephen Scaff
 * @package      views/modules
 * @version      1.0
 * @todo         Test again against a while loop to determine performance
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name           = get_sub_field('section_name');
$hash           = jumpoff_make_hash($name);
$heading_title  = get_sub_field('heading_title');
$name           = get_sub_field('section_name');
$hash           = jumpoff_make_hash($name);
$properties     = get_sub_field('properties');
$view_all_url   = get_sub_field('view_all_url');

if (!empty($properties)) :

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="properties  module">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title"><?php echo $heading_title; ?></h2>
    </header>
    <div class="properties__grid grid-1-to-5">
      <?php
      foreach ( $properties as $property ) :
        $title = $property['title'];
        $url = $property['url'];
        $image_id = $property['image'];
        $img_src = wp_get_attachment_image_src($image_id, 'full')[0];
        $img_alt = get_post_meta($image_id, '_wp_attachment_image_alt', true);
        $infos = $property['info'];
      ?>
      <article class="card-property">
        <?php if ($url): ?>
        <a class="card-property__link" href="<?php echo $url; ?>">
        <?php else : ?>
        <div class="card-property__link">
        <?php endif; ?>

          <figure class="card-property__figure">
            <div class="card-property__bg-img" style="background-image: url(<?php echo $img_src; ?>)"></div>
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title"><?php echo $title; ?></h4>
            <?php
            if (!empty($infos)) :
              foreach ( $infos as $info ) :
                $label = $info['label'];
                $value = $info['value'];
            ?>
            <div class="card-property__item">
              <span class="card-property__label"><span><?php echo $label; ?></span></span>
              <span class="card-property__value"><?php echo $value; ?></span>
            </div>
            <?php
              endforeach;
            endif;
            ?>
            <?php if ($url) : ?>
              <span class="card-property__btn btn-line">View Property</span>
            <?php endif; ?>
          </div>

        <?php if ($url): ?>
        </a>
        <?php else : ?>
        </div>
        <?php endif; ?>
      </article>
    <?php endforeach; ?>
    </div>

    <?php if ($view_all_url) : ?>
    <footer class="ending">
      <a class="btn" href="<?php echo $view_all_url; ?>">View All</a>
    </footer>
    <?php endif; ?>
  </div>
</section>

<?php endif; ?>
