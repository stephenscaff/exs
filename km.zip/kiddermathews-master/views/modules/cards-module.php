<?php
/**
 * Views/Modules/Cards-Module
 *
 * Card building module
 *
 * @author       Stephen Scaff
 * @package      jumpoff/kidder
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name = get_sub_field('section_name');
$hash = jumpoff_make_hash($name);
$heading_title = get_sub_field('heading_title');
$cards = get_sub_field('cards');
$view_more_url = get_sub_field('view_more_url');
$view_more_btn = get_sub_field('view_more_btn_text');

if (!empty($cards)) :

?>

<section id="<?php if ($name) { echo $hash; }; ?>"  class="properties module">
  <div class="grid-lg">
    <?php if ($heading_title) : ?>
    <header class="heading">
      <h2 class="heading__title"><?php echo $heading_title; ?></h2>
    </header>
    <?php endif; ?>
    <div class="cards__grid grid-1-2-4">
      <?php
      foreach ( $cards as $card ) :
        $title = $card['title'];
        $image_id = $card['image'];
        $img = jumpoff_ft_img('full', $image_id);
        $content = $card['content'];
        $link = $card['button_link'];
        $url = $card['button_url'];
        $link_or_url = jumpoff_field_fallback($link, $url);
        $btn_text = $card['button_text'];

      ?>
      <article class="card-post">
        <?php if ($link_or_url) : ?>
        <a class="card-post__link" href="<?php echo $link_or_url; ?>">
        <?php else : ?>
        <div class="card-post__wrap">
        <?php endif; ?>
          <figure class="card-post__figure">
            <img class="card-post__img"
                 src="<?php echo $img->url; ?>"
                 alt="<?php echo $img->alt; ?>"/>
          </figure>

          <div class="card-post__main">
            <div>
              <h4 class="card-post__title"><?php echo $title; ?></h4>
              <p class="card-post__excerpt">
                <?php echo $content; ?>
              </p>

            <?php if ($link_or_url): ?>
              <span class="card-post__btn btn-line"><?php echo $btn_text; ?></span>
            <?php endif; ?>
            </div>
          </div>
          <?php if ($link_or_url) : ?>
        </a>
        <?php else : ?>
        </div>
        <?php endif; ?>
      </article>
    <?php endforeach; ?>
    </div>

    <?php if ($view_more_url) : ?>
    <footer class="ending">
      <a class="btn" href="<?php echo $view_more_url; ?>"><?php echo $view_more_btn; ?></a>
    </footer>
    <?php endif; ?>
  </div>
</section>

<?php endif; ?>
