<?php
/**
 * Views/Modules/Success Stories Module
 *
 * The module for adding selected Success Stories to a page.
 * If on a professional page, we pass the professional's id to
 * archive link as a value for the param 'pro_id'
 *
 * @author       Stephen Scaff
 * @package      jumpoff/kidder
 * @version      1.0
 * @see          fields/modules/success-stories.php
 * @see          scss/components/_card-blocks.scss
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name             = get_sub_field('section_name');
$hash             = jumpoff_make_hash($name);
$heading_title    = get_sub_field('heading_title');
if (!$heading_title) $heading_title = 'Success Stories';
$testimonials     = get_sub_field('quotes');
$archive_link     = get_post_type_archive_link('success_story');

$related_or_selected_stories = "";
$selected_stories = get_sub_field('success_story_selector');
$stories_count    = 1;
$by_location      = get_sub_field('success_story_location');
$by_specialty     = get_sub_field('success_story_specialty');
$location_slug    = "";
$specialty_slug   = "";

if (is_post_type('professional') || is_post_type('team')) {
  $professional_id = get_the_ID();
  $archive_link    = get_post_type_archive_link('success_story').'?pro_id='.$professional_id;
}

if ( $selected_stories ) {

  $related_or_selected_stories = $selected_stories;

} elseif ($by_location OR $by_specialty) {

  if ($by_location) {
    $location_slug = $by_location->slug;
  }
  elseif ($by_specialty) {
    $specialty_slug = $by_specialty->slug;
  }

  $args = array(
    'post_type'        => 'success_story',
    'posts_per_page'   => 5,
    'tax_query' => array(
      'relation' => 'OR',
      array(
        'taxonomy' => 'location',
        'field'    => 'slug',
        'terms'    => array($location_slug),
      ),
      array(
        'taxonomy' => 'specialty',
        'field'    => 'slug',
        'terms'    => array($specialty_slug),
      ),
    ),
  );

  $related_or_selected_stories = get_posts( $args );
}

if ($related_or_selected_stories) :
$num_stories      = count($related_or_selected_stories);
?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="card-blocks is-stories module">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title"><?php echo $heading_title; ?></h2>
    </header>

    <div class="card-blocks__grid has-<?php echo $num_stories; ?>">
      <?php
      foreach ( $related_or_selected_stories as $story ) : setup_postdata( $story);
        $title   = get_the_title($story);
        $url     = get_the_permalink($story);
        $img     = jumpoff_ft_img('full', $story);
        $img_url = $img->url;
        if (empty($img_url)) $img_url = jumpoff_random_img();
        $specialty_term = get_the_terms($story, 'specialty');
        $stories_count++;
      ?>
      <article class="card-block is-story">
        <a class="card-block__link" href="<?php echo $url; ?>">
          <figure class="card-block__figure" style="background-image: url(<?php echo $img_url; ?>)"></figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__meta">
                <?php if ($specialty_term) echo $specialty_term[0]->name; ?>
              </span>
              <h3 class="card-block__title"><?php echo $title; ?></h3>
            </div>
          </header>
        </a>
      </article>

      <?php if ($stories_count > 5) : ?>
      <article class="card-block is-story is-story-all">
        <a class="card-block__link js-svg-trigger" href="<?php echo $archive_link; ?>">
          <figure class="card-block__svg">
            <?php echo jumpoff_get_svg('lines-for-story'); ?>
          </figure>
          <header class="card-block__header">
            <div>
              <span class="card-block__btn">View All Success Stories</span>
            </div>
          </header>
        </a>
      </article>
    <?php
    endif;
   endforeach;
   wp_reset_postdata(); ?>
    </div>
  </div>
</section>
<?php endif; ?>
