<?php
/**
* Gallery Module
*
* Module that creates a gallery of images with various image width options.
*
* @author       Stephen Scaff
* @package      partials/modules
* @version      1.0
* @see          inc/fields/fields-vars-modules.php
* @see          src/assets/scss/components/_gals.scss
*/

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="gal module">
  <div class="grid-full">
    <div class="gal__grid">
    <?php
    while( have_rows('images') ): the_row();
      $img = get_sub_field('image');
      $img_width = get_sub_field('image_width');
    ?>
    <figure class="gal__figure <?php echo $img_width; ?>">
      <div class="gal__img" style="background-image: url(<?php echo $img['url']; ?>)"></div>
    </figure>
  <?php endwhile; ?>
    </div>
  </div>
</section>
