<?php
/**
 * Views/Modules/Resarch Module
 *
 * The module for adding research blocks;
 *
 * @author       Karlie Watts
 * @package      jumpoff/kidder
 * @version      1.0
 * @see          fields/modules/research.php
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$reports_archive = get_post_type_archive_link('market_report');
$research_cards  = get_sub_field('research_cards');

if ($research_cards) : ?>

<section class="research-cards module">
  <div class="grid-lg">
    <div class="properties__grid grid-1-2-3">
      <?php
      foreach ( $research_cards as $research_card ) :

        $title            = $research_card['title'];
        $market_report    = $research_card['market_report'];
        $summary          = $research_card['summary'];
        $inventory_map    = $research_card['inventory_map'];
        $img_id           = $research_card['image'];
        $img              = jumpoff_ft_img('full', $img_id);
        $filter_url       = get_filter_url('market_report', 'specialty', $market_report);
      ?>

      <article class="card-property is-research">
       <div class="card-property__wrap" href="#">
         <figure class="card-property__figure">
           <img class="card-property__img" src="<?php echo $img->url; ?>" alt="<?php echo $img->alt; ?>">
         </figure>
         <div class="card-property__main">
           <h4 class="card-property__title"><?php echo $title; ?></h4>
           <?php if ($market_report) : ?>
           <a class="card-property__item" href="<?php echo $filter_url; ?>">
             <span class="card-property__label"><span class="btn-line">Market Reports</span></span>
             <span class="card-property__value">View</span>
           </a>
           <?php endif; ?>
           <?php if ($summary) : ?>
           <a class="card-property__item no-trans" href="<?php echo $summary['url']; ?>"  target="_blank">
             <span class="card-property__label"><span class="btn-line">West Coast Summary</span></span>
             <span class="card-property__value">pdf</span>
          </a>
          <?php endif; ?>
          <?php if ($inventory_map) : ?>
            <a class="card-property__item no-trans" href="<?php echo $inventory_map['url']; ?>" target="_blank">
            <span class="card-property__label"><span class="btn-line">Inventory Map</span></span>
            <span class="card-property__value">pdf</span>
           </a>
         <?php endif; ?>
         </div>
       </div>
      </article>
      <?php endforeach; ?>
    </div>
    <footer class="ending">
      <a class="btn" href="<?php echo $reports_archive; ?>" target="_blank">View All</a>
    </footer>
  </div>
  <?php endif; ?>
</section>
