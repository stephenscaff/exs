<?php
/**
 * Views/Modules/Banner Module
 *
 * The module for adding a banner featuring a background image with
 * text atop, and an optional button/link.
 *
 * @author       Stephen Scaff
 * @package      views/modules
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$quote = get_sub_field('quote_quote');
$cite = get_sub_field('quote_cite');
$bg_color = get_sub_field('quote_bg_color');
$bg_image = get_sub_field('quote_bg_image');
$has_bg = '';

if ($bg_image) {
  $has_bg = 'has-bg';
}
$module_classes = chain_module_classes([
  'module',
  $bg_color,
  $has_bg
]);

?>

<section class="quote <?php echo $module_classes ?>">

  <?php if ($bg_image) : ?>
    <figure class="quote__figure" style="background-image: url(<?php echo $bg_image['url'];  ?>)"></figure>
  <?php endif; ?>
  <header class="quote__header grid">
    <div>
      <blockquote>
        <p><?php echo $quote; ?></p>
        <?php if ($quote) : ?><cite><?php echo $cite; ?></cite><?php endif; ?>
      </blockquote>
    </div>
  </header>
</section>
