<?php
/**
 * Testimonials
 *
 * The module for creating a collection of Testimonials with a simulated
 * load more functionality that displays x number of array items on click,
 * in addition to a Read More function within the quote to control
 * chatacter count of each quote.
 *
 * @author       Stephen Scaff
 * @package      jumpoff/kidder
 * @version      1.0
 * @see          fields/fields-modules.php
 * @see          js/components/_show-more.js
 * @see          scss/components/_testimonials.scss
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name         = get_sub_field('section_name');
$hash         = jumpoff_make_hash($name);
$testimonials = get_sub_field('quotes');

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="testimonials module has-show-more">
  <div class="testimonials__bg bg-grey-light">
    <div class="grid-lg">
      <header class="heading">
        <h2 class="heading__title">Testimonials</h2>
      </header>

      <div class="testimonails__items js-show-more">
        <?php
        foreach ( $testimonials as $testimonial ) :
          $quote  = $testimonial['quote'];
          $author = $testimonial['author'];
          $byline = $testimonial['byline'];
        ?>
        <article class="testimonial show-more__item ">
          <div class="testimonial__grid">
            <header class="testimonial__header">
              <?php if ($author) : ?><h4 class="testimonial__author"><?php echo $author; ?></h4><?php endif; ?>
              <?php if ($byline) : ?><span class="testimonial__byline"><?php echo $byline; ?></span><?php endif; ?>
            </header>

            <div class="testimonial__quote">
              <div class="js-read-more" data-rm-words="50">
                <?php echo $quote; ?>
              </div>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
      <footer class="ending no-pad">
        <a class="btn js-show-more-btn">Show More</a>
      </footer>
    </div>
  </div>
</section>
