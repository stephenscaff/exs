<?php
/**
 * Views/Modules/Banner Module
 *
 * The module for adding a banner featuring a background image with
 * text atop, and an optional button/link.
 *
 * @author       Stephen Scaff
 * @package      views/modules
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$name = get_sub_field('section_name');
$hash = jumpoff_make_hash($name);
$pretitle = get_sub_field('pretitle');
$title = get_sub_field('title');
$image_id = get_sub_field('image');
$img = jumpoff_ft_img('full', $image_id);
$btn_text = get_sub_field('button_text');
$link = get_sub_field('button_link');
$url = get_sub_field('button_url');
$link_or_url = jumpoff_field_fallback($link, $url);

?>

<section id="<?php if ($name) { echo $hash; }; ?>" class="banner module">
  <?php if ($link_or_url) : ?>
  <a class="banner__link" href="<?php echo $link_or_url; ?>">
  <?php else : ?>
  <div class="banner__wrap">
  <?php endif; ?>
    <figure class="banner__figure" style="background-image: url(<?php echo $img->url;  ?>)"></figure>
    <header class="banner__header">
      <div class="grid-lg">
        <div>
          <span class="banner__pretitle"><?php echo $pretitle; ?></span>
          <h2 class="banner__title"><?php echo $title; ?></h2>

          <?php if ($link_or_url) : ?>
          <div class="banner__btn">
            <span class="btn-line is-white"><?php echo $btn_text; ?></span>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </header>
  <?php if ($link_or_url) : ?>
  </a>
  <?php else : ?>
  </div>
  <?php endif; ?>
</section>
