<?php
/**
 * Views/Market_Report/_filter-bar
 *
 * The search and filter bar for market reports
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$all_market_reports_url = jumpoff_get_page_url('market_report', 1);

?>

<section class="filter-bar has-search is-market-reports">
  <div class="grid-lg">
    <div class="filter-bar__grid">
      <div class="filter-bar__search">
        <form class="search-box" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
          <i class="search-box__icon icon-search"></i>
          <input type="hidden" name="post_type" value="<?php echo $post_type; ?>">
		      <input
            id="s"
            class="search-box__input js-search"
            name="s"
            type="search"
            placeholder="Search for reports by location or property type">
        </form>
      </div>

      <div class="filter-bar__items is-right">
        <div class="filter-bar__dropdown dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger"><div>State</div> <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php echo $all_market_reports_url; ?>">All States</a>
            <?php echo jumpoff_query_filters('state', 'market_report', 'dropdown__link'); ?>
          </nav>
        </div>

        <div class="filter-bar__dropdown dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger"><div>Product Type</div> <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php echo $all_market_reports_url; ?>">All Product Types</a>
            <?php echo jumpoff_query_filters('product_type', 'market_report', 'dropdown__link'); ?>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>
