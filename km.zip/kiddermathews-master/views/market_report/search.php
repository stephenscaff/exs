<?php
/**
 * View/Market_Report/search
 * Search View for market reports
 *
 * @author    Stephen Scaff
 * @package   jumpoff/kidder/views
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

global $wp_query;

$search_query = get_search_query();
$search_count = $wp_query->found_posts;
$search_terms = $wp_query->search_terms;

?>

<main class="has-header-offset">

<?php

include(locate_template('views/shared/mast.php'));
include(locate_template('views/market_report/_search-bar.php'));
include(locate_template('views/shared/search-info.php'));

?>

<section class="text-posts is-reports pad has-fetch-more js-results-container is-grid">
  <div class="grid-lg">
    <div id="js-posts" class="text-posts__grid">
      <?php
      if ( have_posts() ): while ( have_posts() ) : the_post();
        get_template_part( 'views/content/text-post'  );
      endwhile; else:
        get_template_part( 'views/content/none' );
      endif;
      ?>
    </div>
  </div>
</section>

<?php include(locate_template('views/shared/fetch-more.php' ));?>

</main>

<?php get_footer(); ?>
