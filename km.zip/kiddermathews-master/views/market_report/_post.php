<?php
/**
 * Views/MarketReports/_post
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) return;

global $post;

$title = get_the_title();
$url = get_the_permalink();
$post_subtitle = get_field('post_subtitle', $post->ID);
$state = jumpoff_term('state', $post->ID);
$specialty = jumpoff_term('specialty', $post->ID);
$pretitle = ($state ? $state->name . ' | ': '') . ($specialty ? $specialty->name : '');

?>

<article class="text-post">
  <a class="text-post__link" href="<?php echo $url; ?>">
    <div class="text-post__main">
      <span class="text-post__meta">
        <?php echo $pretitle; ?>
      </span>

      <h4 class="text-post__title"><?php echo $title; ?></h4>
      <?php if ($post_subtitle ): ?>
        <span class="text-post__subtitle"><?php echo $post_subtitle; ?></span>
      <?php endif; ?>
      <span class="text-post__btn btn-line">Read More</span>
    </div>
  </a>
</article>
