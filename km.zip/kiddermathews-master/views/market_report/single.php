<?php
/**
 * Views/Market_Report/Single
 * The default template single Market reports
 *
 * @author    Stephen Scaff
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while (have_posts()) : the_post();

$post_title = get_the_title();
$post_ft_img = jumpoff_ft_img('full');
$post_subtitle = get_post_meta($post->ID,'subtitle', true);
$reports_title = get_field('reports_title');
$current_report = get_field('current_report');
$prior_reports = get_field('prior_reports');

?>

<main role="main">
  <article class="post-single">

<?php
include(locate_template('views/post/_post-mast.php'));
include(locate_template('views/post/_post-content.php'));
include(locate_template('views/market_report/_downloads.php'));
include(locate_template('views/post/_post-footer.php'));
?>

  </article>
</main>

<?php endwhile; ?>

<?php get_footer(); ?>
