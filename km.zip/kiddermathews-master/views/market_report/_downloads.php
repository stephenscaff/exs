<?php
/**
 * Views/Market_Report/_Downloads
 * File downloads section for market reports
 *
 * @author    Stephen Scaff
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="downloads">
  <div class="grid-sm">
    <div class="downloads__current">
      <a class="btn is-download" href="<?php echo $current_report['url']; ?>" target="_blank">
        <i class="icon-download-file"></i>
        <span>Download Market Report</span>
      </a>
    </div>

  <?php if ($prior_reports) : ?>
    <h4 class="downloads__title">Prior <?php echo $reports_title; ?> Reports</h4>

    <?php
    foreach($prior_reports as $prior_report) :
      $title = $prior_report['report']['title'];
      $url = $prior_report['report']['url']; ?>

      <div class="downloads__link">
        <a class="link-download" href="<?php echo $url; ?>" target="_blank">
          <i class="icon-download-file"></i>
          <span class="btn-line"><?php echo $title; ?></span>
        </a>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
  </div>
</section>
