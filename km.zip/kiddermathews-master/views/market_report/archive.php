<?php
/**
 * Template for Market Reports
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$post_type = get_post_type( get_the_ID() );

?>

<main class="has-header-offset">

<?php
include(locate_template('views/shared/mast.php'));
include(locate_template('views/market_report/_search-bar.php'));
?>

<section class="text-posts is-reports pad has-fetch-more">
  <div class="grid-lg">
    <div id="js-posts" class="text-posts__grid">
      <?php
      if ( have_posts() ): while ( have_posts() ) : the_post();
        get_template_part( 'views/market_report/_post'  );
      endwhile; else:
        get_template_part( 'views/content/none' );
      endif;
      ?>
    </div>
  </div>
</section>

<?php get_template_part( 'views/shared/fetch-more' );?>

</main>

<!-- Footer  -->
<?php get_footer(); ?>
