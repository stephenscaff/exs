<?php
/**
 * Views/Office_location/Single
 *
 * Single view for Office Locations
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while (have_posts()) : the_post();

$title       = get_the_title();
$content     = apply_filters( 'the_content', get_the_content() );
$address     = get_field('location_address');
$numbers     = get_field('location_contact_numbers');
$brochure    = get_field('location_brochure');
$pm_brochure = get_field('property_management_brochure');

# EVP / LRP
$evp = get_field('location_evp');
$lrp = get_field('location_rp');

if ($evp) {
  $evp_name = get_the_title($evp[0]->ID);
  $evp_url = get_the_permalink($evp[0]->ID);
  $evp_titles = get_field('professional_designation', $evp[0]->ID);
  $evp_email = get_field('professional_email', $evp[0]->ID);
}

if ($lrp) {
  $lrp_name = get_the_title($lrp[0]->ID);
  $lrp_url = get_the_permalink($lrp[0]->ID);
  $lrp_titles = get_field('professional_designation', $lrp[0]->ID);
  $lrp_email = get_field('professional_email', $lrp[0]->ID);
}

?>

<main class="has-header-offset">
  <article>
    <?php get_template_part( 'views/shared/mast' ); ?>

    <section class="page-content is-office_location">
      <div class="grid-lg">
        <div class="page-content__grid has-lg-col-pad">
          <section class="page-content__main">
            <?php echo $content; ?>
          </section>

        <aside class="page-content__sidebar sidebar">
          <div class="sidebar__items">
            <div class="sidebar__item">
              <!-- Sidebar -->
              <div class="sidebar__item">

              <?php if ($brochure) : ?>
                <div class="sidebar__brochure">
                  <a class="link-download"
                    href="<?php echo $brochure['url']; ?>"
                    target="_blank"
                    title="Download Property Management Capabilities Brochure">
                    <i class="icon-download-file"></i>
                    <span class="btn-line">Capabilities Brochure</span>
                  </a>
                </div>
              <?php endif; ?>

              <?php if ($pm_brochure) : ?>
                <div class="sidebar__brochure">
                  <a class="link-download" href="<?php echo $pm_brochure['url']; ?>" target="_blank" title="Download Property Management Capabilities Brochure">
                    <i class="icon-download-file"></i>
                    <span class="btn-line">Property Mgmt Brochure</span>
                  </a>
                </div>
              <?php endif; ?>
              <h5 class="sidebar__title">Contact</h5>

              <address class="sidebar__address">
                <?php echo $address; ?>
                <!-- Phone numbers -->
                <?php foreach ($numbers as $number) :
                  $label = $number['label'];
                  $number = $number['number']; ?>
                  <div>
                    <?php echo $label; ?> <a class="link-invert" href="tel:<?php echo format_tel_link($number); ?>"><?php echo $number; ?></a>
                  </div>

                <?php endforeach; ?>
              </address>

              <a class="btn-line link-invert" href="https://www.google.com/maps/place/<?php echo preg_replace("/<br\W*?\/>/", "+", $address); ?>" target="_blank">
                Get Directions
              </a>
            </div>
            <br/>


            <?php if ($evp) : ?>
              <div class="sidebar__block">
              <h5 class="sidebar__title">Managing Director</h5>
              <a class="sidebar__name-link link-invert" href="<?php echo $evp_url; ?>">
                <span class="sidebar__name"><?php echo $evp_name; ?><?php if ($evp_titles) : ?>, <small><?php echo $evp_titles; ?></small><?php endif; ?>
                </span>
              </a>
              <a class="sidebar__email link-underline" href="mailto:<?php echo $evp_email; ?>">
                <?php echo $evp_email; ?>
              </a>
            </div>
            <?php endif; ?>

            <?php if ($lrp) : ?>
            <div class="sidebar__block">
              <h5 class="sidebar__title">Regional President</h5>
              <a class="sidebar__name-link link-invert" href="<?php echo $lrp_url; ?>">
                <span class="sidebar__name"><?php echo $lrp_name; ?><?php if ($lrp_titles) : ?>, <small><?php echo $lrp_titles; ?></small><?php endif; ?></span>
              </a>
              <a class="sidebar__email link-underline" href="mailto:<?php echo $lrp_email; ?>">
                <?php echo $lrp_email; ?>
              </a>
            </div>
            <?php endif; ?>
          </div>
        </div>
        </aside>
    </div>
  </div>
</section>

    <section class="modules">
      <?php include(locate_template('views/shared/modules.php')); ?>
    </section>
  </article>
</main>

<?php endwhile; ?>

<?php get_footer(); ?>
