<?php
/**
 * Views/Office_Location/Archive
 *
 * Map view of locations, featuring google maps api
 *
 * @see js/components/Map/*                                                                                                            n
 *
 * @author     Stephen Scaff
 * @package    jumpoff
 * @subpackage views
 * @version    1.0.0
 * @see js/components/Map/*
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>

<main class="bg-white">
  <section class="locations-split">
    <aside class="locations-split__sidebar">
      <header class="locations-split__header">
        <h1 class="locations-split__title">Office Locations</h1>
      </header>
      <section class="filter-bar is-locations">
        <div class="grid-lg">
          <div class="filter-bar__grid">
            <div class="filter-bar__items is-right">
              <div class="filter-bar__dropdown dropdown js-dropdown">
                <button class="dropdown__label js-dropdown-trigger"><div>City</div> <span></span></button>
                <nav class="dropdown__nav">
                  <a class="dropdown__link is-heading js-filter" data-filter="all_cities">All Cities</a>
                  <?php echo get_locations_filters('city'); ?>
                </nav>
              </div>

              <div class="filter-bar__dropdown dropdown js-dropdown">
                <button class="dropdown__label js-dropdown-trigger"><div>State</div> <span></span></button>
                <nav class="dropdown__nav">
                  <a class="dropdown__link js-filter is-heading" data-filter="all_states">All Locations</a>
                  <a class="dropdown__link js-filter" data-filter="az"> Arizona</a>
                  <a class="dropdown__link js-filter" data-filter="ca"> California</a>
                  <a class="dropdown__link js-filter" data-filter="or"> Oregon</a>
                  <a class="dropdown__link js-filter" data-filter="nv"> Nevada</a>
                  <a class="dropdown__link js-filter" data-filter="wa"> Washington</a>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div class="locations-split__controls"></div>
      <div class="locations-split__listings js-locations-listings"></div>
    </aside>

    <section class="locations-split__map js-locations-map"></section>
  </section>
</main>

<?php get_footer(); ?>
