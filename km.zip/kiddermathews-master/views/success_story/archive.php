<?php
/**
 * Success Story Archive                                                                                                             n
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

global $wp_query;


if (has_get('pro_id')) {
  $pro_id = htmlspecialchars($_GET["pro_id"]);
}

?>

<main role="main" class="bg-white has-header-offset">

<section class="mast-title">
  <div class="grid">
    <h1 class="mast-title__title">Success Stories </h1>
  </div>
</section>

<?php
include(locate_template('views/success_story/_search-bar.php'));
include(locate_template('views/shared/search-info.php'));
?>


<section class="card-blocks pad-b has-fetch-more">
  <div class="grid-lg">
    <div id="js-posts" class="card-blocks__grid grid-1-2-4">

      <?php if (has_get('pro_id') ) : ?>

      <?php

        $ppp = get_option('posts_per_page');
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

        $args = array (
          'post_type'      => 'success_story',
          'posts_per_page' => $ppp,
          'paged'          => $paged,
          'meta_query'     => array(
           array(
            'key'     => 'related_professional',
            'value'   => $pro_id,
            'compare' => 'LIKE'
           )
          )
        );

        $posts = new WP_Query($args);

        while ( $posts->have_posts() ) : $posts->the_post();
          include(locate_template('views/content/success-story.php'));
        endwhile; ?>

      <?php else : ?>

      <?php
        while ( have_posts() ) : the_post();
          include(locate_template('views/content/success-story.php'));
        endwhile;
      endif;
      ?>
    </div>
  </div>
</section>

<?php get_template_part( 'views/shared/fetch-more' ); ?>

</main>

<?php get_footer(); ?>
