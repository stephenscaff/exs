<?php
/**
* Views/Success_Story/Single
* Single view for success stories, which now features the modules template
*
* @author    Stephen Scaff
* @package   jumpoff/kidder
* @version   1.2.0
* @since     1.2.0 - modules tempalte instead of _content.
*/

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while (have_posts()) : the_post();

$post_title = get_the_title();
$post_ft_img = jumpoff_ft_img('full');
$post_subtitle = get_post_meta($post->ID,'subtitle', true);

?>

<main class="has-header-offset">

<article class="post-single is-success-story">

<?php include(locate_template( 'views/success_story/_story-mast.php' )); ?>
<?php include(locate_template( 'views/success_story/_story-stats.php' )); ?>

<section class="modules">
<?php include(locate_template( 'views/shared/modules.php' )); ?>
</section>

<?php include(locate_template( 'views/post/_post-footer.php' )); ?>

</article>

<?php include(locate_template( 'views/shared/related.php' ) ); ?>
<?php get_template_part( 'views/shared/bottom-nav' ); ?>

</main>

<?php endwhile; ?>

<?php get_footer(); ?>
