<?php
/**
 * Views/Success_Story/Search                                                                                                           n
 *
 * @author    Stephen Scaff
 * @package   jumpoff/kidder
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

global $wp_query;

$location = get_query_var('location');
$specialty = get_query_var('specialty');

if (has_get('pro_id')) {
  $pro_id = htmlspecialchars($_GET["pro_id"]);
}

?>

<main role="main" class="bg-white has-header-offset">

<section class="mast-title">
  <div class="grid">
    <h1 class="mast-title__title">Success Stories </h1>
  </div>
</section>

<?php
include(locate_template('views/success_story/_search-bar.php'));
include(locate_template('views/shared/search-info.php'));
?>

<section class="card-blocks pad-b has-fetch-more">
  <div class="grid-lg">
    <div id="js-posts" class="card-blocks__grid grid-1-2-4">
    <?php
    if (have_posts()) :
      while ( have_posts() ) : the_post();
        include(locate_template('views/content/success-story.php'));
      endwhile;
    else :
      get_template_part( 'views/content/none' );
    endif;
     ?>
    </div>
  </div>
</section>

<?php get_template_part( 'views/shared/fetch-more' );?>

</main>

<?php get_footer(); ?>
