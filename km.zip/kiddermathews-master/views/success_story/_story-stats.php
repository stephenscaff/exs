<?php
/**
 * Stats Module
 *
 * Module for creating a collection of stat based info.
 *
 * The module for creating a Team CTA.
 *
 * @author       Stephen Scaff
 * @package      jumpoff/kidder
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;


$story_stats = get_field('story_stat');

if ($story_stats) : ?>
<section class="story-stats">
  <div class="grid-lg">
    <div class="story-stats__bg">
      <div class="story-stats__grid grid-1-to-5">
        <?php foreach ( $story_stats as $story_stat) :
          $number = $story_stat['number'];
          $title = $story_stat['title'];
          $text = $story_stat['text'];
        ?>
        <article class="story-stat">
          <div class="story-stat__numb"><?php echo $number; ?></div>
          <?php if ($title) : ?><h5 class="story-stat__title"><?php echo $title; ?></h5><?php endif; ?>
          <?php if ($text) : ?><p class="story-stat__text"><?php echo $text; ?></p><?php endif; ?>
        </article>
      <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>
