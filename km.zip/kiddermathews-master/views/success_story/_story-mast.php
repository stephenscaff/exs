<?php
/**
* Views/Success_Story/StoryMast
* Single view for success stories, which now features the modules template
*
* @author    Stephen Scaff
* @package   jumpoff/kidder
* @version   1.2.0
* @since     1.2.0 - modules tempalte instead of _content.
*/

if ( ! defined( 'ABSPATH' ) ) exit;

$id = get_the_ID();
$post_title = get_the_title();
$post_ft_img = jumpoff_ft_img('full');
$post_subtitle = get_field('post_subtitle');
$post_location = get_field('post_location');
$breadcrumbs = get_post_breadcrumbs();

?>

<section class="color-mast <?php if (has_ft_img($id)) { echo "has-ft-img";}; ?>">
  <?php if (has_ft_img($id)) : ?>
  <figure class="color-mast__figure" style="background-image: url(<?php echo $post_ft_img->url; ?>)"></figure>
  <?php else : ?>
    <figure class="color-mast__lines">
      <?php echo jumpoff_get_svg('lines-for-alpha'); ?>
    </figure>
  <?php endif; ?>

  <div class="grid-lg">
    <header class="color-mast__header grid-sm">
      <?php if ($post_location) : ?>
      <span class="color-mast__meta"><?php echo $post_location; ?></span>
      <?php endif; ?>
      <h1 class="color-mast__title"><?php echo $post_title; ?></h1>
      <?php if ($post_subtitle) : ?><p class="color-mast__subtitle"><?php echo $post_subtitle; ?></p><?php endif; ?>

      <?php echo $breadcrumbs; ?>
    </header>
  </div>
</section>
