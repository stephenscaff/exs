<?php
/**
 * Success Story Content Sections
 * Replaces default post content with success-stroery fields
 *
 * @author    Stephen Scaff
 * @package   jumpoff / kidder
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$story_outline = get_field('story_outline');
$story_challange = get_field('story_challange');
$story_approach = get_field('story_approach');
$story_results = get_field('story_results');
$story_services = get_field('story_services');

?>

<section class="post-content content">
  <div class="grid-sm">
    <?php if ($story_outline) : ?>
    <section class="post-content__block">
      <h3 class="post-content__title">Project Outline</h3>
      <?php echo $story_outline; ?>
    </section>
    <?php endif; ?>

    <?php if ($story_challange) : ?>
    <section class="post-content__block">
      <h3 class="post-content__title">Challenge</h3>
      <?php echo $story_challange; ?>
    </section>
    <?php endif; ?>

    <?php if ($story_approach) : ?>
    <section class="post-content__block">
      <h3 class="post-content__title">Approach</h3>
      <?php echo $story_approach; ?>
    </section>
    <?php endif; ?>

    <?php if ($story_results) : ?>
    <section class="post-content__block">
      <h3 class="post-content__title">Results</h3>
      <?php echo $story_results; ?>
    </section>
    <?php endif; ?>

    <?php if ($story_services) : ?>
    <section class="post-content__block">
      <h3 class="post-content__title">Services Provided</h3>
      <?php echo $story_services; ?>
    </section>
    <?php endif; ?>
  </div>
</section>
