<?php
/**
* The default template for single blog posts.
*
* @author    Stephen Scaff
* @package   jumpoff
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

while (have_posts()) : the_post();

$title = get_the_title();
$subtitle = get_field('career_subtitle');
$address = get_field('career_address');
$ft_img = jumpoff_ft_img('full');
$intro = get_field('career_intro');
$list_blocks = get_field('career_list_block');
$disclaimer = get_field('career_disclaimer');
$career_apply_url = get_field('career_apply_url');
?>

<main class="has-header-offset">

<article>

<!-- Post Header -->
<section class="career-mast">
  <figure class="career-mast__figure" style="background-image: url(<?php echo $ft_img->url; ?>)"></figure>
  <div class="grid-lg">

    <a class="career-mast__back btn-back" href="<?php echo jumpoff_get_page_url('career', 1); ?>">
      <i class="icon-left-arrow"> </i> Back
    </a>

    <header class="career-mast__header grid-sm">
      <h1 class="career-mast__title"><?php echo $title; ?></h1>
      <?php if ($subtitle) : ?><p class="career-mast__subtitle"><?php echo $subtitle; ?></p><?php endif; ?>
      <?php if ($address) : ?><p class="career-mast__address"><?php echo $address; ?></p><?php endif; ?>
    </header>
  </div>
</section>


<section class="career-details">
  <div class="grid-sm">

    <div class="career-details__item">
      <p><?php echo $intro; ?></p>
    </div>

    <?php

    foreach ($list_blocks as $list_block) :
      $title = $list_block['title'];
      $items = $list_block['items'];
    ?>

    <div class="career-details__item">
      <h3 class="career-details__title"><?php echo $title; ?></h3>
      <ul class="career-details__list">
        <?php echo jumpoff_format_lines($items); ?>
      </ul>
    </div>

  <?php endforeach; ?>

    <p class="career-details__disclaimer"><?php echo $disclaimer; ?></p>
  </div>
</section>

<footer class="career-cta">
  <div class="grid-sm">
    <a class="btn" href="<?php echo $career_apply_url; ?>">Apply Now</a>
  </div>
</footer>

</article>

</main>

<?php endwhile; ?>

<?php get_footer(); ?>
