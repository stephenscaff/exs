<?php
/**
 * Careers Archive                                                                                                               n
 *
 * Depreicated!: Post Type removed in favor of modules template
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

/**
 * Careers Logic
 */
$ppp = get_option('posts_per_page');
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

if (is_tax()) {
 $queried_object = get_queried_object();
 $tax = $queried_object->taxonomy;
 $term_slug = $queried_object->slug;
 $term_name = $queried_object->name;

 $args = array (
   'post_type'       => 'career',
   'posts_per_page'  => -1,
   'tax_query'       => array(
     array(
       'taxonomy'    => $tax,
       'field'       => 'slug',
       'terms'       => $term_slug,
       'operator'    => 'IN',
     )
   )
 );
} else {

   $args = array (
     'post_type'        => 'career',
     'posts_per_page'   => $ppp,
     'paged'            => $paged,
   );
 }

$careers = new WP_Query($args);

?>

<main class="has-header-offset">

<!-- Mast -->
<?php get_template_part( 'views/shared/mast' ); ?>

<!-- Filters -->
<section class="filter-bar is-careers">
  <div class="grid-lg">
    <div class="filter-bar__grid">
      <h2 class="filter-bar__title">Open Positions</h2>
      <div class="filter-bar__items is-right">

        <div class="filter-bar__dropdown dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger"><div>Department</div> <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php echo jumpoff_get_page_url('career'); ?>">All Departments</a>
            <?php echo jumpoff_query_filters('career_department', 'career', 'dropdown__link'); ?>
          </nav>
        </div>

        <div class="filter-bar__dropdown dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger"><div>Location</div> <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php echo jumpoff_get_page_url('career'); ?>">All Locations</a>
            <?php echo jumpoff_query_filters('location', 'career', 'dropdown__link'); ?>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Careers -->
<section class="careers">
    <div class="careers__items js-posts">
      <?php
      if (have_posts()) :
        while ( $careers->have_posts() ) : $careers->the_post();
        $url = get_the_permalink();
        $title = get_the_title();
        $excerpt = jumpoff_excerpt(160);
        $dept = get_the_terms($post->ID, 'career_department');
        $dept_name = $dept[0]->name;
        $loc = get_the_terms($careers->ID, 'location');
        $loc_name = $loc[0]->name;
      ?>
      <article class="career-block">
        <a class="career-block__link" href="<?php echo $url; ?>">
          <header class="career-block__header grid-sm">
            <span class="career-block__dept"><?php echo $dept_name; ?> - <?php echo $loc_name; ?></span>
            <h2 class="career-block__title"><?php echo $title; ?></h2>
            <p class="career-block__text"><?php echo $excerpt; ?></p>
            <span class="career-block__btn btn-line">Learn More</span>
          </header>
        </a>
      </article>
      <?php
        endwhile;
      else :
        get_template_part( 'views/content/none' );
      endif;
      ?>
    </div>
  </div>
</section>

<?php
/**
 * Fetch More
 */
if (!is_tax()) :
  get_template_part( 'views/shared/fetch-more' );
endif;
?>

</main>

<?php get_footer(); ?>
