<?php
/**
 * Views/Properties/Search-Mast
 *
 * Search Mast for properties
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$located_id = jumpoff_get_id();
$mast_pretitle = get_field('mast_pretitle', $located_id) ;
$mast_title = get_field('mast_title', $located_id) ;
$mast_text = get_field('mast_text', $located_id);
$mast_img = get_field('mast_image', $located_id);
$ft_img = jumpoff_ft_img('full');

?>
<section class="properties pad">
  <div class="grid-lg">
    <header class="heading">
      <h2 class="heading__title">Listing Properties by Type</h2>
    </header>
    <div class="properties__grid grid-2-3-4-5">

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title">Office</h4>
            <a class="btn-line" href="/index.html?propertyType=Office&amp;listType=For Sale">For Sale</a>
            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Office&amp;listType=For Lease">For Lease</a>
          </div>
        </div>
      </article>

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title">Industrial</h4>
            <a class="btn-line" href="/index.html?propertyType=Industrial&amp;listType=For Sale">For Sale</a>
            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Industrial&amp;listType=For Lease">For Lease</a>
          </div>
        </div>
      </article>

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title">Retail</h4>
            <a class="btn-line" href="/index.html?propertyType=Retail&amp;listType=For Sale">For Sale</a>
            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Retail&amp;listType=For Lease">For Lease</a>
          </div>
        </div>
      </article>

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title">Multifamily</h4>
            <a class="btn-line" href="/index.html?propertyType=Multifamily&amp;listType=For Sale">For Sale</a>
            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Multifamily&amp;listType=For Lease">For Lease</a>
          </div>
        </div>
      </article>

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title">Land</h4>
            <a class="btn-line" href="/index.html?propertyType=Land&amp;listType=For Sale">For Sale</a>
            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Land&amp;listType=For Lease">For Lease</a>
          </div>
        </div>
      </article>

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title">Healthcare</h4>
            <a class="btn-line" href="/index.html?propertyType=Healthcare&amp;listType=For Sale">For Sale</a>
            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Healthcare&amp;listType=For Lease">For Lease</a>
          </div>
        </div>
      </article>

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title">Hospitality</h4>
            <a class="btn-line" href="/index.html?propertyType=Hospitality&amp;listType=For Sale">For Sale</a>
            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Hospitality&amp;listType=For Lease">For Lease</a>

          </div>
        </div>
      </article>

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">

            <h4 class="card-property__title">Life Sciences</h4>
            <a class="btn-line" href="/index.html?propertyType=Life Science&amp;listType=For Sale">For Sale</a>

            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Life Science&amp;listType=For Lease">For Lease</a>
          </div>
        </div>
      </article>

      <article class="card-property is-search">
        <div class="card-property__wrap" href="http://www.kiddermathews.com/properties.php">
          <figure class="card-property__figure">
            <img class="card-property__img" src="http://127.0.0.1/kiddermathews/wp-content/uploads/2018/11/tmp-ft-image-800x480.jpeg" alt="">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title">Speciality</h4>
            <a class="btn-line" href="/index.html?propertyType=Other&amp;listType=For Sale">For Sale</a>

            <hr class="sep">
            <a class="btn-line" href="/index.html?propertyType=Othere&amp;listType=For Lease">For Lease</a>
          </div>
        </div>
      </article>

    </div>
  </div>
</section>
