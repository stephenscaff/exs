<?php
/**
 * Views/Properties/Property_Types
 *
 * Search Mast for properties
 *
 * @author    Stephen Scaff
 * @package   jumpoff/kidder
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$heading_title = get_field('heading_title') ;
$property_types = get_field('property_types') ;

?>

<section class="properties pad">
  <div class="grid-lg">
    <header class="heading">
      <h3 class="heading__title"><?php echo $heading_title; ?></h3>
    </header>
    <div class="properties__grid grid-2-to-5">
      <?php
      foreach ( $property_types as $property_type ) :
        $title = $property_type['title'];
        $image_id = $property_type['image']['id'];
        $img = jumpoff_ft_img('full', $image_id);
        $url_sale = $property_type['url_for_sale'];
        $url_lease = $property_type['url_for_lease'];
      ?>

      <article class="card-property is-property-type">
        <div class="card-property__wrap">
          <figure class="card-property__figure">
            <img class="card-property__img" src="<?php echo $img->url; ?>" alt="<?php echo $img->id; ?>">
          </figure>

          <div class="card-property__main">
            <h4 class="card-property__title"><?php echo $title; ?></h4>
            <?php if ($url_sale) : ?>
              <div class="card-property__item">
                <a class="btn-line" href="<?php echo $url_sale; ?>">For Sale</a>
              </div>
            <?php endif; ?>
            <?php if ($url_lease) : ?>
              <div class="card-property__item">
                <a class="btn-line" href="<?php echo $url_lease; ?>">For Lease</a>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
    </div>
  </div>
</section>
