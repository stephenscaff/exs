<?php
/**
 * Views/Properties/Search-Mast
 *
 * Search Mast for properties
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$located_id = jumpoff_get_id();
$mast_pretitle = get_field('mast_pretitle', $located_id) ;
$mast_title = get_field('mast_title', $located_id) ;
$mast_text = get_field('mast_text', $located_id);
$mast_img = get_field('mast_image', $located_id);
$ft_img = jumpoff_ft_img('full');

?>

<section class="mast has-search">
  <?php if ($mast_img) : ?>
    <figure class="mast__figure" style="background-image:url(<?php echo $mast_img['url']; ?>)"></figure>
  <?php else : ?>
    <figure class="mast__figure" style="background-image:url(<?php echo $ft_img->url ?>)"></figure>
  <?php endif; ?>
    <div class="grid">
      <header class="mast__header">
        <?php if ($mast_pretitle) : ?><span class="mast__pretitle"><?php echo $mast_pretitle; ?></span><?php endif; ?>
        <h1 class="mast__title"><?php echo $mast_title; ?></h1>
      </header>
      <div class="mast__search">
        <form id="js-search-form" class="" action="<?php echo get_site_url(); ?>/properties/">
          <div class="search-group">
            <div class="search-group__grid">

              <div class="search-group__main">
                <i class="search-group__icon icon-search"></i>
                <input id="js-search-input" class="search-group__input" name="term" type="text" placeholder="Search by location, address, building name, or broker">
              </div>

              <div class="search-group__controls">
                <div class="search-group__toggles">
                  <div class="radio-toggles">
                    <label class="radio-toggle">
                    <input class="radio-toggle__input" type="radio" name="search-toggle[]" value="For Sale" checked>
                      <span class="btn-line">For Sale</span>
                    </label>
                    <label class="radio-toggle is-line">
                    <input class="radio-toggle__input" type="radio" value="For Lease" name="search-toggle[]">
                      <span class="btn-line">For Lease</span>
                    </label>
                  </div>
                </div>
              <button class="search-group__btn btn" type="submit">Search</button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>

<script>

  /**
   * Forward Search Results
   */
  function forwardToSearchResults() {
    const searchTerm = $('#js-search-input').val();
    const listingType = $("input[name='search-toggle[]']:checked").val();
    let url = '<?php echo get_site_url(); ?>/properties/index.html?listType='+listingType;

    if (searchTerm) {
      url += '&term='+searchTerm;
    }

    window.location.href = url;
  }

  $('.search-group__btn').on("click", function (event) {
      event.preventDefault();
      forwardToSearchResults();
  });

  $('#js-search-input').on("keypress", function (event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      forwardToSearchResults();
    }
  });

</script>
