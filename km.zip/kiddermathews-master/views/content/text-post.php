<?php
/**
 * Views/Content/Text-Post
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) return;

global $post;

$title = get_the_title();
$url = get_the_permalink();
$pretitle = get_the_time('m.d.y');
$post_subtitle = get_field('post_subtitle', $post->ID);

if (is_post_type('market_report') OR is_post_type('office_location') OR is_post_type('trend_article')) {
  $state = jumpoff_term('state', $post->ID);
  $specialty = jumpoff_term('specialty', $post->ID);
  $pretitle = ($state ? $state->name . ' | ': '') . ($specialty ? $specialty->name : '');
}

?>

<article class="text-post">
  <a class="text-post__link" href="<?php echo $url; ?>">
    <div class="text-post__main">
      <span class="text-post__meta">
        <?php echo $pretitle; ?>
      </span>

      <h4 class="text-post__title"><?php echo $title; ?></h4>
      <?php if ($post_subtitle && is_post_type('market_report')) : ?>
        <span class="text-post__subtitle"><?php echo $post_subtitle; ?></span>
      <?php endif; ?>
      <span class="text-post__btn btn-line">Read More</span>
    </div>
  </a>
</article>
