<?php
/**
 * Views/Content/Professional
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) return

$pro_title = get_the_title();
$pro_url = get_the_permalink();
$pro_title = get_the_title();
$pro_position = get_field('professional_position');
$pro_location = jumpoff_term('location');
$pro_speciality = jumpoff_term('specialty');
$pro_email = get_field('professional_email');
$pro_phone = get_field('professional_phone');
$pro_tel_link = format_tel_link($pro_phone);
$ft_img = jumpoff_ft_img('full');

?>

<article class="card-pro">
  <a class="card-pro__link" href="<?php echo $pro_url; ?>">
    <figure class="card-pro__figure">
      <?php if ($ft_img->url) : ?>
        <img class="card-pro__img is-png" src="<?php echo $ft_img->url; ?>" alt="<?php echo $ft_img->alt; ?>"/>
      <?php endif; ?>
    </figure>
    <div class="card-pro__main">
      <header class="card-pro__header">
        <h4 class="card-pro__title"><?php echo $pro_title; ?></h4>
        <?php if ($pro_position): ?>
        <span class="card-pro__position"><?php echo $pro_position; ?></span>
        <?php endif; ?>
      </header>
      <?php if ($pro_speciality && !is_page('leadership')) : ?>
        <span class="card-pro__speciality"><?php echo $pro_speciality->name; ?></span>
     <?php endif; ?>
      <?php if ($pro_location) : ?>
      <span class="card-pro__city-state"><?php echo $pro_location->name; ?></span>
      <?php endif; ?>
    </div>
    <footer class="card-pro__footer">
      <span class="card-pro__email" data-nested-link="mailto:<?php echo $pro_email; ?>"><?php echo $pro_email; ?></span>
      <span class="card-pro__tel" data-nested-link="tel:<?php echo format_tel_link($pro_tel_link); ?>"><?php echo $pro_phone; ?></span>
    </footer>

    <div class="card-pro__btn"><span class="btn-line">View Profile</span></div>
  </a>
</article>
