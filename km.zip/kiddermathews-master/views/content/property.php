<?php
/**
 * Views/Content/Property
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) return

?>
<article class="card-property">
  <a class="card-property__link" href="">
    <figure class="card-property__figure">
      <img class="card-property__img" src="http://source.unsplash.com/egRzhd8YMwM/800x480/" alt=""/>
    </figure>
    <div class="card-property__main">

      <h4 class="card-property__title">Seattle Fancypants Bldg</h4>

      <div class="card-property__item">
        <span class="card-property__label">City/State</span>
        <span class="card-property__value">Seattle, WA</span>
      </div>
      <div class="card-property__item">
        <span class="card-property__label">Square Ft</span>
        <span class="card-property__value">24,000</span>
      </div>
      <div class="card-property__item">
        <span class="card-property__label">Status</span>
        <span class="card-property__value">For Sale</span>
      </div>

      <span class="card-property__btn btn-line">View Property</span>

    </div>
  </a>
</article>
