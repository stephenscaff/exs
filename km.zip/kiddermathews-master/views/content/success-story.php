<?php
/**
 * Views/Content/Success-Story
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) return;

$id = get_the_ID();
$story_title = get_the_title();
$story_url = get_the_permalink();
$story_img = jumpoff_ft_img('full');
$story_img_url = $story_img->url;
if (empty($story_img_url)) $story_img_url = jumpoff_random_img();

$specialty_term = get_the_terms($id, 'specialty');
$location_term = get_the_terms($id, 'location');

?>

<article class="card-block is-story">
  <a class="card-block__link" href="<?php echo $story_url; ?>">
    <figure class="card-block__figure" style="background-image: url(<?php echo $story_img_url; ?>)"></figure>
    <header class="card-block__header">
      <div>
        <span class="card-block__meta">
          <?php if ($specialty_term) echo $specialty_term[0]->name; ?>
        </span>
        <h3 class="card-block__title"><?php echo $story_title; ?></h3>
      </div>
    </header>
  </a>
</article>
