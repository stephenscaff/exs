<?php
/**
 * Views/Content/Post
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$post_url = get_the_permalink();
$post_title = get_the_title();
$post_img = jumpoff_ft_img('large');
$post_img_url = $post_img->url;
$post_excerpt = jumpoff_excerpt(150);
$post_cat = jumpoff_cat('name');
$date = get_the_time('m.j.Y');
$article_source = get_field('article_source');


if (empty($post_img_url)) {
  $post_img_url = jumpoff_random_img();
}

$date = get_the_time('m.d.y');
// $location_term = jumpoff_term('location');
// $pretitle = $post_cat . ' | ' . $location . ' | ' . $date;

?>

<article class="card-post">
  <a class="card-post__link" href="<?php echo $post_url; ?>">
    <figure class="card-post__figure">
      <img class="card-post__img" src="<?php echo $post_img_url; ?>" alt="<?php echo $post_img->alt; ?>"/>
    </figure>
    <div class="card-post__main">
      <div>
      <span class="card-post__meta">
        <?php if (!empty($post_cat)) { echo $post_cat . ' | '; } ?>
        <?php if (!empty($location_term->name) && !is_trend_articles()) { echo $location_term->name . ' | '; } ?>
        <?php echo $date; ?>
      </span>

      <h4 class="card-post__title"><?php echo $post_title; ?></h4>
      <?php if ($article_source) : ?>
        <span class="card-post__source"><?php echo $article_source; ?></span>
      <?php endif; ?>
      <p class="card-post__excerpt"><?php echo $post_excerpt; ?></p>
      <span class="card-post__btn btn-line">Read More</span>
    </div>
    </div>
  </a>
</article>
