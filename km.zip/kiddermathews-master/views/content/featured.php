<?php
/**
 * Views/Content/Featured
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$ft_link = get_the_permalink();
$ft_title = get_the_title();
$ft_img = jumpoff_ft_img('full');
$ft_excerpt = jumpoff_excerpt('160');

$ft_img = jumpoff_ft_img('large');
$ft_img_url = $ft_img->url;

if (empty($ft_img_url)) {
  $ft_img_url = jumpoff_random_img();
}

?>

<section class="featured-post has-border">
  <div class="grid-lg">
    <a class="featured-post__link" href="<?php echo $ft_link; ?>">
      <div class="featured-post__grid">
        <header class="featured-post__header">
          <div>
            <span class="featured-post__meta">
              Featured - <span data-sim-link="<?php echo jumpoff_cat('url'); ?>"><?php echo jumpoff_cat('name'); ?></span>
            </span>

            <h2 class="featured-post__title"><?php echo $ft_title; ?></h2>

            <p class="featured-post__excerpt"><?php echo $ft_excerpt; ?></p>

            <div class="featured-post__btn">
              <span class="btn-line">Read More</span>
            </div>
          </div>
        </header>

        <figure class="featured-post__figure">
          <img src="<?php echo $ft_img_url; ?>" alt="<?php echo $ft_img->alt; ?>">
        </figure>
      </div>
    </a>
  </div>
</section>
