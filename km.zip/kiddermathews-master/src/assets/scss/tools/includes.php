<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

require_once('acf-modules.php');
require_once('acf-index-pages.php');
require_once('acf-to-search.php');
require_once('acf-extras.php');
