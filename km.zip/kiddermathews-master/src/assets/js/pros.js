import Utils from './components/_Utils.js';
import * as MapUtils from './components/Maps/_MapUtils';
import GoogleMapsApi from './components/Maps/_GoogleMapsApi';
import { stylers }   from './components/Maps/_stylers.js';
import propertyMarkerTmpl from './components/Maps/templates/_propertyMarker.tmpl.js';

/**
 * Init Property Map
 * Main map rendering function that uses our GMaps API class
 */
function PropertiesMap() {

  const gmapApi = new GoogleMapsApi();
  const mapEl = document.querySelector('.js-property-map');
  const properties = Utils.fetchData(propertiesData);

  gmapApi.load().then(() => {
   properties.then((data) => {
     renderMap(mapEl, data.results)
     // if (data.results == 0) {
     //   removeMapModule()
     // } else {
     //   renderMap(mapEl, data.results)
     // }
   });
 })
}

// Init if present
if (document.querySelector('.js-property-map')) {
  PropertiesMap();
}

/**
 * Render Map
 * @param {map obj} mapEl - Google Map
 * @param {Promise | obj} mapEl - resolved promise of map data
 */
function renderMap(mapEl, results) {

  /**
   * Map Options
   * @property {mapType} mapTypeId - type of map
   * @property {obj} styles - map styles json
   * @property {number} zoom - intial zoom level
   */
  const options = {
    mapTypeId:   google.maps.MapTypeId.ROADMAP,
    styles:      stylers.styles,
    zoom:        8
  }

  /**
   * Google map instance
   * @type {Map}
   */
  const map = new google.maps.Map(mapEl, options);

  addMarkers(map, results);
}

/**
 * Add Markers
 * @param {map obj} mapEl - Google Map
 * @param {obj} markers - object of marker data
 */
function addMarkers(map, markers) {

  /**
   * Infowindow Instance
   * @type {InfoWindow}
   */
  const infowindow = new google.maps.InfoWindow();

  /**
   * Custom Icon object
   * @property {string} url - marker image base64
   * @property {Size}
   */
  const icon = {
    url:        stylers.icons.red,
    scaledSize: new google.maps.Size(40, 40)
  }

  map.markers = [];

  markers.forEach((result, i) => {

    /**
     * Marker Template
     * @type {function} MarkerTmpl - passes data to marker
     * @param {object} result - Marker Data
     * @requires _MarkerTmpl.js
     */
    let tmpl = propertyMarkerTmpl(result);

    if (result.latitude == null  || result.longitude == null) return;

    let marker = new google.maps.Marker({
      position: new google.maps.LatLng(
        result.latitude,
        result.longitude,
      ),
      map: map,
      icon: icon,
      title: result.listing_name,
      listing_type: result.listing_type,
      animation: google.maps.Animation.DROP,
      location: {
        address:result.listing_address,
        city: result.city,
        state: result.state_code,
      },
      content: tmpl
    });

    map.markers.push(marker);
    handleMarkerClick(map, marker, infowindow);
  });
  //handleFilters(map, marker, infowindow)
  MapUtils.centerMap(map, map.markers);
  handleFilters(map, map.markers, infowindow)
  //console.log('map zoom', map.getZoom())
}

/**
 * Render Map
 *
 * @param {map obj} mapEl
 * @param {marker} marker
 * @param {infowindow} infoWindow
 */
function handleMarkerClick(map, marker, infowindow) {

  google.maps.event.addListener(marker, 'click', function() {
    MapUtils.toggleInfoWindow(map, marker, infowindow)
  });

  google.maps.event.addListener(map, 'click', function(event) {
    if (infowindow) {
      infowindow.close(map, infowindow);
    }
  });
}


/**
 * Handle Filters
 *
 * @param {map obj} mapEl
 * @param {marker} marker
 * @param {infowindow} infoWindow
 */
function handleFilters(map, markers, infowindow) {
  const filters = document.querySelectorAll('.js-filter');

  Utils.forEach ( filters, function (index, filter) {
    filter.addEventListener('click', function(e) {
      e.target.classList.add('.is-active');

      if (infowindow) {
        infowindow.close(map, infowindow);
      }

      let filterVal = filter.dataset.filter.toLowerCase();
      filterMarkers(filterVal, markers);
   });
 });
}


/**
 * Filter Markers
 *
 * @param {string} filterVal - the clicked on filter value
 * @param {google map markers} markers
 */
function filterMarkers(filterVal, markers) {

  Utils.forEach( markers, function(index, marker) {

    // Normalize Values
    let markerListType = marker.listing_type.replace(/\s/g, '').toLowerCase();
    let filter = filterVal.replace(/\s/g, '').toLowerCase();

    marker.setVisible(false);

    if (markerListType == filter) {
      marker.setVisible(true);
      //MapUtils.toggleInfoWindow(map, marker, infowindow)
    } else {
      marker.setVisible(false);
    }
  });
}

/**
 * Remove Map Module
 */
function removeMapModule() {
  const mapModule = document.querySelector('.properties-map.module')
  mapModule.parentNode.removeChild(mapModule)

  return
}
