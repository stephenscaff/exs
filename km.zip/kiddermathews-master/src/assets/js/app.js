import "@babel/polyfill";
import './components/_polys.js'
import Utils from './components/_Utils.js'
import './components/_Sniffers.js'
import PageTransitions from './components/_PageTransitions'
import HeaderState from './components/_HeaderState.js'
import MenuSmall from './components/_MenuSmall.js'
import MastPromo from './components/_MastPromo.js'
import NestedLinks from './components/_NestedLinks.js'
import ShowMore from './components/_ShowMore.js'
import CompletedTransaction from './components/_CompletedTransactions.js'
import Spanizr from './components/_Spanizr.js'
import ReadMore from './components/_ReadMore.js'
import ProfessionalsNav from './components/PageNav/_ProfessionalsNav.js'
import ScrollDown from './components/PageNav/_ScrollDown.js'
import SvgEffects from './components/SvgEffects/_SvgEffects.js'
import Dropdowns from './components/_Dropdowns.js'
import ExternalLinks from './components/_ExternalLinks.js'
import ResultsControls from './components/_ResultsControls.js'
import Accordion from './components/_Accordions.js'
import CustomSelect from './components/_CustomSelect.js'
import VimeoPopUps from './components/_VimeoPopUps.js'

PageTransitions.init();
HeaderState.init();
MenuSmall.init();
MastPromo.init();
ReadMore.init();
ShowMore.init();
CompletedTransaction.init();
Spanizr.init();
SvgEffects.init();
ExternalLinks.init();
ResultsControls.init();
NestedLinks.init();
ProfessionalsNav.init();
ScrollDown.init();

if (document.querySelectorAll('[data-vimeo-popup]')) {
  VimeoPopUps.init();
}

// Dropdowns inits
if ( document.querySelectorAll('.js-dropdown').length ) {
  Dropdowns.init();
}

// Accordion init
if ( document.querySelectorAll('.accordion').length ) {
  Accordion.init();
}

// Custom Select inits
if (document.querySelector('[id*="js-select-"]')) {
  var selectSpecialty = new CustomSelect({
    elem: "js-select-specialty"  // id of the original select element
  });

  var selectLocation = new CustomSelect({
    elem: "js-select-location"  // id of the original select element
  });
}
