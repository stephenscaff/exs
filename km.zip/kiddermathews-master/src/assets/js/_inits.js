/*jshint -W030*/
/*globals feature: false */

/**
 * Global Site inits1
 */
var site = {

  /**
   * SCG Draw Animations
   * @see /vendor/_vivus.js
   */
  svgDraw: function() {
    var svgDraws = document.querySelectorAll('.js-svg-draw');
    for (var i = 0; i < svgDraws.length; i++) {
      new Vivus(svgDraws[i], {
        // type: 'oneByOne',
        duration: 200,
        animTimingFunction: Vivus.EASE
      });
    }
  },

  /**
   * SCG Draw Animations
   * @see /vendor/_vivus.js
   */
  svgHover: function() {

    var svgTriggers = document.querySelectorAll('.js-svg-trigger');
      for (var i = 0; i < svgTriggers.length; i++) {
    	   var svg = svgTriggers[i].querySelector('.js-svg-hover');
    	    svgTriggers[i].addEventListener("mouseover", function() {

          console.log('svg to trigger', svg)
          new Vivus(svg, {
            type: 'oneByOne',
            duration: 100,
            //animTimingFunction: Vivus.EASE
          });
      });
    }
  },
};

if (document.querySelector('.js-svg-draw')) {
  // console.log('draw')
  site.svgDraw();
}

if (document.querySelector('.js-svg-hover')) {
  site.svgHover();
}

/**
 * Bind Touch Start On mobile.
 */
if ( WhoDis.anyMobile() ) {
  document.addEventListener("touchstart", function(){}, true);
}

/**
 * Add Classes for IEs
 */
if ( WhoDis.anyMS() ) {
  html.classList.add('is-ms');
}

if ( WhoDis.IE() ) {
  html.classList.add('is-ie');
}

if ( WhoDis.IE10() ) {
  html.classList.add('is-ie10');
}

if ( WhoDis.Edge() ) {
  html.classList.add('is-edge');
}


//
// var svgTriggers = document.querySelectorAll('.js-svg-trigger');
//   for (var i = 0; i < svgTriggers.length; i++) {
// 	   var svg = svgTriggers[i].querySelector('.js-svg-hover');
// 	    svgTriggers[i].addEventListener("mouseover", function() {
//
//       console.log('svg to trigger', svg)
//       new Vivus(svg, {
//         type: 'oneByOne',
//         duration: 100,
//         animTimingFunction: Vivus.EASE
//       });
//   });
// }
