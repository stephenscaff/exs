import Utils from './components/_Utils.js';
import * as MapUtils from './components/Maps/_MapUtils';
import GoogleMapsApi from './components/Maps/_GoogleMapsApi';
import { stylers }   from './components/Maps/_stylers.js';
import locationMarkerTmpl from './components/Maps/templates/_locationMarker.tmpl.js';
import locationListTmpl from './components/Maps/templates/_locationList.tmpl.js';

const gmapApi      = new GoogleMapsApi('locations');
const mapEl        = document.querySelector('.js-locations-map');
const listingsEl   = document.querySelector('.js-locations-listings');
const listingsData = Utils.fetchData(`${appGlobals.locations_api}?orderby=menu_order&order=asc&per_page=100&_embed=1`);

/**
 * Locations Map
 * Map for the split view on Office Locations Archive
 */
const LocationsMap = {

   /**
    * Init
    */
   init() {
     this.bindEvents();
   },

   bindEvents() {
     gmapApi.load().then(() => {
       LocationsMap.renderMap(listingsData);
     });
   },

   /**
    * Render Map
    */
   renderMap(data) {

     /**
      * Map Options
      * @property {LatLng} center - center default
      * @property {mapType} mapType - type of map
      * @property {obj} styles - map styles json
      * @property {number} zoom - intial zoom level
      * @property {boolean} scrollWheel - disable
      */
     const options = {
       center:      google.maps.LatLng(0, 0),
       mapTypeId:   google.maps.MapTypeId.ROADMAP,
       styles:      stylers.styles,
       zoom:        6
     }

     /**
      * Custom Icon object
      * @property {string} url - marker image base64
      * @property {Size}
      */
     const icon = {
       url:        stylers.icons.red,
       scaledSize: new google.maps.Size(40, 40)
     }

     /**
      * Infowindow Instance
      * @type {InfoWindow}
      */
     const infowindow = new google.maps.InfoWindow()

     /**
      * Google map instance
      * @type {Map}
      */
     const map = new google.maps.Map(mapEl, options)

     /**
      * Markers Array
      */
     map.markers = [];

     /**
      * Create Markers on resolution of promise of data
      * Loop through data and add markers
      * @param {object} data_listings
      * @requires data-listings.js
      */
     data.then((results) => {

       //console.log('results', results)
       results.forEach((result, i) => {
         /**
          * Marker Template
          * @type {function} MarkerTmpl - gets marker template, passes in data.
          * @param {object} data_listing - Marker Data
          * @requires _MarkerTmpl.js
          */
         let tmpl = locationMarkerTmpl(result)

         if (!result.location_map) return

         // Marker Object
         const marker = new google.maps.Marker({
           position: new google.maps.LatLng(
             result.location_map.lat,
             result.location_map.lng
           ),
           map: map,
           icon: icon,
           title: result.property_title,
           animation: google.maps.Animation.DROP,
           location: {
             city: result.location.city,
             state: result.location.state,
           },
           content: tmpl
         });

         // push markers to array
         map.markers.push(marker)

         LocationsMap.handleMarkerClick(map, marker, infowindow)
         // this.handleListClick(map, marker, infowindow)
       })

       MapUtils.centerMap(map, map.markers)
       LocationsMap.setMobileZoom(map, map.markers)
       LocationsMap.renderList(listingsData)

       data.then((results) => {
         LocationsMap.handleListClick(map, map.markers, infowindow)
         LocationsMap.handleFilters(map, map.markers, infowindow)
         ///3MapInit.filterMarkers(map, map.markers, infowindow);
       });

     });
   },

   /**
    * Set Mobile Zoom
    * Using matchMedia to decrease zoom level on
    * mobile sizes via map.setZoom()
    */
   setMobileZoom(map, markers) {
     let mqMax = window.matchMedia("(max-width: 54em)")

     if (mqMax.matches) {
       map.setZoom(4)
       MapUtils.centerMap(map, markers)

     } else {
       map.setZoom(6)
       MapUtils.centerMap(map, markers)
     }

     mqMax.addListener(function(e) {
       if (e.matches) {
         map.setZoom(4)
         MapUtils.centerMap(map, markers)
       } else {
        map.setZoom(6)
        MapUtils.centerMap(map, markers)
       }
     });
   },

 /**
  * Handle Filters
  * On filter click, pass filtering to filterMarker, filterListing methods
  */
 handleFilters(map, markers, infowindow) {
   const filters = document.querySelectorAll('.js-filter');
   const filterAll = document.querySelectorAll('[data-filter="all"]');

   Utils.forEach ( filters, function (index, filter) {

     filter.addEventListener('click', function(e) {

       if (infowindow) {
         infowindow.close(map, infowindow)
       }

       // console.log(filter)
       let filterVal = filter.dataset.filter.toLowerCase()

       LocationsMap.filterListings(filterVal)
       LocationsMap.filterMarkers(filterVal, markers)
    });
  });
 },


 /**
  * Filter Listings
  * @param {string} filterVal - the clicked on filter value
  */
 filterListings(filterVal) {
   let listings = document.querySelectorAll('.listing')

   Utils.forEach(listings, function(index, listing) {

     // Normalize Values
     let listingCity = listing.dataset.city.toLowerCase()
     let listingState = listing.dataset.state.toLowerCase()
     let city = listingCity.replace(/\s/g, '')
     let state = listingState.replace(/\s/g, '')
     let filter = filterVal.replace(/\s/g, '')

     // console.log('select val', filter, 'list state', state)
     listing.classList.add('is-hidden')

     if (city == filter) {
       listing.classList.remove('is-hidden')
       listing.classList.add('is-visible')
     }

     if (state == filter) {
       listing.classList.remove('is-hidden')
       listing.classList.add('is-visible')
     }

     if (filter == 'all_cities' || filter == 'all_states') {
       listing.classList.remove('is-hidden')
       listing.classList.add('is-visible')
     }
   });
 },


 /**
  * Filter Markers
  * @param {string} filterVal - the clicked on filter value
  * @param {google map markers} markers
  */
 filterMarkers(filterVal, markers) {

   Utils.forEach(markers, function(index, marker) {

     // Normalize Values
     let markerCity = marker.location.city.toLowerCase()
     let markerState = marker.location.state.toLowerCase()
     let city = markerCity.replace(/\s/g, '')
     let state = markerState.replace(/\s/g, '')
     let filter = filterVal.replace(/\s/g, '')

     marker.setVisible(false)

     if (city == filter) {
       marker.setVisible(true)
     }

     if (state == filter) {
       marker.setVisible(true)
     }

     if (filter == 'all_cities' || filter == 'all_states') {
       marker.setVisible(true)
     }
   })
 },

 /**
  * Marker Click Handler
  * Toggle a single info window instance across markers
  * @param {google Map}
  * @param {google Marker}
  * @param {google InfoWindow}
  */
 handleMarkerClick(map, marker, infowindow) {

   /**
    * Click Event
    * @param {Marker}
    */
   google.maps.event.addListener(marker, 'click', function() {
     MapUtils.toggleInfoWindow(map, marker, infowindow)
   });

    /**
     * Close InfoWindow on map click.
     */
    google.maps.event.addListener(map, 'click', function(event) {
      if (infowindow) {
        infowindow.close(map, infowindow)
      }
    });
  },

 /**
  * Render Listings sidebar el
  * @param {object} data
  */
 renderList(data) {
   data.then((results) => {
     results.forEach((result) => {
       let tmpl = locationListTmpl(result)
       listingsEl.insertAdjacentHTML('beforeend', tmpl)
     })
   })
 },

 /**
  * List Click Handler
  * @param {google map} map
  * @param {google marker} marker - current marker object
  * @param {google infoWindow} infowindow
  */
 handleListClick(map, currentMarker, infowindow) {
   let listingLinks = document.querySelectorAll('.js-listing-trigger')

   listingLinks.forEach((listingLink, i) => {
     listingLink.addEventListener('click', function() {

       MapUtils.toggleInfoWindow(map, currentMarker[i], infowindow)

       map.markers.forEach((marker) => {
         marker.setVisible(true)
       })
     })
   })
  }
};

LocationsMap.init();
