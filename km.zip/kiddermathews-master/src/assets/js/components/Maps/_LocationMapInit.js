import Utils from '../../components/_Utils.js'
import * as MapUtils from './_MapUtils';
import GoogleMapsApi from './_GoogleMapsApi';
import { stylers }   from './_stylers.js';
import locationMarkerTmpl from './templates/_locationMarker.tmpl.js';
import locationListTmpl from './templates/_locationList.tmpl.js';

/**
 * Replaced this with MapInit.js
 * MapInit
 * Initializes google map,
 * creates a series of markers from external data,
 * uses a with a single custom infoWindow instance
 * @requires GoogleMapsApi.js
 * @requires stylers
 * @requires data_listings
 * @requires MarkerTmpl
 * @requires Utils.fetchDatals
 * @requires appGlobals.locations_api = global var
 */
class LocationsMapInit {

  constructor() {
    this.gmapApi = new GoogleMapsApi();
    this.mapEl = document.querySelector('.js-locations-map');
    this.listingsEl = document.querySelector('.js-locations-listings');
    this.data = Utils.fetchData(`${appGlobals.locations_api}?per_page=100&order=desc&_embed=1`);
  }

  /**
   * Kicks things off on promise to gmaps api
   * @requires _GoogleMapsApi.js
   */
  init() {
    this.gmapApi.load().then(() => {
      this.renderMap(this.data)
      //this.renderList(this.data)
    });
  }

  /**
   * Render Map
   * Primary creation of map and markers.
   */
  renderMap(data) {

    /**
     * Map Options
     * @property {LatLng} center - center default
     * @property {mapType} mapType - type of map
     * @property {obj} styles - map styles json
     * @property {number} zoom - intial zoom level
     * @property {boolean} scrollWheel - disable
     */
    const options = {
      center:      google.maps.LatLng(0, 0),
      mapTypeId:   google.maps.MapTypeId.ROADMAP,
      styles:      stylers.styles,
      zoom:        5,
      scrollwheel: false
    }

    /**
     * Custom Icon object
     * @property {string} url - marker image base64
     * @property {Size}
     */
    const icon = {
      url:        stylers.icons.red,
      scaledSize: new google.maps.Size(40, 40)
    }

    /**
     * Infowindow Instance
     * Create a single infoWindow to swap out for each marker.
     * @type {InfoWindow}
     */
    const infowindow = new google.maps.InfoWindow();

    /**
     * Google map instance
     * @type {Map}
     */
    const map = new google.maps.Map(this.mapEl, options);

    /**
     * Markers Array
     * @type {array}
     */
    map.markers = [];

    /**
     * Create Markers on resolution of promise of data
     * Loop through data and add markers
     * @param {object} data_listings
     * @requires data-listings.js
     */
    data.then((results) => {
      results.forEach((result, i) => {

        /**
         * Marker Template
         * @type {function} MarkerTmpl - gets marker template, passes in data.
         * @param {object} data_listing - Marker Data
         * @requires _MarkerTmpl.js
         */
        let tmpl = locationMarkerTmpl(result);

        if (!result.location_map) return;

        const marker = new google.maps.Marker({
          position: new google.maps.LatLng(
            result.location_map.lat,
            result.location_map.lng
          ),
          map: map,
          icon: icon,
          title: result.property_title,
          animation: google.maps.Animation.DROP,
          location: {
            city: result.location.city,
            state: result.location.state,
          },
          content: tmpl
        });

        // push markers to array
        map.markers.push(marker);

        this.handleMarkerClick(map, marker, infowindow);

        //
        // this.handleListClick(map, marker, infowindow)

      });

      MapUtils.centerMap(map, map.markers);

      this.renderList(this.data)
    //
    // this.handleListClick(map, map.markers)
      data.then((results) => {
        this.handleListClick(map, map.markers, infowindow)
        this.filterMarkers(map, map.markers, infowindow);
      });

      // data.then((results) => {
      //   let listingLinks = document.querySelectorAll('.listing__link');
      //   listingLinks.forEach((listingLink, i) => {
      //     listingLink.addEventListener('click', function() {
      //       map.panTo(map.markers[i].getPosition());
      //       infowindow.setContent(map.markers[i].content);
      //       infowindow.open(map, map.markers[i]);
      //     })
      //   });
      // });
    });
  }


  /**
   * filter Markers
   * Logic to handle map filtering by category on click
   *
   * @param {obj} map - google map object
   */
  filterMarkers(map, markers, infowindow) {
     const filters = document.querySelectorAll('.js-filter');
     const filterAll = document.querySelectorAll('[data-filter="all"]');

     Utils.forEach ( filters, function (index, filter) {

       filter.addEventListener('click', function(e) {

         let filterVal = filter.dataset.filter.toLowerCase();

         Utils.forEach ( markers, function (index, marker) {
           let markerVal = marker.location.city.toLowerCase()

           // let count = 40;
           // let t = (count * index) + 30;

           if (filterVal != markerVal) {
             marker.setVisible(false);
             return;
           }
           if (filterVal == markerVal) {
               //marker.setVisible(true);

               marker.setVisible(true);
               MapUtils.toggleInfoWindow(map, marker, infowindow)

             } else {
               marker.setVisible(false);
             }
             if (filterVal == 'all') {
               marker.setVisible(true);
               this.animateMarkerIn(marker).bind(this);
             }
             // count++;
         });
       });
     });
  }


  /**
   * Marker Click Handler
   * Toggle a single info window instance across markers
   * @param {Map}
   * @param {Marker}
   * @param {InfoWindow}
   */
  handleMarkerClick(map, marker, infowindow) {

    /**
     * Click Event
     * @param {Marker}
     */
    google.maps.event.addListener(marker, 'click', function() {
      MapUtils.toggleInfoWindow(map, marker, infowindow)
    });

     /**
      * Close InfoWindow on map click.
      */
     google.maps.event.addListener(map, 'click', function(event) {
       if (infowindow) {
         infowindow.close(map, infowindow);
       }
     });
   }

  /**
   * Render Listings sidebar el
   */
  renderList(data) {
    data.then((results) => {
      results.forEach((result) => {
        let tmpl = locationListTmpl(result);
        this.listingsEl.insertAdjacentHTML('beforeend', tmpl);
      })
    })
  }

  /**
   * List Click Handler
   */
  handleListClick(map, currentMarker, infowindow) {
    let listingLinks = document.querySelectorAll('.js-listing-trigger');

    listingLinks.forEach((listingLink, i) => {
      listingLink.addEventListener('click', function() {

        MapUtils.toggleInfoWindow(map, currentMarker[i], infowindow)

        map.markers.forEach((marker) => {
          marker.setVisible(true);
        });
      })
    });
  }
}

export default LocationsMapInit;
