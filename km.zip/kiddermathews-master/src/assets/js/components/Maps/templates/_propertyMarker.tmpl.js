
/**
 * Marker Template
 * @param {obj} data - property data/json
 */

 let formatter = new Intl.NumberFormat('en-US', {
   style: 'currency',
   currency: 'USD',
 });


function propertyMarkerTmpl(data) {
  let priceOrSqFtLabel = data.list_price ? 'Price' : 'SF';
  let priceOrSqFt = data.list_price ? formatter.format(data.list_price) : data.sf_avail;

  let url = `/properties/single.html?listing=${data.listing_key}&property=${data.property_key}`;

  return `<article class="marker-box">
    <div class="marker-box__wrap">
      <div class="marker-box__grid">
        <figure class="marker-box__figure">
          <a href="${url}" target="_blank">
            <img class="marker-box__img" src="${data.property_photo}"/>
          </a>
        </figure>
        <div class="marker-box__main">
          <span class="marker-box__title">${data.property_name}</span>
          <address class="marker-box__address">
            <span class="marker-box__street">${data.property_address}</span>
            <span class="marker-box__city-state">${data.city} ${data.state_code} ${data.zip_postal_code}</span>
          </address>
          <span class="marker-box__info"><strong>Type</strong> ${data.property_type}</span>
          <span class="marker-box__info"><strong>${priceOrSqFtLabel}</strong> ${priceOrSqFt} </span>

          <a class="marker-box__btn btn-line" href="${url}" target="_blank">View Details</a>
        </div>
      </div>
    </div>
  </article>`;
}

export default propertyMarkerTmpl;
