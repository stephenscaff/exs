
/**
 * Marker Template
 * @param {obj} data - property data/json
 */
function locationMarkerTmpl(data) {
  return `<article class="marker-box">
    <div class="marker-box__wrap">
      <div class="marker-box__grid">
          <figure class="marker-box__figure">
            <a class="marker-box__btn" href="${data.link}">
              <img class="marker-box__img" src="${data.featured_image_thumb}"/>
            </a>
          </figure>
        <div class="marker-box__main">
          <span class="marker-box__title">${data.title.rendered}</span>
          <address class="marker-box__address">
            <span class="marker-box__address">${data.location_address}</span>
          </address>

          <a class="marker-box__btn btn-line" href="${data.link}">View Details</a>
        </div>
      </div>
    </div>
  </article>`;
}

export default locationMarkerTmpl;
