
/**
 * Marker Template
 * @param {obj} data - property data/json
 */
function locationListTmpl(data) {
  return `<article class="listing" data-city="${data.location.city}" data-state="${data.location.state}">
    <div class="listing__trigger js-listing-trigger" href="#">
      <h5 class="listing__title">${data.title.rendered}</h5>
      <address class="listing__address">${data.location_address}</address>
      <span class="listing__tel" data-nested-link="tel:${data.location_contact_numbers[0].number}">${data.location_contact_numbers[0].number}</span>
      <a class="listing__btn btn-line is-white" href="${data.link}">View Details</a>
    </div>
  </article>`;
}

export default locationListTmpl;
