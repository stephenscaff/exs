/**
 * Toggle Info Window
 * Toggle a single info window instance across markers
 * @param {Map}
 * @param {Marker}
 * @param {InfoWindow}
 */
export function toggleInfoWindow(map, marker, infowindow) {
  //map.panTo(marker.getPosition());
  infowindow.setContent(marker.content);
  infowindow.open(map, marker);
 }


 /**
  * Center Map
  * Figures out map center for
  * 1 or many markers
  * @param {Map}
  */
export function centerMap(map, marker){
  let addresses = [];
  const bounds = new google.maps.LatLngBounds()

  map.markers.forEach((marker) => {
    bounds.extend(marker.getPosition())

    let address = marker.location.address;
    addresses.push(address)
  });

  // A really shitty way to check if we have
  // more than one marker and not the same location
  if (map.markers.length > 1 && (addresses[0] != addresses[1])) {

    map.setCenter(bounds.getCenter())
    map.fitBounds(bounds)
    map.setZoom(map.getZoom()-1)
    console.log('zoom', map.getZoom())

  } else {
    map.setCenter(bounds.getCenter())
    map.setZoom(10);
  }
}


/**
 * Handle Active State for filter links
 * @param {html element} target - clicked target
 */
export function activeState(target) {
  const active = document.querySelector('.is-active');

  if (active){
   active.classList.remove('is-active');
  }

  target.currentTarget.classList.add('is-active');
}


/**
 * animate Marker
 * Animate markers into exists.
 *
 * @param {obj} marker - google map marker
 * @param {number} timeout - timeout value
 */
export function animateMarkerIn(marker) {

  marker.setVisible(true);
  marker.setVisible(false);

  setTimeout(() => {
    marker.setVisible(true);
    //marker.setAnimation(google.maps.Animation.DROP);
    marker.setAnimation(google.maps.Animation.BOUNCE);
    setTimeout(() => {
      marker.setAnimation(null);
    }, 700);
  }, 10);
}
