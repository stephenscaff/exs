import Utils from '../components/_Utils.js'

/**
 * Menu Viewer
 * Menu Fade Interaction.
 *
 * @author: Stephen Scaff
 * @version 1.2.0;
 * @see assets/scss/_site-menu.js
 * @see partials/partial-site-menu.php
 */

const MastPromo = (() => {

  const mastEl = document.querySelector('.js-mast-promo'),
        mastLinks =   document.querySelectorAll('.js-mast-promo-link'),
        mastBGs =  document.querySelectorAll('.js-mast-promo-bg'),
        mastTitles =  document.querySelectorAll('.js-mast-promo-title'),
        mastTitleFirst = document.querySelector('.mast-promo__title.is-first ');


  return {

    /**
     * Init
     */
    init() {
      if (!mastEl) return;
      this.bindEvents();
    },

    /**
     * Bind Events
     */
    bindEvents() {

      Utils.forEach ( mastLinks, function (index, mastLink) {
          MastPromo.transitionLayer(mastLink, index);
          MastPromo.hoverState(mastEl, mastLink);
      });
    },

    hoverState(el, link) {
      link.addEventListener('mouseover', function() {
          MastPromo.showLayer(el);
          MastPromo.hideLayer(mastTitleFirst);
      });
      link.addEventListener('mouseout', function() {
          MastPromo.hideLayer(el);
          MastPromo.showLayer(mastTitleFirst);
      });
    },

    /**
     * Transition Layer
     * Transitions layer to active stat on hover/foucs
     * @param  {Object}  el the element / layer that transitions to active
     * @param  {number}  i the index of the current active el.
     */
    transitionLayer(el, i){
      var activeLayer = mastBGs[i];
      var activeTitle = mastTitles[i];

      el.addEventListener('mouseover', function() {
          MastPromo.showLayer(activeLayer);
          MastPromo.showLayer(activeTitle);
      });

      el.addEventListener('focus', function() {
          MastPromo.showLayer(activeLayer);
          MastPromo.showLayer(activeTitle);
      });

      el.addEventListener('mouseout', function() {
          MastPromo.hideLayer(activeLayer);
          MastPromo.hideLayer(activeTitle);
      });

      el.addEventListener('blur', function() {
          MastPromo.hideLayer(activeLayer);
          MastPromo.hideLayer(activeTitle);
      });

    },

    /**
     * Show Layer
     * @param  {Object}  el the element / layer to display
     */
    showLayer(el){
      el.classList.add('is-active');
    },

    /**
     * Hide Layer
     * @param  {Object}  el the element / layer to hide
     */
    hideLayer(el){
      el.classList.remove('is-active');
    },
  };
 })();

export default MastPromo;
