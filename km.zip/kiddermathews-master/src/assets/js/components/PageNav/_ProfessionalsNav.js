
import PageNav from './_PageNav.js'

/**
 * Professional Nav
 * Scrolling page nav on single profs pages
 * @requires {class} PageNav
 */
let anchorLinks = document.querySelectorAll('.js-page-nav a[href^="#"]');
let mqMed = window.matchMedia('(min-width: 32em)');
let anchorOffset = 200;

if (mqMed.matches) {
  let anchorOffset = 270;
}

let ProfessionalsNav = new PageNav(anchorLinks, anchorOffset);

export default ProfessionalsNav;
