
import  smoothscroll from './_polyfill';

/**
 * Page Nav
 * Scroll anchor animation thing.
 * @requires smoothscroll-polyfill
 */
class PageNav {

  /**
   * @param {elements} links - collection of anochor links
   * @param {number} offset - number in pixels to offset anchor.
   */
  constructor(links, offset) {
    this.links = links;
    this.offset = offset;
  }

  /**
   * Init scrollBy poly
   * Kick off anchor scroll handler
   */
  init() {
    smoothscroll.polyfill();
    this.handler();
  }

  /**
   * Handler
   * Loop though anchors, listen for click.
   */
  handler() {
    //this.links.forEach(each => (each.onclick = this.linkScroll));
    this.links.forEach((link) => {
      link.addEventListener("click", (e) => {
        this.linkScroll(e)
      }, false);
    });
  }

  /**
   * Link Scroll
   * Do the animated scroll to anchor thang.
   * @param {event} event - Click event
   */
  linkScroll(event) {

    const distanceToTop = el => Math.floor(el.getBoundingClientRect().top);
    event.preventDefault();
    const targetID = event.target.getAttribute("href");
    const targetAnchor = document.querySelector(targetID);

    if (!targetAnchor) return;

    const originalTop = distanceToTop(targetAnchor) - this.offset;

    window.scrollBy({ top: originalTop, left: 0, behavior: "smooth" });

    // const checkIfDone = setInterval(function() {
    //   const atBottom = window.innerHeight + window.pageYOffset >= document.body.offsetHeight - 2;
    //   if (distanceToTop(targetAnchor) === 0 || atBottom) {
    //     targetAnchor.tabIndex = "-1";
    //     targetAnchor.focus();
    //     window.history.pushState("", "", targetID);
    //     console.log(window.history.pushState("", "", targetID))
    //     clearInterval(checkIfDone);
    //   }
    // }, 150);
  }
}


export default PageNav;
