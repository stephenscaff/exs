
import PageNav from './_PageNav.js'

/**
 * Scroll Down
 * Simple scroll to anchor jaun.

* @requires {class} PageNav
 */
let scrollLinks = document.querySelectorAll('.js-scroll-down');

let mqMed = window.matchMedia('(min-width: 32em)');
let scrollOffset = 100;

if (mqMed.matches) {
  let scrollOffset = 170;
}

let ScrollDown = new PageNav(scrollLinks, scrollOffset);

export default ScrollDown;
