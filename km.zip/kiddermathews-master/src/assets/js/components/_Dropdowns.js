import Utils from '../components/_Utils.js'

/**
 * Dropdowns
 * Dropdown component used for Activity Filters
 *
 * @see partials/partial-activity-filters.php
 * @see src/assets/scss/components/_dropdowns.scss
 */
const Dropdowns = (() => {

  const html = document.querySelector('html');
  const dds = document.querySelectorAll('.js-dropdown');
  const ddTriggers = document.querySelectorAll('.js-dropdown-trigger');

  return{

    /**
    * Init
    */
    init() {
     this.bindEvents();
    },

    bindEvents() {

      /**
      * Main DD Click Event
      */
      Utils.forEach ( ddTriggers, function (index, ddTrigger) {

        ddTrigger.addEventListener('click', function (e) {
          console.log('clicked', ddTrigger)
          Dropdowns.open(ddTrigger);
          e.preventDefault();
        });
      });

       /**
        * Close open DD on Outside Click
        */

      html.addEventListener('click', function(e) {
        let openDD = document.querySelector('.js-dropdown.is-open .js-dropdown-trigger');
        if (!openDD) return;
        Dropdowns.close(openDD);
        e.stopPropagation();
      });
    },


     /**
      * Close Clicked DD
      */
      close(el){
        console.log('close',el)
        el.parentElement.classList.add('is-closing');

        setTimeout(function(){
           el.parentElement.classList.remove('is-open');
           el.parentElement.classList.remove('is-closing');
           el.parentElement.classList.add('is-closed');
        }, 200);
      },

     /**
      * Open Clicked DD
      */
     open(el){
       el.parentElement.classList.add('is-opening');

       setTimeout(function(){
         el.parentElement.classList.remove('is-closed');
         el.parentElement.classList.remove('is-opening');
         el.parentElement.classList.add('is-open');
      }, 150);
    },
  };
})();

export default Dropdowns;
