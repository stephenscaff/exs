import Utils from '../components/_Utils.js'

/**
 * Accordion
 * Accordion-like UI for the main mobile/sm nav.
 */
const Accordion = (() => {

  const accordion = document.querySelector('.accordion');
  const sub = document.querySelector('.accordion__content');
  const activeClass = 'is-active';
  let isOpen = false;

  return{

    /**
     * Init
     */
    init() {
      if (!accordion) return;
      this.bindEvents();

      if (accordion.dataset.accordionInit === "mobile-only") {
        Accordion.mobileChecks();
      }
    },


    /**
     * Bind Events
     */
    bindEvents() {

      let triggers = accordion.querySelectorAll('.js-accordion-trigger');

      Utils.forEach(triggers, function (index, trigger) {

        trigger.addEventListener('click', function (e) {
          e.stopPropagation();

          const activeTrigger = accordion.querySelector('.accordion__item'+'.'+activeClass);
          const triggerParent = trigger.parentElement;
          const clickedContent = trigger.parentElement.querySelector('.accordion__content');
          const targetEl = trigger;
          const clickedElement = e.target.parentElement;

          Accordion.toggle(activeTrigger, triggerParent, clickedElement);
        });
      });
    },

    /**
     * Toggle
     * Main accordiion-like action
     */
    toggle(activeTrigger, triggerParent, clickedElement) {

      let subs = document.querySelectorAll('.accordion__item');

      if (triggerParent.classList.contains('is-active')) {
        triggerParent.classList.remove('is-active');
        return;
      }

      Utils.forEach(subs, function (index, sub) {
        sub.classList.remove(activeClass);
      });

      triggerParent.classList.add(activeClass);
    },


    /**
     * Mobile Checks
     *
     * For mobile only accordions to collapsing long lists
     * of content that would result in insane mobile scrolling.
     */
    mobileChecks() {
      const mobileAccordion = document.querySelector('.accordion.is-mobile-accordion');
      let mqMax = window.matchMedia("(max-width: 54em)");

      if (mqMax.matches) {
        Accordion.onMobile(mobileAccordion);

      } else {
        Accordion.notMobile(mobileAccordion);
      }

      mqMax.addListener(function(e) {
        if (e.matches) {
          Accordion.onMobile(mobileAccordion);
        } else {
          Accordion.notMobile(mobileAccordion);
        }
      });
    },


    /**
     * Not Mobile
     * Actions when not on mobile
     * @param {html element} el - element to add remove classes on.
     */
    notMobile(el) {
      el.classList.remove('is-mobile')
      el.classList.add('is-not-mobile')
    },

    /**
     * On Mobile
     * Actions when on mobile
     * @param {html element} el - element to add remove classes on.
     */
    onMobile(el) {
      el.classList.remove('is-not-mobile')
      el.classList.add('is-mobile')
    },
  };
})();

export default Accordion;
