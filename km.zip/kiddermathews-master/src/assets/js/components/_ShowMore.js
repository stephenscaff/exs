import Utils from '../components/_Utils.js'

/**
 * Show ReadMore
 * Faking a Load More Experience with a domlist delivered via Repeater Field.
 * @author Stephen Scaff
 */
 const ShowMore = (() => {

   return{

     /**
      * Init
      */
     init() {
       this.bindEvents();
     },

     bindEvents() {
       ShowMore.handleClick()
       ShowMore.hideOnLoad()
       ShowMore.showItems()
     },

     hideOnLoad() {
       var allItems = document.querySelectorAll('.js-show-more .show-more__item');
       Utils.forEach ( allItems, function (index, allItem) {
         allItem.classList.add('is-hidden');
       });
     },

     showItems() {
       var showMores = document.querySelectorAll('.js-show-more');


       Utils.forEach (showMores, function (index, showMore) {
         var hiddenItems = showMore.querySelectorAll('.js-show-more .show-more__item:not(.is-visible)');
         var numToShow = 3;
         var items = Array.prototype.slice.call(hiddenItems).slice(0, numToShow);

         Utils.forEach ( items, function (index, item) {
           item.classList.remove('is-hidden');
           item.classList.add('is-visible');
         });

         var count = hiddenItems.length - numToShow;

         ShowMore.hideBtn(count)
       });
     },

     handleClick() {
       var showMoreBtns = document.querySelectorAll('.js-show-more-btn');

       Utils.forEach ( showMoreBtns, function (index, showMoreBtn) {

         showMoreBtn.addEventListener('click', function() {
           ShowMore.showItems();
         });
      });
    },

    hideBtn(items) {
      if (items <= 0) {
        document.querySelector('.js-show-more-btn').classList.add('is-hidden')
      }
    },
  };
})();

export default ShowMore;
