/**
 * Export Tests
 */

const hi = 'hiya!';

function hello(text){
  return console.log(text);
}

function yo(text){
  return console.log(text);
}

module.exports = {
  hi,
  hello,
  yo
};
