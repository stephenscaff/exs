import Vivus   from './_vivus.js';

/**
 * WhoDis.js
 * A simple little sniffer.
 * for conditional checks.
 *
 * @return {boolean}
 * @author stephen scaff
 */
const SvgEffects = (() => {


  return {

    init() {
      this.bindEvents();
    },

    bindEvents() {
      SvgEffects.draw();
      SvgEffects.hover();
    },

    /**
     * Draw
     */
    draw() {
      const svgDraws = document.querySelectorAll('.js-svg-draw');
      svgDraws.forEach((svgDraw) => {
        new Vivus(svgDraw, {
          // type: 'oneByOne',
          duration: 200,
          animTimingFunction: Vivus.EASE
        });
      });
    },

    /**
     * SVG Hover Effect
     */
    hover() {
      const svgTriggers = document.querySelectorAll('.js-svg-trigger');

      svgTriggers.forEach((svgTrigger) => {
        let svg = svgTrigger.querySelector('.js-svg-hover');
        svgTrigger.addEventListener("mouseover", function() {
          new Vivus(svg, {
            // type: 'oneByOne',
            duration: 200,
            animTimingFunction: Vivus.EASE
          });
        });
      });
    }
  };
})();

export default SvgEffects;
