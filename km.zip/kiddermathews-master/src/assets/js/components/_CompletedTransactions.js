import Utils from '../components/_Utils.js'

/**
 * Show CompletedTransactions
 * Faking a Load More Experience with a domlist delivered via Repeater Field.
 * @author Stephen Scaff
 */
 const CompletedTransaction = (() => {

   return{

     /**
      * Init
      */
     init() {
       this.bindEvents();
     },

     bindEvents() {
       CompletedTransaction.handleClick()
       CompletedTransaction.hideOnLoad()
       CompletedTransaction.showItems()
     },

     hideOnLoad() {
       let allItems = document.querySelectorAll('.js-completed-trans .completed-trans__item');
       Utils.forEach ( allItems, function (index, allItem) {
         allItem.classList.add('is-hidden');
       });
     },

     showItems() {
       let completedTransactions = document.querySelectorAll('.js-completed-trans');


       Utils.forEach (completedTransactions, function (index, completedTransaction) {
         let hiddenItems = completedTransaction.querySelectorAll('.js-completed-trans .completed-trans__item:not(.is-visible)');
         let numToShow = 20;
         let items = Array.prototype.slice.call(hiddenItems).slice(0, numToShow);

         Utils.forEach ( items, function (index, item) {
           item.classList.remove('is-hidden');
           item.classList.add('is-visible');
         });

         let count = hiddenItems.length - numToShow;

         CompletedTransaction.hideBtn(count)
       });
     },

     handleClick() {
       let completedTransactionBtns = document.querySelectorAll('.js-completed-trans-btn');

       Utils.forEach ( completedTransactionBtns, function (index, completedTransactionBtn) {

         completedTransactionBtn.addEventListener('click', function() {
           CompletedTransaction.showItems();
         });
      });
    },

    hideBtn(items) {
      if (items <= 0) {
        document.querySelector('.js-completed-trans-btn').classList.add('is-hidden')
      }
    },
  };
})();

export default CompletedTransaction;
