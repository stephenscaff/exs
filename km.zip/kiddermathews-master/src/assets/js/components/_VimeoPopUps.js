import Utils from '../components/_Utils.js'

function VimeoPopUps() {
  this.html = document.querySelector('html')
  this.popUpLinks = document.querySelectorAll('[data-vimeo-popup]')
  this.isOpen = false
}

/**
 * Vimeo Popups
 */
VimeoPopUps.prototype = {
  constructor : VimeoPopUps,

  init() {
    this.handleClick()
  },

  /**
   * Open Click Event
   */
  handleClick() {

    this.popUpLinks.forEach((popUpLink) => {
      popUpLink.addEventListener('click', (e) => {
        e.preventDefault()

        this.open(popUpLink)
        this.request(popUpLink)
      })
    })
  },

  /**
   * Open Popup
   */
  open(link) {
    this.html.classList.add('popup-is-opening')
    this.isOpen = true
    setTimeout(() => {
      this.html.classList.remove('popup-is-opening')
      this.html.classList.add('popup-is-open')
    }, 200)
  },

  /**
   * Close Popup
   */
  close(popup){
    let self = this;
    this.html.classList.add('popup-is-closing')
    popup.classList.add('is-closing')

    var closer  = setTimeout(function(){
      this.html.classList.remove('popup-is-open')
      popup.classList.remove('is-open')
      this.html.classList.remove('popup-is-closing')
      this.html.classList.add('popup-is-closed')
      popup.classList.remove('is-closing')
      popup.classList.add('is-closed')

      self.remove(popup)
      this.isOpen = false
    }, 1000)
  },

  /**
   * Handle Closing Click Event
   */
  handleClose() {
    let self = this;
    const popup = document.querySelector('.popup')
    const closeLink = document.querySelector('.js-close-popup')

    closeLink.addEventListener('click', (e) => {
      e.preventDefault()
      this.close(popup)
    })

    if (this.isOpen) {
      window.onkeydown = function(e) {
        if (e.keyCode === 27) {
          self.close(popup)
        }
      }
    }
  },

  /**
   * Remove Popup/Vid
   */
  remove(el) {
    el.remove()
  },

  /**
   * Vimeo API request
   */
  request(popUpLink) {
    let self = this;
    let vimeoID       = popUpLink.dataset.vimeoPopup,
        vimeoColor    = popUpLink.dataset.vimeoColor,
        vimeoPlayer   = 'https://player.vimeo.com/video/',
        vimeoApi      = 'https://www.vimeo.com/api/oembed.json?url=',
        vimeoPlayerId = vimeoPlayer + vimeoID,
        vimeoRequest  = 'https://www.vimeo.com/api/oembed.json?url=' +
                        encodeURIComponent(vimeoPlayerId) + '&color=' + vimeoColor + '&autoplay=1&callback=?';

    Utils.loadJSONP(vimeoRequest, (data) => {
      const vimeoData = unescape(data.html)
      const tmpl      = this.popUpTmpl(vimeoData)

      document.body.insertAdjacentHTML( 'beforeend', tmpl )
        this.handleClose()
    })
  },

  /**
   * PopUp Template
   */
  popUpTmpl(vidEl) {
    return `
      <section class="popup is-open" aria-hidden="true">
       <button class="popup__close js-close-popup" aria-label="Close">
         <div class="popup__x close-x is-white"></div>
       </button>
        <div class="popup__vid">
          <div class="flex-vid vimeo popup__vid js-vid-wrap">${vidEl}</div>
        </div>
      </section>`
  }
}

export default new VimeoPopUps;
