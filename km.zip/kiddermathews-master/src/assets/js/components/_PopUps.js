function VimeoPopUps() {
  this.html = document.querySelector('html')
  this.popUpLinks = document.querySelectorAll('[data-vimeo-popup]')
}

VimeoPopUps.prototype = {
  constructor : VimeoPopUps,

  init() {
    let self = this
    this.handleClick()
  },

  handleClick() {
    this.popUpLinks.forEach((popUpLink) => {
      popUpLink.addEventListener('click', function(e) {
        e.preventDefault()

        self.open(popUpLink)
        self.play(popUpLink)
      })
    })
  },

  open(link) {
    this.html.classList.remove('popup-is-closed');
    this.html.classList.add('popup-is-opening');
    link.classList.remove('is-closed');
    link.classList.add('is-open');

    setTimeout(function(){
      this.html.classList.remove('popup-is-opening');
      this.html.classList.add('popup-is-open');
    }, 200)
  },

  close(popup){

    this.html.classList.add('popup-is-closing')
    popup.classList.add('is-closing')

    setTimeout(function(){
      this.html.classList.remove('popup-is-open')
      popup.classList.remove('is-open')
      this.html.classList.remove('popup-is-closing')
      this.html.classList.add('popup-is-closed')
      popup.classList.remove('is-closing')
      popup.classList.add('is-closed')

      self.remove(popup)
    }, 1000)
  },

  handleClose() {
    const popup = document.querySelector('.popup')
    const closeLink = document.querySelector('.js-close-popup')

    closeLink.addEventListener('click', function(e) {
      e.preventDefault()
      self.close(popup)
    })
  },

  play(popUpLink) {

    let vimeoID = popUpLink.dataset.vimeoPopup,
        vimeoColor = popUpLink.dataset.vimeoColor,
        vimeoPlayer = 'https://player.vimeo.com/video/',
        vimeoApi =    'https://www.vimeo.com/api/oembed.json?url=',
        vimeoPlayerId = vimeoPlayer + vimeoID,
        vimeoRequest = 'https://www.vimeo.com/api/oembed.json?url=' + encodeURIComponent(vimeoPlayerId) + '&color=' + vimeoColor + '&autoplay=1&callback=?';

    Utils.loadJSONP(vimeoRequest, function(data) {
      const vimeoData = unescape(data.html)
      const tmpl = popUpTmpl(vimeoData)

      document.body.insertAdjacentHTML( 'beforeend', tmpl )
        handleClose()
    });
  },

  remove(popup) {
    popup.remove()
  }


  popUpTmpl(vidEl) {
    return `<section class="popup is-open" aria-hidden="true">
       <button class="popup__close js-close-popup" aria-label="Close">
         <div class="popup__x close-x is-white"></div>
       </button>
        <div class="popup__vid">
          <div class="flex-vid vimeo popup__vid js-vid-wrap">${vidEl}</div>
        </div>
      </section>`
  },
}

export default VimeoPopUps;
