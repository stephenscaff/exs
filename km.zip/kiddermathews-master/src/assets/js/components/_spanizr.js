import Utils from '../components/_Utils.js'


const Spanizr = (() => {


  const words = document.querySelectorAll('.js-words');

  return {

    init() {
      this.bindEvents();
    },

    bindEvents(el) {
      if (!words.length) return;
        Spanizr.spanizeWords(words);
    },

    spanizeWords(els) {
      Utils.forEach ( els, function (index, el) {
        var text = Spanizr.getText(el);
        var spanize = Spanizr.wrapWord(text);
        el.innerHTML = spanize;
      });
    },

    wrapChars(str) {
      return str.replace(/\w/g, '<span class="char"><span>$&</span></span>');
    },

    wrapWord(str){
      ///\w+/g
      return str.replace(/([A-z0-9'@+-<>.,'’"?!*&/]+)/g,  '<span class="word"><span>$&</span></span>');
    },

    getText(el) {
      return el.innerHTML;
    },

    replace(el, newEl) {
      el.innerHTML = newEl;
      return newEL;
    },
  }
})();

export default Spanizr;
