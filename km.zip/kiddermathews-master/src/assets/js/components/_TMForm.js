
/**
 * Nested Links
 * Allows for links nested inside a block level link wrap
 * via a data attribute of the link location.
 * @author Stephen Scaff
 */
const TMForm  = (() => {

  const apiURL = 'https://m2.tm00.com/TMPartnerService/Services/SubscriberService.svc/AddSubscriber';
  const formEl = document.querySelector('#js-form');
  const inputs = document.querySelectorAll('.js-input[required]');
  const loader = document.querySelector('.js-form-loader');
  const successMessage = document.querySelector('.js-success-message');
  const errorMessage = document.querySelector('.js-error-message');
  let isValid = false, isValidEmail = false;

  return {

    init() {
      if (!formEl) return;
      this.bindEvents();
    },

    bindEvents() {

      formEl.addEventListener('submit', function (e) {
        e.preventDefault();
        console.log('hey')
        TMForm.validateForm();
      });
    },

    /**
     * Validate Form
     */
    validateForm() {

      const emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
      const emailField = formEl["email"];


      inputs.forEach((input) => {

        if (input.value == "") {
          input.classList.add('is-invalid');
          isValid = false;
          window.scroll({top: 0, left: 0, behavior: 'smooth' });
          return;
        } else {
          input.classList.remove('is-invalid')
          isValid = true;
        }
      });

      // Validate Email
      if (!emailField.value.match(emailFormat)) {
        emailField.classList.add('is-invalid');
        isValidEmail = false;
      } else {
        emailField.classList.remove('is-invalid');
        isValidEmail = true;
      }

      if (isValid && isValidEmail) {
        TMForm.handleRequest();
      }
    },

    /**
     * Get Form Data
     */
    getFormData(formData) {
      var json = {};
      for (item of formData.keys()){
          json[item] = formData.get(item);
      }
       return json;
    },

    /**
     * Handle Fetch
     */
    handleRequest() {

      // Show Loader
      TMForm.isSubmitting();

      var data = new FormData(formEl);
      console.log('form el', formEl)
      console.log('form data', data)


      var json = TMForm.getFormData(data);


      fetch(apiURL, {
        method: 'POST',
        headers: {
           'Authorization': 'Basic Mjc6MXN6YW9yN2U1OQ==',
           'Content-Type': 'application/json',
        },
        body: JSON.stringify(json),
      })
      .then(function (response) {
        console.log('then', response.ok)

        if (response.ok = true) {
          return TMForm.onSuccess();
        } else {
          return TMForm.onError(error);
        }
      }).catch(function (error) {
        return TMForm.onError(error);
      });
    },

    /**
     * Show Loader UI
     */
    isSubmitting() {
      formEl.classList.add('is-submitting');
      loader.classList.remove('is-hidden');
    },

    /**
     * Handle Success State
     */
    onSuccess(response) {
      setTimeout(() => {
        successMessage.classList.remove('is-hidden');
        loader.classList.add('is-hidden');
        console.log('YASSS!')
      }, 900);
    },

    /**
     * Handle Error State
     */
    onError(error) {
      setTimeout(() => {
        errorMessage.classList.remove('is-hidden');
        loader.classList.add('is-hidden');
        console.log('DANGGGG!!')
      }, 900);
    },
  }
})();

export default TMForm;
