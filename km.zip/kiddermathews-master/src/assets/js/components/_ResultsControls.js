/**
  * ResultsControls
  * A grouped collection of Controls and utils for Results
  * @author stephen scaff
  */
const ResultControls = (() => {

  // const container = document.querySelector('.properties-split');
  const resultsContainer = document.querySelector('.js-results-container');

  return {

    /**
     * Combine our methods here
     * to allow a single init on the default export.
     */
    init() {
      // this.mapToggle();
      this.listToggle();
    },

    /**
     * Toggle Search Results
     */
    listToggle() {
      const listToggle = document.querySelector('.js-toggle-list');
      const gridToggle = document.querySelector('.js-toggle-grid');

      if (!listToggle) return;

      listToggle.addEventListener('click', function(e) {
        gridToggle.classList.remove('is-active');
        listToggle.classList.add('is-active');
        resultsContainer.classList.remove('is-grid');
        resultsContainer.classList.add('is-list');
      });

      gridToggle.addEventListener('click', function(e) {
        listToggle.classList.remove('is-active');
        gridToggle.classList.add('is-active');
        resultsContainer.classList.add('is-grid');
        resultsContainer.classList.remove('is-list');
      });
    }
  };
})();

export default ResultControls
