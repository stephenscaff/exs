<?php
/**
 * Calls Post Archive Template as Fallback for custom template loader
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

if ( ! defined( 'ABSPATH' ) ) exit;

include(locate_template( 'views/post/archive.php' ) );
