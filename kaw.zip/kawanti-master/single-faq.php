<?php
/**
* The default template for single activities
*
* @author    Stephen Scaff
* @package   jumpoff
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while (have_posts()) : the_post();

$title = get_the_title();

?>

<main role="main" class="has-header-offset">

  <!-- Mast -->
  <section class="mast-title">
    <header class="mast__header">
      <h1 class="mast-title__title"><?php echo $title; ?></h1>
    </header>
  </section>

  <!-- Faq -->
  <section class="faqs">
    <div class="grid-sm">

    <?php
    while( have_rows('faq') ): the_row();
      $q = get_sub_field('question');
      $a = get_sub_field('answer');
    ?>
      <div class="faq-item">
        <strong class="faq-item__q"><?php echo $q; ?></strong>
        <div class="faq-item__a">
          <div class="read-more js-read-more" data-rm-words="70">
          <?php echo $a; ?>
          </div>
        </div>
      </div>
    <?php endwhile; ?>

    <a class="faqs__link" href="<?php echo jumpoff_get_page_url('faq', 1); ?>">← Back to All FAQs</a>
    </div>
  </section>

</main>

<?php endwhile; ?>


<!-- Footer-->
<?php get_footer(); ?>
