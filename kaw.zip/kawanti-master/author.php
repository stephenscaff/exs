
<?php
/**
 * Template for author posts archives.                                                                                                               n
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$author_id = get_the_author_meta('ID');
$author_content = get_user_meta($author_id, 'user_content', true);
$author_avatar = get_user_meta($author_id, 'user_avatar', true);
$author_avatar_img = wp_get_attachment_image_src($author_avatar)[0];
$author_position = get_user_meta($author_id, 'position', true);
$author_link = get_author_posts_url( $author_id, get_the_author_meta( 'user_nicename' ) );
$author_name = get_the_author_meta('display_name');

?>

<main role="main" class="has-header-offset">


<section class="mast-title is-author">
  <header class="mast-title__header">
    <figure class="mast-title__avatar">
      <img class="mast-title__avatar-img" src="<?php echo $author_avatar_img; ?>">
    </figure>
    <h1 class="mast-title__title"><?php echo $author_name; ?></h1>
    <p class="mast-title__byline"><?php echo $author_content; ?></p>
  </header>
</section>

<section class="author-post-info">
  <div class="grid">
    <div class="author-post-info__text"><strong><?php echo $author_name; ?></strong> Has <strong><?php the_author_posts(); ?> Posts</strong></div>
  </div>
</section>

<!-- Posts -->
<section class="post-cards is-posts has-fetch-more">
  <div class="grid-lg">
    <div id="js-posts" class="post-cards__grid">
      <?php
      if ( have_posts() ): while ( have_posts() ) : the_post();
        get_template_part( 'partials/content/content', 'post' );
      endwhile; else:
        get_template_part( 'partials/content/content', 'none' );
      endif; ?>
    </div>
  </div>
</section>

<!-- Load More -->
<?php get_template_part( 'partials/partial', 'fetch-more' );?>

</main>

<!-- Footer  -->
<?php get_footer(); ?>
