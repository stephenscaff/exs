<?php
# Shortcodes

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly


require_once('shortcode-blockquotes.php');
