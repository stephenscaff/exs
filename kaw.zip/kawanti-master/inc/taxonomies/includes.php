<?php

if ( ! defined( 'ABSPATH' ) ) exit;

require_once 'taxonomies.php' ;
