<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Career
 *
 *  Slug :      Career
 *  Supports : 'title','thumbnail','editor'
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'career';

 // Call the function and save it to $labels
 $labels = jumpoff_post_type_labels('Career', 'Careers');

 $args = [
   'public'             => true,
   'description'        => 'Kawanit\'s Careers',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 4,
   'menu_dashicon'      => 'dashicons-groups',
   'menu_icon'          => 'dashicons-groups',
   'query_var'          => true,
   'supports'           => array( 'title' ),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => false,
   'publicly_queryable'  => false,
   // 'rewrite'            => array('slug' => 'reviews', 'with_front' => false),
 ];

 register_post_type( $type, $args);

});


/**
 *  Taxonomy: Career Locations
 *
 *  @author     Stephen Scaff
 *  @version    1.0
 *  @see        inc/post-types/taxonomy-controller.php for term/tax template controller.
 */

 add_action( 'init', function() {
   $tax =  'career_location';
   $type = array('career');

   // Call the function and save it to $labels
   $labels = jumpoff_post_type_labels('Career Location', 'Career Locations');

   $args = [
       'description'        => 'Kawanti career locations',
       'labels'             => $labels,
       'hierarchical'        => true,
       'show_ui'             => true,
       'show_admin_column'   => true,
       'show_in_quick_edit'  => true,
       'show_in_menu'  => true,
       'rewrite'            => array('slug' => 'careers-location', 'with_front' => false),
   ];

   register_taxonomy( $tax, $type, $args);

 });


 /**
  *  Taxonomy: Career Departments
  *
  *  @author     Stephen Scaff
  *  @version    0.2
  *  @since      0.2 - removed career depts.
  */
// add_action( 'init', function() {
//   $tax =  'career_department';
//   $type = array('career');
//
//   // Call the function and save it to $labels
//   $labels = jumpoff_post_type_labels('Career Departments', 'Career Departments');
//
//   $args = [
//       'description'         => 'Kawanti career department',
//       'labels'              => $labels,
//       'hierarchical'        => true,
//       'show_ui'             => true,
//       'show_admin_column'   => true,
//       'show_in_quick_edit'  => true,
//       'show_in_menu'        => true,
//       'rewrite'             => array(
//         'slug'        => 'careers-department',
//         'with_front'  => false
//     ),
//   ];
//
//   register_taxonomy( $tax, $type, $args);
//
// });
