<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 *  Post Type: Activity
 *
 *  Slug :      activities
 *
 *  @version    1.0
 *  @author     stephen scaff
 */

add_action( 'init', function() {
 $type = 'activity';

 // Call the function and save it to $labels
 $labels = jumpoff_post_type_labels('Activity', 'Activities');

 $args = [
   'public'             => true,
   'description'        => 'Kawanit\'s Activites and Tours',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 3,
   'menu_dashicon'      => 'dashicons-flag',
   'menu_icon'          => 'dashicons-flag',
   'query_var'          => true,
   'supports'           => array( 'title','thumbnail' ),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'rewrite'            => array('slug' => 'activities', 'with_front' => false),
 ];

 register_post_type( $type, $args);

});


/**
 *  Taxonomy: Activities Type
 *
 *  Slug : activity
 *  hierarchical : true
 *
 *  @author     Stephen Scaff
 *  @version    1.0
 */

add_action( 'init', function() {
 $tax =  'activity_type';
 $type = array('activity', 'review');

 // Call the function and save it to $labels
 $labels = jumpoff_post_type_labels('Activity Type', 'Activity Types');

 $args = [
     'description'        => 'Kawanti\'s Activity Types.',
     'labels'             => $labels,
     'hierarchical'        => true,
     'show_ui'             => true,
     'show_admin_column'   => true,
     'show_in_quick_edit'  => true,
     'rewrite'            => array('slug' => 'activities', 'with_front' => false),
 ];

 register_taxonomy( $tax, $type, $args);

});


 /**
  *  Taxonomy: Activities Location
  *
  *  Slug : activity-location
  *  hierarchical : true
  *
  *  @author     Stephen Scaff
  *  @version    1.0
  */

  add_action( 'init', function() {
    $tax =  'activity_location';
    $type = 'activity';

    // Call the function and save it to $labels
    $labels = jumpoff_post_type_labels('Activity Location', 'Activity Locations');

    $args = [
        'description'        => 'Kawanti\'s Activity Locations.',
        'labels'             => $labels,
        'hierarchical'        => true,
        'show_ui'             => true,
        'show_admin_column'   => true,
        'show_in_quick_edit'  => true,
        'rewrite'            => array('slug' => 'activity-location', 'with_front' => false),
    ];

    register_taxonomy( $tax, $type, $args);

  });

 /**
  *  Activity Tax URL Routing
  *
  *  Allows our activities taxonomies to share
  *  '/activies' base url.
  *
  */
add_action('generate_rewrite_rules', function($wp_rewrite) {

  $rules = array();

  $activities = get_post_types(
    array(
      'name'     => 'activity',
      'public'   => true,
      '_builtin' => false
    ), 'objects' );


  $activity_types = get_taxonomies(
    array(
      'name'      => 'activity_type',
      'public'    => true,
      '_builtin'  => false
    ), 'objects'
  );

  $activity_locations = get_taxonomies(
    array(
      'name'      => 'activity_location',
      'public'    => true,
      '_builtin'  => false
    ), 'objects'
  );

  foreach ( $activities as $post_type ) {
    $post_type_name = $post_type->name;
    $post_type_slug = $post_type->rewrite['slug'];
    /**
     * Activity Type Tax
     */
    foreach ( $activity_types as $taxonomy ) {
      if ( $taxonomy->object_type[0] == $post_type_name ) {
        $terms = get_categories( array( 'type' => $post_type_name, 'taxonomy' => $taxonomy->name, 'hide_empty' => 0 ) );
        foreach ( $terms as $term ) {
          $rules[$post_type_slug . '/' . $term->slug . '/?$'] = 'index.php?' . $term->taxonomy . '=' . $term->slug;
        }
      }
    }

    /**
     * Activity Location Tax
     */
    foreach ( $activity_locations as $taxonomy ) {
      if ( $taxonomy->object_type[0] == $post_type_name ) {
        $terms = get_categories( array( 'type' => $post_type_name, 'taxonomy' => $taxonomy->name, 'hide_empty' => 0 ) );
        foreach ( $terms as $term ) {
          $rules[$post_type_slug . '/' . $term->slug . '/?$'] = 'index.php?' . $term->taxonomy . '=' . $term->slug;
        }
      }
    }
  }

  $wp_rewrite->rules = $rules + $wp_rewrite->rules;

});
