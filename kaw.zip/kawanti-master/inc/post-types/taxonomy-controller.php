<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

 /**
  * Taxonomy Controller
  * Speciify Taxonomy templates / views
  *
  * @return locate_template
  */
add_filter( 'taxonomy_template', function(){
  $template = '';
  $current_post = get_queried_object();
  $current_tax = $current_post->taxonomy;

  if ( is_tax('activity_type') OR is_tax('activity_location')){
    $template = locate_template( 'archive-activity.php' );
  }
  if ( is_tax('career_location') OR is_tax('career_department')){
    $template = locate_template( 'templates/careers.php' );
  }

  return $template;

});
