<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Flush Rewrites
 */
add_action( 'after_switch_theme', 'jumpoff_flush_rewrite_rules' );

function jumpoff_flush_rewrite_rules() {
  flush_rewrite_rules();
}

require_once 'post-type-activity.php' ;
require_once 'post-type-reviews.php' ;
require_once 'post-type-career.php' ;
require_once 'post-type-faq.php' ;
require_once 'taxonomy-controller.php' ;
