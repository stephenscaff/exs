<?php

/**
 *  Admin Dash View
 *
 *
 *  @version    1.0
 *  @see        admin-dash.php
 *  @see        admin/admin-theme/assets (for styles)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

# Wp admin bootstrap
require_once( ABSPATH . 'wp-load.php' );
require_once( ABSPATH . 'wp-admin/admin.php' );
require_once( ABSPATH . 'wp-admin/admin-header.php' );

?>

<section class="dash">

  <header class="dash-header">
    <h1 class="dash-header__title">Welcome to Kawanti</h1>
    <p class="dash-header__text">From here you can create and manage the front-end experience of Kawanti.com.</p>
    <p class="dash-header__text">  <a class="" href="<?php echo site_url( '/' ); ?>" target="_blank">Launch Homepage</a>
  </header>

  <section class="dash-cards">

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'admin.php?page=contacts' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-phone-talk"></i>

          <h3 class="dash-card__title">Edit Contacts</h3>

          <p class="dash-card__text">Edit global links, contacts, socials, etc. </p>
        </div>
      </a>
    </article>

    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'post.php?post=4&action=edit' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-home"></i>

          <h3 class="dash-card__title">Home Page</h3>

          <p class="dash-card__text">Manage / Edit Homepage content & modules</p>
        </div>
      </a>
    </article>


    <article class="dash-card">
      <div class="dash-card__link">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-rowing"></i>

          <h3 class="dash-card__title">Activities</h3>

          <p class="dash-card__text">
            <a href="<?php echo admin_url( 'edit.php?post_type=activity' ); ?>">Manage Activities</a>
            <a href="<?php echo admin_url( 'edit.php?post_type=activity&page=activity-index' ); ?>">Activities Index Page</a>
            <a href="<?php echo admin_url( 'edit-tags.php?taxonomy=activity_type&post_type=activity' ); ?>">Activities Types</a>
            <a href="<?php echo admin_url( 'edit-tags.php?taxonomy=activity_location&post_type=activity' ); ?>">Activities Locations</a>
          </p>
        </div>
      </div>
    </article>

    <article class="dash-card">
      <div class="dash-card__link">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-users"></i>

          <h3 class="dash-card__title">Careers</h3>

          <p class="dash-card__text">
            <a href="<?php echo admin_url( 'edit.php?post_type=career' ); ?>">Manage Careers</a>
            <a href="<?php echo admin_url( 'edit-tags.php?taxonomy=career_location&post_type=career' ); ?>">Career Locations</a>
            <a href="<?php echo admin_url( 'edit-tags.php?taxonomy=career_department&post_type=career' ); ?>">Career Departments</a>
          </p>
        </div>
      </div>
    </article>

    <article class="dash-card">
      <div class="dash-card__link">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-live_help"></i>

          <h3 class="dash-card__title">FAQs</h3>

          <p class="dash-card__text">
            <a href="<?php echo admin_url( 'edit.php?post_type=faq' ); ?>">Manage FAQs</a>
            <a href="<?php echo admin_url( 'post-new.php?post_type=faq' ); ?>">Add New FAQ Page</a>
          </p>
        </div>
      </div>
    </article>


    <article class="dash-card">
      <div class="dash-card__link">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-pages"></i>

          <h3 class="dash-card__title">Pages</h3>

          <p class="dash-card__text">
            <a href="<?php echo admin_url( 'edit.php?post_type=page' ); ?>">Manage Pages</a>
            <a href="<?php echo admin_url( 'post-new.php?post_type=page' ); ?>">Add New Page</a>
          </p>
        </div>
      </div>
    </article>



    <article class="dash-card">
      <div class="dash-card__link">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-chat"></i>

          <h3 class="dash-card__title">Reviews</h3>

          <p class="dash-card__text">
            <a href="<?php echo admin_url( 'edit.php?post_type=review' ); ?>">Manage Reviews</a>
            <a href="<?php echo admin_url( 'post-new.php?post_type=review' ); ?>">Add New Review</a>
          </p>
        </div>
      </div>
    </article>



    <article class="dash-card">
      <a class="dash-card__link" href="<?php echo admin_url( 'edit.php' ); ?>">
        <div class="dash-card__content">
          <i class="dash-card__icon icon-tag"></i>

          <h3 class="dash-card__title">Articles</h3>

          <p class="dash-card__text">Write an Article</p>
        </div>
      </a>
    </article>
  </section>
</section>
<?php //include( ABSPATH . 'wp-admin/admin-footer.php' );
