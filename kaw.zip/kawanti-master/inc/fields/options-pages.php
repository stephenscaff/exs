<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Create Global Elements Menu Item
 */
if( function_exists('acf_add_options_page') ) {

 	# Site Globals (Parent)
	$site_globals = acf_add_options_page(array(
		'page_title' 	=> 'Site Globals',
		'menu_title' 	=> 'Site Globals',
		'icon_url'		=> 'dashicons-admin-site',
		'redirect' 		=> true
	));

	# Company Contacts
	$page_contacts = acf_add_options_sub_page(array(
    'page_title'  => 'Company Contacts',
    'menu_title'  => 'Company Contacts',
    'menu_slug'   => 'contacts',
    'position'    =>  '1',
		'parent_slug' 	=> $site_globals['menu_slug'],
	));

  # Company Contacts
  $page_footer = acf_add_options_sub_page(array(
    'page_title'  => 'Footer Content',
    'menu_title'  => 'Footer Content',
    'menu_slug'   => 'footer',
    'position'    =>  '2',
    'parent_slug' 	=> $site_globals['menu_slug'],
  ));
}


/**
 * Remove Menu from appearance.
 * Add as it's own parent page
 */
add_action( 'admin_menu', function() {
  global $submenu, $menu;

  // Remove Menus from appearance
  if ( isset($submenu['themes.php']) ) {

    foreach( $submenu['themes.php'] as $key => $item ) {
      if ( $item[2] === 'nav-menus.php' ) {
        unset($submenu['themes.php'][$key]);
      }
    }
  }

  // Allow editors to edit menus
  // $role_object = get_role( 'editor' );
  // $role_object->add_cap( 'edit_theme_options' );

  // Add Menu Pages
  add_menu_page( 'Menus', 'Menus', 'edit_posts', 'nav-menus.php', '', 'dashicons-list-view', 61 );

});
