<?php
/**
 * Fields - Modules Home
 * Location: templates/home.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;

$modules_home = new FieldsBuilder('modules_home', [
  'key' => 'group_modules_home',
  'position' => 'acf_after_title',
  'menu_order' => '3',
]);

$modules_home
  ->addFlexibleContent('modules', [
    'button_label'=> "Add Module",
  ])
  ->addLayout($activity_types_module, [
    'name'=> "activity_types_module",
  ])
  ->addLayout($cta_module, [
    'name'=> "cta_module",
  ])
  ->addLayout($post_feed_module, [
    'name'=> "post_feed_module",
  ])
  ->addLayout($reviews_slider_module , [
    'name'=> "reviews_slider_module",
  ])
  ->addLayout($two_column_module , [
    'name'=> "two_column_module",
  ])
  ->setLocation('page_template', '==', 'templates/home.php');

  add_action('acf/init', function() use ($modules_home) {
     acf_add_local_field_group($modules_home->build());
  });
