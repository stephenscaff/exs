<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Contacts Fields
 */
$contacts_fields = new StoutLogic\AcfBuilder\FieldsBuilder('contacts');

$contacts_fields

    # Kawanti Tab
    ->addTab('Kawanti Contacts')

    # Kawanti Mail
    ->addTextArea('kawanti_mail_address', [
      'wrapper' =>  ['width' => '100%'],
      'rows' =>  '4',
    ])

    # Kawanti Phones
    ->addMessage('Kawanti Phone Numbers', '')
    ->addText('kawanti_phone_local', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('kawanti_phone_tollfree', [
      'wrapper' =>  ['width' => '50%']
    ])

    # Kawanti Emails
    ->addMessage('Kawanti Emails', '')
    ->addText('kawanti_email', [
      'wrapper' =>  ['width' => '100%']
    ])

    # Kawanti Socials
    ->addMessage('Kawanti Socials', '')
    ->addText('kawanti_youtube', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('kawanti_instagram', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('kawanti_twitter', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('kawanti_linkedin', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('kawanti_facebook', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('kawanti_vimeo' , [
      'wrapper' => ['width' => '50%']
    ])
    ->addText('kawanti_snapchat' , [
      'wrapper' => ['width' => '50%']
    ])

    # Taquan
    ->addTab('Taquan Contacts')

    # Taquan Address
    ->addTextArea('taqaun_mail_address', [
      'wrapper' =>  ['width' => '100%'],
      'rows' =>  '4',
    ])

    # Phones
    ->addMessage('Phone Numbers', '')
    ->addText('taqaun_phone_local', [
      'wrapper' =>  ['width' => '50%']
    ])
    ->addText('taqaun_phone_tollfree', [
      'wrapper' =>  ['width' => '50%']
    ])

    # Emails
    ->addMessage('Taquan Emails', '')
    ->addText('taqaun_email', [
      'wrapper' =>  ['width' => '100%']
    ])


    ->setLocation('options_page', '==', 'contacts');

add_action('acf/init', function() use ($contacts_fields) {
   acf_add_local_field_group($contacts_fields->build());
});
