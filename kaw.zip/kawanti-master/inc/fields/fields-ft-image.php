<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Featured Image Position
 * Adds a select to the featured image box for selecting background position.
 */
add_filter( 'admin_post_thumbnail_html', function( $html, $post_id ) {

  $selected_option = get_post_meta( $post_id, 'ft_img_position', true );

  return $html .= '
    <div class="ft-image-field" style="border-top: 1px solid #ddd;margin: 2em -1em 0;padding: 1em">
      <label style="font-weight: 700">Image Position</label>
      <br/><br/>
      <form>
        <select name="ft_img_position" style="display:block;width:100%">
          <option value="center" ' . selected( $selected_option, 'center', false ) . '>Center</option>
          <option value="top" ' .    selected( $selected_option, 'top', false ) . '>Top</option>
          <option value="bottom" ' . selected( $selected_option, 'bottom', false ) . '>Bottom</option>
        </select>
      </form>
    </div>';
}, 10, 2 );


/**
 * Save Ft Image Position Field
 */
add_action( 'save_post', function( $post_id ) {
  if ( isset( $_POST[ 'ft_img_position' ] ) ) {
    update_post_meta(
      $post_id,
      'ft_img_position',
      sanitize_text_field( $_POST[ 'ft_img_position' ]
    ));
  }
});
