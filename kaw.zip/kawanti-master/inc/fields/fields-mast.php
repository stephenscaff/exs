<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *   Mast Home
 *   For Home Page Masthead
 */
$mast_fields = new StoutLogic\AcfBuilder\FieldsBuilder('mast', [
    'key' => 'group_mast',
    'position' => 'acf_after_title',
    'menu_order' => '1',
]);;

$mast_fields
->addText( 'mast_pretitle' )
->addTextArea('mast_title', [
  'label' => 'Mast Title - wrap word in &lt;em> to apply script font. Example: &lt;em>word here&lt;/em> ',
  'rows'  => 3,
  'new_lines' => 'br'
])
->addMessage('  ', 'Provide images that will randomly display on page load. Size Images to 2000 x 1200')
->addRepeater('mast_images', [
  'button_label' => 'Add Images',
  'layout' => 'block',
])
  ->addImage('image', [
    'label' => 'Mast Background Image. Size to 2000x1250'
  ])
->endRepeater()
->addImage('mast_stamp', [
  'label' => 'Mast Stamp/Badge Image. Upload PNG. Size to 500x500'
])
# @todo - rework locations or at least apply to a universal template?
->setLocation('page_template', '==', 'templates/home.php')
         ->or('page_template', '==', 'templates/careers.php')
         ->or('page_template', '==', 'templates/reviews.php')
         ->or('page_template', '==', 'templates/modules.php')
         ->or('options_page', '==',  'activity-index')
         ->or('options_page', '==',  'posts-index');

add_action('acf/init', function() use ($mast_fields) {
   acf_add_local_field_group($mast_fields->build());
});
