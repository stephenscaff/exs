<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Modules Library
 */
use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Acitivity Type Module
 * @see partials/modules/cards-builder-module.php
 * @see scss/components/cards.scss
 */
$activity_types_module = new FieldsBuilder('activity_types_module');
$activity_types_module
  ->addMessage('', 'The Activity Type Module outputs a grid of your Activity Types (categories)');

/**
 * Cards Builder Module
 * @see partials/modules/cards-builder-module.php
 * @see scss/components/cards.scss
 */
$cards_module = new FieldsBuilder('cards_module');
$cards_module
  ->addMessage('', 'The Cards Module enables you to build a section containing UI cards in a 3 column grid ')
  ->addFields($heading_field)
  ->addRepeater('cards', [
    'min' => 2,
    'button_label' => 'Add Card',
    'layout' => 'block',
  ])
    ->addImage('image')
    ->addText('pretitle')
    ->addText('title')
    ->addTextArea('content', [
      'row' => '4',
    ])
    ->addFields($button_field)
  ->endRepeater();

/**
 * Content Module
 * Creates an content / wysi section
 * @see scss/components/_content (post-content)
 */
$content_module = new FieldsBuilder('content_module');
$content_module
  ->addMessage('', 'The Content Module creates an all purpose content/wysi region.')
  ->addFields($heading_field)
  ->addWysiwyg('content');


/**
 * CTA Module
 * @see partials/modules/cards-builder-module.php
 * @see scss/components/cards.scss
 */
$cta_module = new FieldsBuilder('cta_module');
$cta_module
  ->addMessage('', 'The CTA Module creates a Call To Action section for advertising special content ')
  ->addImage('image', [
    'wrapper' =>  ['width' => '50%'],
    'label'   =>  'Background Video',
  ])
  ->addFile('vid_mp4', [
  'wrapper' =>  ['width' => '50%'],
  'label'   =>  'Background Video',
  ])
  ->addText('title')
  ->addTextArea('content')
  ->addFields($button_field);


/**
 * Gallery Module
 * @see partials/modules/gallery-module.php
 * @see scss/components/gals.scss
 */
$gallery_module = new FieldsBuilder('gallery_module');
$gallery_module
  ->addMessage('', 'The Gallery Module creates a gallery of images. You can select the size of each image. <br/>Image Combos inlcude 100%, 50/50, 33/33/33, 33/67 ')
  ->addRepeater('images', [
    'min' => 1,
    'button_label' => 'Add Image',
    'layout' => 'block',
  ])
    ->addImage('image', [
      'wrapper'    =>  ['width' => '25%'],
    ])
    ->addSelect('image_width', [
      'wrapper'    =>  ['width' => '75%'],
    ])
      ->addChoice('is-100', '100%')
      ->addChoice('is-50', '50%')
      ->addChoice('is-66', '66%')
      ->addChoice('is-33', '33%')
  ->endRepeater();



/**
 * Link List Module
 */
$link_list_module = new FieldsBuilder('link_list_module');
$link_list_module
  ->addMessage('', 'The Link List Moudule creates a list of linked items.')
  ->addFields($heading_field)
  ->addRepeater('items', [
    'min' => 1,
    'button_label' => 'Add Item',
    'layout' => 'block',
  ])
  ->addText('text', [
    'wrapper' =>  ['width' => '33.333%'],
  ])
  ->addPageLink('link', [
    'allow_null'  => 'true',
    'wrapper' =>  ['width' => '33.333%'],
    'label'  =>   'Page Link (internal)',
  ])
  # Button URL
  ->addText('url', [
    'wrapper' =>  ['width' => '33.333%'],
    'label'  =>   'URL (external)'
  ]);



/**
 * Post Feed Module
 */
$post_feed_module = new FieldsBuilder('post_feed_module');
$post_feed_module
  ->addMessage('', 'The Post Feed Module outputs a section displaying 3 post blocks either by latest or selection.')
  ->addRelationship('post_selector',  [
   'label'      => 'Or Select 3 Posts',
   'post_type' =>  'post',
   'filters' => array('search', '', ''),
   'max'  => 3,
   'wrapper'    =>  ['width' => '50%'],
  ]);


/**
 * Reviews Slider Module
 */
$reviews_slider_module = new FieldsBuilder('reviews_slider_module');
$reviews_slider_module
->addMessage('', 'The Reveiws Slider Creates a slider of Reviews by selection or random')
// ->addTaxonomy('review_term', [
//  'label'      => 'Show Reviews by Activity Type',
//  'taxonomy'   => 'activity_type',
//  'return_format' => 'object',
//  'field_type'     => 'select',
//  'allow_null'     => 1,
//  'wrapper'    =>  ['width' => '50%'],
// ])
->addRelationship('review_selector',  [
 'label'      => 'Select specific Reviews',
 'post_type'  =>  'review',
 'filters'    => array('search', '', ''),
 'max'        => 5,
 'wrapper'    =>  ['width' => '100%'],
]);


/**
 * Two Column Module
 */
$two_column_module = new FieldsBuilder('two_column_module');
$two_column_module
  ->addMessage('', 'The Two Column module creates 2 columns of single content that can link to other pages ')
  ->addRepeater('columns', [
    'max' => 2,
    'min' => 2,
    'button_label' => 'Add Column',
    'layout' => 'block',
  ])
  ->addText('title')
  ->addTextArea('content')
  ->addFields($button_field);
