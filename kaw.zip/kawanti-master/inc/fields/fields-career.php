<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Fields - Career
 * Location: Career posts and post types.
 */

$career_fields = new StoutLogic\AcfBuilder\FieldsBuilder('career', [
  'key' => 'group_career',
  'position' => 'normal',
  'menu_order' => '1',
]);

$career_fields
  ->addTextArea('career_excerpt',  [
    'rows' =>  '4'
  ])
  ->addText('career_link' , [
      'wrapper' => ['width' => '100%']
    ])
  ->setLocation('post_type', '==', 'career');

add_action('acf/init', function() use ($career_fields) {
   acf_add_local_field_group($career_fields->build());
});
