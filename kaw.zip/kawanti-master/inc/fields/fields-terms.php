<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// $term_query_string = '';
//
// if ($_GET['taxonomy']){
//   $term_query_string = $_GET['taxonomy'];
// }
// $term_name = convert_to_words($term_query_string);

/**
 * Fields - Career
 * Location: Career posts and post types.
 */
$term_fields = new StoutLogic\AcfBuilder\FieldsBuilder('term_fields', [
 'key' => 'term_fields',
 'position' => 'normal',
 'menu_order' => '1',
]);

$term_fields
 ->addImage('term_image', [
   'label' => '<strong>Image</strong> <br/>Displays on Term pages in Masts and cards. Size to 2000x1250<br/>',
   'return_format' => 'array',
 ])
 ->addSelect('term_image_position', [
   'label' => '<strong>Mast Image Position</strong> <br/>(vertical position of image in Mast - adjust for optimal presentation)'
 ])
  ->addChoice('top', 'Top')
  ->addChoice('center', 'Center')
  ->addChoice('bottom', 'Bottom')

 ->setLocation('taxonomy', '==', 'career_location')
          ->or('taxonomy', '==', 'career_department')
          ->or('taxonomy', '==', 'activity_type')
          ->or('taxonomy', '==', 'activity_location');

add_action('acf/init', function() use ($term_fields) {
  acf_add_local_field_group($term_fields->build());
});
