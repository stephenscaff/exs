<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Footer Content Fields
 */
$footer_fields = new StoutLogic\AcfBuilder\FieldsBuilder('footer');

$menu_link = admin_url( 'nav-menus.php' );

$footer_fields
    # Footer Message
    ->addTextArea('footer_message', [
      'wrapper' =>  ['width' => '100%'],
      'rows' =>  '4',
    ])
    ->addMessage('<h3>Footer Menus</h3>', 'Manage the Footer Menus <a href="' . $menu_link . '">HERE</a>')

    ->setLocation('options_page', '==', 'footer');

add_action('acf/init', function() use ($footer_fields) {
   acf_add_local_field_group($footer_fields->build());
});
