<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *   review Sections
 */
$review_fields = new StoutLogic\AcfBuilder\FieldsBuilder('review', [
    'key' => 'group_review',
    'position' => 'acf_after_title',
    'menu_order' => '1',
]);;

$review_fields
->addText('review_author', [
  'label' => 'review Author',
])
->addSelect('review_stars',  [
  'placeholder' => 'Select a star value',
  'allow_null' => 1,
])
->addChoice('5-star', '5 Stars')
->addChoice('4-star', '4 Stars')
->addChoice('3-star', '3 Stars')
->addChoice('2-star', '2 Stars')
->addChoice('1-star', '1 Star')
->addTextArea('review_content', [
  'label' => 'review Content',
  'rows'  => 5,
  'new_lines' => 'br'
])
->addRelationship('related_activity', [
  'post_type'	=> 'activity',
  'filters' => array('search', '', ''),
  'return_format' => 'id',
  'label' => 'Related Activity <br/><span style="font-weight: 400">Select an Activity that this review relates to</span>'
])
->setLocation('post_type', '==', 'review');

add_action('acf/init', function() use ($review_fields) {
   acf_add_local_field_group($review_fields->build());
});

function get_stars($star) {
  $output = "";
  switch ($star) {
    case '5-star':
        $output = '<i class="icon-star-filled"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i>';
        break;
      case '4-star':
        $output = '<i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-outline"></i>';
          break;
      case '3-star':
        $output = '<i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-outline"></i><i class="icon-star-outline"></i>';
          break;
      case '2-star':
        $output = '<i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-outline"></i><i class="icon-star-outline"></i><i class="icon-star-outline"></i>';
          break;
      case '2-star':
        $output = '<i class="icon-star"></i><i class="icon-star-outline"></i><i class="icon-star-outline"></i><i class="icon-star-outline"></i><i class="icon-star-outline"></i>';
          break;
    }

    return $output;
}
