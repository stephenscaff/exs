<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Fields - SEO
 * Location: all pages, posts and post types. Edit as needed.
 */

$seo_fields = new StoutLogic\AcfBuilder\FieldsBuilder('seo', [
  'key' => 'seo',
  'position' => 'normal',
  'menu_order' => '13',
]);

$seo_fields
  ->addText('seo_title')
  ->addTextArea('seo_description',  [
    'rows' =>  '2'
  ])
  ->addImage('seo_image')
  ->setLocation('post_type', '==', 'page')
           ->or('post_type', '==', 'post')
           ->or('post_type', '==', 'activity')
           ->or('post_type', '==', 'faq')
           ->or('options_page', '==',  'posts-index')
           ->or('options_page', '==',  'activity-index')
           ->or('options_page', '==',  'faq-index')
           ->or('options_page', '==',  'career-index')
           ->or('taxonomy', '==', 'activity_type')
           ->or('taxonomy', '==', 'activity_location')
           ->or('taxonomy', '==', 'career_department')
           ->or('taxonomy', '==', 'career_location');

add_action('acf/init', function() use ($seo_fields) {
   acf_add_local_field_group($seo_fields->build());
});
