<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *   Intro Sections
 */
$intro_fields = new StoutLogic\AcfBuilder\FieldsBuilder('intro', [
    'key' => 'group_intro',
    'position' => 'acf_after_title',
    'menu_order' => '3',
]);;

$intro_fields
->addText('intro_title', [
  'label' => 'Intro Title',
])
->addTextArea('intro_content', [
  'label'     => 'Intro Content',
  'rows'      => 4,
  'new_lines' => 'br'
])
->setLocation('page_template', '==', 'templates/careers.php')
         ->or('page_template', '==', 'templates/home.php')
         ->or('page_template', '==', 'templates/reviews.php')
         ->or('page_template', '==', 'templates/contact.php')
         ->or('options_page',  '==', 'activity-index');

add_action('acf/init', function() use ($intro_fields) {
   acf_add_local_field_group($intro_fields->build());
});
