<?php
/**
 * Fields - Modules for our Modules Template
 * Location: templates/modules.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

use StoutLogic\AcfBuilder\FieldsBuilder;

$modules_template = new FieldsBuilder('modules_template', [
  'key' => 'group_modules_template',
  'position' => 'acf_after_title',
  'menu_order' => '3',
]);

$modules_template
  ->addFlexibleContent('modules', [
    'button_label'=> "Add Module",
  ])
  ->addLayout($activity_types_module, [
    'name'=> "activity_types_module",
  ])
  ->addLayout($cards_module, [
    'name'=> "cards_module",
  ])
  ->addLayout($content_module, [
    'name'=> "content_module",
  ])
  ->addLayout($cta_module, [
    'name'=> "cta_module",
  ])
  ->addLayout($gallery_module, [
    'name'=> "gallery_module",
  ])
  ->addLayout($link_list_module, [
    'name'=> "link_list_module",
  ])
  ->addLayout($post_feed_module, [
    'name'=> "post_feed_module",
  ])
  ->addLayout($reviews_slider_module , [
    'name'=> "reviews_slider_module",
  ])
  ->addLayout($two_column_module , [
    'name'=> "two_column_module",
  ])
  ->setLocation('page_template', '==', 'templates/modules.php')
    ->or('page_template', '==', 'templates/careers.php');

  add_action('acf/init', function() use ($modules_template) {
     acf_add_local_field_group($modules_template->build());
  });
