<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *   Mast Home
 *   For Home Page Masthead
 */
$faqs_fields = new StoutLogic\AcfBuilder\FieldsBuilder('faq', [
    'key' => 'group_faq',
    'position' => 'acf_after_title',
    'menu_order' => '1',
]);;

$faqs_fields
->addRepeater('faq', [
  'button_label' => 'Add Item',
  'layout' => 'block',
  'min'    => 1,
])
  ->addText('question')
  ->addWysiwyg('answer')
->endRepeater()
# @todo - rework locations or at least apply to a universal template?
->setLocation('post_type', '==', 'faq');

add_action('acf/init', function() use ($faqs_fields) {
   acf_add_local_field_group($faqs_fields->build());
});
