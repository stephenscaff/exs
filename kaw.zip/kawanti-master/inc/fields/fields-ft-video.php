<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *   Ffeatured Video
 */
$featured_video_fields = new StoutLogic\AcfBuilder\FieldsBuilder('ft_video', [
    'key' => 'group_ft_video',
    'position' => 'side',
    'menu_order' => '1',
]);;

$featured_video_fields
->addFile('featured_video', [
  'label'   =>  'Featured Video'
])
# @todo - rework locations or at least apply to a universal template?
->setLocation('post_type', '==', 'activity');

add_action('acf/init', function() use ($featured_video_fields) {
   acf_add_local_field_group($featured_video_fields->build());
});
