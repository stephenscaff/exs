<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Modules Library
 */
use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Activity Booking Fields
 */
 $activity_booking = new StoutLogic\AcfBuilder\FieldsBuilder('activity_booking', [
   'key' => 'group_activity_booking',
   'position' => 'acf_after_title',
   'menu_order' => '1',
 ]);
  $activity_booking
   ->addMessage('', 'Use Online Booking if available, OR, use Call For Booking if Tour cannot be booked online')
   ->addTab('Online Booking')
   ->addUrl('booking_url', [
     'label' => '<h3>Booking URL</h3>Provide Fare Harbor or Take Flight URL',
   ])
   ->addText('booking_price', [
     'label' => '<h3>Price</h3>Provide starting at web price',
   ])
   ->addText('booking_price_disclaimer', [
     'label' => '<h3>Disclaimer</h3>Provide a disclaimer message',
     'default_value' => 'Rate is only valid for tours purchased through the website'
   ])
   ->addTab('Call for Booking')
   ->addTextArea('booking_call_message', [
      'rows' => '3',
   ])
   ->addText('booking_call_phone')
   ->setLocation('post_type', '==', 'activity');
 add_action('acf/init', function() use ($activity_booking) {
    acf_add_local_field_group($activity_booking->build());
 });
 /**
  * Activity Booking Fields
  */
$related_activities = new StoutLogic\AcfBuilder\FieldsBuilder('related_activities', [
  'key' => 'group_related_activity',
  'position' => 'normal',
  'menu_order' => '8',
]);

$related_activities
  ->addRelationship('activity_selector',  [
   'label'      => 'Related Activities',
   'post_type'  =>  'activity',
   'filters'    => array('search', '', ''),
   'max'        => 2,
  ])
  ->setLocation('post_type', '==', 'activity');
  add_action('acf/init', function() use ($related_activities) {
   acf_add_local_field_group($related_activities->build());
  });

/**
  * ACtivity Intro Module
  * @see scss/components/_content (post-content)
  */
$activity_intro_module = new FieldsBuilder('activity_intro_module');
$activity_intro_module
 ->addMessage('', 'The Activity Intro Module adds the main intro section or the Activity.')
 ->addText('title')
 ->addWysiwyg('content');


 /**
  * ACtivity Intro Module
  * @see scss/components/_content (post-content)
  */
// $activity_difficulty_module = new FieldsBuilder('activity_difficulty_module');
// $activity_difficulty_module
//  ->addMessage('', 'The Activity Degree Module allows you to specifiy the Activity\'s Level of Difficulty.')
//  ->addSelect('difficulty_select')
//   ->addChoice('tip-easy', 'Easy')
//   ->addChoice('tip-medium', 'Medium')
//   ->addChoice('tip-active', 'Active')
//  ->addWysiwyg('content');

 /**
  * Activity Tips Module
  * @see scss/components/_content (post-content)
  */
$activity_gallery_module = new FieldsBuilder('activity_gallery_module');
$activity_gallery_module
 ->addMessage('', 'The Activity Gallery Module adds the main intro section or the Activity.')
 ->addRepeater('images', [
   'max' => 20,
   'min' => 1,
   'button_label' => 'Add Image',
   'layout' => 'block',
 ])
 ->addImage('image');


 /**
  * Activity Tips Module
  * @see scss/components/_content (post-content)
  */
$activity_video_module = new FieldsBuilder('activity_video_module');
$activity_video_module
->addMessage('', 'The Activity Video Module allows you to add a video to the page. Upload an Mp3 OR provide a Vimeo ID OR Youtube ID')
->addFile('video_mp4', [
 'wrapper' =>  ['width' => '33.333%'],
 'label'   =>  'Mp4'
])
->addText('video_vimeo_id', [
 'wrapper' =>  ['width' => '33.333%'],
 'label'   =>  'Vimeo ID'
])
->addText('video_youtube_id', [
 'wrapper' =>  ['width' => '33.333%'],
 'label'   =>  'YouTube ID'
]);


 /**
  * Activity Tips Module
  * @see scss/components/_content (post-content)
  */
$activity_tips_module = new FieldsBuilder('activity_tips_module');
$activity_tips_module
 ->addMessage('', 'The Activity Tips Module creates a list of useful tips.')
 ->addTab('Tips')
 ->addRepeater('tips')
  ->addFields($tip_icons)
  ->addText('title')
 ->addTextArea('content', [
   'rows' => '2',
   'maxlength' => '82',
 ])
 ->endRepeater()
 ->addTab('Difficulty')

  ->addSelect('difficulty_select', [
    'return_format'	=> 'array'
  ])
   ->addChoice('tip-easy', 'Easy')
   ->addChoice('tip-moderate', 'Moderate')
   ->addChoice('tip-active', 'Active')
  ->addTextArea('difficulty_content');
 /**
  * Reviews Slider Module
  */
 $activity_reviews_module = new FieldsBuilder('activity_reviews_module');
 $activity_reviews_module
 ->addMessage('', 'The Reveiws Modules allows you to display Reviews by selection or Activity Type')
 ->addText('add_review_link')
 ->addTrueFalse('related_reviews', [
   'label' => 'Related Reviews <br/><span style="font-weight: 400;">Show Reviews specific to this Activity (as selected on the review admin page)'
 ])
 ->addTaxonomy('review_term', [
  'label'      => 'Or, Show Reviews by Activity Type',
  'taxonomy'   => 'activity_type',
  'return_format' => 'object',
  'field_type'     => 'select',
  'allow_null'     => 1,
  'wrapper'    =>  ['width' => '50%'],
 ])
 ->addRelationship('review_selector',  [
  'label'      => 'Or, select specific Reviews',
  'post_type'  =>  'review',
  'filters'    => array('search', '', ''),
  'max'        => 6,
  'wrapper'    =>  ['width' => '50%'],
 ]);


/**
 * Activity Modules
 */
$modules_activity = new FieldsBuilder('modules_activity', [
 'key' => 'group_modules_activity',
 'position' => 'acf_after_title',
 'menu_order' => '3',
]);

$modules_activity
 ->addFlexibleContent('modules', [
   'button_label'=> "Add Module",
 ])
 ->addLayout($activity_intro_module, [
   'name'=> "activity_intro_module",
 ])
 ->addLayout($activity_gallery_module, [
   'name'=> "activity_gallery_module",
 ])
 ->addLayout($activity_video_module, [
   'name'=> "activity_video_module",
 ])
 ->addLayout($activity_tips_module, [
   'name'=> "activity_tips_module",
 ])
 ->addLayout($activity_reviews_module, [
   'name'=> "activity_reviews_module",
 ])
 ->setLocation('post_type', '==', 'activity');

 add_action('acf/init', function() use ($modules_activity) {
    acf_add_local_field_group($modules_activity->build());
 });
