<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Buttons
 */
$button_field = new FieldsBuilder('button');
$button_field
 # Button Page link
 ->addPageLink('button_link', [
   'allow_null'  => 'true',
   'wrapper' =>  ['width' => '33.333%'],
   'label'  =>   'Button Page Link (internal)',
 ])
 # Button URL
 ->addText('button_url', [
   'wrapper' =>  ['width' => '33.333%'],
   'label'  =>   'Button URL (external)'
 ])
 # Button Text
 ->addText('button_text', [
   'wrapper' =>  ['width' => '33.333%'],
 ]);


 /**
  * Headings
  */
 $heading_field = new FieldsBuilder('heading');
 $heading_field
  # Heading Title
  ->addText('heading_title', [
    'label' =>  'Section Title'
  ]);


 /**
  * Icon Selector
  */
 $tip_icons = new FieldsBuilder('tips_icons');
 $tip_icons
   ->addSelect('tips_icon',  [
     'placeholder' => 'Select an Icon',
     'allow_null' => 1,
   ])
   ->addChoice('tip-age', 'Age')
   ->addChoice('tip-duration', 'Duration')
   ->addChoice('tip-height', 'Height')
   ->addChoice('tip-meal', 'Meal')
   ->addChoice('tip-shopping', 'Shopping')
   ->addChoice('tip-snack', 'Snack')
   ->addChoice('tip-toes', 'Toes')
   ->addChoice('tip-waiver', 'Waiver')
   ->addChoice('tip-weight', 'Weight');
