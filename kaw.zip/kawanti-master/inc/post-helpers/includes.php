<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

require_once 'post-templates.php';
require_once 'filters.php';
