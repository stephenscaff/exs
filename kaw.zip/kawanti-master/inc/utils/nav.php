<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Bail if accessed directly

/**
 *   Nav Active Class.
 *   Adds active class, since we're not using native wp menus
 *
 *   @param    string $page_name
 *   @return   string 'is-active';
 */
function jumpoff_active_class( $page_name ){
  if (is_page( $page_name ) || is_post_type_archive( $page_name )) {
    return 'is-active';
  }
}


/**
 *   Gets page link.
 *   For use with our custom navigations
 *
 *   @param    string $page_name
 *   @return   string 'is-active';
 */
function jumpoff_get_page_url( $page_name, $cpt='' ){
  if ( $cpt == true ) {
    $page_url = esc_url( get_post_type_archive_link( $page_name ) );
  } else {
    $page_url = esc_url( get_permalink( get_page_by_title( $page_name ) ) );
  }
  return $page_url;
}


/**
 * Get Subpage Links
 * Outputs a post types subpages as nav items
 * @var $post_type sring - The desired post type
 * @var $klass string - class name for link
 * @return string
 */
function jumpoff_get_subpage_links( $post_type, $klass ){
  global $post ;

  $args = array(
   'posts_per_page'   => -1,
   'post_type'        => $post_type,
  );
  $links  = get_posts( $args );
  $output = '';

  foreach ( $links as $post ) : setup_postdata( $post );
    $url     = get_the_permalink();
    $title   = get_the_title();
    $output .= '<a class="'. $klass . '" href="' . $url . '">' . $title . '</a>';
  endforeach;
  wp_reset_postdata();

  return $output;
}




/**
 * Render Menu
 * Renders Simple Menus with options for class name and menu title.
 *
 * @var string $menu_name
 * @var string $menu_class - Nav element class name
 * @var string $menu_title - optional menu title
 * @return $output html blob
 */
 function render_menu($menu_name, $menu_class = null, $menu_title = null) {
   global $post;
   $locations = get_nav_menu_locations();
   $menu_id = $locations[$menu_name];
   $menu_items = wp_get_nav_menu_items($menu_id);
   $output = '';
   $output .= '
    <nav class="'.$menu_class.'">';
    if ($menu_title) :
      $output .= '<h5 class="'.$menu_class.'__title">'.$menu_title.'</h5>';
    endif;
    $output .= '<ul class="'.$menu_class.'__list" role="menubar">';
    if ($menu_items) :
      foreach($menu_items as $menu_item  => $item) :
          $output .= '
           <li class="'.$menu_class.'__item" role="menuitem"><a class="'.$menu_class.'__link" href="'.$item->url.'">'.$item->title.'</a></li>';
      endforeach;
    endif;
    $output .= '
    </ul>
  </nav>';

  return $output;
}
