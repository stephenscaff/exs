<?php

if ( ! defined( 'ABSPATH' ) ) exit;

require_once 'body-class.php';
require_once 'debuggers.php';
require_once 'conditionals.php';
require_once 'formating.php';
require_once 'nav.php';
require_once 'paths.php';
require_once 'post-type-labels.php';
require_once 'sitemap.php';
