<?php
/**
* The default template for single activities
*
* @author    Stephen Scaff
* @package   jumpoff
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while (have_posts()) : the_post();
global $post;

$this_post_id = get_the_ID();
$post_title = get_the_title();
$post_ft_img = jumpoff_ft_img('full');
$ft_vid = get_field('featured_video');
$ft_img_position = get_post_meta($this_post_id,'ft_img_position', true);
$booking_url = get_field('booking_url');
$booking_price = get_field('booking_price');
$booking_price_disclaimer = get_field('booking_price_disclaimer');
$booking_call_message = get_field('booking_call_message');
$booking_call_phone = get_field('booking_call_phone');


get_template_part( 'partials/partial', 'schema-activity' );


?>

<main role="main" class="has-header-offset">

<!-- Activity Article -->
<article class="activity-article">

  <!-- Activity mast -->
  <section class="activity-mast">

    <?php if ($ft_vid && !wp_is_mobile()) : ?>
    <div class="activity-mast__bg-vid bg-vid">
      <span class="bg-vid__cover"></span>
      <video class="bg-vid__vid" autoplay="" loop="" muted poster="">
        <source type="video/mp4" src="<?php echo $ft_vid['url']; ?>">
      </video>
    </div>
    <?php endif; ?>

    <figure class="activity-mast__figure js-plax-mast" style="background-image: url(<?php echo $post_ft_img->url; ?>); background-position: <?php echo $ft_img_position; ?>"></figure>
    <header class="activity-mast__header grid-lg">
      <h1 class="activity-mast__title"><?php echo $post_title; ?></h1>
    </header>
    <?php if (is_flight_activity()) : ?>
      <figure class="medallion-shield"><img src="<?php echo jumpoff_img(); ?>/badges/medallion-shield.png" alt="Alaskian Medallion Shield "/></figure>
    <?php endif; ?>
    <div class="border-bottom-texture"></div>
  </section>

<!-- Activity Details (layout) -->
  <section class="activity-details">
    <div class="grid-lg">
      <div class="activity-details__grid">

        <!-- Aside -->
        <aside class="activity-details__aside">

          <!-- Booking -->
          <div class="activity-booking">
            <div class="activity-booking__bg">

              <?php if ($booking_price) : ?>
                <h5 class="activity-booking__title">Web Rates Starting At</h5>
                <div class="activity-booking__price">$<?php echo $booking_price; ?><span class="ast">*</span></div>
                <a class="activity-booking__btn btn" href="<?php echo $booking_url; ?>">Book Now</a>
                <?php if ($booking_price_disclaimer) : ?><span class="activity-booking__disclaimer">*<?php echo $booking_price_disclaimer; ?></span><?php endif; ?>
              <?php endif; ?>

              <?php if ($booking_call_message && !$booking_price) : ?>
                <h5 class="activity-booking__title">Online Booking Unavailable</h5>
                <?php if ($booking_call_message) : ?><p class="activity-booking__message"><?php echo $booking_call_message; ?></p><?php endif; ?>
                <?php if ($booking_call_phone) : ?><a class="activity-booking__btn btn" href="tel:<?php echo format_tel_link($booking_call_phone); ?>">Call: <?php echo $booking_call_phone; ?></a><?php endif; ?>
              <?php endif; ?>
            </div>
          </div>
        </aside>

        <!-- Activity Main -->
        <section class="activity-details__main">
          <?php get_template_part( 'partials/partial', 'modules' ); ?>
        </section>
      </div>
    </div>
  </section>

  <?php get_template_part( 'partials/partial', 'related-activities' ); ?>

</article>

</main>

<?php endwhile; ?>

<!-- FareHarbor Lightframe API  -->
<script src="https://fareharbor.com/embeds/api/v1/?autolightframe=yes"></script>

<!-- Footer-->
<?php get_footer(); ?>
