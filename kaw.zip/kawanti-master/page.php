<?php
/**
 * Default Page Template
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

$title = get_the_title();
$ft_img = jumpoff_ft_img('full');

if (has_ft_img($post->ID)) {
  $has_ft_img = true;
}
?>

<!-- Main -->
<main class="has-header-offset">

<!-- Mast -->
<section class="mast-title <?php if ($has_ft_img) : echo 'has-ft-img'; endif; ?>">
  <header class="mast__header">
    <h1 class="mast-title__title"><?php echo $title; ?></h1>
    <p class="mast-title__subtitle"><?php echo $subtitle; ?></p>
  </header>

  <?php if ($has_ft_img) : ?>
    <div class="mast-title__ft-img grid">
      <figure class="mast-title__figure">
        <div class="mast-title__img" style="background-image: url(<?php echo $ft_img->url; ?>)"></div>
      </figure>
    </div>
  <?php endif; ?>
</section>

<!-- Content -->
<section class="content pad">
  <div class="grid-sm">
  <?php
    while (have_posts()) : the_post();
      the_content();
   endwhile;
  ?>
  </div>
</section>

</main>

<!-- Footer -->
<?php get_footer(); ?>
