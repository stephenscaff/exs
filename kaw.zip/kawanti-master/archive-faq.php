<?php
/**
 * Template for Activites, Actiity Type, Activity Location Archives
 *
 * A controller function redirects activity archives to this template.
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 * @see       inc/post-type/post-type-activities
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

$title = 'Frequently Asked Questions';
$subtitle = get_field('subtitle');
?>

<main role="main" class="has-header-offset">

<!-- Mast -->
<section class="mast-title">
  <header class="mast__header">
    <h1 class="mast-title__title"><?php echo $title; ?></h1>
    <?php if ($subtitle) : ?><p class="mast-title__subtitle"><?php echo $subtitle; ?></p><?php endif; ?>
  </header>
</section>

<section class="faqs-cards pad">
  <div class="grid-lg">
    <div class="faqs-cards__grid grid-1-3">
      <?php

      $args = array(
        'posts_per_page'   => -1,
        'post_type'        => 'faq',
      );

      $careers = get_posts( $args );


      foreach ( $careers as $post ) : setup_postdata( $post );
        $link = get_the_permalink();
        $title = get_the_title();
        $img = jumpoff_ft_img('medium');
      ?>
        <article class="post-card">
          <a class="post-card__link" href="<?php echo $link; ?>">
            <figure class="post-card__figure">
              <img class="post-card__img" src="<?php echo $img->url; ?>" alt="<?php echo $img->alt; ?>"/>
            </figure>
            <header class="post-card__header">
              <h3 class="post-card__title"><?php echo $title; ?></h3>
              <span class="post-card__btn btn-line">Read On</span>
            </header>
          </a>
        </article>
      <?php endforeach;
      wp_reset_postdata();

      ?>
    </div>
  </div>
</section>


</main>

<!-- Footer  -->
<?php get_footer(); ?>
