<?php
/**
* The default template for single blog posts.
*
* @author    Stephen Scaff
* @package   jumpoff
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

while (have_posts()) : the_post();

$post_title = get_the_title();
$post_ft_img = jumpoff_ft_img('full');
$post_subtitle = get_post_meta($post->ID,'subtitle', true);
// Auhtors
$author_id = get_the_author_meta('ID');
$author_content = get_user_meta($author_id, 'user_content', true);
$author_avatar = get_user_meta($author_id, 'user_avatar', true);
$author_avatar_img = wp_get_attachment_image_src($author_avatar)[0];
$author_position = get_user_meta($author_id, 'position', true);
$author_link = get_author_posts_url( $author_id, get_the_author_meta( 'user_nicename' ) );
$author_name = get_the_author_meta('display_name');

?>

<main role="main" class="has-header-offset">

<article>

<!-- Post Mast -->
<section class="post-mast">
  <figure class="post-mast__figure" style="background-image: url(<?php echo $post_ft_img->url; ?>)"></figure>
  <header class="post-mast__header grid">
    <time class="post-mast__meta"><?php the_time('F j, Y'); ?></time>
    <h1 class="post-mast__title"><?php echo $post_title; ?></h1>
    <p class="post-mast__subtitle"><?php echo $post_subtitle; ?></p>
  </header>
</section>

<!--Post Content -->
<section class="post-content content">
  <div class="grid-sm">
      <?php the_content(); ?>
  </div>
</section>

<!--Post Shares -->
<aside class="post-shares">
  <div class="grid-sm">
  <h5 class="post-shares__title">Share</h5>
  <nav class="post-shares__links">
    <a class="post-shares__link" href="http://twitter.com/intent/tweet?text=<?php the_title(); ?>+<?php the_permalink(); ?>">Twitter</a> -
    <a class="post-shares__link" href="http://www.facebook.com/share.php?u=<?php the_permalink(); ?>/&amp;title=<?php the_title(); ?>">Facebook</a> -
    <a class="post-shares__link" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php the_title(); ?>&summary=&source=<?php get_home_url(); ?>" target="_blank" rel="external">LinkedIn</a>
  </nav>
  </div>
</aside>

<!-- Post Footer -->
<section class="post-footer">
  <div class="grid-sm">
    <div class="post-footer__bg">

      <header class="post-footer__heading">
        <span class="post-footer__label">Posted By</span>
      </header>

      <div class="post-footer__grid">
        <figure class="post-footer__avatar">
          <img class="post-footer__avatar-img" src="<?php echo $author_avatar_img; ?>">
        </figure>
        <div class="post-footer__byline">
          <a class="post-footer__byline-author" href="<?php echo $author_link; ?>"><?php echo $author_name; ?></a>
          <p class="post-footer__byline-attr"><?php echo $author_position; ?></p>
          <p class="post-footer__byline-bio"><?php echo $author_content; ?></p>
        </div>
      </div>
    </div>
  </div>
</section>

</article>

<?php

// get_template_part( 'partials/partial', 'next' );
get_template_part( 'partials/partial', 'related-posts' );

?>
</main>

<?php endwhile; ?>

<!-- Footer-->
<?php get_footer(); ?>
