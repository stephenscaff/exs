<?php
/**
 * Four Oh Four Template
 *
 * @author    Stephen Scaff
 * @package   404
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<!-- MAIN -->
<main role="main" class="bg-white has-header-offset">

<section class="fourohfour">
  <div class="grid">
    <div class="fourohfour__grid">
      <figure class="fourohfour__figure">
        <img src="<?php echo jumpoff_img(); ?>/404/404-2.gif">
      </figure>

      <div class="fourohfour__content">
        <span class="fourohfour__meta">404</span>
        <h1 class="fourohfour__title">Whoops!</h1>
        <p class="fourohfour__text">Looks like you've lost your way. <br/>But no worries, we'll help you find what your looking for.</p>
        <nav class="fourohfour__nav">
          <div><a class="fourhofour__link" href="<?php echo jumpoff_get_page_url('home') ?>">Take Me Home</a></div>
          <div><a class="fourhofour__link" href="<?php echo jumpoff_get_page_url('activities', 1) ?>">Book an Activity</a></div>
          <div><a class="fourhofour__link" href="<?php echo jumpoff_get_page_url('about') ?>">About Kawanti</a></div>
          <div><a class="fourhofour__link" href="<?php echo jumpoff_get_page_url('contact') ?>">Contact Us</a></div>
          <div><a class="fourhofour__link" href="<?php echo jumpoff_get_page_url('help') ?>">Help & Support</a></div>
        </nav>
      </div>
    </div>
  </div>
</section>

</main>

<!-- Footer  -->
<?php get_footer(); ?>
