/**
 * Site Inits object
 * Just to provide a bit of encaplsation & control
 */
var site = {

  /**
   * Plyr Init
   * @see js/vendor/_plyr.js
   * @see scss/vendor/_plyr.js
   */
  plyr: function() {
    var players = Plyr.setup('.js-plyr');
  },

  /**
   * Slider - Reviews
   * @see js/libs/_slick.js
   */
  reviewsSlider: function() {
    var $slider = $('.js-reviews-slider');

    $slider.slick({
       mobileFirst: true,
       dots: false,
       fade: true,
       touchThreshold:20,
       edgeFriction: 0.015,
       cssEase: 'linear',
       slidesToShow: 1,
       slidesToScroll: 1,
       arrows: true,
       infinite:true,
       nextArrow: '<button class="reviews-slider__next"><i class="icon-right-chev"></i></button>',
       prevArrow: '<button class="reviews-slider__prev"><i class="icon-left-chev"></i></button>',
   });
  },

  /**
   * Instagram Init
   * @see js/components/_instagrammin.js
   */
  instagrammin: function() {
    $('.js-instagrammin').everydayImInstagrammin({
      clientID: '7108018920',
      accessToken: '7108018920.1677ed0.886d99d768e84521bd99310157a07440',
      numberPics: '12',
    });
  },

  plaxMast: function() {
    var rellax = new Rellax('.js-plax-mast', {
      speed: -3,
    });
  },

};


/**
 * Init Plyr
 */
if ( document.querySelectorAll('.js-plyr').length ) {
  site.plyr();
}

/**
 * Init Testimonials Slider
 */
if ( document.querySelectorAll('.js-reviews-slider').length ) {
  site.reviewsSlider();
}

/**
 * Init Instagrammin
 */
if ( document.querySelectorAll('.js-instagrammin').length ) {
  site.instagrammin();
}

// if ( document.querySelectorAll('.js-plax-mast').length ) {
//   site.plaxMast();
// }
