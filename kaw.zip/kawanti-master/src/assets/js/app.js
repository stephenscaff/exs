/**
 * JS Includes
 * Include js files here, in the desired order.
 */
 /* jshint -W030 */
 /* globals feature: false */


//=include libs/_slick.js
//=include libs/_plyr.js
//=include components/_utils.js
//=include components/_page-transitions.js
//=include components/_popups.js
//=include components/_dropdowns.js
//=include components/_header-state.js
//=include components/_menu-small.js
//=include components/_instagrammin.js
//=include components/_activity-gallery.js
//=include components/_read-more.js
//=include components/_external-links.js
//=include components/_random-bg.js
//=include _inits.js
