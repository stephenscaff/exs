/**
 * Activity Gallery
 *
 * Launches the popup image slider (lightbox) for our Activity Gallery Module.
 * This js module just initializes slick.js on click and sets focus so the user
 * can also key through images.

 * The popup functionality is handled with out popups.js module.
 *
 * @author stephen scaff
 * @see partials/modules/activity-gallery-module.php
 * @see js/compnoents/_popups.js
 * @see js/libs/_slick.js
 */
 var ActivityGallery = function(){


   return {

     init: function() {
       this.bindEvents();
     },

     bindEvents: function() {
       ActivityGallery.handleClick();
     },

     initSlick: function() {
       var $slider = $('.js-gallery-slider');

       $slider.not('.slick-initialized').slick({
          mobileFirst: true,
          dots: false,
          fade: true,
          touchThreshold:20,
          edgeFriction: 0.015,
          cssEase: 'linear',
          slidesToShow: 1,
          slidesToScroll: 1,
          arrows: true,
          infinite:true,
          nextArrow: '<button class="gallery-popup__next"><i class="icon-right-chev"></i></button>',
          prevArrow: '<button class="gallery-popup__prev"><i class="icon-left-chev"></i></button>',
      });
     },

     handleClick: function() {
       var el = document.querySelector('.js-gallery-trigger');

       el.addEventListener('click', function (e) {
         ActivityGallery.initSlick();

         setTimeout(function() {
           $(document).find('.slick-list').attr('tabindex', 0).focus();
         }, 100);
       });
     },
   }
 }();

if ( document.querySelectorAll('.js-gallery-slider').length ) {
  ActivityGallery.init();
}
