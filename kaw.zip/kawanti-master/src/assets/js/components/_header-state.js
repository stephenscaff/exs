/**
* Header State
* Updats Header state on scroll
*/
var HeaderState = (function() {


 body = document.querySelector('body');
 header = document.querySelector('.app-header');
 threshold = 190;
 throttleAmnt = 10;
 lastKnownScrollY = 0;
 classes = {
   pinned : 'header-is-pinned',
   unpinned : 'header-is-unpinned',
 }

 return{

   init: function(){
     this.bindEvents()
   },

   bindEvents: function(){
     setTimeout(function() {
       window.addEventListener('scroll', Util.throttle(HeaderState.scrollEvent, throttleAmnt));
     }, 10);
   },

  /**
   * Attaches the scroll event
   * @private
   */
  scrollEvent : function() {

    var scrollDistance =  Math.round(window.scrollY);

    if (scrollDistance >= threshold) {
      HeaderState.pin();
    }

    if (scrollDistance <= 0) {
      HeaderState.unpin();
    }
  },

  /**
   * Pinned State (fixed position)
   */
  pin: function() {
     body.classList.remove(classes.unpinned);
     body.classList.add(classes.pinned);
   },

   /**
    * Unpinned State
    */
   unpin: function() {
     body.classList.remove(classes.pinned);
     body.classList.add(classes.unpinned);
   },
 };
})();

HeaderState.init();
