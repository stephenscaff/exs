/**
 * Dropdowns
 * Dropdown component used for Activity Filters
 *
 * @see partials/partial-activity-filters.php
 * @see src/assets/scss/components/_dropdowns.scss
 */
var Dropdowns = (function() {

  var html = document.querySelector('html');
  var dds = document.querySelectorAll('.js-dropdown');
  var ddTriggers = document.querySelectorAll('.js-dropdown-trigger');

  return{

    /**
    * Init
    */
    init: function() {
     this.bindEvents();
    },

    bindEvents:function() {

      /**
      * Main DD Click Event
      */
      Util.forEach ( ddTriggers, function (index, ddTrigger) {

        ddTrigger.addEventListener('click', function (e) {
          Dropdowns.open(ddTrigger);
          e.preventDefault();
        });
      });

       /**
        * Close open DD on Outside Click
        */

      html.addEventListener('click', function(e) {
        var openDD = document.querySelector('.js-dropdown.is-open .js-dropdown-trigger');
        if (!openDD) return;
        Dropdowns.close(openDD);e.stopPropagation();
      });
    },


     /**
      * Close Clicked DD
      */
      close: function(el){
        console.log('close',el)
        el.parentElement.classList.add('is-closing');

        setTimeout(function(){
           el.parentElement.classList.remove('is-open');
           el.parentElement.classList.remove('is-closing');
           el.parentElement.classList.add('is-closed');
        }, 200);
      },

     /**
      * Open Clicked DD
      */
     open: function(el){
       el.parentElement.classList.add('is-opening');

       setTimeout(function(){
         el.parentElement.classList.remove('is-closed');
         el.parentElement.classList.remove('is-opening');
         el.parentElement.classList.add('is-open');
      }, 150);
    },
  };
})();

if ( document.querySelectorAll('.js-dropdown').length ) {
  Dropdowns.init();
}
