

/**
* Random Backgorund Images
* Sets a random background image from an
* array of paths, set to a data attribute.
*/
var RandoBgs = (function() {


 var randomBgs = document.querySelectorAll('.js-rando-image');


 return{

    init: function() {
      this.bindEvents()
    },

    bindEvents: function() {
      RandoBgs.getImages();
    },

    /**
     * getImages
     * Gets images array from data-attribute and parses as JSON.
     */
    getImages: function() {
      Util.forEach ( randomBgs, function (index, randomBg) {
        var images = JSON.parse(randomBg.dataset.images);
        randomImage = RandoBgs.getRandomImage(images);

        RandoBgs.setImage(randomBg, randomImage);
      });
    },

    /**
     * getRandomImage
     * Gets a random images from provided array.
     * @return {string} the image path
     */
    getRandomImage: function(imageArr) {
     var randomize = Math.floor(Math.random()*imageArr.length);
     var selectedImage = imageArr[randomize];
     return selectedImage;
    },

    /**
     * Sets our image path as a background image.
     */
    setImage: function(el, image) {
      el.style.backgroundImage = 'url('+image+')';
    }
  };
})();

if (document.querySelector('.js-rando-image')) {
  RandoBgs.init();
}
