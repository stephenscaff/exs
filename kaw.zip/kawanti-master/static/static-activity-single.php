<?php
/**
* The default template for single blog posts.
*
* @author    Stephen Scaff
* @package   jumpoff
* @version   1.0.0
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

while (have_posts()) : the_post();

$post_title = get_the_title();
$post_ft_img = jumpoff_ft_img('full');
$post_subtitle = get_post_meta($post->ID,'subtitle', true);
$author_id = get_the_author_meta('ID');
$author_avatar = get_user_meta($author_id, 'user_avatar', true);
$author_avatar_img = wp_get_attachment_image_src($author_avatar)[0];
$author_position = get_user_meta($author_id, 'position', true);
$author_link = get_author_posts_url( $author_id, get_the_author_meta( 'user_nicename' ) );
$author_name = get_the_author_meta('display_name');

?>

<main role="main" class="has-header-offset">

<article class="activity-article">

<!-- Activity mast -->
<section class="activity-mast">
  <figure class="activity-mast__figure" style="background-image: url(<?php echo $post_ft_img->url; ?>)"></figure>
  <header class="activity-mast__header grid-lg">
    <h1 class="activity-mast__title"><?php echo $post_title; ?></h1>
  </header>
</section>

<!-- Activity Details (layout) -->
<section class="activity-details">
  <div class="grid-lg">
    <div class="activity-details__grid">
      <!-- Aside -->
      <aside class="activity-details__aside">

        <!-- Booking -->
        <div class="activity-booking">
          <div class="activity-booking__bg">
            <h5 class="activity-booking__title">Web Rates Starting At</h5>
            <div class="activity-booking__price">$269<span class="ast">*</span></div>
            <button class="activity-booking__btn btn">Book Now</button>
            <span class="activity-booking__disclaimer">*rate is only valid fortours purchased through the website</span>
          </div>
        </div>
      </aside>

    <!-- Activity Main -->
    <section class="activity-details__main">


      <section class="activity-intro module">
        <h2 class="activity-intro__title">Visit Misty Fjords National Monument From Ketchikan, Alaska</h2>

        <div class="activity-intro__content">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sed nunc quis magna hendrerit pretium fermentum in mauris. Integer eget cursus quam. Cras non sapien sed augue tincidunt tristique in eget enim.</p>

          <p>Quisque efficitur tortor metus, vitae bibendum velit gravida non. Nulla ut ipsum et neque cursus pharetra. Mauris sollicitudin feugiat lorem, et malesuada dolor fringilla eu.</p>

          <p>Phasellus lobortis justo id purus congue elementum. Curabitur gravida turpis in ex aliquet, vel scelerisque tellus mattis. Phasellus tempus risus lacus. Pellentesque iaculis quis quam nec ullamcorper.</p>
        </div>

      </section>

      <section class="activity-tips module">

        <h4 class="activity-tips__title">Need to Know</h4>

        <div class="activity-tips__grid">
          <div class="activity-tips">
            <div class="activity-tips__icon"><i class="icon-map"></i></div>
            <p class="activity-tips__text">Tour time is 2 hours including transfers</p>
          </div>

          <div class="activity-tips">
            <div class="activity-tips__icon"><i class="icon-glasses"></i></div>
            <p class="activity-tips__text">Tour time is 2 hours</p>
          </div>

          <div class="activity-tips">
            <div class="activity-tips__icon"><i class="icon-map"></i></div>
            <p class="activity-tips__text">You can't be all kinds of blind man</p>
          </div>

          <div class="activity-tips">
            <div class="activity-tips__icon"><i class="icon-map"></i></div>
            <p class="activity-tips__text">Be chill as bill on the hill phil</p>
          </div>

          <div class="activity-tips">
            <div class="activity-tips__icon"><i class="icon-map"></i></div>
            <p class="activity-tips__text">There be dragons and bears and stuff   </p>
          </div>

          <div class="activity-tips">
            <div class="activity-tips__icon"><i class="icon-map"></i></div>
            <p class="activity-tips__text">Tout time is 2 hours</p>
          </div>
        </div>

      </section>


      <section class="activity-degree module">
        <h4 class="activity-degree__title">Level of Dfficulty</h4>

        <div class="badge is-easy"><span>Easy</span></div>

        <div class="badge is-moderate"><span>Moderate</span></div>

        <div class="badge is-hard"><span>Hard</span></div>

        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sed nunc quis magna hendrerit pretium fermentum in mauris. Integer eget cursus quam. Cras non sapien sed augue tincidunt tristique in eget enim.</p>

      </section>

      <section class="activity-gal module">
        <h4 class="activity-gal__title">Photo Gallery</h4>


      </section>


      <section class="activity-reviews module">


      </section>

      </section>
    </div>
  </div>
</section>

</article>
</main>

<?php endwhile; ?>

<!-- Footer-->
<?php get_footer(); ?>
