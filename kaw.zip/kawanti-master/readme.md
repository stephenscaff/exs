# Kawanti

## A custom wp build for Kawanti


### Features

- Gulp for task running
- A lightweight front-end framework of sorts, with sensible scss/js structuring and a js includes system (see src/assets/js/app.js),
- Organization by partials and components
- A php approach to field management via ACF and Stout Logic's ACF Builder
- Custom drag and drop modules for content authorship
- Custom Admin theme (styles and functionality)
- A small library of useful utilities/helpers

### Dependencies
- [Node](https://nodejs.org/en/download/) : to run `gulp`.
- [NPM](https://www.npmjs.com/get-npm) : also to run `gulp`.
- [Gulp](https://gulpjs.com/) : for compiling, minimizing and linting scss, js, svgs, images, etc.
- [SCSS/SASS](https://sass-lang.com/) : for css authorship.
- [WordPress](https://wordpress.org/) : This is a custom Wordpress build
- [ACF](https://www.advancedcustomfields.com/pro/) : For managing fields, metas, options, etc.
- [StoutLogic ACF Builder](https://github.com/StoutLogic/acf-builder) : A more sane way to register ACF fields within PHP utils

### Run

Install Gulp

```
npm install gulp
```

Install Gulp dependencies

```
npm install --save-dev
```

Install Composer dependencies

```
composer install
```


### Composer

Currently Composer is just installing StoutLogic's ACF Builder.

Make sure to run composer first, or the theme can't locate autoload and you'll see a custom error.


### CSS / JS

As much as possible, css and js is organized by component, named after it's usage / BEM naming convention. JS files are loaded via `gulp includes` from `js/_app.js`. Most stuff in this project is just ES5 right now. Will probably change that soon.

### Post helpers


```
/**
 * Get Excerpts
 * @see inc/post-helpers/post-templates.php
 */
jumpoff_get_excerpt('150')

/**
 * Get Featured Image (url | alt)
 * @see inc/media/featured-images.php
 */
jumpoff_ft_img('full')

# Useage
$ft_img = jumpoff_ft_img('full');
$ft_img_url = $ft_img->url;
$ft_img_alt = $ft_img->alrt;


/**
 * Get SVG Paths
 * Gulp helper builds svgs saved in images with .php so they can be included.
 * @see inc/utils/paths.php
 */
 jumpoff_svg( $file_name )

/**
 * Get static Image directory `assets/images/*`
 */
 jumpoff_img()

 /**
  * Get static Image directory `assets/images/*`
  * @see inc/utils/nav.php
  */
  jumpoff_page_url()

```

### Fields

This build uses ACF for Fields, but actual field authorship is enhanced with [Stout Logic's ACF Builder](https://github.com/StoutLogic/acf-builder).

Stout Logic provides a fluent API for rapidly creating and configuring ACF Fields in PHP, using a really nice builder pattern. It's a more robust solution than `acf-json` in actual practice.

A full cheatsheet on the available fields and their params can be found here:

[Stout Logic's ACF Builder Cheat Sheet](https://gist.github.com/stephenscaff/7eaf497fa01bea5b9b5a939539412b2c)


### Creating Fields

Here's an example of creating fields:

```

/**
 * Fields - SEO
 * Location: Pages, posts, Team post type.
 */
$seo_fields = new StoutLogic\AcfBuilder\FieldsBuilder('seo', [
  'key' => 'seo',
  'position' => 'normal',
]);

$seo_fields
  ->addText('seo_title')
  ->addTextArea('seo_description',  [
    'rows' =>  '2'
  ])
  ->addImage('seo_image')
  ->setLocation('post_type', '==', 'page')
           ->or('post_type', '==', 'post')
           ->or('post_type', '==', 'team');

add_action('acf/init', function() use ($seo_fields) {
   acf_add_local_field_group($seo_fields->build());
});
```

All Fields are registered in `inc/fields/*`, generally in their own clearly named file. Variables for reuse are housed in `inc/fields/fields-vars.php` and `inc/fields/fields-vars-modules.php`


### Setting Field Locations
`
You can set the locations of field groups with the `->setLocation()` and `->or()` methods.

```
// Set to a page template
->setLocation('page_template', '==', 'templates/home.php')

// Set to a post type
->setLocation('post_type', '==', 'work');

// Set to a page (uses get_id_by_name() helper)
->setLocation('page', '==', get_id_by_name('about'));

// Options page or Post Type Index page
->setLocation('options_page', '==', 'work-index');

// Chaining Locations
->setLocation('page', '==', get_id_by_name('home'))
         ->or('page', '==', get_id_by_name('about'))
         ->or('page_template', '==', 'templates/single-column.php')
         ->or('options_page', '==', 'careers-index')
         ->or('post_type', '==', 'work');

```

### Field Variables
```

# Module fields use addLayout()
$content_module = new FieldsBuilder('content_module');
$content_module
  ->addMessage('', 'The Content Module creates an all purpose content/wysi region.')
  ->addWysiwyg('content');



# Application (inside a field group called `group_modules`)
->addLayout($content_module, [
  'name'=> "content-module",
])


# Simple fields use `addFields()`
$title_field = new FieldsBuilder('title');
$title_field
  ->addText('title');

# Application
addFields($title_field)
```


### Modules

The Jumpoff uses ACF's Flexible content fields to create a drag-and-drop module system.

A custom class (`inc/acf-utils/acf-modules.php`) further enhances flexible content fields by mapping them by name to files within the `partials/modules` directory. So, when used, an FC field named `intro-module` with load the module file `intro-module.php`.

Calling the Modules in a template

```
while (has_sub_field('modules')) :
  ACF_Modules::render(get_row_layout());
endwhile;
```


### Post / Content Types

Define post types at `inc/post-types/*`.
Use the helper method `jumpoff_post_type_labels('Single Name', 'Collection Name')` found in `inc/utils/post-type-labels`

*Example Post Type*

```
/**
 *  Post Type: Work
 */

add_action( 'init', function() {
 $type = 'work';

 $labels = jumpoff_post_type_labels('Work Item', 'Work');

 $args = [
   'public'             => true,
   'description'        => 'Wecu Team Members.',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 3,
   'menu_dashicon'      => 'dashicons-book-alt',
   'menu_icon'          => 'dashicons-book-alt',
   'query_var'          => true,
   'supports'           => array( 'title','thumbnail', 'editor' ),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => true,
   'rewrite'            => array('slug' => 'work', 'with_front' => false),
 ];
 register_post_type( $type, $args);
});
```

### INC

Site functionality is generally added in the `inc` folder, as oppose to plugins and whatnot.
Take a run through this directory to see what options and helpers are available.


### Debugging

The jumpoff has 2 debugger utilities located in `inc/utils/debuggers`

```
# Simple debugger with formatted output.
jumpoff_dump($foo)


# JS Console Debugger
jumpoff_dump_js($data)

# JSON Formater
jumpoff_format_json($data)

```


### Conditionals

See `inc/utils/conditionals` for a variety of useful conditionals


### General Utilities

Here are some useful utils. Check `inc/utils` for more.

```
/**
 * Field or Fallback
 * Gets a specified field, or if not set, gets a specified fallback
 * @see inc/utils/conditionals.php
 */
jumpoff_field_fallback($btn_page_link, $btn_url)


/**
 * Add group of module classes
 * Accepts and array of vars or strings to output them as classes on a component
 * @see inc/utils/formating.php
 * @useage
 * $bg_color = get_field('bg_color');
 * $pad      = get_field('padding')
 * $classes  = jumpoff_add_classes([$bg_color, $pad, 'module']);
 *
 * <section class="cards <?php echo $classes; ?>">
 */
 jumpoff_add_classes([$var, $other_var, 'module'])
 ```
