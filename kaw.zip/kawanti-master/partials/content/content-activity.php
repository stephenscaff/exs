<?php
/**
 * Activity Card
 *
 * @author    Trash Fire
 * @package   content
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$link = get_the_permalink();
$title = get_the_title();
$img = jumpoff_ft_img('full');

// get_template_part( 'partials/partial', 'schema-activity' );

?>

<article class="activity-card">
  <a class="activity-card__link" href="<?php echo $link; ?>">
    <figure class="activity-card__figure">
      <img class="activity-card__img" src="<?php echo $img->url; ?>" alt="<?php echo $img->alt; ?>"/>
    </figure>
    <header class="activity-card__header">
      <h4 class="activity-card__title"><?php echo $title; ?></h4>
    </header>
  </a>
</article>
