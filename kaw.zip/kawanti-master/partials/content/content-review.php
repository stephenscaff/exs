<?php
/**
 * Review content
 *
 * @author    Karlie Trash Fire Watts
 * @package   content
 * @version   1.0
 * @todo      maybe make data-rm-words a variable instead. Worried about the slider instance
 */

if ( ! defined( 'ABSPATH' ) ) exit;


$review_title = get_the_title($id);
$review_author = get_field('review_author', $id);
$review_stars = get_stars(get_field('review_stars', $id));
$review_content = get_field('review_content', $id);

$rm_length = '';

if ( is_page('home') ) {
  $rm_length = 63;
}
elseif (is_page('reviews')) {
  $rm_length = 50;
}
elseif (is_post_type('activity')) {
  $rm_length = 99;
}
else {
  $rm_length = 50;
}
?>

<article class="review">
  <div class="review__wrap">
    <h4 class="review__title"><span><?php echo $review_title; ?></span></h4>
    <div class="review__stars"><?php echo $review_stars; ?></div>

    <div class="read-more is-inline js-read-more" data-rm-words="<?php echo $rm_length; ?>">
      <p class="review__excerpt"><?php echo $review_content; ?></p>
    </div>

    <div class="review__author"><span><?php echo $review_author; ?></span></div>
  </div>
</article>
