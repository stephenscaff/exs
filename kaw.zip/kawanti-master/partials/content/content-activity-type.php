<?php
/**
 * Activity Card
 *
 * @author    Stephen Scaff
 * @package   content
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$term_obj = get_queried_object();
$id = $term->id;
$url = get_term_link($term);
$title = $term->name;
$img = get_field('term_image', $term);




?>

<article class="activity-card">
  <a class="activity-card__link" href="<?php echo $url; ?>">
    <figure class="activity-card__figure">
      <img class="activity-card__img" src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>"/>
    </figure>
    <header class="activity-card__header">
      <h4 class="activity-card__title"><?php echo $title; ?></h4>
    </header>
  </a>
</article>
