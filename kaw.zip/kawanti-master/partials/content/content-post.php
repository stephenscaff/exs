<?php
/**
 * Post Content
 *
 * @author    Stephen Scaff
 * @package   partials/content
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$post_link = get_the_permalink();
$post_title = get_the_title();
$post_img = jumpoff_ft_img('full');
$post_excerpt = jumpoff_excerpt(150);

?>

<article class="post-card">
  <a class="post-card__link" href="<?php echo $post_link; ?>">
    <figure class="post-card__figure">
      <img class="post-card__img" src="<?php echo $post_img->url; ?>" alt="<?php echo $post_img->alt; ?>"/>
    </figure>
    <div class="post-card__content">
      <span class="post-card__date"><?php the_time('m/d/y'); ?></span>
      <h3 class="post-card__title"><?php echo $post_title; ?></h3>
      <p class="post-card__excerpt"><?php echo $post_excerpt; ?></p>
      <span class="post-card__btn btn-line">Read On</span>
    </div>
  </a>
</article>
