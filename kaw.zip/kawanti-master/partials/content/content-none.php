<?php
/**
* Content: None
*
* @author    Stephen Scaff
* @package   partials/content
* @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) exit;

$title = 'No Results';
$text = 'Sorry, we couldn\'t find what you\'re looking for.';
$url = '';

if (is_post_type('activity') OR is_tax('activity_type') OR is_tax('activity_location')) :

  $title = 'No Activites';
  $text = 'Sorry, no activities currently match your filter. Please give it another go.';
  $url = '';

elseif (is_post_type('career') OR  is_tax('career_department') OR is_tax('career_location')):

  $title = 'No Career Listings';
  $text = 'Sorry, no career listings currently match your filter. Please give it another go or try back later.';
  $url = '';

endif;

?>

<article class="nunzo">
  <div class="nunzo__wrap">
    <span class="nunzo__icon">😕</span>
    <h2 class="nunzo__title"><?php echo $title; ?></h2>
    <p class="nunzo__text"><?php echo $text; ?></p>
  </div>
</article>
