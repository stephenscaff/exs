<?php
/**
 * Career Content
 *
 * @author    Karlie Trash Fire Watts
 * @package   content
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$career_location = jumpoff_term('career_location');
$career_link = get_field('career_link');
$career_title = get_the_title();
$career_excerpt = get_field('career_excerpt');

?>

<article class="careers-listing">
    <div class="careers-listing__wrap">
      <div class="careers-listing__meta">
        <h3 class="careers-listing__meta-location"><?php echo $career_location->name; ?></h3>
      </div>
      <div class="careers-listing__main">
        <h3 class="careers-listing__title"><?php echo $career_title; ?></h3>
        <p class="careers-listing__excerpt"><?php echo $career_excerpt; ?></p>
        <a class="btn-line" href="<?php echo $career_link; ?>" target="_blank">Apply Now</a>
      </div>
    </div>
</article>
