<?php
/**
 *  Partial: Masts
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version    1.0
 *  @see       inc/utils/conditions.php for jumpoff_id() logic that snags relevant post id.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

//vars
$term_obj = get_queried_object();
$mast_title = $term_obj->name;
$term_img_id = get_field('term_image', $term_obj->taxonomy . '_' . $term_obj->term_id);
$term_img_position = get_field('term_image_position', $term_obj->taxonomy . '_' . $term_obj->term_id);
$mast_img = jumpoff_ft_img('full', $term_img_id)->url;

if (is_tax('activity_type') OR is_tax('activity_location') OR ('career_location') OR ('career_department'))   :
  $mast_img = get_field('term_image', $term_obj->taxonomy . '_' . $term_obj->term_id)['url'];
endif;

?>

<section class="mast is-tax">
  <figure class="mast__figure js-plax-mast" style="background-image:url(<?php echo $mast_img; ?>); background-position: <?php echo $term_img_position; ?>"></figure>
  <div class="grid-lg">
    <header class="mast__header">
    <?php if ($mast_title) : ?>
      <h1 class="mast__title"><?php echo  $mast_title; ?></h1>
    <?php endif; ?>
  </header>
  </div>
  <div class="border-bottom-texture"></div>
</section>
