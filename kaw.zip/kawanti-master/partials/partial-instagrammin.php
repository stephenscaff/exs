<?php
/**
 *  Partial: Instagrammin
 *
 *  Template for displaying the Instagram Section
 *
 *  @author    Karlie Trash Fire Watts
 *  @package   partials
 *  @version    1.0
 *  @see      src/assets/js/components/_isntagrammin (@kawantiadv)
 */

 $instagram = get_field('kawanti_instagram', 'options');

?>

<section class="insta-feed">
  <div class="grid-lg">
    <header class="insta-feed__header">
    <h5 class="insta-feed__title">@kawantiadv</h5>
    <?php if ($instagram) : ?><div class="insta-feed__btn"><a class="btn-clear is-sm" href="<?php echo $instagram; ?>">follow</a></div><?php endif; ?>
  </header>
  <div class="insta__grid  js-instagrammin"></div>
</section>
