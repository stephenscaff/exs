<?php
/**
 * Related Activities
 *
 * Displays specified activities (via selector field) or random activites
 * from with the term.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * By Selected or Term
 * Gets 2 Activities, first by selected via field,
 * then by same term.
 */
$by_selected_or_term = "";
$by_selected = get_field('activity_selector');

if ($by_selected) {

  $by_selected_or_term = $by_selected;

} else {

  $terms = get_the_terms($post->ID, 'activity_type');

  if (!$terms) return;

  foreach ( $terms as $term ) {
    $slugs[] = $term->slug;
  }

  $args = array(
    'post_type'       => 'activity',
    'posts_per_page'  => 2,
    'orderby'         => 'rand',
    'order'           => 'DESC',
    'post__not_in'    => array($post->ID),
    'tax_query'       => array(
      'taxonomy'      => 'activity_type',
      'field'         => 'slug',
      'terms'         => $slugs,
      'operator'      => 'IN',
     ),
  );

  $by_selected_or_term = get_posts( $args );
}

?>

<section class="related pad-t">
  <div class="grid-lg">
    <header class="related__heading">
      <h2 class="related__title">More Activities</h2>
    </header>
    <div class="related__grid grid-1-2">
      <?php
      foreach ( $by_selected_or_term as $post ) : setup_postdata( $post );
        get_template_part( 'partials/content/content', 'activity' );
      endforeach;
      wp_reset_postdata();
      ?>
      </div>
    </div>
  </div>
</section>
