<?php
/**
 * Partial: Header
 *
 * Main site/app header and nav section.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$kawanti_phone = get_field('kawanti_phone_local', 'options');

?>

<header class="app-header">
  <div class="app-header__grid">
    <nav class="app-header__nav is-left">
      <a class="app-header__link" href="<?php echo jumpoff_get_page_url('activity', 1); ?>">Activities</a>
      <a class="app-header__link" href="<?php echo jumpoff_get_page_url('about'); ?>">About</a>
      <a class="app-header__link" href="<?php echo jumpoff_get_page_url('careers'); ?>">Careers</a>
    </nav>

    <a class="app-header__brand" href="<?php echo jumpoff_get_page_url('home'); ?>"><?php echo jumpoff_svg('kawanti-logo'); ?></a>

    <nav class="app-header__nav is-right">
      <a class="app-header__link" href="tel:<?php echo format_tel_link($kawanti_phone); ?>"><?php echo $kawanti_phone; ?></a>
      <a class="app-header__btn btn-clear is-sm" href="<?php echo jumpoff_get_page_url('activity', 1); ?>"><span>Book Now</span></a>
    </nav>

    <button class="menu-toggle js-menu-toggle mobile-only" arial-label="Menu"><div class="menu-toggle__bars"></div></button>
  </div>
</header>
