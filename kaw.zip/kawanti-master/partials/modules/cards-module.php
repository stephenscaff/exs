<?php
/**
 * Cards Module
 *
 * Creates a grid of our card components.
 *
 * @author       Stephen Scaff
 * @package      modules
 * @see          inc/fields/fields-vars-modules
 * @see          scss/components/_cards.scss
 * @version      1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$heading_title = get_sub_field('heading_title');
$hash = jumpoff_make_hash($heading_title);
$col_count = count(get_sub_field('cards'));
$col_class = '';

if ($col_count == 2) {
  $col_class = 'is-halfs';
}

?>

<section id="<?php echo $hash; ?>" class="cards pad module">
  <div class="grid-lg">

  <?php if ($heading_title) : ?>
    <header class="heading">
      <h2 class="heading__title"><?php echo $heading_title; ?></h2>
    </header>
  <?php endif; ?>

    <div class="cards__grid <?php echo $col_class ?>">
      <?php
      while( have_rows('cards') ): the_row();
        $pretitle = get_sub_field('pretitle');
        $img = get_sub_field('image');
        $title = get_sub_field('title');
        $content = get_sub_field('content');
        $link = get_sub_field('button_page_link');
        $url = get_sub_field('button_url');
        $link_or_url = jumpoff_field_fallback($link, $url);
        $btn_text = get_sub_field('button_text');
      ?>

      <article class="card">
        <?php if ($link_or_url) : ?>
        <a class="card__link" href="<?php echo $link_or_url; ?>">
        <?php else : ?>
        <div class="card__wrap">
        <?php endif; ?>

          <?php if ($img) : ?>
          <figure class="card__figure">
            <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
          </figure>
          <?php endif; ?>
          
          <div class="card__content">
            <?php if ($pretitle) : ?>
              <span class="card__meta"><?php echo $pretitle; ?></span>
            <?php endif; ?>

            <h3 class="card__title"><?php echo $title; ?></h3>

            <?php if ($content) : ?>
              <p class="card__excerpt"><?php echo $content; ?></p>
            <?php endif; ?>

            <?php if ($btn_text) : ?>
              <span class="card__btn btn-line"><?php echo $btn_text; ?></span>
            <?php endif; ?>
          </div>
        <?php if ($link_or_url) : ?>
        </a>
        <?php else : ?>
        </div>
        <?php endif; ?>
      </article>
    <?php endwhile; ?>
  </div>
</section>
