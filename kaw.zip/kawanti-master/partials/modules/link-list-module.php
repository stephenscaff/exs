<?php
/**
 * Link List Module
 *
 * Creates a columned list of links.
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$heading_title = get_sub_field('heading_title');
$hash = jumpoff_make_hash($heading_title);

?>

<section id="<?php echo $hash; ?>" class="link-list pad module">
  <div class="grid-lg">

    <?php if ($heading_title) : ?>
    <header class="heading">
      <h2 class="heading__title"><?php echo $heading_title; ?></h2>
    </header>
    <?php endif; ?>

    <ul class="link-list__items">
      <?php
      while( have_rows('items') ): the_row();
        $text = get_sub_field('text');
        $link = get_sub_field('link');
        $url = get_sub_field('url');
        $link_or_url = jumpoff_field_fallback($link, $url);
      ?>
      <li class="link-list__item">
        <a class="link-list__link" href="<?php echo $link_or_url; ?>">
          <span class="list-list__text"><?php echo $text; ?></span>
        </a>
      </li>
    <?php endwhile; ?>
    </ul>
  </div>
</section>
