<?php
/**
 * Activity Types Module
 *
 * Builds a grid of
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="activity-cards is-activity-type">
  <div class="grid-lg">
    <div class="activity-cards__grid">
    <?php
    $args = array(
      'taxonomy'   => 'activity_type',
      'hide_empty' => 0,
    );
    $terms = get_terms( $args);

    foreach ($terms as $term) :
      include(locate_template('partials/content/content-activity-type.php'));
    endforeach;
    ?>
    </div>
  </div>
</section>
