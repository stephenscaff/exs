<?php
/**
 * Activity Gree Module
 *
 * Builds a grid of
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$difficulty_select = get_sub_field('difficulty_select');
$badge_class = 'is-' . $difficulty_select;

$content = get_sub_field('content');
?>

<section class="activity-difficulty module">
  <h3 class="activity-difficulty__title">Level of Dfficulty</h3>
  <div class="activity-difficulty__main">
    <div class="activity-difficulty__icon"><?php echo jumpoff_svg($difficulty_select); ?></div>
    <div class="activity-difficulty__content content">
      <?php echo $content; ?>
    </div>
  </div>
</section>
