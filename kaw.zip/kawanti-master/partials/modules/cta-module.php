<?php
/**
 * CTA Module
 *
 * The module for creating full width CTA Sections
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title = get_sub_field('title');
$content = get_sub_field('content');
$img = get_sub_field('image');
$vid_mp4 = get_sub_field('vid_mp4');
$btn_text = get_sub_field('button_text');
$link = get_sub_field('button_link');
$url = get_sub_field('button_url');
$link_or_url = jumpoff_field_fallback($link, $url);

?>

<section class="cta module">
  <div class="border-top-texture"></div>
  <a class="cta__link" href="<?php echo $link_or_url; ?>">
    <?php if ($vid_mp4) : ?>
    <div class="cta__bg-vid bg-vid">
      <span class="bg-vid__cover"></span>
      <video class="bg-vid__vid" autoplay="" loop="" muted poster="">
        <source type="video/mp4" src="<?php echo $vid_mp4['url']; ?>">
      </video>
    </div>
    <?php endif; ?>
    <figure class="cta__figure" style="background-image: url(<?php echo $img['url']; ?>)"></figure>
    <header class="cta__header">
      <h2 class="cta__title"><?php echo $title; ?></h2>
      <p class="cta__excerpt"><?php echo $content; ?></p>
      <?php if ($btn_text) : ?><span class="btn-clear is-white"><?php echo $btn_text; ?></span><?php endif; ?>
    </header>
  </a>
</section>
