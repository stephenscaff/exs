<?php
/**
 *  Content Module
 *
 * The module for creating general content regions
 *
 * @author       Stephen Scaff
 * @package      partials/modules
 * @version      1.0
 * @see          inc/fields/fiels-vars-module
 * @see          src/assets/scss/components/_post-content.scss
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title = get_sub_field('heading_title');
$hash = jumpoff_make_hash($title);

$content = get_sub_field('content');

?>

<section id="<?php echo $hash; ?>" class="content pad module">
  <div class="grid-sm">

    <?php if ($title) : ?>
    <header class="content__header">
      <h2 class="content__title"><?php echo $title; ?></h2>
    </header>
    <?php endif; ?>
    <div class="content__main">
      <?php echo $content; ?>
    </div>
  </div>
</section>
