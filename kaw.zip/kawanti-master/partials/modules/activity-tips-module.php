<?php
/**
 * Activity Tips Module
 *
 * Creates the Needs to Know section on single Activity pages
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$difficulty_select = get_sub_field('difficulty_select');
$difficulty_content = get_sub_field('difficulty_content');

?>

<section class="activity-tips module">
  <h3 class="activity-tips__title">Need to Know</h3>

  <div class="activity-tips__grid">
    <?php
    while( have_rows('tips') ): the_row();
      $icon = get_sub_field('tips_icon');
      $title = get_sub_field('title');
      $content = get_sub_field('content');
    ?>
      <div class="activity-tip">
        <div class="activity-tip__icon"><?php echo jumpoff_svg($icon); ?></div>
        <div class="activity-tip__main">
          <h5 class="activity-tip__title"><?php echo $title; ?></h5>
          <p class="activity-tip__text"><?php echo $content; ?></p>
        </div>
      </div>
    <?php endwhile; ?>
  </div>

  <div class="activity-tips__level">
      <header class="activity-tips__level-header">
        <div class="activity-tips__level-icon"><?php echo jumpoff_svg($difficulty_select['value']); ?></div>
        <h5 class="activity-tips__level-title">
          Difficulty Level: <?php echo $difficulty_select['label']; ?>
        </h5>
      </header>
      <div class="activity-tips__level-content">
        <p class="activity-tips__level-text"><?php echo $difficulty_content; ?></p>
      </div>
    </div>
</section>
