<?php
/**
 * Reviews Slider Module
 *
 * Module that adds a slider of Reviews (post type)
 * by tax (activity_type) or manual selection via Relationship Field.
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Latest or Selected Logic
 * Gets 3 latest posts, unless posts are manually
 * selected via posts_selector relationship field.
 */
$by_related_term_or_selected = "";
$by_related_review = get_sub_field('related_reviews');
$by_term = "";
$by_selected = get_sub_field('review_selector');
$current_id = get_the_id();


if ( $by_selected ) {
  $by_related_term_or_selected = $by_selected;
}

elseif ( $by_related_review == true ) {

  $args = array (
    'post_type'      => 'review',
    'meta_query'     => array(
      array(
        'key'     => 'related_activity',
        'value'   => $current_id ,
        'compare' => 'LIKE'
      )
    )
  );

  $by_related_term_or_selected  = get_posts( $args );
}

else {
 $by_term = get_sub_field('review_term');

 $args = array(
   'post_type'      => 'review',
   'posts_per_page' => 3,
   'orderby'        => 'rand',
   'tax_query'      => array(
     array (
       'taxonomy' => 'activity_type',
       'field'    => 'slug',
       'terms'    => $by_term->slug,
       'operator' => 'IN',
     ),
   )
 );

  $by_related_term_or_selected  = get_posts( $args );
}

$add_review_link = get_sub_field('add_review_link');

?>

<section class="activity-reviews module">
  <header class="activity-reviews__header">
    <h3 class="activity-reviews__title">Guest Reviews</h3>
    <div class="activity-reviews__btn">
      <a class="btn-clear is-sm" href="<?php echo $add_review_link; ?>">Add A Review</a>
    </div>
  </header>

  <div class="activity-reviews__items">
    <?php
    shuffle($by_related_term_or_selected );
    foreach ( $by_related_term_or_selected as $post ) : setup_postdata( $post );
      $id = $post;
      include(locate_template("partials/content/content-review.php"));
    endforeach;
    wp_reset_postdata(); ?>
  </div>
</section>
