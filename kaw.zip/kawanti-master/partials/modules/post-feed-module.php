<?php
/**
 * CTA Module
 *
 * The module for creating full width CTA Sections
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Latest or Selected Logic
 * Gets 3 latest posts, unless posts are manually
 * selected via posts_selector relationship field.
 */
$latest_or_selected = "";
$selected = get_sub_field('post_selector');

if ($selected) {
  $latest_or_selected = $selected;
} else {
  $args = array(
    'post_type'       => 'post',
    'posts_per_page'  => 3,
    'orderby'         => 'date',
    'order'           => 'DESC',
  );

  $latest = get_posts( $args );
  $latest_or_selected = $latest;
}

?>

<section class="post-feeds">
  <div class="grid-lg">
  <div class="border-top-texture"></div>
  <div class="post-feeds__grid">
    <?php

    foreach ( $latest_or_selected as $post ) : setup_postdata( $post );


      //$img     = jumpoff_ft_img('large', $post->ID);
      $link    = get_the_permalink($post->ID);
      $title   = get_the_title($post->ID);
      $excerpt = jumpoff_excerpt(120);
      $img     = jumpoff_ft_img('large', $post->ID);
    ?>
    <article class="post-feed">
      <a class="post-feed__link" href="<?php echo $link; ?>">
      <figure class="post-feed__figure" style="background-image: url(<?php echo $img->url; ?>);"></figure>
      <header class="post-feed__header">
        <h4 class="post-feed__title"><?php echo $title; ?></h4>
        <p class="post-feed__excerpt"><?php echo $excerpt; ?></p>
      </header>
      </a>
    </article>
    <?php endforeach; wp_reset_postdata(); ?>
    </div>
  </div>
</section>
