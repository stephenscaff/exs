<?php
/**
 * Two Columns Modules
 *
 * Creates a simple 2 column layout, using the col-block pattern.
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="col-blocks module">
  <div class="grid-lg">
    <div class="col-blocks__grid">
      <?php
      while( have_rows('columns') ): the_row();
        $title = get_sub_field('title');
        $content = get_sub_field('content');
        $button_text = get_sub_field('button_text');
        $url = get_sub_field('button_url');
        $link = get_sub_field('button_link');
        $link_or_url = jumpoff_field_fallback($link, $url);
      ?>
      <article class="col-block">
        <a class="col-block__link" href="<?php echo $link_or_url; ?>">
          <header class="col-block__header">
            <h4 class="col-block__title"><?php echo $title; ?></h4>
            <p class="col-block__excerpt"><?php echo $content; ?></p>
            <div class="col-block__btn">
              <span class="btn-line"><?php echo $button_text; ?></span>
            </div>
          </header>
        </a>
      </article>
    <?php endwhile; ?>
    </div>
  </div>
</section>
