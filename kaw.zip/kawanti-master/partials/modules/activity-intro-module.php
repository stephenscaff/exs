<?php
/**
 * Activity Intro Module
 *
 * Builds a grid of
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$title = get_sub_field('title');
$content = get_sub_field('content');

?>

<section class="activity-intro module">
  <h2 class="activity-intro__title"><?php echo $title; ?></h2>

  <div class="activity-intro__content">
    <div class="read-more js-read-more" data-rm-words="55">
    <?php echo $content; ?>
    </div>
  </div>
</section>
