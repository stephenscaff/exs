<?php
/**
 * Activity Types Module
 *
 * Builds a grid of
 *
 * @author       Stephen Scaff
 * @package      modules
 * @version      1.0
 * @see          inc/fields/fields-vars-modules
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$images = get_sub_field('images');
$first_image = $images[0]['image'];


if (!empty($first_image)) : ?>

<section class="activity-gal module ">
  <h3 class="activity-gal__title">Photo Gallery</h3>


  <figure class="activity-gal__preview">
    <a class="activity-gal__trigger js-gallery-trigger" href="#" data-popup="gallery-popup">
    <img class="activity-gal__preview-img" src="<?php echo $first_image['url']; ?>" alt="<?php echo $first_image['alt']; ?>"/>
    <button class="activity-gal__btn btn is-white is-sm">More Photos</button>
    </a>
  </figure>

</section>

<!-- Gallery Images Popup -->
<section id="gallery-popup" class="gallery-popup popup" aria-hidden="true">
  <button class="popup__close js-close-popup" aria-label="Close">
    <div class="popup__x  close-x is-white"></div>
  </button>

  <div class="gallery-popup__images">
    <div class="gallery-popup__slider js-gallery-slider">
    <?php
    while( have_rows('images') ): the_row();
      $img = get_sub_field('image');
    ?>
      <div class="gallery-popup__item">
        <div>
          <figure class="gallery-popup__figure">
            <img class="gallery-popup__img" src="<?php echo $img['url']; ?>" alt="<?php echo $img['url']; ?>"/>
            <?php if ($img['caption']) : ?><figcaption class="gallery-popup__caption"><?php echo $img['caption']; ?></figcaption><?php endif; ?>
          </figure>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<?php endif; ?>
