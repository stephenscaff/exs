<?php
/**
* Reviews Slider Module
*
* Module that adds a slider of Reviews (post type)
* by tax (activity_type) or manual selection via Relationship Field.
*
* @author       Stephen Scaff
* @package      modules
* @version      1.0
* @see          inc/fields/fields-vars-modules
*/

if ( ! defined( 'ABSPATH' ) ) exit;

/**
* Latest or Selected Logic
* Gets 3 latest posts, unless posts are manually
* selected via posts_selector relationship field.
*/
$by_random_or_selected = "";
$by_selected = get_sub_field('review_selector');
// $by_term =  get_sub_field('review_term');

if ($by_selected) {

  $by_random_or_selected = $by_selected;

} else {

$args = array(
  'post_type'       => 'review',
  'posts_per_page'  => 10,
  'orderby'         => 'rand',
  'order'           => 'ASC',
);

$by_random_or_selected = get_posts( $args );

}

?>

<section class="reviews-slider is-to-edge module">
  <div class="grid-lg">
    <div class="reviews-slider__items js-reviews-slider">
      <?php
      shuffle($by_random_or_selected);
      foreach ( $by_random_or_selected as $post ) : setup_postdata( $post );
        $id = $post;
        include(locate_template("partials/content/content-review.php"));
      endforeach;
      wp_reset_postdata(); ?>
    </div>
  </div>
</section>
