<?php
/**
 * Posts: Related
 *
 * The section for Related Posts.
 *
 * @author    Stephen Scaff
 * @package   jumpoff/content/posts-related
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<section class="related pad bg-grey-light">
  <div class="grid-lg">
    <header class="related__heading">
      <h3 class="related__title">Keep Reading</h3>
    </header>
    <div class="related__grid grid-1-2">
    <?php
    // $cat = jumpoff_get_cat_slug();
    $args = array(
      'post_type'        => 'post',
      // 'category_name'    => $cat,
      'posts_per_page'   => 2,
      'orderby'          => 'date',
      'order'            => 'DESC',
      'post__not_in'     => array($post->ID),
      'tax_query' => array()
    );

    $related = get_posts( $args );
    foreach ( $related as $post ) : setup_postdata( $post );
      get_template_part( 'partials/content/content', 'post' );
    endforeach;
    wp_reset_postdata();
    ?>
    </div>
  </div>
</section>
