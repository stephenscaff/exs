<?php
/**
 * Partial: Footer
 *
 * Global footer element, inlcuding wp_footer().
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$facebook = get_field('kawanti_facebook', 'options');
$twitter = get_field('kawanti_twitter', 'options');
$instagram = get_field('kawanti_instagram', 'options');
$linkedin = get_field('kawanti_linkedin', 'options');
$youtube = get_field('kawanti_youtube', 'options');
$vimeo = get_field('kawanti_vimeo', 'options');
$snapchat = get_field('kawanti_snapchat', 'options');
$footer_message = get_field('footer_message', 'options');

?>

<section class="app-socials">
  <div class="grid">
    <header class="app-socials__header">
      <h5 class="app-socials__title">Join Our Community</h5>
    </header>
    <nav class="app-socials__nav">
      <?php if ($facebook) : ?><a class="app-socials__link" href="<?php echo $facebook; ?>"><i class="icon-facebook-sq"></i></a><?php endif; ?>
      <?php if ($twitter) : ?><a class="app-socials__link" href="<?php echo $twitter; ?>"><i class="icon-twitter"></i></a><?php endif; ?>
      <?php if ($instagram) : ?><a class="app-socials__link" href="<?php echo $instagram; ?>"><i class="icon-instagram"></i></a><?php endif; ?>
      <?php if ($linkedin) : ?><a class="app-socials__link" href="<?php echo $linkedin; ?>"><i class="icon-linkedin-sq"></i></a><?php endif; ?>
      <?php if ($youtube) : ?><a class="app-socials__link" href="<?php echo $youtube; ?>"><i class="icon-youtube-play"></i></a><?php endif; ?>
      <?php if ($vimeo) : ?><a class="app-socials__link" href="<?php echo $vimeo; ?>"><i class="icon-vimeo-sq"></i></a><?php endif; ?>
      <?php if ($snapchat) : ?><a class="app-socials__link" href="<?php echo $snapchat; ?>"><i class="icon-snapchat"></i></a><?php endif; ?>
    </nav>
  </div>
</section>

<footer class="app-footer">
  <!-- <figure class="app-footer__bg" style="background-image: url(<?php echo jumpoff_img(); ?>/footer/app-footer-bg.jpg)"></figure> -->
  <div class="grid-lg">
    <div class="app-footer__grid">
      <div class="app-footer__byline">
        <a class="app-footer__brand" href="<?php echo jumpoff_get_page_url('home'); ?>"><?php echo jumpoff_svg('kawanti-logo'); ?></a>
        <?php if ($footer_message) : ?><p class="app-footer__bio"><?php echo $footer_message; ?></p><?php endif; ?>
      </div>
      <div class="app-footer__main">
        <?php echo render_menu('footer_menu_1', 'footer-nav'); ?>
        <?php echo render_menu('footer_menu_2', 'footer-nav'); ?>
        <?php echo render_menu('footer_menu_3', 'footer-nav'); ?>
        <?php echo render_menu('footer_menu_4', 'footer-nav'); ?>
      </div>
    </div>

    <aside class="app-footer__colophon">
      <div class="app-footer__colophon-grid">
        <div class="app-footer__creds">
          <a class="app-footer__logo-taquan" href="http://www.taquanair.com/" target="_blank"><?php echo jumpoff_svg('taquan-logo'); ?></a>
          <h5 class="app-footer__logo-tagline">A Kawanti Adventures Affiliate</h5>
          <p class="app-footer__copyright">&copy; <?php echo date("Y"); ?> Kawanti Adventures. All rights reserved.</p>
        </div>

        <div class="app-footer__promo">
          <span class="app-footer__promo-label">We're recommended on</span>
          <a class="app-footer__logo-tripadvisor"><?php echo jumpoff_svg('tripadvisor-logo'); ?></a>
        </div>
      </div>
    </aside>
  </div>
</footer>

<!-- poly -->
<script type="text/javascript">

if (/MSIE \d|Trident.*rv:/.test(navigator.userAgent) ) {
  document.write('<script src="https://cdn.polyfill.io/v2/polyfill.min.js?features=es6,Array.prototype.includes,CustomEvent,Object.entries,Object.values,URL,promise,fetch"><\/script>');
}

</script>

<?php wp_footer(); ?>

<?php //get_template_part( 'partials/partial', 'bugherd' );?>

</body>
</html>
