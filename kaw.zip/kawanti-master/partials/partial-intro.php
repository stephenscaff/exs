<?php
/**
 * Posts: Related
 *
 * The section for Related Posts.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$ids = jumpoff_ids();

$intro_title = get_field('intro_title', $ids);
$intro_content = get_field('intro_content', $ids);

$mod_class = '';

if (strlen($intro_content) <= 150) {
  $mod_class = 'has-measure-sm';
}

if ($intro_title OR $intro_content) : ?>

<section class="intro <?php echo $mod_class; ?>">
  <div class="grid-lg">
    <header class="intro__header">
      <h2 class="intro__title"><?php echo $intro_title; ?></h2>
      <p class="intro__excerpt"><?php echo $intro_content; ?></p>
    </header>
  </div>
</section>

<?php endif; ?>
