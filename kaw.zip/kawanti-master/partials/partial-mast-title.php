<?php
/**
 *  Partial: Mast Title
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version    1.0
 *  @see       inc/utils/conditions.php for jumpoff_id() logic that snags relevant post id.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$id = jumpoff_ids();
$title = get_the_title($id);
$ft_img = jumpoff_ft_img('full', $id);
$ft_img_position = get_post_meta($this_post_id,'ft_img_position', true);

if (has_ft_img($post->ID)) {
  $has_ft_img = true;
}

?>

<!-- Mast -->
<section class="mast-title <?php if ($has_ft_img) : echo 'has-ft-img'; endif; ?>">
  <header class="mast__header">
    <h1 class="mast-title__title"><?php echo $title; ?></h1>
    <p class="mast-title__subtitle"><?php echo $subtitle; ?></p>
  </header>

  <?php if ($has_ft_img) : ?>
    <div class="mast-title__ft-img grid">
      <figure class="mast-title__figure">
        <div class="mast-title__img" style="background-image: url(<?php echo $ft_img->url; ?>); background-position: <?php echo $ft_img_position; ?>"></div>
      </figure>
    </div>
  <?php endif; ?>
</section>
