<?php
/**
 * Partial: Bugherd
 *
 * Bugherd partial
 *
 * @author    Karlie Watts
 * @package   partials
 * @version   1.0
 */

?>
<script type='text/javascript'>
  (function (d, t) {
   var bh = d.createElement(t), s = d.getElementsByTagName(t)[0];
   bh.type = 'text/javascript';
   bh.src = 'https://www.bugherd.com/sidebarv2.js?apikey=t1heuft6ja3ihbxx9ixdza';
   s.parentNode.insertBefore(bh, s);
   })(document, 'script');
</script>
