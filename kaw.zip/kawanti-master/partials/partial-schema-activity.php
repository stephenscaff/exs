<?php
/**
 * Posts: Related
 *
 * The section for Related Posts.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$link = get_the_permalink();
$title = get_the_title();
$img = jumpoff_ft_img('full');
$phone = get_field('kawanti_phone_local', 'options');
$phone_tollfree = get_field('kawanti_phone_tollfree', 'options');
$email = get_field('kawanti_email', 'options');


?>

<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": [
    "TouristAttraction"
  ],
  "name": "<?php echo $title; ?>",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "AK",
    "addressCountry": "USA"
  },
  "publicAccess": true,
  "touristType": [
    "Adventure tourism",
    "Wildlife tourism",
    "Flightseeing tourism",
    "Alaska Tourism"
  ],
  "telephone": ["<?php echo $phone; ?>", "<?php echo $phone_tollfree; ?>"],
  "sameAs": "<?php echo $link; ?>",
  "image": "<?php echo $img->url; ?>"
}
</script>
