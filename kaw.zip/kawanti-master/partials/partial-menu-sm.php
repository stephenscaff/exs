<?php
/**
 * Partial: Mobile Menu
 *
 * Main menu on mobile/small.
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="menu-sm">
  <nav class="menu-sm__nav">
    <a class="menu-sm__link" href="<?php echo jumpoff_get_page_url('home'); ?>"><span>Home</span></a>
    <hr class="menu-sm__sep"/>
    <a class="menu-sm__link" href="<?php echo jumpoff_get_page_url('activity', 1); ?>"><span>Activities</span></a>
    <hr class="menu-sm__sep"/>
    <a class="menu-sm__link" href="<?php echo jumpoff_get_page_url('about'); ?>"><span>About</span></a>
    <a class="menu-sm__link" href="<?php echo jumpoff_get_page_url('careers'); ?>"><span>Careers</span></a>
    <a class="menu-sm__link" href="<?php echo jumpoff_get_page_url('reviews'); ?>"><span>Reviews</span></a>
    <a class="menu-sm__link" href="<?php echo jumpoff_get_page_url('blog'); ?>"><span>Blog</span></a>
    <hr class="menu-sm__sep"/>
    <a class="menu-sm__link" href="<?php echo jumpoff_get_page_url('faq',1); ?>"><span>FAQs</span></a>
    <hr class="menu-sm__sep"/>
    <a class="menu-sm__link" href="<?php echo jumpoff_get_page_url('activity', 1); ?>"><span>Book Now</span></a>
  </nav>
</section>
