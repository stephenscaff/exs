<?php
/**
 *  Partial: Masts
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   partials
 *  @version    1.0
 *  @see       inc/utils/conditions.php for jumpoff_id() logic that snags relevant post id.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

//vars
$id = jumpoff_ids();
$mast_pretitle = get_field('mast_pretitle', $id);
$mast_title = get_field('mast_title', $id);
$mast_stamp = get_field('mast_stamp', $id);
$class = 'is-'.jumpoff_mod_class();
$ft_img_position = get_post_meta($post->ID, 'ft_img_position', true);

/**
 * Random Images Logic
 * Images are added via a repeater
 * then randomized on load.
 * @since v2 - moved randomizer to javascript cause of cache.
 * @see js/components/_random-bg.js
 */
$img_arr = array();
$random_img = '';

if (have_rows('mast_images', $id) ) :
  while( have_rows('mast_images', $id) ) : the_row();
    $img = get_sub_field('image');
    $fallback_img = $img['url'];
    $img = '"'.$img['url'].'"';
    $img_arr[] = $img;
  endwhile;

  $formated_img_arr = rtrim(implode(',', $img_arr), ',');

endif;

?>

<section class="mast <?php echo $class; ?>">
  <figure
  class="mast__figure js-rando-image"
  data-images = '[<?php echo $formated_img_arr; ?>]'
  style="background-image:url(<?php echo $fallback_img; ?>); background-position: <?php echo $ft_img_position; ?>"></figure>
  <div class="grid-lg">
    <header class="mast__header">
    <?php if ($mast_pretitle) : ?>
      <h5 class="mast__meta"><?php echo $mast_pretitle; ?>
    <?php endif; ?>
    <?php if ($mast_title) : ?>
      <h1 class="mast__title"><?php echo  $mast_title; ?></h1>
    <?php endif; ?>
  </header>
  </div>
  <?php if ($mast_stamp) : ?>
    <figure class="mast__stamp"><img class="mast__stamp-img" src="<?php echo $mast_stamp['url']; ?>" alt="<?php echo $mast_stamp['alt']; ?>"/></figure>
  <?php endif; ?>
  <div class="border-bottom-texture"></div>
</section>
