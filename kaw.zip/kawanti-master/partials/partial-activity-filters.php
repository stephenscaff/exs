<?php
/**
 * Partial: Footer
 *
 * Global footer element, inlcuding wp_footer().
 *
 * @author    Stephen Scaff
 * @package   partials
 * @version   1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="filter-bar">
  <div class="grid-lg">
    <nav class="filter-bar__nav">
      <div class="filter-bar__item">
        <div class="dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger">Type <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php echo jumpoff_get_page_url('activity', 1); ?>">All Activities</a>
            <?php echo jumpoff_tax_filters('activity_type', 'dropdown__link'); ?>
          </nav>
        </div>
      </div>

      <div class="filter-bar__item">
        <div class="dropdown js-dropdown">
          <button class="dropdown__label js-dropdown-trigger">Location <span></span></button>
          <nav class="dropdown__nav">
            <a class="dropdown__link is-heading" href="<?php echo jumpoff_get_page_url('activity', 1); ?>">All Locations</a>
            <?php echo jumpoff_tax_filters('activity_location', 'dropdown__link'); ?>
          </nav>
        </div>
      </div>
    </nav>
  </div>
</section>
