<?php
/**
 * Template Name: Reviews
 *
 * @author    Karlie Watts
 * @package   page
 * @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly\

get_header();


?>

<main role="main" class="has-header-offset">

<?php get_template_part( 'partials/partial', 'mast' ); ?>
<?php get_template_part( 'partials/partial', 'intro' ); ?>

<?php

$ppp = get_option('posts_per_page');
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

$args = array(
  'post_type'        => 'review',
  'posts_per_page'   => $ppp,
  'paged'            => $paged,
  'order'           => 'ASC',
);

$reviews = new WP_Query($args);

?>

<section class="reviews-collection has-fetch-more">
 <div id="js-posts" class="grid-sm">

 <?php
  $original_posts = (array) $reviews->posts;

  shuffle( $original_posts );

  $shuffled_posts = json_decode( json_encode( $original_posts ), FALSE );

  $reviews->posts = $shuffled_posts;

  while ( $reviews->have_posts() ) : $reviews->the_post();
    get_template_part( 'partials/content/content', 'review' );
  endwhile;
  
 ?>
 </div>
</section>

<?php get_template_part( 'partials/partial', 'fetch-more' );?>

</main>

<?php get_footer(); ?>
