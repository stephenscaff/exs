
<?php
/**
 * Template Name: Careers
 *
 * Template to query for careers listings, which are non-hierarchical (no single view)
 * This template is also used for careers taxonomy pages, so we get the queried_object and
 * use that to alter our Posts Query.
 *
 * @author    Karlie Watts & Stephen Scaff
 * @package   page
 * @version   1.2.0
 * @see       inc/post-types/post-type-career.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly\

get_header();

?>

<main role="main" class="has-header-offset">

<?php

if (is_tax()) :
  get_template_part( 'partials/partial', 'mast-tax' );
else :
  get_template_part( 'partials/partial', 'mast' );
endif;

if (!is_tax()) : ?>

<section class="modules has-bg-texture">
  <div class="bg-texture"></div>
  <?php get_template_part( 'partials/partial', 'modules' ); ?>
</section>

<?php endif;

$ppp = get_option('posts_per_page');
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

if (is_tax()) {
  $queried_object = get_queried_object();
  $tax = $queried_object->taxonomy;
  $term_slug = $queried_object->slug;
  $term_name = $queried_object->name;

  $args = array (
    'post_type'       => 'career',
    'posts_per_page'  => -1,
    'tax_query'       => array(
      array(
        'taxonomy'    => $tax,
        'field'       => 'slug',
        'terms'       => $term_slug,
        'operator'    => 'IN',
      )
    )
  );
  } else {

    $args = array (
      'post_type'        => 'career',
      'posts_per_page'   => $ppp,
      'paged'            => $paged,
    );
  }

$careers = new WP_Query($args);

?>

<section class="careers-collection has-fetch-more">

  <section class="filter-bar is-careers">
    <div class="grid">
      <div class="filter-bar__wrap">
        <h2 class="filter-bar__title">Open Positions</h2>
        <div class="filter-bar__items">
          <!-- <div class="filter-bar__dropdown dropdown js-dropdown">
            <button class="dropdown__label js-dropdown-trigger">Department <span></span></button>
            <nav class="dropdown__nav">
              <a class="dropdown__link is-heading" href="<?php // echo jumpoff_get_page_url('activity', 1); ?>">All Departments</a>
              <?php // echo jumpoff_tax_filters('career_department', 'dropdown__link'); ?>
            </nav>
          </div> -->

          <div class="filter-bar__dropdown dropdown js-dropdown">
            <button class="dropdown__label js-dropdown-trigger">Location <span></span></button>
            <nav class="dropdown__nav">
              <a class="dropdown__link is-heading" href="<?php echo jumpoff_get_page_url('activity', 1); ?>">All Locations</a>
              <?php echo jumpoff_tax_filters('career_location', 'dropdown__link'); ?>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>

  <div class="grid">
    <div id="js-posts">
    <?php
      if (have_posts()) :
        while ( $careers->have_posts() ) : $careers->the_post();
          get_template_part( 'partials/content/content', 'career' );
        endwhile;
      else :
        include(locate_template('partials/content/content-none.php'));
      endif;
    ?>
    </div>
  </div>
</section>

<?php if (!is_tax()) : ?>
<?php get_template_part( 'partials/partial', 'fetch-more' );?>
<?php endif; ?>

</main>

<?php get_footer(); ?>
