<?php
/**
 * Template Name: Home
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<main>

<?php get_template_part( 'partials/partial', 'mast' ); ?>

<section class="modules has-bg-texture">
  <div class="bg-texture"></div>
  <?php get_template_part( 'partials/partial', 'intro' ); ?>
  <?php get_template_part( 'partials/partial', 'modules' ); ?>
</section>

<?php get_template_part( 'partials/partial', 'instagrammin' ); ?>

</main>

<?php get_footer(); ?>
