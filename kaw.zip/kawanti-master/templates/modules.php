<?php
/**
 * Template Name: Modules
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<main class="has-header-offset">

<?php get_template_part( 'partials/partial', 'mast' ); ?>

<section class="modules has-bg-texture">
  <div class="bg-texture"></div>
  <?php get_template_part( 'partials/partial', 'modules' ); ?>
</section>

</main>

<?php get_footer(); ?>
