<?php
/**
 * Template Name: Contact
 *
 * Contact Page template that calls intro fields and global company contacts (options table)
 *
 * @author    Karlie Watts & Stephen Scaff
 * @package   page
 * @version   1.2.0
 * @see       inc/post-types/post-type-career.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly\

get_header();

$title = get_the_title();
$ft_img = jumpoff_ft_img('full');

$has_ft_img = false;

if (has_ft_img($post->ID)) {
  $has_ft_img = true;
}

$intro_title = get_field('intro_title');
$intro_content = get_field('intro_content');
$kawanti_phone = get_field('kawanti_phone_local', 'options');
$kawanti_email = get_field('kawanti_email', 'options');

?>

<!-- Main -->
<main role="main" class="has-header-offset">

<!-- Mast -->
<section class="mast-title <?php if ($has_ft_img) : echo 'has-ft-img'; endif; ?>">
  <header class="mast__header">
    <h1 class="mast-title__title"><?php echo $title; ?></h1>
  </header>

  <?php if ($has_ft_img) : ?>
    <div class="mast-title__ft-img grid">
      <figure class="mast-title__figure">
        <div class="mast-title__img" style="background-image: url(<?php echo $ft_img->url; ?>)"></div>
      </figure>
    </div>

  <?php endif; ?>
</section>

<!-- Content -->
<section class="contacts">
  <div class="grid">
    <div class="contacts__grid">
      <header class="contacts__header">
        <h2 class="contacts__title"><?php echo $intro_title; ?></h2>
        <p class="contacts__excerpt"><?php echo $intro_content; ?></p>
      </header>

      <div class="contact__main">
        <div class="contacts__block">
          <h3 class="contacts__heading">Phone</h3>
          <a class="contacts__tel" href="tel:<?php echo format_tel_link($kawanti_phone); ?>"><?php echo $kawanti_phone; ?></a>
        </div>

        <div class="contacts__block">
          <h3 class="contacts__heading">Email</h3>
          <a class="contacts__email" href="mailto:<?php echo $kawanti_email; ?>"><?php echo $kawanti_email; ?></p>
        </div>
      </div>
    </div>
  </div>
</section>


</main>

<!-- Footer -->
<?php get_footer(); ?>
