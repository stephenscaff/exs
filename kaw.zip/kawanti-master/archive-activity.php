<?php
/**
 * Template for Activites, Actiity Type, Activity Location Archives
 *
 * A controller function redirects activity archives to this template.
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 * @see       inc/post-type/post-type-activities
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

?>

<main role="main" class="has-header-offset">

<!-- Mast -->
<?php
if (is_tax()) :
  get_template_part( 'partials/partial', 'mast-tax' );
else :
  get_template_part( 'partials/partial', 'mast' );
endif;

get_template_part( 'partials/partial', 'activity-filters' );
get_template_part( 'partials/partial', 'intro' );

?>

<section class="activity-cards is-activities">
  <div class="grid-lg">
    <div class="activity-cards__grid">
      <?php
      /**
       * Filter our query for fetch more
       * @see inc/post-helpers/query-filters
       */
      //add_filter('post_limits', 'jumpoff_limit_posts');

      $ppp = get_option('posts_per_page');
      $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

      if (is_tax()) {
        $queried_object = get_queried_object();
        $tax = $queried_object->taxonomy;
        $term_slug = $queried_object->slug;
        $term_name = $queried_object->name;

        $args = array (
          'post_type'       => 'activity',
          'posts_per_page'  => -1,
          'tax_query'       => array(
            array(
              'taxonomy'    => $tax,
              'field'       => 'slug',
              'terms'       => $term_slug,
              'operator'    => 'IN',
            )
          )
        );
        } else {

          $args = array (
            'post_type'        => 'activity',
            'posts_per_page'   => -1,
            'paged'            => $paged,
          );
        }

        $posts = new WP_Query($args);

        if (have_posts()) :
          while ( $posts->have_posts() ) : $posts->the_post();
            include(locate_template('partials/content/content-activity.php'));
          endwhile;
        else :
          include(locate_template('partials/content/content-none.php'));
        endif;

        //remove_filter('post_limits', 'jumpoff_limit_posts');
        wp_reset_postdata();
?>

    </div>
  </div>
</section>

<?php //get_template_part( 'partials/posts', 'fetch-more' );?>

</main>

<!-- Footer  -->
<?php get_footer(); ?>
