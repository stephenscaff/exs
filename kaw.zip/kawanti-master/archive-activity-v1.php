<?php
/**
 * Template for Activites, Actiity Type, Activity Location Archives
 *
 * A controller function redirects activity archives to this template.
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 * @see       inc/post-type/post-type-activities
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<main role="main" class="has-header-offset">

<!-- Mast -->
<?php
if (is_tax()) :
  get_template_part( 'partials/partial', 'mast-tax' );
else :
  get_template_part( 'partials/partial', 'mast' );
endif;
?>

<?php get_template_part( 'partials/partial', 'activity-filters' );?>

<section class="activity-cards is-activities">
  <div class="grid-lg">
    <div class="activity-cards__grid">
      <?php
      if ( have_posts() ): while ( have_posts() ) : the_post();
        get_template_part( 'partials/content/content', 'activity' );
      endwhile; else:
        get_template_part( 'partials/content/content', 'none' );
      endif; ?>
    </div>
  </div>
</section>

<?php get_template_part( 'partials/posts', 'fetch-more' );?>

</main>

<!-- Footer  -->
<?php get_footer(); ?>
