<?php
/**
 * Default Page Template
 *
 * @author    Stephen Scaff
 * @package   Jumpoff/Gramery
 * @version   2.0.0
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header(); ?>


<main class="app-main">
<?php get_template_part( 'views/shared/mast' ); ?>
<?php get_template_part( 'views/shared/modules' ); ?>
</section>

</main>

<?php get_footer(); ?>
