<?php
/**
 * views/modules/intro-module
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$title        = get_sub_field('title');
$content      = get_sub_field('content');
$module_shift = get_sub_field('shift');
$link         = get_sub_field('button_link');
$url          = get_sub_field('button_url');
$btn_text     = get_sub_field('button_text');
$link_or_url  = get_field_fallback($link, $url);

?>

<section class="intro module">
  <div class="grid-lg">
    <div class="intro__wrap <?php echo $module_shift; ?>">
      <header class="intro__header">
        <?php if ($title) : ?>
          <h3 class="intro__title"><?php echo $title; ?>
        <?php endif; ?>
        <?php if ($content) : ?>
          <?php echo $content; ?>
        <?php endif; ?>
      </header>
      <?php if ($link_or_url) : ?>
      <a class="btn-block has-border" href="<?php echo $link_or_url; ?>" data-aos="btn-border">
        <span class="btn-block__btn btn-line oh">
          <span><?php echo $btn_text; ?></span>
        </span>
        <span class="btn-block__arrow">
          <?php echo get_svg('right-arrow'); ?>
        </span>
      </a>
    <?php endif; ?>
    </div>
  </div>
</section>
