<?php
/**
 * views/modules/content-module
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$title   = get_sub_field('title');
$content = get_sub_field('content');

?>

<section class="content">
  <div class="grid-sm">
    <?php if ($title) : ?>
      <span class="mark"><?php echo get_svg('line'); ?></span>
      <h1 class="content__title"><?php echo $title; ?></h1>
    <?php endif; ?>

    <?php if ($content) : ?>
      <div class="content__excerpt">
        <p><?php echo $content; ?></p>
      </div>
    <?php endif; ?>

  </div>
</section>
