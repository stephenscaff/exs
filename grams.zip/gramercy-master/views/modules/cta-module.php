<?php
/**
 * views/modules/cta-module
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$title       = get_sub_field('cta_title');
$text        = get_sub_field('cta_text');
$link         = get_sub_field('button_link');
$url          = get_sub_field('button_url');
$btn_text     = get_sub_field('button_text');
$store_link   = get_sub_field('store_link');
$cta_link = "";

if ($link) {
  $cta_link = $link;
} elseif ($url) {
  $cta_link = $url;
} elseif ($store_link) {
  $cta_link = get_field($store_link, 'option');
}
?>


?>

<section class="cta">
  <div class="grid-lg">
    <div class="cta__block">
      <span class="mark"><?php echo get_svg('line'); ?></span>
      <?php if ($title) : ?><h2 class="cta__title"><?php echo $title; ?></h2><?php endif; ?>
      <?php if ($text) : ?><p class="cta__text"><?php echo $text; ?></p><?php endif; ?>
      <?php if ($link_or_url) : ?>
      <a class="btn-block has-border" href="<?php echo $cta_link; ?>">
        <span class="btn-block__btn btn-line">
          <?php echo $btn_text; ?>
        </span>
        <span class="btn-block__arrow">
          <?php echo get_svg('right-arrow'); ?>
        </span>
      </a>
    <?php endif; ?>
    </div>
  </div>
</section>
