<?php
/**
 * Template Name: Contact
 *
 * @author      Karlie Watts
 * @package     jumpoff
 * @subpackage  template
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$co_address       = get_field('company_address', 'options');
$co_phone         = get_field('company_phone', 'options');
$co_email         = get_field('company_email', 'options');
$operations_email = get_field('operations_email', 'options');
$club_email       = get_field('club_email', 'options');
$events_email     = get_field('events_email', 'options');

?>


<main class="app-main" data-router-wrapper>

    <section class="contact">
      <div class="contact__header-container grid-lg">

        <h2 class="contact__title">Contacts</h2>
        <hr class="sep is-full" />

      <div class="contacts">
        <div class="contacts__individuals">
            <div class="contacts__individual">
              <h3 class="contacts__item-title">Winemaking/Winery Operations</h3>
              <p class="contacts__item-info">Email: <?php echo $operations_email; ?></p>
            </div>
            <div class="contacts__individual">
              <h3 class="contacts__item-title">Wine Club Information</h3>
              <p class="contacts__item-info">Email: <?php echo $club_email; ?></p>
            </div>
            <div class="contacts__individual">
              <h3 class="contacts__item-title">Appointments & Events</h3>
              <p class="contacts__item-info">Email: <?php echo $events_email; ?></p>
            </div>
        </div>

        <div class="contacts__company">
          <div class="contacts__company-detail">
            <span class="contacts__title">address</span>
            <p class="contacts__info"><?php echo $co_address; ?></p>
            <br />
            <span class="contacts__title">contact</span>
            <p class="contacts__info">Phone: <?php echo $co_phone; ?><br />Email: <?php echo $co_email; ?></p>

          </div>
        </div>
      </div>
    </div>
  </section>

</main>
