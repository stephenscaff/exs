<?php
/**
 * views/modules/card-block-module
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$module_shift = get_sub_field('shift');
$image        = get_sub_field('image');
$title        = get_sub_field('title');
$content      = get_sub_field('content');
$link         = get_sub_field('button_link');
$url          = get_sub_field('button_url');
$btn_text     = get_sub_field('button_text');
$store_link   = get_sub_field('store_link');
$cta_link = "";

if ($link) {
  $cta_link = $link;
} elseif ($url) {
  $cta_link = $url;
} elseif ($store_link) {
  $cta_link = get_field($store_link, 'option');
}
?>

<section class="card-block" data-aos="scale-block">
  <div class="grid-lg">
    <article class="card-block__item <?php echo $module_shift; ?>">
      <a class="card-block__link" href="<?php echo $cta_link; ?>">
        <figure class="card-block__figure">
          <div class="card-block__scaler">
            <div class="card-block__img" style="background-image: url(<?php echo $image['url']; ?>)"></div>
          </div>
        </figure>
        <div class="card-block__main <?php echo $module_shift; ?>">
          <h3 class="card-block__title oh"><span><?php echo $title; ?></h3>
          <p class="card-block__text"><?php echo $content; ?></p>
          <span class="card-block__btn btn-block"  data-aos="slice-in">
            <span class="btn-block__btn btn-line oh">
              <span><?php echo $btn_text; ?></span>
            </span>
            <span class="btn-block__arrow">
              <?php echo get_svg('right-arrow'); ?>
            </span>
          </span>
        </div>
      </a>
    </article>
  </div>
</section>
