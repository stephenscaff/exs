<?php
/**
 * views/modules/hours.php
 *
 * @author      Karlie Watts
 * @package     jumpoff
 * @subpackage  template
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$co_address       = get_field('company_address', 'options');
$co_phone         = get_field('company_phone', 'options');
$co_email         = get_field('company_email', 'options');
$events_email     = get_field('events_email', 'options');
$hour_items       = get_field('hour_items', 'options');
$disclaimer       = get_field('disclaimer', 'options');

?>

<section class="hours">
  <div class=" grid-lg">
    <hr class="sep is-full" />
    <div class="hours__cols">

      <div class="hours__col">
        <h2 class="hours__title">Appointments & Events</h2>
        <p class="hours__info">Email: <?php echo $events_email; ?></p>
        <br />
        <p class="hours__info">*<?php echo $disclaimer; ?></p>
      </div>

      <div class="hours__col">
        <span class="hours__subtitle">Hours</span>

        <?php foreach ($hour_items as $hour_item) :
          $detail  = $hour_item['hour_detail'];
        ?>
          <div class="hours__item">
            <p class=""><?php echo $detail; ?></p>
          </div>
        <?php endforeach; ?>

      </div>

      <div class="hours__col">
        <span class="hours__subtitle">address</span>
        <p class="hours__info"><?php echo $co_address; ?></p>
        <br />
        <span class="hours__subtitle">contact</span>
        <p class="hours__info">Phone: <?php echo $co_phone; ?><br />Email: <?php echo $co_email; ?></p>
      </div>

    </div>
  </div>
</section>
