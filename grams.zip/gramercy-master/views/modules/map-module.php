<?php
/**
 * views/modules/map-module
 *
 * @author       Stephen Scaff & Karlie Watts
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$title = get_sub_field('title');
$locations = get_sub_field('locations');
$locations_obj = json_encode($locations, JSON_NUMERIC_CHECK);

?>

<script>
  var locationsData = <?php echo $locations_obj; ?>
</script>

<section class="location-map module">
  <div class="grid-lg">
    <?php if ($title) : ?>
      <header class="location-map__header">
        <span class="mark"><?php echo get_svg('line'); ?></span>
        <h3 class="location-map__title"><?php echo $title; ?></h3>
      </header>
    <?php endif; ?>
    <div class="location-map__wrap">
      <div class="location-map__map js-location-map"></div>
    </div>
  </div>
</section>
