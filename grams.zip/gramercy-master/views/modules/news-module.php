<?php
/**
 * views/modules/Team
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;
global $post;

if ( ! defined( 'ABSPATH' ) ) exit;

$archive_link = get_post_type_archive_link( 'post' );

$args = array(
  'post_type'       => 'post',
  'posts_per_page'  => '3',
);

$posts = get_posts( $args );

?>

<section class="news module pad">
  <div class="grid-lg">
    <header class="news__header" data-aos="slice-in">
      <span class="mark"><?php echo get_svg('line'); ?></span>
      <h2 class="news__title oh"><span>News & Events</span></h2>
    </header>

    <div class="news__grid grid-1-3">
      <?php
      foreach ( $posts as $post ) : setup_postdata( $post );
        $post_title  = get_the_title();
        $post_ft_img = get_ft_img('large');
        $excerpt     = get_excerpt(150);
        $link        = get_the_permalink($post->ID);
      ?>

      <article class="card" data-aos="scale-block">
        <a class="card__link" href="<?php echo $link; ?>">
          <figure class="card__figure">
            <div class="card__scaler">
              <img class="card__img" src="<?php echo $post_ft_img->url; ?>">
            </div>
          </figure>
          <header class="card__header">
            <h3 class="card__title"><?php echo $post_title; ?></h3>
            <p class="card__excerpt"><?php echo $excerpt; ?></p>
            <span class="btn-line">Read Story</span>
          </header>
        </a>
      </article>
      <?php endforeach; wp_reset_postdata(); ?>
    </div>

    <footer class="news__footer pad-t">
      <a class="btn-block has-border" href="<?php echo $archive_link; ?>" data-aos="btn-border" data-aos-delay="10000">
        <span class="btn-block__btn btn-line oh"><span>View All</span></span>
        <span class="btn-block__arrow">
          <?php echo get_svg('right-arrow'); ?>
        </span>
      </a>
    </footer>
  </div>
</section>
