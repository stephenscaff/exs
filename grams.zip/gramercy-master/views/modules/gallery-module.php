<?php
/**
 * views/modules/fare-section
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="gallery module">
  <div class="gal">
    <?php
    while ( have_rows('images') ): the_row();
      $img       = get_sub_field('image');
      $img_width = get_sub_field('image_width');
      $svg       = get_sub_field('svgs');
      $theme     = get_sub_field('themes');
    ?>
    <?php if ($svg) : ?>
      <figure class="gal__item <?php echo $theme; ?>">
          <span class="gal__item-svg <?php echo $theme; ?>"><?php echo get_svg($svg); ?></span>
      </figure>
      <?php else : ?>
       <figure class="gal__item <?php echo $img_width; ?>" style="background-image: url(<?php echo $img['url']; ?>)"></figure>
      <?php endif; ?>
    <?php endwhile; ?>
  </div>
</section>
