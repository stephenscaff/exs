<?php
/**
 * views/modules/quotes-module
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="quotes">
  <div class="grid-lg">
    <div class="quotes__main js-quotes">
    <?php
    while ( have_rows('quotes') ): the_row();
      $quote  = get_sub_field('quote_content');
      $author = get_sub_field('author');
    ?>
      <div class="quote js-quote">
        <blockquote class="quote__bq">
          <?php echo $quote; ?>
          <cite class="quote__cite"><?php echo $author; ?></cite>
        </blockquote>
      </div>
    <?php endwhile; ?>
    </div>

    <nav class="quotes__nav" data-aos="btn-border">
      <span class="quotes__nav-control is-prev js-quote-prev oh"><span>prev</span></span>
      <span class="quotes__nav-sep oh"><span>/</span></span>
      <span class="quotes__nav-control is-next js-quote-next oh"><span>next</span></span>
    </nav>
  </div>
</section>
