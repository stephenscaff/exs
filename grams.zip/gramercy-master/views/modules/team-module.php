<?php
/**
 * views/modules/Team
 *
 * @author       Stephen Scaff
 * @package      views/modules
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$args = array(
  'post_type'       => 'team',
  'posts_per_page'  => '-1',
);

$teams = get_posts( $args );

?>

<section class="teams module">
  <div class="grid-lg">
    <header class="teams__header">
      <span class="mark"><?php echo get_svg('line'); ?></span>
      <h2 class="teams__title">Our Team</h2>
      <hr class="sep is-full" />
    </header>

    <div class="teams__grid">

      <?php
      foreach ( $teams as $post ) : setup_postdata( $post );
        $name     = get_the_title($post);
        $position = get_field('team_position', $post);
        $bio      = get_field('team_bio', $post);
        $image    = get_field('team_image', $post);
      ?>

      <article class="team">
        <figure class="team__figure">
          <img class="team__img" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
        </figure>
        <div class="team__details">
          <header class="team__header">
            <span class="team__position"><?php echo $position; ?></span>
            <h3 class="team__name"><?php echo $name; ?></h3>
          </header>
          <div class="team__bio"><?php echo $bio; ?></div>
        </div>
      </article>
      <?php endforeach; wp_reset_postdata(); ?>
    </div>
  </div>
</section>
