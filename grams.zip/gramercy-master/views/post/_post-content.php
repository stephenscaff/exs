<?php
/**
 * Post Content
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$post_title = get_the_title();

?>

<section class="post-content content">
  <header class="post-mast__header grid-sm ">
    <span class="mark"><?php echo get_svg('line'); ?></span>
    <h1 class="post-mast__title"><?php echo $post_title; ?></h1>
  </header>
  <div class="grid-sm">
    <?php the_content(); ?>
  </div>
</section>
