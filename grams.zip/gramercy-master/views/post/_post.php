<?php
/**
 * Views/Post/_Post
 * Looped post content
 *
 * @author    Stephen Scaff
 * @package   partials/content
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$post_link    = get_the_permalink();
$post_title   = get_the_title();
$post_img     = get_ft_img('large');
$post_excerpt = get_excerpt(150);

?>

<article class="card">
  <a class="card__link" href="<?php echo $link; ?>">
    <figure class="card__figure">
      <div class="card__scaler">
        <img class="card__img" src="<?php echo $post_ft_img->url; ?>">
      </div>
    </figure>
    <header class="card__header">
      <h3 class="card__title"><?php echo $post_title; ?></h3>
      <p class="card__excerpt"><?php echo $excerpt; ?></p>
      <span class="btn-line">Read Story</span>
    </header>
  </a>
</article>
