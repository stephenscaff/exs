<?php
/**
 * Views/Posts/Archive
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

 namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$featured    = get_field('featured');
$featured_or_latest = "";

# If Featured exists, use featured, else get latest
if ($featured) {
  $featured_or_latest = $featured;
} else {
  # Get Posts: Latest
  $latest_args = array(
    'post_type'        => 'post',
    'posts_per_page'   => 1,
  );
  $latest = get_posts( $latest_args );
  $featured_or_latest = $latest;
}

?>

<main class="has-header-offset">

  <section class="mast-title">
    <div class="grid-lg">
      <span class="mark"><?php echo get_svg('line'); ?></span>
      <h2 class="contact__title">News & Events</h2>
    </div>
  </section>

  <?php
  # Loop Logic
  if (!is_category()) :
    if (!is_paged()) :
      if ($featured_or_latest) :
        foreach( $featured_or_latest as $post) :
          setup_postdata( $post );
            include(locate_template('views/post/_featured.php' ));
          wp_reset_postdata();
        endforeach;
      endif;
    endif;
  endif;
  ?>

  <section class="posts-cards posts-archived">
    <div class="grid-lg">
      <div id="js-posts" class="news__grid">
        <?php

        if (is_category()) {

          $queried_object = get_queried_object();
          $tax = $queried_object->taxonomy;
          $term_slug = $queried_object->slug;
          $term_name = $queried_object->name;

          $args = array (
            'post_type'       => 'post',
            'posts_per_page' => $ppp,
            'paged'          => $paged,
            'tax_query'       => array(
              array(
                'taxonomy'    => 'category',
                'field'       => 'slug',
                'terms'       => $term_slug,
                'operator'    => 'IN',
              )
            )
          );
        }

        else {
          add_filter('post_limits', 'limit_posts_filter');
          $ppp = get_option('posts_per_page');
          $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

          $post_args = array(
            'post_type'        => 'post',
            'posts_per_page'   => $ppp,
            'paged'            => $paged,
            'post__not_in'     => array($featured_or_latest[0]->ID)
          );

          $posts = new \WP_Query($post_args);

      if (have_posts()) :
        while ( $posts->have_posts() ) : $posts->the_post();
          include(locate_template('views/post/_post.php'));
        endwhile;
        else :
          include(locate_template('views/content/none.php'));
        endif;

        wp_reset_postdata();
        remove_filter('post_limits', 'limit_posts_filter');
      }
      ?>
    </div>
  </div>
</section>
<?php get_template_part( 'views/shared/fetch-more' ); ?>
<?php get_template_part( 'views/shared/modules' ); ?>
</main>

<?php get_footer(); ?>
