<?php
/**
 *  Views/Posts/_Post-Mast
 *  Post Mast for Single Posts and post-like post types
 *
 *  @author    Stephen Scaff
 *  @package   jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$post_img = get_ft_img('full');
$post_img_url = $post_img->url;

# Featured Image or Fallback logic
$has_img = false;

if ($post_img->url) {
  $has_img = true;
}

?>

<section class="post-mast <?php if ($has_img) { echo 'has-img'; } else { echo 'no-img'; }; ?> has-post-offset">

  <?php if ($has_img) : ?>
  <figure class="post-mast__figure grid-lg">
    <img class="post-mast__img" src="<?php echo $post_img_url; ?>" alt="<?php echo $post_img->alt; ?>">
    <?php if ($post_img->caption) : ?>
      <figcaption class="post-mast__img-caption"><?php echo $post_img->caption; ?></figcaption>
    <?php endif; ?>
  </figure>
  <?php endif; ?>
</section>
