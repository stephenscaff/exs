<?php
/**
 * Views/Shared/Header
 * Main site/app header and nav section.
 *
 * @author    Stephen Scaff
 * @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$post_title = get_the_title();
$next_post = get_adjacent_post(false, '', true);
$prev_post = get_adjacent_post(false, '', false);

$prev_link = get_the_permalink($prev_post->ID);
$next_link = get_the_permalink($next_post->ID);

?>

<header class="post-header">
  <div class="grid-lg">
    <div class="post-header__grid">

      <a class="post-header__prev" href="<?php echo $prev_link; ?>">
        <span class="post-header__btn btn-block">
          <span class="btn-block__arrow is-left">
            <?php echo get_svg('right-arrow'); ?>
          </span>
          <div class="post-header__link">
            <span class="btn-line">previous</span>
          </div>
        </span>
      </a>



        <div class="post-header__title">
          <h4 class=""><?php echo $post_title; ?></h4>
        </div>


        <a class="post-header__next" href="<?php echo $next_link; ?>">
          <span class="post-header__btn btn-block">
            <div class="post-header__link">
              <span class="btn-line">next</span>
            </div>
            <span class="btn-block__arrow">
              <?php echo get_svg('right-arrow'); ?>
            </span>
          </span>
        </a>

      <!-- </nav> -->
    </div>
  </div>
</header>
