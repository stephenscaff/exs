<?php
/**
 * Views/Posts/Related
 * The section for Related Posts.
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="heading">
  <header class="grid-lg">
    <span class="mark"><?php echo get_svg('line'); ?></span>
    <h2 class="heading__title">Recommended Reading</h2>
  </header>
</section>

<section class="posts pad-sm">
  <div class="posts__grid">
    <?php
    include(locate_template('views/post/more-posts.php' ));
    ?>
  </div>
</section>
