<?php
/**
 * Views/Post/Post-Footer
 *
 * @author    Stephen Scaff
 * @package   jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$title       = get_field('dl_title');
$file        = get_field('dl_file');

?>

<section class="post-footer">
  <div class="grid-sm">
    <div class="post-footer__grid">
      <div class="downloader__block">
        <span class="mark"><?php echo get_svg('line'); ?></span>
        <h2 class="downloader__title"><?php echo $title; ?></h2>

        <a class="btn-block has-border" href="<?php echo $file['url']; ?>" target="_blank">
          <span class="btn-block__btn btn-line">Download PDF</span>
          <span class="btn-block__arrow">
            <?php echo get_svg('right-arrow'); ?>
          </span>
        </a>
      </div>
    </div>
  </div>
</section>
