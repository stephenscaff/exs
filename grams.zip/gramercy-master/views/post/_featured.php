<?php
/**
 * Views/Post/_Post
 * Looped post content
 *
 * @author    Stephen Scaff
 * @package   partials/content
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$post_link    = get_the_permalink();
$post_title   = get_the_title();
$post_img     = get_ft_img('large');
$post_excerpt = get_excerpt(150);

?>

<section class="card-block is-featured">
  <div class="grid-lg">
    <article class="card-block__item">
      <a class="card-block__link" href="<?php echo $post_link; ?>">
        <figure class="card-block__figure">
          <div class="card-block__scaler">
            <div class="card-block__img" style="background-image: url(<?php echo $post_img->url; ?>)"></div>
          </div>
        </figure>
        <div class="card-block__main">
          <h3 class="card-block__title"><?php echo $post_title; ?></h3>
          <p class="card-block__text"><?php echo $post_excerpt; ?></p>

          <span class="card-block__btn btn-block">
            <span class="btn-block__btn btn-line">Read Story</span>
            <span class="btn-block__arrow">
              <?php echo get_svg('right-arrow'); ?>
            </span>
          </span>
        </div>
      </a>
    </article>
  </div>
</section>
