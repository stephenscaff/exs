<?php
/**
 *  Views/Shared/Mast
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$name              = get_the_title($post);
$trade_location    = get_field('trade_location', $post);
$trade_desc        = get_field('trade_description', $post);
$bottle_shot       = get_field('bottle_shot', $post);
$trade_thumb       = get_field('trade_thumb', $post);
$tech_sheet        = get_field('tech_sheet', $post);
$bottle_shot       = get_field('bottle_shot', $post);

?>

<article class="trade-card">
  <header class="trade-card__header">
    <span class="trade-card__pretitle"><?php echo $trade_location; ?></span>
    <h2 class="trade-card__title"><?php echo $name; ?></h2>
  </header>

  <?php if ($trade_desc) : ?>
  <p class="trade-card__desc"><?php echo $trade_desc; ?></p>
  <?php endif; ?>

  <div class="trade-card__grid">
    <?php if ($trade_thumb) : ?>
      <figure class="trade-card__figure">
        <img class="trade-card__img" src="<?php echo $trade_thumb['url']; ?>" />
      </figure>
    <?php endif; ?>

    <div class="trade-card__btns">
      <?php if ($tech_sheet) : ?>
        <div class="trade-card__btn">
        <a class="btn" href="<?php echo $tech_sheet['url']; ?>" download>Tech Sheet</a>
      </div>
      <?php endif; ?>
      <?php if ($bottle_shot) : ?>
        <div class="trade-card__btn">
        <a class="btn" href="<?php echo $bottle_shot['url']; ?>" download>Bottle Shot</a>
      </div>
      <?php endif; ?>
    </div>
  </div>
</article>
