<?php
/**
 * Views/Shared/Header
 * Main site/app header and nav section.
 *
 * @author    Stephen Scaff
 * @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<header class="app-header">
  <div class="grid-lg">
    <div class="app-header__grid">
      <a class="app-header__toggle js-menu-toggle" href="">
        <span class="toggle-open"><?php echo get_svg('menu'); ?></span>
        <span class="toggle-close"><?php echo get_svg('menu'); ?></span>

      </a>
      <a class="app-header__brand" href="<?php echo get_page_url('home'); ?>">
        <?php echo get_svg('keyhole'); ?>
      </a>
      <nav class="app-header__nav">
        <span class="app-header__link">
          <a>Account</a>
          <div data-ecp-presence></div>
        </span>
        <span class="app-header__link cart-link">
          <div data-ecp-minicart></div>
          <!-- <a>
            <span class="cart-link__label">Cart</span>
            <span class="cart-link__amnt">(0)</span>
          </a> -->
        </span>
      </nav>
    </div>
  </div>
</header>
