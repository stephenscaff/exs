<?php
/**
 * Views/Shared/Alerts
 *
 * @author    Karlie Watts
 * @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$alert_message = get_field('alert_message', 'options');

?>

<?php if ($alert_message) : ?>
<section class="alert js-alert is-hidden-alert">
  <span class="alert__message"><?php echo $alert_message; ?></span>
  <button class="alert__close icon-alert-x js-close-alert" />
</section>
<?php endif; ?>

<script>
/**
 * Alert Cookie
 */
var alert = document.querySelector('.js-alert');
var closeAlert = document.querySelector('.js-close-alert');
var hasAlertCookie = (document.cookie.match(/^(?:.*;)?\s*alert\s*=\s*([^;]+)(?:.*)?$/)||[,null])[1];

if (!hasAlertCookie) {
  alert.classList.remove('is-hidden-alert');

  closeAlert.addEventListener('click', function (e) {
    alert.classList.add('is-hidden-alert');
    setCookie('alert', '1', 1);
    e.preventDefault();
  });
}

/**
 * Cookie Helper
 */
function setCookie(cname, cvalue, exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  var expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

</script>
