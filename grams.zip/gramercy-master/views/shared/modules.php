<?php
/**
 *  Views/Shared/Modules
 *
 *  @author    Stephen Scaff
 *  @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$ids = get_id();

while (has_sub_field('modules', $ids)) :
  ACF_Modules::render(get_row_layout());
endwhile;
