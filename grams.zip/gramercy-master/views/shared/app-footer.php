<?php
/**
 * Views/Shared/Footer
 *
 * Global footer element, inlcuding wp_footer().
 *
 * @author    Stephen Scaff
 * @package   jumpoff/gramercy
 * @version   1.0
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$address                 = get_field('contacts_address', 'options');
$phone                   = get_field('contacts_phone', 'options');
$email                   = get_field('contacts_email', 'options');
$twitter                 = get_field('contacts_twitter', 'options');
$facebook                = get_field('contacts_facebook', 'options');
$instagram               = get_field('contacts_instagram', 'options');
$youtube                 = get_field('contacts_youtube', 'options');
$ecellars_signup         = get_field('signup', 'options');
$ecellars_email          = get_field('emailinglist', 'options');
$ecellars_new_account    = get_field('new-account', 'options');
$ecellars_signin         = get_field('signin', 'options');
$ecellars_view_cart      = get_field('view_cart', 'options');
?>


<footer class="app-footer">
  <div class="grid-lg">
    <div class="app-footer__grid">
      <div class="app-footer__infos">

        <?php if ($address) : ?>
        <div class="app-footer__col">
          <h5 class="app-footer__heading">Address</h5>
          <address class="app-footer__address">
            <?php echo format_lines($address, 'span'); ?></address>
          </address>
        </div>
        <?php endif; ?>

        <?php if ($phone || $email) : ?>
        <div class="app-footer__col">
          <h5 class="app-footer__heading">Contact</h5>
          <?php if ($phone) : ?>
            <div><span>Phone:</span> <a class="" href="tel:<?php echo $phone; ?>"><?php echo $phone; ?></a></div>
          <?php endif; ?>
          <?php if ($email) : ?>
            <div><span>Email:</span> <a class="" href="tel:<?php echo $email; ?>"><?php echo $email; ?></a></div>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>

      <div class="app-footer__navs">
        <div class="app-footer__col">
          <h5 class="app-footer__heading">Gramercy</h5>
          <?php echo render_menu('footer_menu_1', 'app-footer'); ?>
        </div>

        <div class="app-footer__col">
          <h5 class="app-footer__heading">Social</h5>
          <nav class="app-footer__nav is-social">
            <?php if ($facebook) : ?><a href="<?php echo $facebook; ?>">Facebook</a><?php endif; ?>
            <?php if ($twitter) : ?><a href="<?php echo $twitter; ?>">Twitter</a><?php endif; ?>
            <?php if ($instagram) : ?><a href="<?php echo $instagram; ?>">Instagram</a><?php endif; ?>
            <?php if ($youtube) : ?><a href="<?php echo $youtube; ?>">YouTube</a><?php endif; ?>
          </nav>
        </div>

        <div class="app-footer__col">
          <h5 class="app-footer__heading">Account</h5>
          <nav class="app-footer__nav">
            <a href="<?php echo $ecellars_signin; ?>">Login</a>
            <a href="<?php echo $ecellars_signup; ?>">Signup</a>
            <a href="<?php echo $ecellars_view_cart; ?>">Cart</a>
          </nav>
        </div>
      </div>
    </div>

    <section class="app-footer__ender">
      <div class="app-footer__ender-grid">
        <figure class="app-footer__ender-gates">
          <?php echo get_svg('gate'); ?>
        </figure>
        <nav class="app-footer__ender-nav">
          <p class="app-footer__copyright">&copy; <?php echo date("Y"); ?> Gramercy Cellars</p>
          <a class="app-footer__ender-link" href="">Terms & Conditions</a>
          <a class="app-footer__ender-link" href="">Privacy</a>
        </nav>
      </div>
    </section>
  </div>
</footer>
<script src="https://cdn.ecellar-rw.com/js/loader.js"></script>
<?php wp_footer(); ?>

</body>
</html>
