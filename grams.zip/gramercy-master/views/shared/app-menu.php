<?php
/**
 * Views/Shared/Header
 * Main site/app header and nav section.
 *
 * @author    Stephen Scaff
 * @package   Jumpoff/Gramercy
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="app-menu">
  <div class="app-menu__wrap">
    <header class="app-menu__header">
      <figure class="app-menu__brand"><?php echo get_svg('gramercy-type'); ?></figure>
    </header>
    <nav class="app-menu__nav">
      <div><a class="app-menu__link" href="<?php echo get_page_url('about'); ?>"><span>About</span></a></div>
      <div><a class="app-menu__link" href="<?php echo get_page_url('shop'); ?>?view=products&slug=current-releases"><span>Wines</span></a></div>
      <div><a class="app-menu__link" href="<?php echo get_page_url('news'); ?>"><span>News & Events</span></a></div>
      <div><a class="app-menu__link" href="<?php echo get_page_url('club'); ?>"><span>Club</span></a></div>
      <div><a class="app-menu__link" href="<?php echo get_page_url('visit'); ?>"><span>Visit</span></a></div>
    </nav>

    <footer class="app-menu__footer">
      <nav class="app-menu__shop-nav">
        <span class="app-menu__shop-link"><div data-ecp-presence></div></span>
        <span class="app-menu__shop-link"><div data-ecp-minicart></div></span>
      </nav>
    </footer>
  </div>
</section>
