<?php
/**
 *  Views/Shared/Mast
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$id            = get_id();
$color_theme   = get_field('themes', $id);
$mast_pretitle = get_field('mast_pretitle', $id);
$mast_title    = get_field('mast_title', $id);
$mast_text     = get_field('mast_text', $id);
$mast_img      = get_field('mast_image', $id);
$ft_img        = get_ft_img('full');
$link          = get_field('button_link');
$url           = get_field('button_url');
$btn_text      = get_field('button_text');
$link_or_url   = get_field_fallback($link, $url);

if (!$mast_img) $mast_img = $ft_img;

$visibility = "";
if (is_page('home')) $visibility = 'is-visually-hidden';

?>

<section class="mast <?php echo $color_theme; ?>">
  <figure class="mast__figure">
    <div class="mast__img"  style="background-image: url(<?php echo $mast_img['url']; ?>)"></div>
  </figure>
  <div class="grid-lg">
    <header class="mast__header">
      <?php if (is_page('home')) { echo get_svg('shine-monogram'); } ?>

      <?php if ($mast_pretitle) : ?>
        <span class="mast__pretitle"><?php echo $mast_pretitle; ?></span>
      <?php endif; ?>

      <?php if (is_page('home')) { echo get_svg('brand-logo'); } ?>

      <?php if ($mast_title) : ?>
        <h1 class="mast__title <?php echo $visibility; ?>"><?php echo $mast_title; ?></h1>
      <?php endif; ?>

      <hr class="sep is-white is-centered" />

      <?php if ($mast_text) : ?>
        <p class="mast__text"><?php echo $mast_text; ?></p>
      <?php endif; ?>
    </header>
  </div>
</section>
