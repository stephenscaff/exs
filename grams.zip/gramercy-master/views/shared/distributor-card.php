<?php
/**
 *  Views/Shared/Mast
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$name          = get_the_title($post);
$dist_location = get_field('distributor_location', $post);
$dit_phone     = get_field('distributor_phone', $post);
$dist_email    = get_field('distributor_email', $post);

?>
<?php if ($name) : ?>
  <article class="distributor-card">
    <span class="distributor-card__pretitle"><?php echo $dist_location; ?></span>
    <h1 class="distributor-card__title"><?php echo $name; ?></h1>
    <a class="distributor-card__desc" href="tel:<?php echo format_tel_link($dit_phone); ?>"><?php echo $dit_phone; ?></a>
    <br />
    <span class="distributor-card__desc"><?php echo $dist_email; ?></span>
  </article>
<?php endif; ?>
