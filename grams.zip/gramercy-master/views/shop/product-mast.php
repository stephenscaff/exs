<?php
/**
 *  Views/Shared/Mast
 *
 *  Template for displaying a common mast section.
 *
 *  @author    Stephen Scaff
 *  @package   Jumpoff
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$mast_title = get_field('mast_title', 'option');
$mast_img   = get_field('mast_image', 'option');

?>

<section class="mast module">
  <figure class="mast__figure">
    <div class="mast__img"  style="background-image: url(<?php echo $mast_img['url']; ?>)"></div>
  </figure>
  <header class="mast__header grid-lg">
    <h1 class="mast__title"><?php echo $mast_title; ?></h1>
  </header>
</section>
