### eCellars Docs Links

https://github.com/ecellar/remote-widgets/wiki/01-Getting-Started#use-deep-linking
https://github.com/ecellar/remote-widgets/wiki/11-Template-Directory


## eCellars routing links

shop/?view=product&slug=2015-cabernet-sauvignon
shop/?view=products&slug=current-releases
shop/?view=categorieslist&slug=wine
