import "@babel/polyfill";
import './components/Sniffers'
import AppMenu from './components/AppMenu'
import PageTransitions from './components/PageTransitions'
import HashTabs from './components/HashTabs'
import './components/Quotes'
import * as Map from './components/Map'
import AOS from 'aos';


PageTransitions.init()
AppMenu.init()
HashTabs.init()

if (document.querySelector('.js-location-map')) {
  Map.GramercyMap('.js-location-map');
}

AOS.init({
  mirror: true,
  anchorPlacement: 'bottom-center',

});
