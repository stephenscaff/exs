/**
 * Site Inits object
 */
var site = {

  /**
  * Hellooo
  */
  hello: function(text) {
    return console.log(text);
  },
};

/**
 * Test Test
 */
var name = 'Doood';
site.hello(`Sup ${name}. Them inits are working.`);
