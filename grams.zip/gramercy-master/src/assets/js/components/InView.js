import Utils from '../components/Utils.js'

/**
 * Inview
 * Simple detection if element is in viewport
 * to add / remove classes.
 */
const InView = (() => {

 const els = document.querySelectorAll('.js-inview');
 const threshold = 30;
 const throttleAmnt = 10;
 const scrollClass = 'is-inview';

 return{

   init(){
     this.bindEvents();
   },

   bindEvents(){
     InView.scrollLogic();
   },

   /**
    * Is In View
    * Simple in viewport detection
    * @param {html element} el - element to detec.
    * @param {number} offset - scroll viewport offset amount
    * @return {boolean} True/False if in viewport
    */
   isInView(el, offset) {
     let top = el.offsetTop;
     let left = el.offsetLeft;
     let width = el.offsetWidth;
     let height = el.offsetHeight;

     while(el.offsetParent) {
       el = el.offsetParent;
       top += el.offsetTop + offset;
       left += el.offsetLeft;
     }

     return (
       top < (window.pageYOffset + window.innerHeight) &&
       left < (window.pageXOffset + window.innerWidth) &&
       (top + height) > window.pageYOffset &&
       (left + width) > window.pageXOffset
     );
   },

   /**
    * Scroll Logic
    * Adds / removes class to el when in viewport
    * Throttles scroll handler via threshold var
    */
   scrollLogic() {
     els.forEach((el) => {
       window.addEventListener('scroll', Utils.throttle(function(){
         if ( InView.isInView(el, threshold) ) {
           el.classList.add(scrollClass);
         } else {
           el.classList.remove(scrollClass);
         }
       }, throttleAmnt));
     });
   },
 };
})();

export default InView;
