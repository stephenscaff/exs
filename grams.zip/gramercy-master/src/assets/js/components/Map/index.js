import Utils from '../../components/Utils.js'
import * as MapUtils from './mapUtils';
import GoogleMapsApi from './GoogleMapsApi'
import { stylers }   from './stylers'
import markerTmpl from './marker.tmpl'

/**
 * Init Property Map
 * Main map rendering function that uses our GMaps API class
 */
export function GramercyMap(el) {

  const gApiKey = 'AIzaSyCR1znF989WxRTbncT77BVOXyJ_dQLVztI'
  const gmapApi = new GoogleMapsApi(gApiKey)
  const mapEl   = document.querySelector(el)
  const locations = locationsData;

  gmapApi.load().then(() => {
    renderMap(mapEl, locations)
 })
}


/**
 * Render Map
 * @param {map obj} mapEl - Google Map
 * @param {Promise | obj} mapEl - resolved promise of map data
 */
function renderMap(mapEl, results) {

  /**
   * Map Options
   * @property {mapType} mapTypeId - type of map
   * @property {obj} styles - map styles json
   * @property {number} zoom - intial zoom level
   */
  const options = {
    mapTypeId:   google.maps.MapTypeId.TERRAIN,
    styles:      stylers.styles,
    zoom:        8
  }

  /**
   * Google map instance
   * @type {Map}
   */
  const map = new google.maps.Map(mapEl, options);

  addMarkers(map, results);
}

/**
 * Add Markers
 * @param {map obj} mapEl - Google Map
 * @param {obj} markers - object of marker data
 */
function addMarkers(map, markers) {

  /**
   * Infowindow Instance
   * @type {InfoWindow}
   */
  const infowindow = new google.maps.InfoWindow();

  let icon;
  /**
   * Custom Icon object
   * @property {string} url - marker image base64
   * @property {Size}
   */
  const icon_diamond_dark = {
    url:        stylers.icons.diamond_dark,
    scaledSize: new google.maps.Size(30, 30)
  }

  const icon_keyhole = {
    url:        stylers.icons.keyhole,
    scaledSize: new google.maps.Size(60, 60)
  }

  map.markers = [];

  markers.forEach((result, i) => {

    let icon = (result.name == "Gramercy Cellars") ? icon_keyhole : icon_diamond_dark

    /**
     * Marker Template
     * @type {function} MarkerTmpl - passes data to marker
     * @param {object} result - Marker Data
     * @requires _MarkerTmpl.js
     */
    let tmpl = markerTmpl(result);

    if (result.gmap.lat == null  || result.gmap.lng == null) return;

    let marker = new google.maps.Marker({
      position: new google.maps.LatLng(
        result.gmap.lat,
        result.gmap.lng,
      ),
      map: map,
      title: result.name,
      icon: icon,
      animation: google.maps.Animation.DROP,
      content: tmpl
    });

    map.markers.push(marker);
    handleMarkerClick(map, marker, infowindow);
  });

  MapUtils.centerMap(map, map.markers);
}

/**
 * Render Map
 *
 * @param {map obj} mapEl
 * @param {marker} marker
 * @param {infowindow} infoWindow
 */
function handleMarkerClick(map, marker, infowindow) {

  google.maps.event.addListener(marker, 'click', function() {
    MapUtils.toggleInfoWindow(map, marker, infowindow)
  });

  google.maps.event.addListener(map, 'click', function(event) {
    if (infowindow) {
      infowindow.close(map, infowindow);
    }
  });
}
