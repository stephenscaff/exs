 /**
    * Map Icon/Pin SVG
    * SVG is base64 encoded.
    */
    export const stylers = {

      /**
       * Map Styler JSON
       */
      styles: [
         {
           "featureType": "administrative",
           "elementType": "labels.text.fill",
           "stylers": [ {
             "color": "#222222"
           } ]
         }, {
           "featureType": "landscape",
           "elementType": "all",
           "stylers": [ {
             "color": "#f2f2f2"
           } ]
         }, {
           "featureType": "landscape.natural.landcover",
           "elementType": "labels.icon",
           "stylers": [ {
             "visibility": "simplified"
           } ]
         }, {
           "featureType": "poi",
           "elementType": "all",
           "stylers": [ {
             "visibility": "off"
           } ]
         }, {
           "featureType": "road",
           "elementType": "all",
           "stylers": [ {
             "saturation": -100
           }, {
             "lightness": 45
           } ]
         }, {
           "featureType": "road.highway",
           "elementType": "all",
           "stylers": [ {
             "visibility": "simplified"
           } ]
         }, {
           "featureType": "road.highway",
           "elementType": "geometry.fill",
           "stylers": [ {
             "color": "#ffffff"
           } ]
         }, {
           "featureType": "road.arterial",
           "elementType": "labels.icon",
           "stylers": [ {
             "visibility": "off"
           } ]
         }, {
           "featureType": "transit",
           "elementType": "all",
           "stylers": [ {
             "visibility": "off"
           } ]
         }, {
           "featureType": "water",
           "elementType": "all",
           "stylers": [ {
             "color": "#dde6e8"
           }, {
             "visibility": "on"
           } ]
         },{
            "featureType": 'landscape.natural',
            "elementType": 'geometry',
            "stylers": [{"color": "#efefef"}]
          },
       ],

     /**
      * Map Icon/Pin SVG
      * SVG is base64 encoded.
      */
     icons: {
       diamond_dark: 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDIzLjAuMywgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IgoJIHZpZXdCb3g9IjAgMCAyMCAyMCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMjAgMjA7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHBhdGggc3R5bGU9ImZpbGw6IzIzMUYyMDsiIGQ9Ik0xOSwxMEMxNSw4LjIsMTEuOCw1LDEwLDFsMCwwbDAsMEM4LjIsNSw1LDguMiwxLDEwbDAsMGwwLDBDNSwxMS44LDguMiwxNSwxMCwxOWwwLDBsMCwwCglDMTEuOCwxNSwxNSwxMS44LDE5LDEwTDE5LDEwTDE5LDEweiIvPgo8L3N2Zz4K',

       diamond_gold: 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDIzLjAuMywgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IgoJIHZpZXdCb3g9IjAgMCAyMCAyMCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMjAgMjA7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHBhdGggc3R5bGU9ImZpbGw6I2E4OTI0YTsiIGQ9Ik0xOSwxMEMxNSw4LjIsMTEuOCw1LDEwLDFsMCwwbDAsMEM4LjIsNSw1LDguMiwxLDEwbDAsMGwwLDBDNSwxMS44LDguMiwxNSwxMCwxOWwwLDBsMCwwCglDMTEuOCwxNSwxNSwxMS44LDE5LDEwTDE5LDEwTDE5LDEweiIgLz4KPC9zdmc+Cg==',

       keyhole: 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDIzLjAuMywgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IgoJIHZpZXdCb3g9IjAgMCAzNiA2MCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgMzYgNjA7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPGcgaWQ9IkN1cnJlbnRfNF8iPgoJPGcgaWQ9ImFib3V0XzJfIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtNjk4LjAwMDAwMCwgLTI0ODQuMDAwMDAwKSI+CgkJPGcgaWQ9Im1hcF8yXyIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNTguMDAwMDAwLCAyMDMwLjAwMDAwMCkiPgoJCQk8ZyBpZD0iU2NyZWVuLVNob3QtMjAxOS0wNC0zMC1hdC0xLjI5LjQ0LVBNXzJfIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLjAwMDAwMCwgMTIwLjAwMDAwMCkiPgoJCQkJPGcgaWQ9Ikdyb3VwLTNfMl8iIHRyYW5zZm9ybT0idHJhbnNsYXRlKDY0MC4wMDAwMDAsIDMzNC4wMDAwMDApIj4KCQkJCQk8cGF0aCBpZD0iRmlsbC0xXzZfIiBzdHlsZT0iZmlsbC1ydWxlOmV2ZW5vZGQ7Y2xpcC1ydWxlOmV2ZW5vZGQ7ZmlsbDojMjMxRjIwOyIgZD0iTTE5LjIsMjcuMkwxOSwyNy4zdjAuM3YxNC40aC0yLjcKCQkJCQkJbC0wLjItMTQuM2wwLDBsLTAuMi0wLjNjLTEuMi0wLjYtMS44LTEuOS0xLjgtMy4zYzAtMiwxLjMtMy41LDMuMi0zLjVjMS45LDAsMy41LDEuMywzLjUsMy4zQzIwLjgsMjUuMSwyMC4yLDI2LjUsMTkuMiwyNy4yCgkJCQkJCSBNMzIuNiwzNi4zYy0xLTAuMi0xLjYtMC42LTIuMS0xLjNjLTAuNC0wLjgtMC43LTIuMS0wLjctNC4zYzAuMS01LDAtOS4xLDAtMTAuNGMwLTAuMSwwLjEtMC4yLDAuMS0wLjMKCQkJCQkJYzAuNC0wLjEsMS40LTAuMSwxLjktMC4zYzAuOC0yLjgsMC40LTcuMywwLjItMTAuM2MtMS44LDAuMS00LjgtMC4xLTcuMSwwLjFjMCwwLTAuOC0yLjEtMS43LTMuM2MwLDAsMC0wLjEsMC0wLjEKCQkJCQkJYy0wLjEtMC4xLTAuMS0wLjEtMC4yLTAuMmMtMC4yLTAuMi0wLjMtMC4zLTAuNS0wLjRjMCwwLDAsMCwwLDBjLTMuOS0zLjItMTIuMS0xLjctMTIuMyw0LjFjLTEuOC0wLjEtNC45LTAuMy03LDAKCQkJCQkJQzMuMyw5LjgsMy4zLDEwLDMuMywxMC4zYy0wLjIsMi4yLTAuNiw4LjQtMC4yLDkuNWwyLjMsMGwwLjIsMGwwLjQsMTIuNGMtMC4yLDItMC45LDMuNy0yLjksMy45YzAuMywzLjQtMC43LDcuNCwwLjMsMTAuMQoJCQkJCQlsNC45LDQuMWwwLDBjMC4xLDAuMSwwLjMsMC4yLDAuNSwwLjNjMC4yLDAuMiw1LjEsMi44LDcuMSwzLjljMC41LDAuNCwxLjEsMC42LDEuOCwwLjVjMCwwLDAuMSwwLDAuMSwwYzAsMCwwLDAsMCwwCgkJCQkJCWMwLjktMC4yLDItMC44LDMuNS0yLjJjMC4zLTAuMywwLjctMC42LDEuMS0wLjhjMi4xLTEuMiw1LjktMS42LDYuOS0yLjVjMS4yLTEsMy4yLTAuNywzLjMtNS4xdjAKCQkJCQkJQzMzLjIsNDEuNywzMi44LDM4LjYsMzIuNiwzNi4zIi8+CgkJCQk8L2c+CgkJCTwvZz4KCQk8L2c+Cgk8L2c+CjwvZz4KPC9zdmc+Cg=='
  }
};
