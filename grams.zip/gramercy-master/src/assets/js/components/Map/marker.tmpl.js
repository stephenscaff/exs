
/**
 * Marker Template
 * @param {obj} data - property data/json
 */
function markerTmpl(data) {
  let ftWine = data.featured_wine ? `<span class="marker-box__link"><span class="marker-box__label">Featured Wine</span> <a " href="${data.featured_wine_url}">${data.featured_wine}</a></span>` : "";

  return `<article class="marker-box">
    <div class="marker-box__main">
      <span class="marker-box__name">${data.name}</span>
      <p class="marker-box__description">${data.description}</p>
      <span>${ftWine}</span>
    </div>
  </article>`;
}

export default markerTmpl;
