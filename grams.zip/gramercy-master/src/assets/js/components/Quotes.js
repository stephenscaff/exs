import Siema from '../components/Siema'

if (document.querySelector('.js-quotes')) {

  /**
   * Quote Slider using Siema Slider
   */
   const QuotesSlider = new Siema({
   selector: '.js-quotes',
   duration: 200,
   easing: 'ease-out',
   perPage: 1,
   startIndex: 0,
   draggable: true,
   threshold: 20,
   loop: true,
   onInit: () => {},
   onChange: () => {}
 })

  const prev = document.querySelector('.js-quote-prev');
  const next = document.querySelector('.js-quote-next');

  prev.addEventListener('click', () => QuotesSlider.prev());
  next.addEventListener('click', () => QuotesSlider.next());

  document.addEventListener('keydown', (e) => {

    if (e.keyCode === 37) {
      QuotesSlider.prev()
    }

    else if (e.keyCode === 39) {
      QuotesSlider.next()
    }
  })
}
