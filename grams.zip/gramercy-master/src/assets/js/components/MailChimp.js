
/**
 * TM Form
 * Form sends submission to Tailor Mail api
 * @author Stephen Scaff
 */
var MCSignup  = (() => {

  var formEl = document.querySelector('#mc-signup');
  var formEl = document.querySelector('#mc-submit');
  var inputs = document.querySelectorAll('.js-input[required]');
  var loader = document.querySelector('.js-form-loader');
  var submitMessage = document.querySelector('.js-signup-message');
  var successMessage = document.querySelector('.js-success-message');
  var errorMessage = document.querySelector('.js-error-message');
  var errorClass = 'is-invalid';
  var isValid = false, isValidEmail = false;

  return {

    init: function() {
      if (!formEl) return;
      this.bindEvents();
    },

    /**
     * BindEVents
     * Kicks things off
     */
    bindEvents: function() {

      formEl.addEventListener('submit', function (e) {
        e.preventDefault();

        MCSubmit.validateForm();
      });
    },

    /**
     * ForEach Utility
     * Ensure we can loop over a object or nodelist
     * @see https://toddmotto.com/ditch-the-array-foreach-call-nodelist-hack/
     */
    forEach: function(array, callback, scope) {
      for (var i = 0; i < array.length; i++) {
        callback.call(scope, i, array[i]);
      }
    },

    /**
     * Validate Form
     */
    validateForm: function() {
      var emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
      var emailField = formEl["email"];
      var requiredInputs = document.querySelectorAll('[required]');

      inputs.forEach((input) => {

        if (input.value == "") {
          input.classList.add('is-invalid');
          isValid = false;
          window.scroll({top: 0, left: 0, behavior: 'smooth' });
          return;
        }
        else {
          input.classList.remove('is-invalid')
          isValid = true;
        }
      });

      // Validate Email
      if (!emailField.value.match(emailFormat)) {
        emailField.classList.add('is-invalid');
        isValidEmail = false;
      }
      else {
        emailField.classList.remove('is-invalid');
        isValidEmail = true;
      }

      if (isValid && isValidEmail) {
        MCSubmit.startSubmit();
      }
    },

    /**
     * Get Form Data
     * Process formData for post request as Tailor Mail API
     * is super finicky about formating.
     * @param object formData - formData object
     * @return object json
     */
    getFormData: function(formData) {
      var json = {};
      for (item of formData.keys()){
        json[item] = formData.get(item);
      }

      return json;
    },

    /**
     * Get Checks
     * Returns prop7 checks as comma seperated string
     * @return string
     */
  	getChecks: function(){
  		var array = []
      var checkboxes = document.querySelectorAll('input.check-prop7:checked')

      for (var i = 0; i < checkboxes.length; i++) {
        array.push(checkboxes[i].value)
		  }

      return array.join(',')
    },

    /**
     * Set Value
     * Helper to set value on a field
     * Calls HandleRequest()
     * @param element key
     * @param string val
     */
  	setValue: function(key, val) {
      key.value = val;
      MCSignup.handleRequest()
    },

    /**
     * Start Submit Process
     * Assigns prop7 checks to hidden field
     * Begins submit animation
     */
    startSubmit: function() {
      MCSignup.isSubmitting()
      MCSignup.handleRequest()
    },

    /**
     * Handle Request
     * Collected formData and posts to api via Fetch.
     */
    handleRequest: function() {

      var data = new FormData(formEl);
      var json = MCSignup.getFormData(data);
      console.log(json);

      fetch(apiURL, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic Mjc6MXN6YW9yN2U1OQ==',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(json),
      })
      .then(function (response) {
        console.log('response', response.ok)

        if (response.ok == true) {
          return MCSignup.onSuccess();
        }
        else {
          return MCSignup.onError(error);
        }
      }).catch(function (error) {
        return MCSignup.onError(error);
      });
    },

    /**
     * Show Loader UI
     */
    isSubmitting: function() {
      formEl.classList.add('is-submitting');
      loader.classList.remove('is-hidden');
    },

    /**
     * Handle Success State
     */
    onSuccess: function(response) {
      setTimeout(() => {
        successMessage.classList.remove('is-hidden');
        loader.classList.add('is-hidden');
        formEl.reset();
        console.log('success!');
      }, 900);
    },

    /**
     * Handle Error State
     */
    onError: function(error) {
      setTimeout(() => {
        errorMessage.classList.remove('is-hidden');
        loader.classList.add('is-hidden');
        console.log('error!!!')
      }, 900);
    },
  }
})();

MCSignup.init();
