import MenuSmall from '../../components/MenuSmall.js'
import HashTabs from '../../components/HashTabs.js'
import * as Map from '../../components/Map/index.js'

export default function Inits() {

HashTabs.init()

  if ( document.querySelector('.js-location-map') ) {
    Map.LocationMap('.js-location-map')
  }
}
