/**
 * Handle SEO Metas
 */
export default function Seo(to, location) {
  [].forEach.call(to.page.head.childNodes, node => {
    switch (node['nodeName']) {
      case 'META':
        if (node.hasAttribute('property'))
            document.querySelector(
              `meta[property="${node.getAttribute('property')}"]`
            ).setAttribute(
              'content', node['content']
            )
        if (node.hasAttribute('name'))
          document.querySelector(
            `meta[name="${node.getAttribute('name')}"]`
          ).setAttribute(
            'content', node["content"]
          )
        break
      case 'LINK':
        if (node.hasAttribute('rel') && 'canonical' === node.getAttribute('rel'))
          document.querySelector(
            `link[rel="${node.getAttribute('rel')}"]`
          ).setAttribute(
            'href', node.getAttribute('href')
          )
        break
      default: break
    }
  })
}
