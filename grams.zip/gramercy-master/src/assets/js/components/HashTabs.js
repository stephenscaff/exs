import Utils from '../components/Utils'

/**
 * HashTabs
 * @param {object} options
 */
function HashTabs (options) {
  options = Utils.extend(options, HashTabs.options);

  this.classActive = options.classActive
  this.classData   = options.classData
  this.classNav    = options.classNav
  this.dataDefault = options.dataDefault;
  this.dataId      = options.dataId;
  this.dataPair    = options.dataPair;
}

/**
 * HashTabs Methods
 */
HashTabs.prototype = {

  constructor : HashTabs,

  /**
   * Init
   */
  init(){
    this.setIDs(this.options)
    this.setActiveTab(this.options, this.getHash())

    window.onhashchange = () => {
      this.setActiveTab(this.options, this.getHash())
    }
    return true
  },

  /**
   * Get Hash
   */
  getHash() {
    // get hash from window location and remove # character
    let hash = String(window.location.hash.replace('#', ''))
    let hashVal = false

    if (hash.length !== 0) {
      // split it to array of parameters by "=" and "&"
      hashVal = hash.split(/\=|&/)
    }
    return hashVal
  },

  /**
   * Set IDs
   * @param {object} options
   */
  setIDs(options) {
    let a, b, c, d
    let tabId
    let tabDefault
    let tabName
    let navList
    let navLiChildren
    let dataList
    let tabs = document.querySelectorAll(`.${this.classNav}`)

    // loop through every instance of hashtab (nav)
    for (let a = 0; a < tabs.length; a += 1) {
      // get current tab id and default tab
      tabId = tabs[a].getAttribute(this.dataId)
      tabDefault = '0'
      tabName = ''

      // check if -default html data is set
      if (tabs[a].getAttribute(this.dataDefault)) {
        tabDefault = tabs[a].getAttribute(this.dataDefault)
      }

      // loop through every nav element of current tab
      navList = tabs[a].querySelectorAll(`.${this.classNav} > li`)

      for (b = 0; b < navList.length; b += 1) {
        // set current item name to loop index
        // or custom -pair name if given
        tabName = String(b)

        if (navList[b].getAttribute(this.dataPair)) {
          tabName = navList[b].getAttribute(this.dataPair)
        }

        // loop through all child nodes of li
        // check for the first a node and add #link to it
        navLiChildren = navList[b].childNodes

        for (let c = 0; c < navLiChildren.length; c += 1) {
          if (navLiChildren[c].nodeName === 'A') {
            navLiChildren[c].setAttribute('href', `#${tabId}=${tabName}`)
          }
        }

        // set default to active
        if (tabName === tabDefault) {
          this.show(navList[b])
        }
      }

      // Set First To Active
      if (navList[0]) {
        this.show(navList[0])
      }

      // find corresponding data element and loop through its children
      dataList = document.querySelectorAll(`.${this.classData}[${this.dataId} = ${tabId}] > li`);

      for (let d = 0; d < dataList.length; d += 1) {
        // set current item name to loop index
        // or custom -pair name if given
        tabName = String(d);

        if (dataList[d].getAttribute(this.dataPair)) {
          tabName = dataList[d].getAttribute(this.dataPair)
        }
        // set default to active
        if (tabName === tabDefault) {
          this.show(dataList[d])
        }
      }
      // Set First To Active
      if (dataList[0]) {
        this.show(dataList[0])
      }
    }
    return true;
  },

  /**
   * Set Active Tab
   * @param {object} options
   * @param {array} hashArray
   */
  setActiveTab(options, hashArray) {
    let a, b, c;
    let parameter
    let value
    let tabName
    let tabNavList
    let tabDataList

    // loop through all hash parameters (every second item)
    for (a = 0; a < hashArray.length; a += 2) {

      // set the parameter and value
      parameter = hashArray[a]
      value = hashArray[a + 1]
      tabName = ''

      // check if hashlink exists in nav element
      if (document.querySelectorAll(
        `.${this.classNav} a[href*="#${parameter}=${value}"]`
      ).length > 0) {
        // get the current tab nav and data lists
        tabNavList = document.querySelectorAll(
          `.${this.classNav}[${this.dataId}="${parameter}"] > li`
        )
        tabDataList = document.querySelectorAll(
          `.${this.classData}[${this.dataId}="${parameter}"] > li`
        )

        // clear active class of all nav elements and give it to the target one
        for (let b = 0; b < tabNavList.length; b += 1) {
          // set current item name to loop index
          // or custom -pair name if given
          tabName = String(b)

          if (tabNavList[b].getAttribute(this.dataPair)) {
            tabName = tabNavList[b].getAttribute(this.dataPair)
          }

          if (tabName === value) {
            this.show(tabNavList[b])
          } else {
            this.hide(tabNavList[b])
          }
        }

        // clear active class of all data elements and give it to the target one
        for (let c = 0; c < tabDataList.length; c += 1) {
          // set current item name to loop index
          // or custom -pair name if given
          tabName = String(c);

          if (tabDataList[c].getAttribute(this.dataPair)) {
            tabName = tabDataList[c].getAttribute(this.dataPair)
          }
          // change classes
          if (tabName === value) {
            this.show(tabDataList[c])
          } else {
            this.hide(tabDataList[c])
          }
        }
      }
    }
    return true;
  },

  /**
   * Show
   * Helper to add active state to el
   * @param {element} el
   */
  show(el) {
    el.classList.add(this.classActive)
  },

  /**
   * Hide
   * Helper to remove active state from el
   * @param {element} el
   */
  hide(el) {
    el.classList.remove(this.classActive)
  }
}


/**
 * Default options
 * @type {Object}
 */
HashTabs.options = {
  classActive: 'is-active',
  classData:   'hashtabs-data',
  classNav:    'hashtabs-nav',
  dataDefault: 'data-hashtabs-default',
  dataId:      'data-hashtabs-id',
  dataPair:    'data-hashtabs-pair'
}

export default new HashTabs();
