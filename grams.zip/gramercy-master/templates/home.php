<?php
/**
 * Template Name: Home
 *
 * @author    Stephen Scaff
 * @package   page
 * @version   2.0.0
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>

<main class="app-main has-header-offset">
  <?php //get_template_part( 'views/shared/mast' ); ?>
  <?php get_template_part( 'views/shared/modules' ); ?>
</main>

<?php get_footer(); ?>
