<?php
/**
 * Template Name: Trade
 * Template for Trade and Distributors
 *
 * @author  Stephen Scaff
 * @package jumpoff/shine
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

?>

<main class="app-main has-header-offset">
  <!-- Trade Bottles Section -->
  <section class="trade-tabs">
    <div class="grid-lg">
      <header class="trade-tabs__header">
        <h2 class="trade-tabs__title">Trade</h2>
      </header>
      <nav class="trade-tabs__nav">
        <ol class="hashtabs-nav" data-hashtabs-id="trade">
          <li class="hashtabs-nav__tab" data-hashtabs-pair="current-releases">
            <a class="trade-tabs__link btn-line" href="current-releases">Current Releases</a>
          </li>
          <li class="hashtabs-nav__tab" data-hashtabs-pair="previous-vintages">
            <a class="trade-tabs__link btn-line" href="previous-vintages">Previous Vintages</a>
          </li>
        </ol>
      </nav>
      <hr class="sep is-full no-mar" />
      <section class="trade-tabs__main">
        <ol class="hashtabs-data"  data-hashtabs-id="trade">
          <!-- Tab Item -->
          <li class="hashtabs-data__tab trade-cards__grid" data-hashtabs-pair="current-releases">
          <?php
          $args = array (
            'post_type'       => 'trade',
            'posts_per_page'  => -1,
            'tax_query'       => array(
              array(
                'taxonomy'    => 'trade_status',
                'field'       => 'slug',
                'terms'       => 'current-release',
                'operator'    => 'IN',
              )
            )
          );
          $currents = get_posts($args);
          foreach ( $currents as $post ) : setup_postdata( $post );
            include(locate_template('views/shared/trade-card.php'));
          endforeach; wp_reset_postdata(); ?>
          </li>

          <!-- Tab Item -->
          <li class="hashtabs-data__tab trade-cards__grid" data-hashtabs-pair="previous-vintages">
          <?php
          $args = array (
            'post_type'       => 'trade',
            'posts_per_page'  => -1,
            'tax_query'       => array(
              array(
                'taxonomy'    => 'trade_status',
                'field'       => 'slug',
                'terms'       => 'previous-vintage',
                'operator'    => 'IN',
              )
            )
          );
          $prevs = get_posts($args);
          foreach ( $prevs as $post ) : setup_postdata( $post );
            include(locate_template('views/shared/trade-card.php'));
          endforeach; wp_reset_postdata(); ?>
          </li>
        </ol>
      </section>
    </div>
  </section>

  <!-- Distributors Section -->
  <section class="trade-tabs">
    <div class="grid-lg">
      <header class="trade-tabs__header">
        <h2 class="trade-tabs__title">Distributors</h2>
      </header>
      <nav class="trade-tabs__nav">
        <!-- Tab Nav -->
        <ol class="hashtabs-nav" data-hashtabs-id="location">
          <li class="hashtabs-nav__tab" data-hashtabs-pair="united-states">
            <a class="trade-tabs__link btn-line" href="us">United States</a>
          </li>
          <li class="hashtabs-nav__tab" data-hashtabs-pair="international">
            <a class="trade-tabs__link btn-line" href="international">International</a>
          </li>
        </ol>
      </nav>
      <hr class="sep is-full no-mar" />
      <section class="trade-tabs__main">
        <ol class="hashtabs-data" data-hashtabs-id="location">
          <!-- Tab Item -->
          <li class="menu-tabs__item distributor-card__grid" data-hashtabs-pair="united-states">
              <?php
              $args = array (
                'post_type'       => 'distributors',
                'posts_per_page'  => -1,
                'tax_query'       => array(
                  array(
                    'taxonomy'    => 'location',
                    'field'       => 'slug',
                    'terms'       => 'united-states',
                    'operator'    => 'IN',
                  )
                )
              );
              $currents = get_posts($args);
              foreach ( $currents as $post ) : setup_postdata( $post );
                include(locate_template('views/shared/distributor-card.php'));
              endforeach; wp_reset_postdata(); ?>
          </li>

          <!-- Tab Item -->
          <li class="menu-tabs__item distributor-card__grid" data-hashtabs-pair="international">
            <?php
            $args = array (
              'post_type'       => 'distributors',
              'posts_per_page'  => -1,
              'tax_query'       => array(
                array(
                  'taxonomy'    => 'location',
                  'field'       => 'slug',
                  'terms'       => 'international',
                  'operator'    => 'IN',
                )
              )
            );
            $prevs = get_posts($args);
            foreach ( $prevs as $post ) : setup_postdata( $post );
              include(locate_template('views/shared/distributor-card.php'));
            endforeach; wp_reset_postdata(); ?>
          </li>
        </ol>
      </section>
    </div>
  </section>
</main>

<?php get_footer(); ?>
