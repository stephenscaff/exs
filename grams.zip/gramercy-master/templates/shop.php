<?php
/**
 * Template Name: Shop
 * Template for menu / fare
 *
 * @author  Stephen Scaff
 * @package jumpoff/gramercy
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

$view = $_GET['view'];
$view_class = "is-${view}";

// Redirect to shop if view is empty
if ((!isset($_GET['view']) OR $_GET['view'] == '')) {
  $shop_url = get_page_url('shop') . '?view=products&slug=current-releases';
  header ("Location: $shop_url");
}

get_header();


?>
<main class="app-main has-header-offset <?php echo $view_class; ?>">
  <div data-ecp-wrapper="true"></div>
</main>

<?php get_footer(); ?>
