<?php
/**
 * Template Name: Products
 * Template for menu / fare
 *
 * @author  Stephen Scaff
 * @package jumpoff/gramercy
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$view = $_GET['view'];
$view_class = "is-${view}";

?>
<main class="app-main has-header-offset <?php echo $view_class; ?> ">
  <div data-ecp-wrapper="true" class="ecp-wrapper"></div>
</main>

<?php get_footer(); ?>
