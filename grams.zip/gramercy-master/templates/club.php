<?php
/**
 * Template Name: Club
 *
 * @author      Karlie Watts
 * @subpackage  template
 */

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$club_title           = get_field('club_title');
$club_info            = get_field('club_info');
$club_email           = get_field('club_email', 'options');
$ecellars_signup      = get_field('sign_up', 'options');
$ecellars_email       = get_field('mailing_list', 'options');
$ecellars_new_account = get_field('new_account', 'options');
$ecellars_signin      = get_field('sign_in', 'options');

?>


<main class="club app-main has-header-offset">
  <div class="grid-lg">

    <section class="club-intro">
      <h1 class="club-intro__title"><?php echo $club_title; ?></h1>
      <p class="club-intro__info"><?php echo $club_info; ?></p>
    </section>

    <div class="sep is-full is-white"></div>

    <section class="club-tiers grid">
      <div class="club-tiers__grid">

        <?
        while ( have_rows('club_tier') ): the_row();
          $title  = get_sub_field('tier_title');
          $detail = get_sub_field('tier_detail');
          $link   = get_sub_field('tier_link');
        ?>
        <article class="club-tiers__item">
          <h2 class="club-tiers__title"><?php echo $title; ?></h2>
          <ul>
            <p class="club-tiers__excerpt"><?php echo format_lines($detail); ?></p>
          </ul>
          <div class="club-tiers__btn">
            <a class="btn-block is-white" href="<?php echo $link; ?>">Join Now</a>
          </div>
        </article>
        <?php endwhile; ?>

    </section>

    <div class="sep is-full is-white"></div>

    <section class="ctas is-white">
        <div class="ctas__grid">
          <div class="ctas-item__first">

            <article class="ctas__block">
              <span class="mark"><?php echo get_svg('line'); ?></span>
              <h2 class="ctas-item__title">Existing Members</h2>
              <a class="btn-block has-white-border" href="<?php echo $ecellars_signin; ?>">
                <span class="btn-block__btn btn-line is-white">Login</span>
                <span class="btn-block__arrow"><?php echo get_svg('right-arrow'); ?></span>
              </a>
            </article>
          </div>
          <div class="ctas-item__second">
            <article class="ctas__block">
              <span class="mark"><?php echo get_svg('line'); ?></span>
              <h2 class="ctas-item__title">More information</h2>
              <a class="btn-block has-white-border" href="mailto:<?php echo $club_email; ?>">
                <span class="btn-block__btn btn-line is-white"><?php echo $club_email; ?></span>
                <span class="btn-block__arrow"><?php echo get_svg('right-arrow'); ?></span>
              </a>
            </article>
          </div>
          <div class="ctas-item__third">
            <article class="ctas-item__block">
              <span class="mark"><?php echo get_svg('line'); ?></span>
              <h2 class="ctas-item__title">Stay informed</h2>
              <p class="ctas-item__excerpt">Get info on upcoming events, releases and behind-the-scenes dirt.</p>
              <a class="btn-block has-white-border" href="<?php echo $ecellars_email; ?>">
                <span class="btn-block__btn btn-line is-white">Join our newsletter</span>
                <span class="btn-block__arrow"><?php echo get_svg('right-arrow'); ?></span>
              </a>
            </article>

          </div>
        </div>
      </section>

    </div>
    <div class="club__footer"><?php get_footer(); ?></div>
</main>
