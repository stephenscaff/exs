<?php

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *  Post Type: Distributors
 *
 *  Slug :      Distributors
 *  Supports : 'title','thumbnail','editor'
 *
 *  @version    1.0
 *  @author     karlie watts
 */

add_action( 'init', function() {
 $type = 'distributors';

 // Call the function and save it to $labels
 $labels = set_post_type_labels('Distributor', 'Distributors');

 $args = [
   'public'             => true,
   'description'        => 'Gramercy Cellars Distributors',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 3,
   'menu_dashicon'      => 'dashicons-id',
   'menu_icon'          => 'dashicons-id',
   'query_var'          => true,
   'supports'           => array( 'title'),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => false,
   'publicly_queryable'  => false
 ];
 register_post_type( $type, $args);
});

/**
 * Distributor Location
 */
add_action( 'init', function() {
  $tax = 'location';
  $type = array('distributors');

  // Call the function and save it to $labels
  $labels = set_post_type_labels('Location', 'Location');

  $args = [
      'description'        => 'Location',
      'labels'             => $labels,
      'hierarchical'        => true,
      'show_ui'             => true,
      'show_admin_column'   => true,
      'show_in_quick_edit'  => true,
  ];
  register_taxonomy( $tax, $type, $args);
});
