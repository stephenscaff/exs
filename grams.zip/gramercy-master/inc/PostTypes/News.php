<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 *   News Post Type
 */

 $dl_fields = new StoutLogic\AcfBuilder\FieldsBuilder('downloader');


 $dl_fields
   ->addText('dl_title', [
     'label' => 'Download Name',
   ])
   ->addFile('dl_file', [
     'label' => 'Download PDF',
   ])
   ->setLocation('post_type', '==', 'post');
 add_action('acf/init', function() use ($dl_fields) {
    acf_add_local_field_group($dl_fields->build());
 });
