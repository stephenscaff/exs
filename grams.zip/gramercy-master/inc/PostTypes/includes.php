<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Flush Rewrites
 */
add_action( 'after_switch_theme', 'jumpoff_flush_rewrite_rules' );

function jumpoff_flush_rewrite_rules() {
  flush_rewrite_rules();
}

require_once('Trade.php');
require_once('Distributors.php');
require_once('News.php');
