<?php

namespace Jumpoff;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 *  Post Type: Trade
 *
 *  Slug :      Trade
 *  Supports : 'title','thumbnail','editor'
 *
 *  @version    1.0
 *  @author     karlie watts
 */

add_action( 'init', function() {
 $type = 'trade';

 // Call the function and save it to $labels
 $labels = set_post_type_labels('Trade', 'Trade');

 $args = [
   'public'             => true,
   'description'        => 'Trade Sheets',
   'labels'             => $labels,
   'show_ui'            => true,
   'menu_position'      => 3,
   'menu_dashicon'      => 'dashicons-welcome-add-page',
   'menu_icon'          => 'dashicons-welcome-add-page',
   'query_var'          => true,
   'supports'           => array( 'title'),
   'capability_type'    => 'post',
   'can_export'         => true,
   'has_archive'        => false,
   'publicly_queryable'  => false,
 ];
 register_post_type( $type, $args);
});

/**
 * Trade Status
 */
add_action( 'init', function() {
  $tax = 'trade_status';
  $type = array('trade');

  // Call the function and save it to $labels
  $labels = set_post_type_labels('Trade Status', 'Trade Status');

  $args = [
      'description'        => 'Trade Status',
      'labels'             => $labels,
      'hierarchical'        => true,
      'show_ui'             => true,
      'show_admin_column'   => true,
      'show_in_quick_edit'  => true,
  ];
  register_taxonomy( $tax, $type, $args);
});
