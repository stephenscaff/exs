<?php

if ( ! defined( 'ABSPATH' ) ) exit;

# Add Featured Images to API
require_once('ApiAdditions.php');
