<?php

/**
 * Bugherd JS
 * Adds the bugherd js to the footer
 */
add_action ( 'wp_footer', function() {
?>
<?php
});
