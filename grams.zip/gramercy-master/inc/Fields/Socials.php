<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Check for Options Page capabilities
 */
 if ( function_exists('acf_add_options_page') ) {

/**
 * Contacts Fields
 */
$socials = new StoutLogic\AcfBuilder\FieldsBuilder('socials');

$socials

  ->addMessage('Socials', '')
  ->addText('socials_youtube',
    [
      'wrapper' =>  ['width' => '50%']
    ]
  )
  ->addText('socials_instagram',
    [
      'wrapper' =>  ['width' => '50%']
    ]
  )
  ->addText('socials_twitter',
    [
      'wrapper' =>  ['width' => '50%']
    ]
  )
  ->addText('socials_facebook',
    [
      'wrapper' =>  ['width' => '50%']
    ]
  )

  ->setLocation('options_page', '==', 'socials');

  add_action('acf/init', function() use ($socials) {
     acf_add_local_field_group($socials->build());
  });
}
