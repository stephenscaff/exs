<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Check for Options Page capabilities
 */
 if ( function_exists('acf_add_options_page') ) {

/**
 * Contacts Fields
 */
$ecellars = new StoutLogic\AcfBuilder\FieldsBuilder('ecellars');

$ecellars
  ->addText('sign_up',
    [
      'label'         => 'Join our Club',
      'wrapper'       =>  ['width' => '50%']
    ]
  )
  ->addText('sign_in',
    [
      'label'         => 'Sign in to existing account',
      'wrapper'       =>  ['width' => '50%']
    ]
  )
  ->addText('new_account',
    [
      'label'         => 'Create an Account',
      'wrapper'       =>  ['width' => '50%']
    ]
  )
  ->addText('all_products',
    [
      'label'         => 'View all products',
      'wrapper'       =>  ['width' => '50%']
    ]
  )
  ->addText('view_cart',
    [
      'label'         => 'View Cart',
      'wrapper'       =>  ['width' => '50%']
    ]
  )
  ->addText('mailing_list',
    [
      'label'         => 'Join our Mailinglist',
      'wrapper'       =>  ['width' => '50%']
    ]
  )
  ->setLocation('options_page', '==', 'ecellars');

  add_action('acf/init', function() use ($ecellars) {
     acf_add_local_field_group($ecellars->build());
  });
}
