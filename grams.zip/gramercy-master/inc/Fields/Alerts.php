<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Alerts
 */
$alerts = new StoutLogic\AcfBuilder\FieldsBuilder('alerts');

$alerts
  ->addText('alert_message', [
    'label'   =>   'Optional Alert Message'
  ])
  ->addPageLink('alert_link', [
    'allow_null'  => 'true',
    'label'       =>   'Alert Link (internal)',
    'post_type'	  => array('page'),
  ])
  ->setLocation('options_page', '==', 'alerts');

add_action('acf/init', function() use ($alerts) {
   acf_add_local_field_group($alerts->build());
});
