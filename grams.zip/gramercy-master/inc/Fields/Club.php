<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 *   Club Fields
 *   For mastheads and stuff.
 */

$club_fields = new StoutLogic\AcfBuilder\FieldsBuilder('club', [
  'key'        => 'group_mast',
  'position'   => 'acf_after_title',
  'menu_order' => '1',
]);;


$club_fields

  ->addWysiwyg('club_info',
    [
      'tabs' => 'visual',
      'media_upload' => 0,
      'delay' => 0
    ]
  )
  ->addRepeater('club_tier', [
    'button_label' => 'Add Club Tier',
    'layout' => 'block',
  ])
  ->addText('tier_title')
  ->addTextArea('tier_detail')
  ->addText('tier_link')
  ->endRepeater()


  ->setLocation('page_template', '==', 'templates/club.php');

add_action('acf/init', function() use ($club_fields) {
   acf_add_local_field_group($club_fields->build());
});
