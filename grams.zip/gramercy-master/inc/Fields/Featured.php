<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 *  Featured News/Post
 */
 $message_label = "Select a Post to Feature";
 $message_text = "If nothing is selected here, the latest or dragged to the top post will be featured.";

 /**
  * Featured Community Post on Community
  */
 $featured_post = new StoutLogic\AcfBuilder\FieldsBuilder('featured', [
   'key' => 'group_featured',
   'position' => 'normal',
   'menu_order' => '1',
 ]);
 $featured_post
   ->addMessage($message_label, $message_text)
   ->addRelationship('featured_post_select',  [
    'post_type' =>  array('post'),
    'filters' => array('search', '', ''),
    'max'  => 1,
   ])
   ->setLocation('options_page', '==', 'posts-index');

 add_action('acf/init', function() use ($featured_post) {
   acf_add_local_field_group($featured_post->build());
 });
