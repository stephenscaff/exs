<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 *   Distributor Post Type
 */

$distributor = new StoutLogic\AcfBuilder\FieldsBuilder('distributor');


$distributor
  ->addText('distributor_location')
  ->addText('distributor_phone', [
    'wrapper' =>  ['width' => '50%']
  ])
  ->addText('distributor_email' , [
    'wrapper' =>  ['width' => '50%']
  ])
  ->setLocation('post_type', '==', 'distributors');

add_action('acf/init', function() use ($distributor) {
   acf_add_local_field_group($distributor->build());
});
