<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Check for Options Page capabilities
 */
 if ( function_exists('acf_add_options_page') ) {

/**
 * Contacts Fields
 */
$shop = new StoutLogic\AcfBuilder\FieldsBuilder('shop');

$shop
->addText('mast_title')
->addImage('mast_image')
->setLocation('options_page', '==', 'shop_options');

  add_action('acf/init', function() use ($shop) {
     acf_add_local_field_group($shop->build());
  });
}
