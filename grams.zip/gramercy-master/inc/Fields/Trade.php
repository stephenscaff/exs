<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 *   Trade
 *   Trade Post Type
 */

$trade = new StoutLogic\AcfBuilder\FieldsBuilder('trade');


$trade
  ->addText('trade_location')
  ->addTextArea('trade_description',
    ['rows' =>  '3']
  )
  ->addImage('trade_thumb', [
    'label' => 'Trade thumbnail <br/><span>Size to 1250x1500</span>',
    'wrapper' =>  ['width' => '33%']
  ])
  ->addFile('tech_sheet', [
    'label'   => 'Tech Sheet',
    'wrapper' =>  ['width' => '33%']

  ])
  ->addFile('bottle_shot', [
    'label'   => 'Bio PDF',
    'wrapper' =>  ['width' => '33%']

  ])
  ->setLocation('post_type', '==', 'trade');

add_action('acf/init', function() use ($trade) {
   acf_add_local_field_group($trade->build());
});
