<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Check for Options Page capabilities
 */
 if ( function_exists('acf_add_options_page') ) {

/**
 * Contacts Fields
 */
$hours = new StoutLogic\AcfBuilder\FieldsBuilder('hours');

$hours

  ->addRepeater('hour_items', [
    'min' => 1,
    'button_label' => 'Add Hour Item',
    'layout' => 'block',
  ])
  ->addText('hour_detail')
  ->endRepeater()
  ->addText('disclaimer')
  ->setLocation('options_page', '==', 'hours');

  add_action('acf/init', function() use ($hours) {
     acf_add_local_field_group($hours->build());
  });
}
