<?php
/**
 * Modules
 */
if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;


/**
 * Modules (primary)
 */
$modules= new FieldsBuilder('modules', [
  'key'        => 'group_modules',
  'menu_order' => '2',
]);

$modules
  ->addFlexibleContent('modules',
    ['button_label'=> 'Add Module']
  )
  ->addLayout($card_block_module,
    ['name'=> 'card_block_module']
  )
  ->addLayout($contact_module,
    ['name'=> 'contact_module']
  )
  ->addLayout($content_module,
    ['name'=> 'content_module']
  )
  ->addLayout($cta_module,
    ['name'=> 'cta_module']
  )
  ->addLayout($hours_module,
    ['name'=> 'hours_module']
  )
  ->addLayout($intro_module,
    ['name'=> 'intro_module']
  )
  ->addLayout($mast_module,
    ['name'=> 'mast_module']
  )
  ->addLayout($map_module,
    ['name'=> 'map_module']
  )
  ->addLayout($news_module,
    ['name'=> 'news_module']
  )
  ->addLayout($team_module,
    ['name'=> 'team_module']
  )
  ->addLayout($quotes_module,
    ['name'=> 'quotes_module']
  )
  ->setLocation('page_template', '==', 'templates/modules.php')
           ->or('page_template', '==', 'templates/home.php')
           ->or('options_page', '==', 'posts-index');

  add_action('acf/init', function() use ($modules) {
     acf_add_local_field_group($modules->build());
  });


/**
 * Fare / Menu Modules
 */
  $fare_modules= new FieldsBuilder('fare_modules', [
    'key'        => 'group_fare_modules',
    'menu_order' => '1',
  ]);

  $fare_modules
    ->addFlexibleContent('modules',
      ['button_label'=> 'Add Module']
    )
    ->addLayout($fare_section_module,
      ['name'=> 'fare_section_module']
    )
    ->setLocation('post_type', '==', 'fare');

    add_action('acf/init', function() use ($fare_modules) {
      acf_add_local_field_group($fare_modules->build());
    });
