<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Card Block Module
 * @see views/modules/card-block-module.php
 * @see scss/components/_card-blocks.scss
 */
$card_block_module = new FieldsBuilder('card_block_module');
$card_block_module
  ->addMessage('', 'The Card Block Module creates Large Card Block element with image, content and link')
  ->addFields($module_shift)
  ->addImage('image')
  ->addText('title')
  ->addTextArea('content')
  ->addSelect('store_link', [
    'label' => 'eCellars Store Link',
    'allow_null' => 1
  ])
    ->addChoice('sign_up', 'Join our Club')
    ->addChoice('sign_in', 'Sign in to existing account')
    ->addChoice('new_account', 'Create an Account')
    ->addChoice('all_products', 'View all products')
    ->addChoice('view_cart', 'View Cart')
    ->addChoice('mailing_list', 'Join our Mailinglist')
  ->addFields($button);
