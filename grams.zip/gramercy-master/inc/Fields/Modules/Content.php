<?php

if ( ! defined( 'ABSPATH' ) ) exit;


use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Content Module
 * Creates an content / wysi section
 * @see scss/components/_content (post-content)
 */
$content_module = new FieldsBuilder('content_module');
$content_module
  ->addMessage('', 'The Content Module creates an all purpose content/wysi region.')
  ->addText('title')
  ->addWysiwyg('content',
    [
      'tabs' => 'visual',
      'toolbar' => 'simple',
      'media_upload' => 0,
      'delay' => 0
    ]
  );
