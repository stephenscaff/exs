<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * News Module
 * @see views/modules/news-module.php
 * @see scss/components/_news.scss
 */
$news_module = new FieldsBuilder('news_module');
$news_module
  ->addMessage('', 'The News Module calls the latest news stories created from the News Content Type.');
