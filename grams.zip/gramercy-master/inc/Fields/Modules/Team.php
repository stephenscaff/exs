<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Teams Module
 * @see views/modules/team-module.php
 * @see scss/components/_teams.scss
 */
$team_module = new FieldsBuilder('team_module');
$team_module
  ->addMessage('', 'The Team Module calls the team members created from the Team Content Type.');
