<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/* CTA Module
 * @see views/modules/cta-module.php
 * @see scss/components/_cta.scss
 */

$cta_module = new FieldsBuilder('cta_module');
$cta_module
  ->addMessage('', 'The CTA Module creates a CTA block.')
  ->addText('cta_title')
  ->addText('cta_text')
  ->addSelect('store_link', [
    'allow_null' => 1
  ])
    ->addChoice('sign_up', 'Join our Club')
    ->addChoice('sign_in', 'Sign in to existing account')
    ->addChoice('new_account', 'Create an Account')
    ->addChoice('all_products', 'View all products')
    ->addChoice('view_cart', 'View Cart')
    ->addChoice('mailing_list', 'Join our Mailinglist')
  ->addFields($button);
