<?php

if ( ! defined( 'ABSPATH' ) ) exit;


use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Intro Module
 * Creates an intro section with link
 * @see scss/components/_intro (post-content)
 */
$intro_module = new FieldsBuilder('intro_module');
$intro_module
  ->addMessage('', 'The Intro Module creates an content section with optional link element.')
  ->addFields($module_shift)
  ->addText('title')
  ->addWysiwyg('content',
    [
      'tabs' => 'visual',
      'toolbar' => 'simple',
      'media_upload' => 0,
      'delay' => 0
    ]
  )
  ->addFields($button);
