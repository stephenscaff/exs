<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Contacts Module
 * @see views/modules/contacts-module.php
 * @see scss/components/_contacts.scss
 */
$hours_module = new FieldsBuilder('hours_module');
$hours_module
  ->addMessage('', 'The Hours Module calls info created from the Global Settings.');
