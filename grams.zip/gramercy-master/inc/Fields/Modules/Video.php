<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Videos Module
 * @see views/modules/videos-module.php
 * @see scss/components/_videos.scss
 */
$video_module = new FieldsBuilder('video_module');
$video_module
  ->addMessage('', 'The Video Module creates a Video Element on the page.')
  ->addText('vimeo_id',
    ['wrapper' => ['width' => '50%']])
  ->addText('youtube_id',
    ['wrapper' => ['width' => '50%']])
  ->addText('video_caption');
