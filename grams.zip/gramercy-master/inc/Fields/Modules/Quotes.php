<?php

if ( ! defined( 'ABSPATH' ) ) exit;


use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Content Module
 * Creates an content / wysi section
 * @see scss/components/_content (post-content)
 */
$quotes_module = new FieldsBuilder('quotes_module');
$quotes_module
  ->addRepeater('quotes', [
    'min' => 1,
    'button_label' => 'Add Quote',
    'layout' => 'block',
  ])
  ->addTextArea('quote_content')
  ->addText('author')
  ->endRepeater();
