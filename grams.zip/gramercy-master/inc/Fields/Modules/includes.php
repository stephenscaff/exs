<?php

if ( ! defined( 'ABSPATH' ) ) exit;

require_once('Mast.php');
require_once('Intro.php');
require_once('Contact.php');
require_once('Content.php');
require_once('CardBlock.php');
require_once('Cta.php');
require_once('Hours.php');
require_once('Team.php');
require_once('Map.php');
require_once('News.php');
require_once('Quotes.php');
