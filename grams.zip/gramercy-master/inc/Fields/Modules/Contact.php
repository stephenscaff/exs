<?php

if ( ! defined( 'ABSPATH' ) ) exit;

use StoutLogic\AcfBuilder\FieldsBuilder;

/**
 * Contacts Module
 * @see views/modules/contacts-module.php
 * @see scss/components/_contacts.scss
 */
$contact_module = new FieldsBuilder('contact_module');
$contact_module
  ->addMessage('', 'The Contact Module calls the info created from the Global Settings.');
