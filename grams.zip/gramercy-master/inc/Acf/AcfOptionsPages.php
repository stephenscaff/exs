<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Create Global Elements Menu Item
 */
if( function_exists('acf_add_options_page') ) {

 	# Site Globals (Parent)
	$site_globals = acf_add_options_page(array(
		'page_title' 	=> 'Site Globals',
		'menu_title' 	=> 'Site Globals',
		'icon_url'		=> 'dashicons-marker',
		'redirect' 		=> true
	));

	# Contacts
	$page_contacts = acf_add_options_sub_page(array(
    'page_title'  => 'Contacts & Info',
    'menu_title'  => 'Contacts',
    'menu_slug'   => 'contacts',
    'position'    =>  '1',
		'parent_slug' 	=> $site_globals['menu_slug'],
	));

	# Socials
	$page_socials = acf_add_options_sub_page(array(
		'page_title'  => 'Socials',
		'menu_title'  => 'Socials',
		'menu_slug'   => 'socials',
		'position'    =>  '2',
		'parent_slug' 	=> $site_globals['menu_slug'],
	));

	# Hours
	$page_hours = acf_add_options_sub_page(array(
		'page_title'  => 'Hours',
		'menu_title'  => 'Hours',
		'menu_slug'   => 'hours',
		'position'    =>  '3',
		'parent_slug' 	=> $site_globals['menu_slug'],
	));

	# eCellars
	$ecellars = acf_add_options_page(array(
		'page_title'  => 'eCellars',
		'menu_title'  => 'eCellars',
		'menu_slug'   => 'ecellars',
		'position'    =>  '4',
		'parent_slug' 	=> $site_globals['menu_slug'],
	));

	# JS Tracking
	$page_tracking_scripts = acf_add_options_page(array(
		'page_title'  => 'Tracking Scripts',
		'menu_title'  => 'Tracking Scripts',
		'menu_slug'   => 'tracking',
		'position'    =>  '6',
		'parent_slug' 	=> $site_globals['menu_slug'],
	));



	# Site Globals (Parent)
	$shop_options = acf_add_options_page(array(
		'page_title' 	=> 'Shop Options',
		'menu_title' 	=> 'Shop Options',
		'menu_slug'   => 'shop_options',
		'icon_url'		=> 'dashicons-marker',
		'redirect' 		=> true
	));
}
